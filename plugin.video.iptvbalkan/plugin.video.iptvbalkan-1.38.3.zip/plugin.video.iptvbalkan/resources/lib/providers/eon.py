# -*- coding: utf-8 -*-
"""
EON (United Cloud) — ported from the IptvBox Android client, where this exact flow is in daily use
against a live account.

The chain is four steps and each one fails differently, so each one reports differently:

  1. client-credentials token from the broker   -> proves we can reach EON at all
  2. brands + cdninfo                           -> resolves which API host this brand lives on
  3. device registration (once per install)     -> yields the device number the account counts
  4. password grant                             -> yields the access token, stream key and stream user

Playback is not a URL the API hands over. The API returns a publishing point, a profile and a server,
and the client BUILDS the URL and signs it with AES-CBC using the account's own stream key. That is why
this cannot be a generic M3U: every tune is minted locally and expires.

The User-Agent matters more here than anywhere else in this addon. EON's stream edge keeps a UA
blocklist — the public Kodi addon's compiled-in string is on it, which is why that addon plays nothing
while its login still works. The default below is the real web client's; when EON blocks it too, change
it in settings and press play. No rebuild.

Every field name below was read off THIS account's live responses, not inferred from the endpoint names.
That distinction is not academic: the first draft of this file assumed `images` was an object with a
`logo` key (it is a list), `logicalChannelNumber` carried the channel number (the field does not exist —
numbering lives in the category layout), `timeshiftEnabled` marked the archive (it is `cutvEnabled`), and
`publishingPoints` was the play descriptor (it is `publishingPoint`, and it is an array). Login and the
HTTP layer were fine; the catalogue was written against a shape EON does not serve.
"""

import base64
import gzip
import hashlib
import io
import json
import os
import threading
import time

try:
    from urllib.parse import quote
except ImportError:                                                # pragma: no cover
    from urllib import quote
import uuid

from .. import aes, diag, localserver, net
from ..i18n import T
from ..provider import Provider, ProviderError, register

BROKER = "https://broker.global.united.cloud/"
CLIENT_ID = "b8d9ade4-1093-46a7-a4f7-0e47be463c10"
CLIENT_SECRET = "1w4dmww87x1e9l89essqvc81pidrqsa0li1rva23"
API_PREFIX = "web"
PLAYER_LIVE = "m3u8"
#: EON's VOD player string, used by _resolve_vod. Per POOL, like the signature beside it: signing a
#: Video klub URL with the live player string produces a URL the edge rejects.
PLAYER_VOD = "fm3u8vcbcs"
#: Connection type in the signed blob. The web client reports BROWSER and the edge echoes it back in its
#: session accounting; sending anything else is an easy way to look like a client EON does not ship.
CONN_TYPE = "BROWSER"
#: The two query params the official web client appends to EVERY /stream request. EON's LIVE edge now
#: REQUIRES them — without them it answers 403 "Nonexisting timeshift stream" instead of the 302 that
#: hands off to a delivery edge, which is what broke live tuning while replay kept working.
STREAM_LANG = "eng"
STREAM_NOFPS_INFO = "false"

# Brand order as the official client lists them; the CDN identifier is resolved from v2/brands at run
# time, so this index is the only thing the user has to pick.
#: The brand names live in resources/settings.xml, which is what the user actually picks from;
#: this list is here so the two can be compared when the broker changes its own order.
BRANDS = ["EON TV (RS)", "EON TV (BA)", "EON TV (ME)", "EON TV (MK)", "EON TV (SI)"]

#: Radio stations start here. `v2/categories/TV` numbers only the TV pool, so the radio pool has no
#: provider numbering of its own and falls back to its position in the list — which starts at 1 and
#: collides head-on with RTS 1. Two channels sharing a number is not cosmetic in IPTV Simple: the second
#: one is the one you cannot reach by typing its number. Raised automatically if a TV channel ever sits
#: above it (EON's own positions currently top out in the 600s).
RADIO_NUMBER_BASE = 1000

#: What a channel gets when it says it HAS an archive but not how long one (`cutvEnabled` true with no
#: usable `cutvDelay`). Seven days is what every channel on the accounts seen so far reports.
#:
#: This constant was referenced before it existed — the fallback line raised NameError instead of using
#: it, which would have failed the whole EON channel list with "0 channels" rather than one channel with
#: a short archive. It never fired here because this account fills `cutvDelay` on every channel, so no
#: test and no live run could reach it; pyflakes found it, which is why it now runs over the addon.
CATCHUP_DAYS_DEFAULT = 7
#: Consecutive guide failures before the pass gives up. Three, like Move's: one failure is
#: a channel, three in a row is the network or the account, and neither is fixed by asking
#: another 298 times.
_GUIDE_GIVE_UP = 3

#: Per-channel play descriptors, cached beside the playlist. Resolving a tune needs four values off the
#: channel list, and that list is half a megabyte — refetching it at every zap would put a visible delay
#: in front of every channel change. The catalogue refresh already has the data, so it writes it here and
#: the play route reads it; a miss (channel added since the last refresh) still falls back to a live fetch.
CTIME_CACHE = "eon_ctime.json"
PLAY_CACHE = "eon_play.json"


def _category_param(category_id):
    """`categoryId=<n>`, or nothing at all. Kept in one place because the same string has to be appended
    to the listing call and to the "is there another page" probe, and a filter applied to one but not the
    other produces a "next page" row that opens somebody else's titles."""
    return ("&categoryId=%s" % category_id) if category_id else ""

#: Video klub paging. A catalogue runs to a few hundred titles; the page cap is a stop, not a target.
VOD_PAGE_SIZE = 50
VOD_MAX_PAGES = 40
#: Pages fetched before the screen is handed over, with a "next page" row for the rest.
#:
#: Measured on the real box: HBO OD is 1,263 titles, and fetching all of it took 34 requests and
#: SEVENTEEN SECONDS of spinner before a single row appeared — for a list nobody scrolls to the end of.
#: Four pages is 200 titles in about two seconds, which is a screen that opens.
VOD_PAGE_BATCH = 4



#: Where the last guide is kept, so the next refresh can ask only for what it does not already have.
GUIDE_CACHE = "eon_guide.json.gz"
#: Everything from two hours ago onward is ALWAYS asked for again. That covers the programme playing
#: now (its end time moves when sport runs over) and the whole of the next day, which is the window in
#: which a schedule change still matters to somebody.
GUIDE_FRESH_BACK_MS = 2 * 3600 * 1000
GUIDE_FRESH_FORWARD_MS = 26 * 3600 * 1000
#: Older than this and the cache is dropped whole rather than merged. A box that has been off for days
#: has a guide full of holes, and stitching a fresh window onto it would leave those holes in place.
GUIDE_CACHE_MAX_AGE = 3 * 86400


#: How many channel ids go into one guide request. Settable so a box can be told to stop (1 = one
#: channel per request, the way every version before 1.38.3 worked) without waiting for a release.
GUIDE_BATCH_DEFAULT = 20


def _events_of(data, ref):
    """
    The events out of one guide answer.

    THE RESPONSE IS AN OBJECT KEYED BY THE REQUESTED CHANNEL ID — not the flat array the endpoint's name
    suggests. Iterating it as a list walks the key string and yields nothing, which is indistinguishable
    from "this channel has no programmes". Written once here because two places now read these answers:
    the prefetch, which concatenates several ranges, and the loop that turns them into guide rows.
    """
    if isinstance(data, dict):
        return data.get(str(ref)) or data.get("content") or []
    return data or []


class _Prefetch(object):
    """
    A few guide requests kept one step ahead of the loop that consumes them.

    Deliberately NOT a thread pool over the whole channel list. It holds a window of at most [workers]
    requests, hands each result to whoever asks for that channel, and refills as the window drains — so
    a caller that stops early (budget spent, Kodi closing, a token that died) leaves at most that many
    requests in flight and nothing else is ever issued.

    An exception raised by a worker is stored and re-raised in [take], on the consuming thread, at the
    point the sequential code would have hit it. That is what lets every rule in `epg()` — the auth
    retry, the give-up counter, the budget — stay exactly where it was and keep working unchanged.
    """

    def __init__(self, session, auth, api, start, end, workers, ranges_for=None):
        self.session = session
        self.auth = dict(auth)
        self.api = api
        self.start, self.end = start, end
        self.workers = workers
        #: ref -> [(from_ms, to_ms), …]. One range is the ordinary case; two happen on a daily refresh
        #: (the near window plus the day that has just rolled into view), and a channel with nothing on
        #: disk gets the single full window. Defaults to the whole window for everybody, which is what
        #: this class did before there was a cache at all.
        self.ranges_for = ranges_for or (lambda _ref: [(start, end)])
        self._queue = []
        self._results = {}
        self._pending = {}
        self._lock = threading.Lock()
        self._threads = []
        #: Requests actually in the air. Counted rather than derived from the thread list: a thread is
        #: appended before it is started and `is_alive()` is False in that gap, so counting threads
        #: schedules more work than asked for — and counting `_pending` counts answers that have
        #: arrived but not yet been collected, which schedules less.
        self._inflight = 0

    def feed(self, refs):
        self._queue = list(refs)
        self._fill()

    def _fill(self):
        """
        Start requests until [workers] are in the air. Safe to call from any thread.

        WHY THAT MATTERS, measured on the owner's box. This was called only from the consuming thread,
        at the end of take() — and take() waits for ONE named channel, in list order. So while the
        slowest of the four answers was outstanding, the three workers that had already finished sat
        idle: nothing could start until the consumer got past the channel it was blocked on. The number
        actually in the air sawtoothed between four and one, averaging about two, which is exactly what
        the log showed — 189 requests at 3.0 s each finished in 259 s, an effective concurrency of 2.2
        rather than 4.

        Topping up from the worker that has just finished keeps all four busy. The "only after a
        success" rule is unchanged and still lives at the call sites: a failure leaves the queue where
        it is, so a box that has lost its network still gives up after three refusals instead of
        sixteen.
        """
        while True:
            with self._lock:
                if not self._queue or self._inflight >= self.workers:
                    return
                # AND NEVER MORE THAN THIS FAR AHEAD OF THE CONSUMER. Topping up from the worker keeps
                # the link busy while take() is blocked on one slow channel — but with nothing else
                # holding it back, a fast answer starts the next request immediately and the whole
                # 302-channel queue drains before the consuming loop has looked at the first result.
                # That quietly undoes two rules the loop depends on: a token that dies at channel five
                # would already have been used on all 302, and "give up after three failures" would
                # have paid for three hundred requests before the third failure was noticed.
                #
                # Twice the worker count is the compromise: enough buffered work that a slow channel
                # never leaves the others idle, little enough that a mid-guide refusal costs at most
                # eight wasted requests instead of three hundred.
                if self._inflight + len(self._results) >= self.workers * 2:
                    return
                ref = self._queue.pop(0)
                event = threading.Event()
                self._pending[ref] = event
                self._inflight += 1
                thread = threading.Thread(target=self._fetch, args=(ref, event))
                thread.daemon = True             # never hold Kodi's shutdown on a guide request
                self._threads.append(thread)
            thread.start()

    def _fetch(self, ref, event):
        try:
            # The ranges are fetched in order and their event lists CONCATENATED, so everything above
            # this line and everything that consumes take() sees exactly what it saw when there was one
            # request: the channel's events. Two small requests move far less than one big one when the
            # link is the limit, which it is — see the note in epg().
            merged, data = [], None
            for begin, finish in self.ranges_for(ref):
                answer = self.session.get(
                    self.api + "v1/events/epg?cid=%s&fromTime=%d&toTime=%d" % (ref, begin, finish),
                    headers=self.auth)
                merged.extend(_events_of(answer, ref))
                data = answer
            outcome = (merged if len(self.ranges_for(ref)) != 1 else data, None)
        except Exception as err:                                   # noqa: BLE001 - re-raised in take()
            outcome = (None, err)
        with self._lock:
            self._results[ref] = outcome
            self._inflight -= 1
        event.set()
        # The next request starts HERE, on the worker that has just freed a slot — see _fill. Only
        # after a success, for the reason spelled out in take(): running ahead into a failure is how
        # three refusals became sixteen.
        if outcome[1] is None:
            self._fill()

    def take(self, ref):
        """This channel's body, waiting for it if the worker has not finished. Raises whatever the
        worker caught, on this thread, exactly where the sequential code would have raised it."""
        with self._lock:
            event = self._pending.get(ref)
        if event is None:                        # never queued (a channel list that changed under us)
            merged = []
            for begin, finish in self.ranges_for(ref):
                merged.extend(_events_of(self.session.get(
                    self.api + "v1/events/epg?cid=%s&fromTime=%d&toTime=%d" % (ref, begin, finish),
                    headers=self.auth), ref))
            return merged
        event.wait()
        with self._lock:
            data, err = self._results.pop(ref, (None, None))
            self._pending.pop(ref, None)
        with self._lock:
            self._threads = [t for t in self._threads if t.is_alive()]
        # REFILL ONLY AFTER A SUCCESS. Running ahead is worth it while the answers are good; the moment
        # one comes back an error, the loop above is about to decide something — re-login, give up,
        # stop — and prefetching into that decision is how "three hundred identical failures in a log
        # nobody can read" comes back in a new shape. Measured with the offline stub: refilling
        # regardless turned a give-up after three failures into sixteen requests; this keeps it at the
        # window that was already in the air.
        if err is None:
            self._fill()
        if err is not None:
            raise err
        return data

    def renew(self, auth):
        """A new token, and nothing half-fetched with the old one."""
        self.auth = dict(auth)
        with self._lock:
            stale = [ref for ref in self._pending]
            self._results.clear()
        # Anything already in flight will finish and be discarded; those channels go back in the queue
        # so the loop still gets them, now with the token that works.
        for ref in stale:
            with self._lock:
                self._pending.pop(ref, None)
        self._queue = stale + self._queue
        self._threads = [t for t in self._threads if t.is_alive()]
        self._fill()


@register
class EonProvider(Provider):

    key = "eon"
    label = "EON"
    supports_vod = True
    supports_search = True
    default_identity = {
        # Deliberately the CURRENT web client's string, not a device-flavoured one. A UA shared with
        # millions of real EON web viewers cannot be blocklisted without blocking their own customers,
        # which is exactly the property the old Chrome/116 addon string did not have.
        "user_agent": ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                       "(KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36"),
        "origin": "https://eon.tv",
        "referer": "https://eon.tv/",
        "accept_language": "en-US,en;q=0.9",
    }
    # Device descriptors sent at registration. Separate from the UA on purpose: the live client proves
    # these two do NOT have to agree (it registers as linux/chrome while sending a Windows UA), so
    # exposing them separately lets us match the official client field by field if it ever changes.
    DEVICE_TYPE = "web_linux_chrome"
    DEVICE_MODEL = "Chrome 116"
    DEVICE_PLATFORM = "web"
    SYSTEM_SW_NAME = "Linux"
    SYSTEM_SW_VERSION = "x86_64"

    def __init__(self, settings):
        Provider.__init__(self, settings)
        self.session = net.Session(self.identity(), trace=settings.verbose())
        self.api = None
        self.images = None
        #: DRM host and Widevine licence endpoint, both filled at login. Every Video klub title is
        #: Widevine-protected, so without these the store lists fine and plays nothing.
        self.entitlement = ""
        self.widevine_url = ""
        #: Measured offset between EON's clock and this device's — see [_ctime].
        self._ctime_offset = None
        self._ctime_at = 0.0
        self.token = None
        self.stream_key = None
        self.stream_un = None
        self.service_provider = None
        self.device_number = None
        self.servers = []
        self.timeshift_servers = []
        #: The Video klub's own pool. Falls back to the live one when a provider exposes none, because
        #: an empty pool would otherwise make the whole store unplayable — the live hosts answer the
        #: same /stream API.
        self.vod_servers = []
        #: rendering profile id -> {"core_stream_id", "video_bitrate"}; picks the bitrate ladder rung
        self.profiles = {}

    # ---- auth -------------------------------------------------------------

    def _basic(self):
        raw = ("%s:%s" % (CLIENT_ID, CLIENT_SECRET)).encode("ascii")
        return "Basic " + base64.b64encode(raw).decode("ascii")

    def _generic_token(self):
        data = self.session.post(BROKER + "oauth/token?grant_type=client_credentials",
                                 headers={"Authorization": self._basic()})
        token = data.get("access_token")
        if not token:
            raise ProviderError("EON refused the client credentials — the addon's built-in client id "
                                "may have been rotated by the provider.")
        return token

    #: Which regional entry point of a CDN to use. The live web client uses "be"; "af31" is the other
    #: published one. Exposed as a constant because it is exactly the sort of value a provider changes.
    API_SELECTOR = "be"

    def _resolve_api(self, generic):
        """
        Which API host serves this account.

        Resolved rather than hardcoded, and written against what the broker actually returns:
        `v2/brands` gives each brand a `cdnIdentifier`, and the matching entry in `v1/cdninfo` holds
        `domains.baseApi` — which is a map keyed by REGION ("be", "af31"), not an object with a
        `domain` field. Getting that wrong is what made every login fail with "no API host": the
        lookup returned None for a response that was perfectly healthy.

        Every ex-Yu brand (SBB, Telemach, TelemachHR, TelemachSI) shares one CDN, so the brand choice
        barely moves this — which is why an unknown index falls back to the CDN the broker itself
        marks as default instead of failing.
        """
        auth = {"Authorization": "bearer " + generic}
        cdns = self.session.get(BROKER + "v1/cdninfo", headers=auth) or []
        brands = self.session.get(BROKER + "v2/brands", headers=auth) or []

        index = self.settings.get_int("eon_brand", 0)
        wanted = ""
        if 0 <= index < len(brands):
            wanted = (brands[index] or {}).get("cdnIdentifier", "")
        chosen = next((c for c in cdns if c.get("identifier") == wanted), None)
        if chosen is None:
            chosen = next((c for c in cdns if c.get("isDefault")), None) or (cdns[0] if cdns else None)
            if chosen is not None:
                diag.log("EON: brand %s has no CDN of its own; using the default (%s)"
                         % (index, chosen.get("identifier")))
        if chosen is None:
            raise ProviderError("EON: the broker returned no CDN information at all.")

        base_map = ((chosen.get("domains") or {}).get("baseApi") or {})
        base = base_map.get(self.API_SELECTOR) or next(iter(base_map.values()), "")
        if not base:
            raise ProviderError("EON: CDN '%s' publishes no API host." % chosen.get("identifier"))
        return "https://api-%s.%s/" % (API_PREFIX, base), base

    def _device_number(self, generic):
        """
        The one value EON's password grant calls `device_number` — a single field, not two.

        This was modelled wrongly at first as a serial we mint plus a number EON assigns back. The
        Android client, which has worked against this account for months, has ONE Device ID field: left
        blank it registers and fills itself in, and filled in it is simply sent. Splitting it into two
        concepts here meant an account that already had its device registered still went and registered
        another one — which on a subscription capped at three devices is not a harmless mistake. It cost
        this account a slot before the difference was noticed.

        So: a configured id is used as-is and nothing is registered. Registration happens only when the
        field is empty AND the user has asked for it, because on a full account it cannot succeed and
        the honest answer is to say so rather than burn the attempt.
        """
        configured = self.setting("device_id").strip()
        if configured:
            return configured

        if not self.settings.get_bool("eon_register_new_device", False):
            raise ProviderError(
                "EON: no Device ID set. Copy the Device ID from a device where this account "
                "(Settings -> Sources -> EON) so this install shares the same device slot. "
                "If you genuinely have a free slot, enable 'Register a new device' in settings.")

        payload = json.dumps({
            "deviceName": "",
            "deviceType": self.DEVICE_TYPE,
            "modelName": self.DEVICE_MODEL,
            "platform": self.DEVICE_PLATFORM,
            "serial": str(uuid.uuid4()),
            "clientSwVersion": "",
            "systemSwVersion": {"name": self.SYSTEM_SW_NAME, "version": self.SYSTEM_SW_VERSION},
        })
        data = self.session.post(self.api + "v1/devices", body=payload,
                                 headers={"Authorization": "bearer " + generic})
        number = str(data.get("deviceNumber") or "")
        if not number:
            raise ProviderError("EON accepted the device registration but returned no device number.")
        # Written straight back, and the toggle is cleared: registering twice is the failure mode this
        # whole method exists to prevent.
        self.remember("device_id", number)
        self.remember("register_new_device", "false")
        diag.log("EON: registered a new device (%s). It now occupies one of this subscription's slots."
                 % number)
        return number

    def _password_login(self, generic, device_number):
        username = self.setting("username")
        password = self.setting("password")
        if not username or not password:
            raise ProviderError("EON: enter your username and password in settings.")
        # The username is sent as an uppercase SHA-256 hex digest, exactly as the web client does; the
        # password is sent as typed. Sending the raw username is rejected.
        user_hash = hashlib.sha256(username.encode("utf-8")).hexdigest().upper()
        boundary = "----WebKitFormBoundary2VHeBtQPpnSo3SjK"

        def field(name, value):
            return ("--%s\r\nContent-Disposition: form-data; name=\"%s\"\r\n\r\n%s\r\n"
                    % (boundary, name, value))

        # `device_number`, not `deviceNumber`: EON answers the camelCase spelling with
        # {"error":"invalid_device","devMessage":"Device is required"} even though the device was
        # registered seconds earlier. The failure reads like an account problem and is purely a name.
        body = (field("username", user_hash) + field("password", password)
                + field("device_number", device_number) + "--%s--\r\n" % boundary)
        try:
            data = self.session.post(
                self.api + "oauth/token?grant_type=password",
                body=body.encode("utf-8"),
                headers={"Authorization": self._basic(),
                         "Content-Type": "multipart/form-data; boundary=" + boundary},
            )
        except net.HttpError as err:
            if err.status in (400, 401):
                raise ProviderError("EON refused the login — check the username and password, and that "
                                    "the subscription is active.")
            raise
        token = data.get("access_token")
        if not token:
            raise ProviderError("EON returned no access token for this account.")
        # snake_case, like every other field in this response — `streamKey`/`streamUn` (which this file
        # read at first, borrowed from the Android port's own naming) simply do not exist here, and
        # `.get()` handed back an empty string that only failed much later, as a 0-byte AES key at the
        # first tune. The key is 22 base64url characters = the 16 bytes the cipher wants.
        stream_key = data.get("stream_key") or ""
        stream_un = data.get("stream_un") or ""
        if not stream_key or not stream_un:
            raise ProviderError("EON logged in but issued no stream key — this account cannot mint "
                                "playable URLs (an inactive or streaming-less subscription).")
        # `expires_in` decides how long the session cache may be trusted; absent, the cache falls back to
        # its own conservative ceiling rather than assuming the token is long-lived.
        return token, stream_key, stream_un, data.get("expires_in")

    #: What a cached login is allowed to skip, and for how long. EON's password grant reports its own
    #: `expires_in` (hours), but the cache is capped well below that: the cost of an over-long cache is a
    #: tune that fails with a stale token, and the cost of a short one is a login the user never notices.
    SESSION_CACHE = "eon-session.json"
    SESSION_MAX_AGE = 3600

    def _session_cache_path(self):
        return self.cache_path(self.SESSION_CACHE)

    def _load_session(self, probe=True):
        """
        Restore the last login instead of repeating it.

        Every plugin call is its own Python process, so before this each playback paid a full seven-request
        login chain — token, cdninfo, brands, password grant, sp, servers, rndprofiles — before the first
        byte of video. The phone's log shows that costing 1.3–2.5 seconds in front of every single tune,
        ten times in three minutes while the user was trying the archive. Nothing in that chain changes
        between tunes.
        """
        try:
            with io.open(self._session_cache_path(), "r", encoding="utf-8") as handle:
                data = json.loads(handle.read())
        except (OSError, IOError, ValueError):
            return False
        if not isinstance(data, dict) or time.time() >= (data.get("expires_at") or 0):
            return False
        # Bound to the account it was minted for. Without this check, changing the username in settings
        # would keep playing the previous subscription's channels until the cache happened to expire.
        if data.get("account") != self._account_fingerprint():
            return False
        try:
            self.api = data["api"]
            self.images = data["images"]
            self.entitlement = data.get("entitlement") or ""
            self.device_number = data["device_number"]
            self.token = data["token"]
            self.stream_key = data["stream_key"]
            self.stream_un = data["stream_un"]
            self.service_provider = data["service_provider"]
            self.widevine_url = data.get("widevine_url") or ""
            self.servers = data["servers"]
            self.timeshift_servers = data["timeshift_servers"]
            self.vod_servers = data["vod_servers"]
            # JSON keys are strings; the profile lookup indexes by int (see _resolve_live).
            self.profiles = dict((int(k), v) for k, v in (data["profiles"] or {}).items())
        except (KeyError, TypeError, ValueError):
            return False
        if not (self.token and self.stream_key and self.profiles):
            return False
        # One cheap call to prove the token is still alive, because the alternative is worse than the
        # 35ms it costs. MEASURED against the live API: `v1/time` answers 200 to a garbage token, so the
        # catch-up path cannot detect a dead session at all (it mints a URL the edge later refuses with
        # no error anywhere in our code) — while `v1/sp` answers 401 in ~35ms against ~1500ms for the full
        # login chain. Without this check a stale cached token reaches `channels()`, which turns a 401
        # into an EMPTY channel list, and an empty line-up for one provider is written over that
        # provider's real one. Cheap insurance against a silent wipe.
        #
        # NOT ON THE TUNE PATH, though, and that is the whole of [probe]. The insurance is against a
        # silent wipe of the CATALOGUE; a tune has no catalogue to wipe, and it already carries its own
        # answer to a dead token — `mint()` below catches an auth refusal, logs in again and retries.
        # So paying 35 ms and a round trip in front of every channel change buys a check that the next
        # line of code performs for free. With the play descriptor cached and the clock offset stored,
        # this leaves a live tune with NO network call of its own before the stream.
        if not probe:
            return True
        try:
            sp = self.session.get(self.api + "v1/sp", headers={"Authorization": "bearer " + self.token})
        except net.HttpError as err:
            if err.is_auth:
                return False
            # No status at all means the network is down, not that the session is bad. A full login would
            # fail too, so keep what we have and let the real call report the outage.
            return True
        self.service_provider = (sp or {}).get("identifier") or self.service_provider
        self.widevine_url = (sp or {}).get("licenseServerUrlWidewine") or self.widevine_url
        return True

    def _store_session(self, expires_in):
        ttl = min(int(expires_in or 0) or self.SESSION_MAX_AGE, self.SESSION_MAX_AGE)
        payload = {
            "account": self._account_fingerprint(),
            "expires_at": time.time() + ttl,
            "api": self.api, "images": self.images, "entitlement": self.entitlement,
            "device_number": self.device_number,
            "token": self.token, "stream_key": self.stream_key, "stream_un": self.stream_un,
            "service_provider": self.service_provider, "widevine_url": self.widevine_url,
            "servers": self.servers,
            "timeshift_servers": self.timeshift_servers, "vod_servers": self.vod_servers,
            "profiles": self.profiles,
        }
        try:
            with io.open(self._session_cache_path(), "w", encoding="utf-8") as handle:
                handle.write(json.dumps(payload, ensure_ascii=False))
        except (OSError, IOError, ValueError) as err:
            diag.log("EON: could not cache the session (%s)" % err)

    def _account_fingerprint(self):
        """Identifies the account WITHOUT storing the credentials a second time — the cache sits in the
        profile folder next to the log, and a password does not belong in it."""
        return hashlib.sha256(
            ("%s|%s" % (self.setting("username"), self.setting("password"))).encode("utf-8")
        ).hexdigest()[:16]

    def forget_session(self):
        """Drop the cached login. Called when the edge rejects a cached token — see [_resolve_live]."""
        self.token = ""
        try:
            os.remove(self._session_cache_path())
        except OSError:
            pass

    def login(self, force=False, probe=True):
        if not force and self._load_session(probe=probe):
            diag.log("EON: reusing the cached session (device %s, %d timeshift servers)"
                     % (self.device_number, len(self.timeshift_servers)))
            return
        generic = self._generic_token()
        self.api, base = self._resolve_api(generic)
        # Logos come back as bare paths ("/d9138754/…/logo_xl.png") on a sibling host of the API, built
        # off the same CDN domain. Without this prefix every channel would carry a relative path Kodi
        # cannot fetch, and the line-up would render with no artwork at all.
        self.images = "https://images-%s.%s/" % (API_PREFIX, base)
        # The DRM pre-authorization host, built from the same base as the API and the image host. Named
        # from the official web client's own requests rather than guessed.
        self.entitlement = "https://entitlement-%s.%s/" % (API_PREFIX, base)
        self.device_number = self._device_number(generic)
        self.token, self.stream_key, self.stream_un, expires_in = \
            self._password_login(generic, self.device_number)
        auth = {"Authorization": "bearer " + self.token}
        sp = self.session.get(self.api + "v1/sp", headers=auth) or {}
        # The signed stream URL carries the provider's IDENTIFIER ("sbb"), not its numeric id.
        self.service_provider = sp.get("identifier") or sp.get("id")
        # Spelled `licenseServerUrlWidewine` in the payload — the provider's own typo, not ours. Needed
        # because every Video klub title is Widevine-protected; see [_resolve_vod].
        self.widevine_url = sp.get("licenseServerUrlWidewine") or ""
        # v1/servers returns an OBJECT keyed by pool ("live_servers", "timeshift_servers"), not a flat
        # list with a type field on each entry. Iterating it as a list walks the KEYS, which is a string,
        # and the failure surfaces far from here as "'str' object has no attribute 'get'".
        servers = self.session.get(self.api + "v1/servers", headers=auth) or {}
        self.servers = [s for s in (servers.get("live_servers") or []) if s.get("hostname")]
        self.timeshift_servers = [s for s in (servers.get("timeshift_servers") or []) if s.get("hostname")]
        self.vod_servers = [s for s in (servers.get("vod_servers") or []) if s.get("hostname")]
        # The bitrate ladder. A channel lists profile IDS; the signed URL needs the profile's
        # `coreStreamId`, so without this map there is no way to name a rendering and nothing plays.
        self.profiles = {}
        for prof in self.session.get(self.api + "v1/rndprofiles", headers=auth) or []:
            pid = prof.get("id")
            if pid is not None:
                self.profiles[int(pid)] = {"core_stream_id": prof.get("coreStreamId") or "",
                                           "video_bitrate": int(prof.get("videoBitrate") or 0)}
        diag.log("EON: logged in (device %s, %d live servers, %d timeshift servers, %d profiles)"
                 % (self.device_number, len(self.servers), len(self.timeshift_servers), len(self.profiles)))
        # Only after everything above succeeded — caching a half-built login would serve a session with
        # no profiles or no servers, and both fail at the tune rather than here where the cause is plain.
        self._store_session(expires_in)

    #: How long a measured clock offset is trusted before it is taken again.
    CTIME_REFRESH_SECONDS = 600

    def _ctime(self, auth):
        """
        EON's server clock, in milliseconds, WITHOUT asking for it every time.

        The signed blob carries `ctime`, and this used to be a `v1/time` call per tune — about 170ms in
        front of every channel change, measured on the box, for a value that moves at exactly the rate
        of the local clock. Asking once and keeping the OFFSET gives the same number; it is re-measured
        every ten minutes so device clock drift can never accumulate into a signature EON rejects.

        AND IT ONLY HALF WORKED UNTIL 1.29.0, which is worth writing down because the shape recurs all
        over this addon: the offset lived on the instance, and the plugin process lives for exactly ONE
        tune. So "re-measured every ten minutes" was in practice "measured before every channel change"
        — the 170 ms was never actually saved outside a catalogue refresh. It is now kept in its own
        small file beside the playlist. Its own file rather than the session's: this is written when the
        measurement is taken, and rewriting the session there would also rewrite its expiry.

        Falls back to the live call if the measurement ever fails, because a tune with no ctime is a tune
        that does not play.
        """
        now = time.time() * 1000.0
        if self._ctime_offset is None:
            self._load_ctime()
        if self._ctime_offset is None or (now - self._ctime_at) > self.CTIME_REFRESH_SECONDS * 1000:
            try:
                served = int((self.session.get(self.api + "v1/time", headers=auth) or {}).get("time") or 0)
            except net.HttpError:
                served = 0
            if served:
                self._ctime_offset = served - now
                self._ctime_at = now
                self._save_ctime()
        if self._ctime_offset is None:
            return ""
        return str(int(now + self._ctime_offset))

    def _ctime_path(self):
        return self.cache_path(CTIME_CACHE)

    def _load_ctime(self):
        try:
            with io.open(self._ctime_path(), "r", encoding="utf-8") as handle:
                data = json.loads(handle.read())
            offset, at = float(data["offset"]), float(data["at"])
        except (OSError, IOError, ValueError, KeyError, TypeError):
            return
        # A stored offset from a box whose clock was later corrected would be wrong by exactly that
        # correction, so it is only trusted for as long as it would have been in memory.
        if (time.time() * 1000.0 - at) <= self.CTIME_REFRESH_SECONDS * 1000:
            self._ctime_offset, self._ctime_at = offset, at

    def _save_ctime(self):
        try:
            with io.open(self._ctime_path(), "w", encoding="utf-8") as handle:
                handle.write(json.dumps({"offset": self._ctime_offset, "at": self._ctime_at}))
        except (OSError, IOError, ValueError):
            pass

    def _auth(self):
        if not self.token:
            self.login()
        return {"Authorization": "bearer " + self.token}

    # ---- catalogue --------------------------------------------------------

    def _placements(self, auth):
        """
        Channel id -> (group names, channel number), from EON's own category layout.

        Two things come out of one endpoint, and conflating them is a trap worth naming. The category
        flagged `defaultList` ("All") holds EVERY channel and carries the provider's canonical NUMBERING
        in each entry's `position`. The themed categories ("Sports", "Movies", …) are the real groups.
        Take "All" as a group and every channel lands in a single group called All; ignore it and the
        line-up loses the numbering the official app shows. So: numbers from the default list, groups
        from the themed ones, walked in the provider's own `order`.

        A channel keeps EVERY themed category it belongs to, in the provider's own order — IPTV Simple
        reads `group-title` as a semicolon-separated list, so RTS 1 appears under both "HD" and "Local"
        just as it does in EON's own app. The Android client had to pick one winner because its Channel
        model carries a single group name; that limitation is not this one's.

        Best-effort throughout — a missing category map costs grouping, never the channel list.
        """
        try:
            raw = self.session.get(self.api + "v2/categories/TV", headers=auth) or []
        except net.HttpError as err:
            diag.log("EON: category map unavailable (%s); channels will be ungrouped" % err, "ERROR")
            return {}

        cats = []
        for cat in raw:
            name = (cat.get("name") or "").strip()
            entries = cat.get("channels")
            if not name or not isinstance(entries, list):
                continue
            cats.append((int(cat.get("order") or 0), name, bool(cat.get("defaultList")), entries))
        cats.sort(key=lambda c: c[0])

        numbers = {}
        for _order, _name, is_default, entries in cats:
            if not is_default:
                continue
            for entry in entries:
                cid = str(entry.get("id") or "")
                if cid and cid not in numbers:
                    numbers[cid] = int(entry.get("position") or 0)

        groups = {}
        for _order, name, is_default, entries in cats:
            if is_default:
                continue
            for entry in entries:
                cid = str(entry.get("id") or "")
                if not cid:
                    continue
                names = groups.setdefault(cid, [])
                if name not in names:
                    names.append(name)

        out = {}
        for cid, names in groups.items():
            out[cid] = (";".join(names), numbers.get(cid, 0))
        # A channel no themed category claims still deserves its provider number, so it is carried with
        # a blank group rather than dropped.
        for cid, number in numbers.items():
            out.setdefault(cid, ("", number))
        return out

    def channels(self):
        auth = self._auth()
        placements = self._placements(auth)

        out = []
        play_cache = {}
        # Read ONCE, not per channel: it is a file on the box's flash and this loop runs three hundred
        # times. It cannot change underneath us either — the token is minted on first use and kept.
        token = localserver.token(self.settings)
        # TV first, so the radio block can be placed above whatever numbers the TV pool actually used.
        radio_base = RADIO_NUMBER_BASE
        for kind, default_group in (("TV", ""), ("RADIO", "Radio")):
            if kind == "RADIO":
                radio_base = max(RADIO_NUMBER_BASE, max([c["number"] for c in out] or [0]) + 1)
            try:
                raw = self.session.get(self.api + "v3/channels?channelType=" + kind, headers=auth) or []
            except net.HttpError as err:
                diag.log("EON: %s channel list failed: %s" % (kind, err), "ERROR")
                continue
            unsubscribed = 0
            for index, ch in enumerate(raw):
                cid = str(ch.get("id") or "")
                if not cid:
                    continue
                # The list is the whole line-up, not this account's. Channels outside the subscription
                # come back with `subscribed: false` and an `errorMessage`, and carry no publishing
                # point at all — showing them would fill the guide with entries that cannot ever play.
                if not ch.get("subscribed"):
                    unsubscribed += 1
                    continue
                play = _play_descriptor(ch, kind)
                if play is None:
                    continue
                name = (ch.get("shortName") or ch.get("name") or "").strip() or ("Channel %s" % cid)
                group, number = placements.get(cid, (default_group, 0))
                if not group:
                    group = default_group
                if not number:
                    number = (radio_base + index) if kind == "RADIO" else (index + 1)
                # `cutvEnabled` + `cutvDelay` (milliseconds, 604800000 = 7 days on this account) is where
                # the archive window lives. `timeshiftEnabled`, which this file used to read, is not a
                # field EON serves — so every channel silently claimed a 7-day archive.
                catchup_days = 0
                # NO ARCHIVE ON RADIO — and this is not a matter of taste, it CRASHED KODI.
                #
                # EON advertises cutvEnabled on its audio stations too, so they carried catchup-days like
                # any TV channel. IPTV Simple then treats even a LIVE tune on such a channel as a catch-up
                # stream and hands ffmpegdirect a buffer window; ffmpegdirect opens the audio fine
                # ("Audio: aac (LC), 48000 Hz, stereo", decoder opened) and then immediately runs
                # SeekCatchupStream to buffer offset 0 — seven days back — and the process dies there.
                # Kodi disappears with no dialog, which is why this looked like "the radio just does not
                # work" rather than a crash.
                #
                # A TV channel survives the same path; a radio one does not. The stream shapes differ:
                # the loopback returns a MASTER playlist with bitrate variants for television and a bare
                # MEDIA playlist of three segments for audio, and the catch-up seek does not survive the
                # latter. Rewinding a radio station is not a feature anyone asked for, so the fix is to
                # stop claiming an archive rather than to chase a crash inside someone else's binary.
                if ch.get("cutvEnabled") and kind != "RADIO":
                    # `or 7` used to sit on the end of this and could never fire — max(1, …) is always
                    # at least 1 — so a channel that says it has an archive but does not say how long
                    # got ONE day instead of the seven the fallback was written for.
                    days = int((ch.get("cutvDelay") or 0) / 86400000)
                    catchup_days = days if days > 0 else CATCHUP_DAYS_DEFAULT
                # LIVE goes through the loopback server too, not only catch-up, and that pairing is
                # the whole reason archive seeking can work at all. IPTV Simple reads the inputstream
                # from the channel's #KODIPROP lines and uses it for both tunes; with live left on
                # `plugin://` it never chose ffmpegdirect, so the catch-up tune arrived with
                # `OpenStream() - Num Props: 0` — no format string, nothing to re-request on a seek.
                # Both on http, ffmpegdirect handles both and IPTV Simple hands it the catchup set.
                #
                # The plugin URL stays as the fallback for an install whose token could not be written:
                # that box loses seeking, not television.
                plugin_url = ("plugin://plugin.video.iptvbalkan/?action=play&provider=eon&id=%s%s"
                              % (cid, self._account_param()))
                # RADIO GOES STRAIGHT TO THE EDGE, NOT THROUGH THE REDIRECTOR — and this is what made a
                # station play for ten to forty seconds and then drop back to Kodi's home screen.
                #
                # Measured, both sides, on 2026-07-31. The signed URL 302s to a session on the edge. For
                # TELEVISION that session answers with a MASTER playlist, so the player takes a variant
                # address out of the body and reloads THAT, straight from the edge — our proxy is touched
                # once and never again. For RADIO the same session answers with a MEDIA playlist: three
                # segments, `MEDIA-SEQUENCE:0`, no `ENDLIST`. The player therefore reloads the playlist
                # it was given — ours — and every one of our answers is a NEWLY SIGNED session starting
                # again at sequence 0. A live playlist whose sequence never advances is a playlist that
                # has ended, and Kodi says so in one line: `PAPlayer::ProcessStream - Stream Finished`.
                #
                # The proxy exists for seeking inside an archive, and radio has no archive here (see the
                # note above), so it buys a station nothing and costs it the stream. Handed the signed
                # URL instead, the player follows the 302 once and reloads the EDGE's own rolling
                # playlist, which is what every other client does.
                if kind == "RADIO":
                    url = plugin_url
                else:
                    url = (localserver.url_for(token, self.key, cid, self.account_id)
                           if token else plugin_url)
                entry = {
                    "id": self.scoped("eon_%s" % cid),
                    "provider": self.key,
                    "provider_label": self.label,
                    "provider_ref": cid,
                    "name": name,
                    "tvg_id": "eon_%s" % cid,
                    "number": number,
                    "logo": self._logo(ch),
                    "group": group,
                    # WHICH LIST A STATION LIVES IN DECIDES WHICH PLAYER PLAYS IT, and that is the
                    # whole of this line. A channel marked radio goes to Kodi's audio player, which
                    # ENDS the stream when a station changes its sample rate in the middle — measured
                    # on Radio Studio B: dead after thirty seconds as radio, alive after three minutes
                    # as television, same URL, same minute, while the edge's playlist rolled forward
                    # normally throughout. Four stations in five never change rate, which is why this
                    # looked random for weeks.
                    #
                    # So the default is television: it works on all 65. `radio_in_radio_list` puts them
                    # back under Kodi's Radio section for anyone who wants them there and can live with
                    # the dropouts — the setting says so in as many words.
                    "radio": kind == "RADIO" and self.settings.get_bool("radio_in_radio_list", False),
                    "audio_only": kind == "RADIO",
                    "catchup_days": catchup_days,
                    "url": url,
                }
                if token and kind != "RADIO":
                    # Told to IPTV Simple through the playlist, because that is where it looks. Without
                    # it the stream is opened by whatever Kodi guesses and the catchup properties are
                    # never produced.
                    #
                    # Not for radio: naming an inputstream on a `plugin://` entry is the trap this file
                    # warns about elsewhere — Kodi would hand the plugin address itself to that engine.
                    # A station is opened by Kodi's own player from the URL the plugin resolves, which
                    # is where audio belongs anyway.
                    entry["inputstream"] = "inputstream.ffmpegdirect"
                    entry["manifest_type"] = "hls"
                if catchup_days:
                    # IPTV Simple substitutes {utc} with the programme's start when the user picks one
                    # out of the archive; without this template the Replay entry replays LIVE.
                    #
                    # Pointed at the loopback redirector rather than at `plugin://` whenever it is
                    # available, and that swap is what makes seeking inside a replay work at all:
                    # ffmpegdirect re-requests this URL with a new {utc} on every seek and cannot call a
                    # plugin path. See resources/lib/localserver.py. Falls back to the plugin URL when no
                    # token has been minted yet, so a catalogue built before the service ever ran still
                    # plays — it just cannot scrub.
                    if token:
                        entry["catchup_source"] = localserver.url_for(
                            token, self.key, cid, self.account_id, catchup=True)
                    else:
                        entry["catchup_source"] = plugin_url + "&utc={utc}"
                out.append(entry)
                play_cache[cid] = play
            if unsubscribed:
                diag.log("EON: %s — %d channels are outside this subscription and were skipped"
                         % (kind, unsubscribed))

        # Empty is a FAILURE, never a line-up. Both channel-list calls above swallow their HttpError and
        # carry on, so a refused token used to return `[]` and be reported as a successful refresh of
        # zero channels. The catalogue writer only protects the case where EVERY provider produced
        # nothing; with a second provider enabled it happily wrote a playlist containing just that one,
        # and 300 EON channels disappeared with nothing in the summary saying why. Raising here puts it
        # on the refresh screen and in the log as the failure it is.
        if not out:
            raise ProviderError("EON returned no channels — the session was refused or the subscription "
                                "carries no line-up. The previous channel list has been kept.")
        self._write_play_cache(play_cache)
        diag.log("EON: %d channels" % len(out))
        return out

    def _logo(self, channel):
        """The channel's logo, made absolute."""
        return self._image(channel.get("images"), "LOGO")

    def _image(self, images, kind):
        """
        Largest image of [kind] from an EON `images` array, made absolute.

        Sizes run XL/L/STB_FHD/M/S and XL is what the official client uses. The `type` prefix filters
        LOGO_16_9 from EVENT_16_9 — the same array shape carries both, and a programme still where a
        channel logo belongs looks like a rendering bug rather than a data one.
        """
        if not isinstance(images, list):
            return ""
        path = ""
        for img in images:
            if not isinstance(img, dict):
                continue
            candidate = img.get("path") or ""
            if not candidate or not str(img.get("type") or "").startswith(kind):
                continue
            if img.get("size") == "XL":
                path = candidate
                break
            if not path:
                path = candidate
        return ((self.images or "").rstrip("/") + path) if path else ""

    def _batched_guide(self, refs, ranges, auth, size):
        """
        Every channel's events in a handful of requests instead of one each, or {} if this endpoint
        will not have it.

        WHY, in numbers off the owner's box rather than from a hunch. Three separate measurements of
        the same account said the same thing:

          * the whole five-day window, one channel per request: 302 requests, 444 s;
          * the same pass after the cache cut each answer from 353 KB to 102 KB — 3.5x less data —
            took 415 s. Bytes were not the cost;
          * with the prefetch kept properly full (effective concurrency 2.2 -> 2.8), 357 requests in
            497 s. Concurrency was not the cost either.

        All three land on 0.68-0.73 requests per second. EON meters the ACCOUNT, not the bytes and not
        the connection, so the only thing that can make the guide faster is asking fewer times. At 20
        ids per request 302 channels become 16 requests.

        `v1/events/epg` takes a comma-separated `cid` and answers with an object keyed by channel id —
        confirmed on the account on 2026-08-04, ten ids asked for and ten answered:
            PROBA GRUPNOG: trazeno 10, odgovoreno 10, kljucevi=['2144','17','1905',…]
        It is still PROVED at run time rather than assumed: the first batch decides, and anything less
        than a clear yes falls back to one request per channel — which is what every version until now
        did, so the worst case is one extra request per refresh.
        """
        if size < 2 or len(refs) < 2:
            return {}
        out = {}
        for begin, finish in ranges:
            index = 0
            while index < len(refs):
                chunk = refs[index:index + size]
                index += size
                try:
                    data = self.session.get(
                        self.api + "v1/events/epg?cid=%s&fromTime=%d&toTime=%d"
                        % (",".join(str(ref) for ref in chunk), begin, finish), headers=auth)
                except Exception as err:                           # noqa: BLE001
                    # Not fatal, and not retried here: the caller still has its per-channel path with
                    # the budget, the one re-login and the give-up counter. Better to lose the
                    # optimisation than to grow a second copy of those rules.
                    diag.log("EON: a batched guide request failed (%s) — one request per channel for "
                             "this refresh" % err)
                    return {}
                answered = [ref for ref in chunk if isinstance(data, dict) and str(ref) in data]
                if len(answered) < 2:
                    diag.log("EON: this endpoint answers one channel at a time (%d asked, %d answered)"
                             " — using one request per channel" % (len(chunk), len(answered)))
                    return {}
                for ref in answered:
                    out.setdefault(str(ref), []).extend(data.get(str(ref)) or [])
        return out

    def _guide_cache_path(self):
        return self.cache_path(GUIDE_CACHE)

    def _read_guide_cache(self, account):
        """
        The previous guide, or None. Refuses anything it cannot safely merge onto.

        Bound to the ACCOUNT for the same reason every other cache here is: a second subscription has a
        different line-up, and half of someone else's guide is worse than no guide.
        """
        try:
            with gzip.open(self._guide_cache_path(), "rb") as handle:
                data = json.loads(handle.read().decode("utf-8"))
        except (OSError, IOError, ValueError, EOFError):
            return None
        if not isinstance(data, dict) or data.get("account") != account:
            return None
        if time.time() - float(data.get("at") or 0) > GUIDE_CACHE_MAX_AGE:
            return None
        rows = data.get("by_ref")
        return data if isinstance(rows, dict) and rows else None

    def _write_guide_cache(self, account, start, end, by_ref):
        """Written through a temp file and renamed — the reader is the next process, and a half-written
        guide reads as a channel line-up with holes in it."""
        path = self._guide_cache_path()
        temporary = path + ".tmp"
        try:
            payload = json.dumps({"account": account, "at": time.time(),
                                  "from": start, "to": end, "by_ref": by_ref},
                                 ensure_ascii=False).encode("utf-8")
            with gzip.open(temporary, "wb", compresslevel=4) as handle:
                handle.write(payload)
            os.replace(temporary, path)
        except (OSError, IOError, ValueError) as err:
            diag.log("EON: the guide cache could not be written (%s) — the next refresh fetches "
                     "everything, which is slower and not wrong" % err)
            try:
                os.remove(temporary)
            except OSError:
                pass

    def epg(self, channels, hours_back=48, hours_forward=72):
        """One request per channel — EON has no batched guide endpoint. Bounded by a wall-clock budget
        rather than a channel count so a slow night degrades to a shorter guide instead of a stalled
        refresh."""
        auth = dict(self._auth())
        # Without this header the endpoint expects ISO-8601 datetimes and answers epoch millis with a
        # flat `400 invalid_input` on EVERY channel — which reads like a rejected account or too wide a
        # window, and is neither. It is the time FORMAT.
        auth["x-ucp-time-format"] = "timestamp"
        now = int(time.time() * 1000)
        start = now - hours_back * 3600 * 1000
        end = now + hours_forward * 3600 * 1000
        # RAISED FROM 240 TO 480 IN 1.30.0, and the reason is the prefetch above rather than impatience.
        # Read off the owner's box: a single guide request there takes about three seconds, so the old
        # budget bought roughly eighty of three hundred and two channels and the rest simply had no
        # guide until some later refresh got to them. With four in flight the same 240 s reached 165 —
        # still short. Doubling it fits the whole line-up, and the budget goes on doing its real job,
        # which is to stop a bad night from turning into a refresh that never ends.
        budget_until = time.time() + self.settings.get_int("eon_epg_budget_sec", 480)
        out = []
        done = 0
        failed = 0
        first_error = ""
        #: Consecutive failures, reset by every channel that works.
        #:
        #: Read off a customer's phone on 2026-08-02: the Wi-Fi had gone to sleep, so every request came
        #: back in the same millisecond with `URLError: [Errno 7] No address associated with hostname`,
        #: and this loop — which treated any non-auth failure as "this channel is a dud, try the next" —
        #: wrote **three hundred** identical failures into the log at full speed. That log then rode
        #: along with his support report and was the entire content of it. Nothing was learned from
        #: failure 2 through 300 that failure 1 had not already said, and the guide could not have been
        #: built either way. Move's loop already stopped at three; this one never had the counter.
        consecutive = 0
        #: One renewal per guide pass — see the auth branch below.
        relogged = False

        # SEVERAL CHANNELS IN FLIGHT, and the reason this is written as a PREFETCH rather than as a
        # parallel loop.
        #
        # EON has no batched guide endpoint, so this is one request per channel and about five of the
        # nine minutes a full refresh takes on the owner's box. Fetching a few at a time is the only
        # lever there is. What makes it delicate is everything the sequential loop below already gets
        # right: a wall-clock budget, Kodi's shutdown, ONE re-login when a token dies mid-guide, and
        # giving up after a few consecutive failures instead of writing three hundred identical lines
        # into a log somebody has to read.
        #
        # So the loop is not parallelised at all. It still walks channels one at a time and applies
        # every one of those rules in order; a small pool only runs AHEAD of it, fetching the next few
        # bodies so they are already in hand when the loop arrives. Nothing is in flight that the loop
        # has not decided to ask for, at most `workers` requests exist at once, and the moment the loop
        # decides to stop the window in flight is simply dropped.
        #
        # The count is a setting because it is the owner's account being asked, not ours: 4 by default,
        # 1 turns it off entirely and restores the previous behaviour byte for byte.
        # Ceiling raised 8 -> 12 and the default 4 -> 8 together with settings.xml: the guide is
        # where the minutes go, and on a four-account box EON alone spent 466s of its 480s
        # budget. Both numbers live in two places, so they move in two places.
        # FOUR, AND THE CEILING IS TWELVE. The default went 4 -> 8 on the theory that "four parallel
        # requests leave the connection mostly idle". Measured on the owner's box, same build, same
        # account, one variable changed:
        #
        #     4 workers -> EON 449 s      8 workers -> EON 479 s
        #
        # and the request log says why: at 4 the box was already moving 0.69 requests a second, and at 8
        # it moved 0.69 a second with each request taking twice as long. The link was never idle — EON's
        # guide is ~353 KB per channel over 302 channels, about 107 MB, and that is the whole 449 s at
        # roughly 240 KB/s. Concurrency cannot buy anything that bandwidth is already spending.
        #
        # The ceiling stays at 12 so a box on a fatter connection can still be told to try. Boxes that
        # already had this raised to 8 are LEFT there rather than migrated back: the difference is small,
        # and a setting that flips between releases is worse than a setting that is slightly wrong.
        # ---- ASK ONLY FOR WHAT IS NOT ALREADY ON DISK ------------------------------------------
        #
        # This is the one thing that makes a difference, and it took a measurement to find out. The
        # guide was the whole cost of a refresh: 449 s of a nine-minute pass, 302 channels at roughly
        # 353 KB each, about 107 MB. Doubling the workers changed nothing (449 s -> 479 s) because the
        # link was already full at ~240 KB/s. When bandwidth is the limit, the only lever is bytes.
        #
        # And most of those bytes are ones this box already has. A daily refresh asks for five days
        # (two back, three forward) of which four were fetched yesterday and have not changed since:
        #
        #   * THE PAST IS SETTLED. What aired is what aired; it is kept and never asked for again.
        #   * THE NEXT DAY IS NOT. A programme's end time moves when sport runs over, and a change to
        #     tonight matters to somebody tonight — so everything from two hours ago to 26 hours out is
        #     ALWAYS fetched fresh, whatever is on disk.
        #   * THE FAR FUTURE is taken from the cache and re-fetched later, when it rolls into that
        #     fresh window. Every programme is therefore asked for again within a day of airing, which
        #     is the only accuracy that can matter to a viewer.
        #
        # A channel with nothing cached — a new one, or one the budget cut off last time — gets the full
        # window, so the cache filling in unevenly can never leave a permanent hole.
        account = self._account_fingerprint() if hasattr(self, "_account_fingerprint") else \
            str(self.setting("username") or "")
        cached = self._read_guide_cache(account)
        cached_rows = (cached or {}).get("by_ref") or {}
        cached_to = int((cached or {}).get("to") or 0)
        fresh_from = min(end, now - GUIDE_FRESH_BACK_MS)
        fresh_to = min(end, now + GUIDE_FRESH_FORWARD_MS)

        #: Where the slice that has rolled into view since the cache was written begins, or None when
        #: there is no such slice. A MINIMUM WIDTH, because "end" moves by a few milliseconds between
        #: two runs: without it, a box refreshed twice in a day asked every channel for a window two
        #: milliseconds wide — 302 requests that could not return anything.
        tail_from = None
        if cached_to and (end - max(fresh_to, cached_to)) > 15 * 60 * 1000:
            tail_from = max(fresh_to, cached_to)

        def ranges_for(ref):
            if str(ref) not in cached_rows:
                return [(start, end)]                              # nothing kept for this channel
            wanted = [(fresh_from, fresh_to)]
            if tail_from is not None:
                wanted.append((tail_from, end))
            return [(a, b) for a, b in wanted if b > a]

        def kept_rows(ref, tvg_id):
            """
            The cached rows for this channel that the fetch above is NOT going to replace.

            `_ms` is LEFT ON. These rows go back into the cache as well as into the guide, and the guide
            copy has it stripped at the call site — stripping it here instead wrote zeros into the cache,
            so the pass after this one saw rows it could not place in time and threw all of them away. A
            programme kept on the first refresh then vanished on the third, which is precisely the shape
            of failure this cache must never have.
            """
            rows = cached_rows.get(str(ref)) or []
            keep = []
            for row in rows:
                begin = row.get("_ms")
                if not isinstance(begin, int) or begin <= 0:
                    continue
                if begin < start or begin > end:
                    continue                                       # outside the window being built
                if fresh_from <= begin < fresh_to:
                    continue                                       # being fetched fresh right now
                if tail_from is not None and begin >= tail_from:
                    continue                                       # in the slice being fetched too
                item = dict(row)
                item["channel_id"] = tvg_id                        # numbering can change between runs
                keep.append(item)
            return keep

        if cached:
            covered = sum(1 for ch in channels if str(ch["provider_ref"]) in cached_rows)
            diag.log("EON: %d of %d channels have a guide on disk — asking only for what changed since "
                     "%s" % (covered, len(channels),
                             time.strftime("%d.%m. %H:%M", time.localtime(float(cached.get("at") or 0)))))

        # ONE REQUEST FOR MANY CHANNELS — see _batched_guide for the measurements that led here.
        # Only channels that want the same ranges travel together; a newcomer with nothing cached needs
        # the full window and stays on the per-channel path.
        batch_size = max(1, min(50, self.settings.get_int("eon_guide_batch", GUIDE_BATCH_DEFAULT)))
        first_ranges = ranges_for(channels[0]["provider_ref"]) if channels else []
        same_window = [ch["provider_ref"] for ch in channels
                       if ranges_for(ch["provider_ref"]) == first_ranges]
        batched = {}
        if batch_size > 1 and len(same_window) >= 2:
            batched = self._batched_guide(same_window, first_ranges, auth, batch_size)
            if batched:
                diag.log("EON: the guide came back for %d channels in %d request(s) instead of %d"
                         % (len(batched),
                            ((len(same_window) + batch_size - 1) // batch_size) * max(1, len(first_ranges)),
                            len(same_window) * max(1, len(first_ranges))))

        workers = max(1, min(12, self.settings.get_int("epg_workers", 4)))
        # Only the channels the batch did not answer are worth prefetching one at a time.
        left = [ch["provider_ref"] for ch in channels if str(ch["provider_ref"]) not in batched]
        prefetch = (_Prefetch(self.session, auth, self.api, start, end, workers, ranges_for)
                    if workers > 1 and left else None)
        if prefetch:
            prefetch.feed(left)
        #: What this pass will write back: ref -> rows, with the raw start kept alongside so the next
        #: run can decide what to keep without parsing XMLTV strings.
        fresh_by_ref = {}

        for ch in channels:
            if time.time() > budget_until:
                diag.log("EON: guide budget spent after %d/%d channels — the rest follows next refresh"
                         % (done, len(channels)))
                break
            # Kodi is shutting down and this loop has minutes of work left. Nothing is written from
            # here, so stopping costs one refresh; carrying on costs the user a box that will not close.
            if self.stopping():
                diag.log("EON: Kodi is closing — the guide stops after %d/%d channels"
                         % (done, len(channels)))
                break
            ref = ch["provider_ref"]
            try:
                if str(ref) in batched:
                    data = batched.pop(str(ref))
                elif prefetch:
                    data = prefetch.take(ref)
                else:
                    data = []
                    for begin, finish in ranges_for(ref):
                        data.extend(_events_of(self.session.get(
                            self.api + "v1/events/epg?cid=%s&fromTime=%d&toTime=%d"
                            % (ref, begin, finish), headers=auth), ref))
            except net.HttpError as err:
                # A token that died mid-guide, recovered ONCE. Read off the box on 2026-07-31: the cached
                # session had just been validated (`v1/sp` answered 200 at 13:44:18) and the very next
                # call, one second later, began answering `401 invalid_token — Access token expired`. It
                # then did so for all 301 channels, one after another, because nothing in this loop ever
                # looked at WHY a channel failed: 55 seconds of requests against the owner's real account
                # for an EON guide that came back completely empty.
                #
                # `v1/sp` validating a token the guide endpoint refuses is the part worth remembering —
                # the cheap liveness check in `_restore_session` cannot be trusted to mean the session is
                # good, only that it was good for that one endpoint a moment ago. So the recovery lives
                # here, at the call that actually failed.
                #
                # Once, and only on an auth error. A re-login per failed channel would be 301 logins on a
                # subscription that counts them, and a retry on an ordinary timeout is what the budget is
                # for. If the second attempt is refused too, the loop STOPS instead of grinding through
                # the rest: 300 more identical 401s tell the owner nothing the first one did not.
                if err.is_auth and not relogged:
                    relogged = True
                    diag.log("EON: the guide was refused (%s) — the session expired mid-refresh, "
                             "logging in again and retrying this channel" % err)
                    try:
                        self.login(force=True)
                    except Exception as relogin_err:                # noqa: BLE001
                        diag.log("EON: could not renew the session for the guide — %s" % relogin_err,
                                 "ERROR")
                        failed += 1
                        first_error = first_error or str(err)
                        break
                    auth = dict(self._auth())
                    auth["x-ucp-time-format"] = "timestamp"
                    if prefetch:
                        # Whatever is in flight carries the dead token; drop it and let the new one
                        # refill, or the next few channels fail for a reason that is already fixed.
                        prefetch.renew(auth)
                    try:
                        data = self.session.get(
                            self.api + "v1/events/epg?cid=%s&fromTime=%d&toTime=%d" % (ref, start, end),
                            headers=auth)
                    except net.HttpError as retry_err:
                        failed += 1
                        first_error = first_error or str(retry_err)
                        diag.log("EON: the guide is still refused after a fresh login (%s) — stopping "
                                 "so the rest of the refresh is not spent on it" % retry_err, "ERROR")
                        break
                else:
                    failed += 1
                    consecutive += 1
                    first_error = first_error or str(err)
                    if err.is_auth:
                        diag.log("EON: the guide is refused even after renewing the session — stopping "
                                 "after %d channels" % done, "ERROR")
                        break
                    if consecutive >= _GUIDE_GIVE_UP:
                        diag.log("EON: %s — the guide stops after %d/%d channels rather than asking "
                                 "%d more times for the same answer (%s)"
                                 % ("this device has no network" if err.is_offline
                                    else "%d channels in a row failed" % consecutive,
                                    done, len(channels), len(channels) - done - failed, err), "ERROR")
                        break
                    continue
            events = _events_of(data, ref)
            rows = []
            for ev in events:
                begin, stop = ev.get("startTime"), ev.get("endTime")
                if not begin or not stop:
                    continue
                rows.append({
                    "channel_id": ch["tvg_id"],
                    "start": _xmltv_time(begin),
                    "stop": _xmltv_time(stop),
                    "title": ev.get("title") or "",
                    "desc": ev.get("shortDescription") or ev.get("description") or "",
                    "category": (ev.get("genres") or [{}])[0].get("name") if ev.get("genres") else "",
                    # EON serves a still for most programmes. It costs one attribute in the XMLTV and
                    # it is what turns Kodi's guide from a text grid into something that looks finished.
                    "icon": self._image(ev.get("images"), "EVENT"),
                    # Kept only in the cache file (stripped before it reaches the guide): comparing
                    # milliseconds is what lets the next run decide what it already has, and re-parsing
                    # an XMLTV string to find out would be the same work done twice.
                    "_ms": int(begin) if str(begin).isdigit() else 0,
                })
            kept = kept_rows(ref, ch["tvg_id"])                # still carrying _ms, for the cache
            # The cache keeps the union — what was reused plus what was just fetched — so tomorrow the
            # settled past is still here without ever being asked for again.
            #
            # COPIED, not shared. `list(rows)` copies the list and not the dicts inside it, so stripping
            # `_ms` from the guide rows a line later stripped it from the cached ones too — they were the
            # same objects. The cache then had no timestamps, the next run could not tell what it
            # already had, and every channel fell back to "keep nothing": measured on the box as a guide
            # that went from 47,621 programmes to 7,322 while looking like it had worked.
            fresh_by_ref[str(ref)] = [dict(row) for row in kept] + [dict(row) for row in rows]
            # The guide gets the same rows without the internal marker. Built as new dicts rather than
            # by popping, because the cache above holds the originals — see kept_rows.
            for row in kept + rows:
                out.append({key: value for key, value in row.items() if key != "_ms"})
            done += 1
            consecutive = 0
        if failed:
            # Named rather than swallowed: a guide that is quietly empty for half the line-up looks like
            # a provider with no EPG, and that ambiguity has cost a debugging round before.
            diag.log("EON: guide failed on %d channels (first: %s)" % (failed, first_error), "ERROR")
        # Written for the channels this pass actually covered. A pass cut short by the budget or by
        # Kodi closing still writes what it has: the channels it never reached simply have nothing on
        # disk, and ranges_for gives those the full window next time.
        if fresh_by_ref:
            self._write_guide_cache(account, start, end, fresh_by_ref)
        diag.log("EON: %d programmes over %d channels" % (len(out), done))
        return out

    # ---- playback ---------------------------------------------------------

    def _play_cache_path(self):
        """Per ACCOUNT: two subscriptions sharing one cache file would hand each other's publishing
        points to the player, and the symptom would be one account playing the other's channels."""
        return self.cache_path(PLAY_CACHE)

    def _write_play_cache(self, cache):
        if not cache:
            return
        try:
            with io.open(self._play_cache_path(), "w", encoding="utf-8") as handle:
                handle.write(json.dumps(cache, ensure_ascii=False))
        except (OSError, IOError, ValueError) as err:
            # A cache that cannot be written costs a slower first tune, nothing more.
            diag.log("EON: could not write the play cache (%s)" % err)

    def _read_play_cache(self):
        try:
            with io.open(self._play_cache_path(), "r", encoding="utf-8") as handle:
                data = json.loads(handle.read())
            return data if isinstance(data, dict) else {}
        except (OSError, IOError, ValueError):
            return {}

    def _play_descriptor_for(self, channel_ref, auth):
        cached = self._read_play_cache().get(str(channel_ref))
        if cached:
            return cached
        # Miss: a channel added since the last refresh, or a play route running before one ever ran.
        for kind in ("TV", "RADIO"):
            raw = self.session.get(self.api + "v3/channels?channelType=" + kind, headers=auth) or []
            entry = next((c for c in raw if str(c.get("id")) == str(channel_ref)), None)
            if entry is None:
                continue
            if not entry.get("subscribed"):
                raise ProviderError("EON: this subscription does not include that channel.")
            play = _play_descriptor(entry, kind)
            if play is None:
                raise ProviderError("EON: this channel carries no publishing point (provider side).")
            return play
        raise ProviderError("EON: channel %s is not in this account's line-up." % channel_ref)

    def resolve(self, channel_ref, at_utc=None, vod=False):
        # Restore the session WITHOUT the health probe — see _load_session's [probe]. A tune that is
        # wrong about its token finds out from the tune itself, which is what mint() is for.
        if not self.token:
            self.login(probe=False)
        mint = (lambda: self._resolve_vod(str(channel_ref))) if vod \
            else (lambda: self._resolve_live(channel_ref, at_utc))
        try:
            return mint()
        except net.HttpError as err:
            # The price of caching the login: a token can be dead before its stated expiry (a password
            # change, a device revoked from EON's panel, a server-side session reset). Without this the
            # cache would turn a two-second delay into a stream that will not start until the cache times
            # out on its own. One forced re-login, one retry — and only for an auth refusal, so a genuine
            # 404/500 still surfaces as itself instead of being masked by a pointless second attempt.
            if not err.is_auth:
                raise
            diag.log("EON: the cached session was refused (HTTP %s) — logging in again" % err.status)
            self.forget_session()
            self.login(force=True)
            return mint()

    def _resolve_live(self, channel_ref, at_utc=None):
        auth = self._auth()
        play = self._play_descriptor_for(channel_ref, auth)
        at_seconds = int(at_utc) if at_utc else None

        # Highest-bitrate rendering the channel offers. The channel lists profile ids; the ladder that
        # maps them to a coreStreamId came from v1/rndprofiles at login.
        best, best_bitrate = None, -1
        for pid in play.get("profile_ids") or []:
            prof = self.profiles.get(int(pid))
            if prof and prof["core_stream_id"] and prof["video_bitrate"] > best_bitrate:
                best, best_bitrate = prof, prof["video_bitrate"]
        if best is None:
            raise ProviderError("EON: none of this channel's rendering profiles are in the account's "
                                "profile list — the stream cannot be addressed.")

        # Live tunes go to the live pool. Replay goes to the TIMESHIFT pool: the live servers' DVR is
        # only hours deep, so a multi-day t= against them is ignored and the live edge plays instead —
        # which surfaces as "I asked for yesterday and got now". The official client targets the second
        # timeshift server; fall back rather than fail so a pool-less account still tunes live.
        if at_seconds and self.timeshift_servers:
            pool = self.timeshift_servers
            server = pool[1] if len(pool) > 1 else pool[0]
        else:
            server = self.servers[0] if self.servers else None
        if server is None:
            raise ProviderError("EON: the account was given no streaming servers to play from.")

        ctime = self._ctime(auth)
        url = _sign_stream(
            stream_key=self.stream_key,
            plain=_plain_params(
                publishing_point=play["publishing_point"],
                core_stream_id=best["core_stream_id"],
                service_provider=self.service_provider,
                stream_un=self.stream_un,
                stream_key=self.stream_key,
                player=PLAYER_LIVE,
                sig=play.get("sig", ""),
                session=_SESSION_PLACEHOLDER,
                server_ip=server.get("ip") or "",
                device_number=self.device_number,
                ctime=ctime,
                aa_enabled=bool(play.get("aa_enabled")),
                at_utc=at_seconds,
                # Never ask for a floor the chosen rendition cannot clear. Derived from the profile
                # actually selected above rather than from "is this a radio channel", so it stays right
                # if EON ever adds another low-bitrate or audio-only profile.
                minvbr=min(100, best["video_bitrate"]),
            ),
            hostname=server.get("hostname") or "",
            service_provider=self.service_provider,
            stream_un=self.stream_un,
            player=PLAYER_LIVE,
            sig=play.get("sig", ""),
        )
        # The edge gates the manifest AND every segment on the same identity the API calls carry: a
        # blocked User-Agent, or a missing Referer/Origin, is answered 403 there while the channel list
        # keeps loading fine. That split is what makes this look like a player bug instead of a header
        # one, so the headers travel with the URL rather than being left to the player's defaults.
        headers = {k: v for k, v in self.session.headers_for().items()
                   if k in ("User-Agent", "Referer", "Origin")}
        if play.get("audio_only"):
            # A dict rather than the usual pair, so the play route can tell them apart. Television
            # keeps the pair it has always returned — there is no reason to move that.
            return {"url": url, "headers": headers, "audio_only": True}
        return url, headers

    # ---- on demand --------------------------------------------------------

    def vod(self, node=None):
        """
        The Video klub, grouped by EON's OWN catalogues — "N1", "HBO OD", "Pickbox NOW" — which is the
        same grouping the official app shows and the reason no genre taxonomy is invented here.

        Titles the account is not subscribed to are KEPT rather than filtered out. Hiding them made the
        store look empty (a few hundred of several thousand), and playing one is already an honest,
        specific failure rather than a silent one. Series are containers whose episodes are fetched only
        when one is opened — there are hundreds, and a seasons call each would multiply the cost of a
        screen most people scroll past.
        """
        if not self.token:
            self.login()
        node = node or ""
        auth = self._auth()

        if not node:
            catalogues = self.session.get(self.api + "v1/catalogues", headers=auth) or []
            return [{"kind": "dir",
                     "name": cat.get("title") or ("Katalog %s" % cat.get("id")),
                     "node": "cat:%s" % cat.get("id")}
                    for cat in catalogues if (cat or {}).get("id")]

        if node.startswith("cat:"):
            # "cat:<id>" is the first screen; "cat:<id>@<page>" is a continuation; "cat:<id>+<cat>" is
            # one category within the catalogue. Paging is expressed as an ordinary `dir` entry rather
            # than a new concept, so default.py renders the "next page" row exactly like any other
            # folder and no caller had to learn anything.
            body = node.split(":", 1)[1]
            addressed, _, start = body.partition("@")
            catalogue_id, _, category_id = addressed.partition("+")
            try:
                first_page = max(0, int(start or 0))
            except ValueError:
                first_page = 0
            # The category chooser is the FIRST thing shown for a catalogue, and only when there is a
            # real choice to make — see [_vod_categories]. It reads the catalogue's first page to learn
            # which categories are in it, and when there is no choice to offer that is EXACTLY the page
            # the listing needs next, so it is handed over rather than asked for twice.
            page_zero = None
            if not category_id and not start:
                chooser, page_zero = self._vod_categories(catalogue_id, auth)
                if chooser:
                    return chooser
            return self._vod_assets(catalogue_id, auth, first_page, category_id, page_zero)
        if node.startswith("series:"):
            return self._vod_episodes(node.split(":", 1)[1], auth)
        return []

    #: VOD category names, keyed by the id assets carry in `categoryIds`.
    #:
    #: Ours are PREFERRED over the server's, which is the opposite of the usual rule here and deliberate:
    #: `v2/categories/VOD` answers in the language of the request, and this addon's identity sends
    #: `Accept-Language: en-US` for reasons that have nothing to do with the user (it matches the web
    #: client EON's edge expects). So the API says "Movies" and "Series" while every other row on the
    #: same screen — "Sve", "Sledeca strana" — is Serbian. The server is still asked, and still names any
    #: category id that appears here without one.
    VOD_CATEGORY_NAMES = {201: "Filmovi", 202: "Serije", 203: "Deca", 204: "Muzika",
                          205: "Sport", 207: "Dokumentarni", 209: "Zabava"}

    def _vod_category_names(self, auth):
        names = {}
        try:
            rows = self.session.get(self.api + "v2/categories/VOD", headers=auth) or []
        except net.HttpError:
            rows = []
        for row in rows:
            # "All categories" (includesAll) is not a category, it is the absence of one — it already
            # exists here as the "Sve" row, and offering both would be the same list twice.
            if (row or {}).get("id") is None or row.get("includesAll"):
                continue
            if row.get("name"):
                names[int(row["id"])] = row["name"]
        # Translated HERE rather than in the table above: that one is a class attribute, built when the
        # module is imported, and the interface language is not resolved until an entry point has called
        # i18n.configure(). A T() up there would freeze whatever was current at import time.
        names.update({cid: T(name) for cid, name in self.VOD_CATEGORY_NAMES.items()})
        return names

    def _vod_categories(self, catalogue_id, auth):
        """
        The category rows for one catalogue — empty when there is nothing to choose between.

        Which categories a catalogue actually holds is read off its FIRST page rather than probed one
        request per category: the page is the same one the listing needs anyway, so the chooser costs a
        single extra call (the names) instead of eight. The consequence is honest and small — a category
        that appears only deep inside a very long catalogue is not offered — and "Sve" always leads to
        the complete list either way.

        Filtering itself is done by the SERVER, with `categoryId`. That is worth stating because most of
        this endpoint's parameters are decoration: measured against the live API, `categoryIds`,
        `category` and `vodType` are all accepted and then ignored, returning the unfiltered page.
        `categoryId` (singular) is the one that works.

        Returns the chooser rows AND the page it read, so a catalogue with nothing to choose between
        does not pay for the same page twice.
        """
        try:
            data = self.session.get(
                self.api + "v1/vodassets?catalogueId=%s&page=0&size=%d" % (catalogue_id, VOD_PAGE_SIZE),
                headers=auth) or {}
        except net.HttpError:
            return [], None
        present = []
        for asset in data.get("content") or []:
            for cid in asset.get("categoryIds") or []:
                if cid not in present:
                    present.append(cid)
        # One category is no choice: showing a single folder called "Filmovi" that contains the whole
        # catalogue is a screen the user has to click through for nothing.
        if len(present) < 2:
            return [], data
        names = self._vod_category_names(auth)
        rows = [{"kind": "dir", "name": T("Sve"), "node": "cat:%s@0" % catalogue_id}]
        for cid in present:
            rows.append({"kind": "dir",
                         "name": names.get(cid) or ("Kategorija %s" % cid),
                         "node": "cat:%s+%s" % (catalogue_id, cid)})
        return rows, data

    def _vod_assets(self, catalogue_id, auth, first_page=0, category_id="", prefetched=None):
        """
        [prefetched] is page [first_page] already in hand — the category chooser's own request. It is
        only ever passed for page 0 of a whole catalogue, which is the one request that would otherwise
        be made twice for the same screen.
        """
        out, page = [], first_page
        last_page = min(first_page + VOD_PAGE_BATCH, VOD_MAX_PAGES)
        while page < last_page:
            try:
                if prefetched is not None and page == first_page:
                    data = prefetched
                else:
                    data = self.session.get(
                        self.api + "v1/vodassets?catalogueId=%s&page=%d&size=%d%s"
                        % (catalogue_id, page, VOD_PAGE_SIZE, _category_param(category_id)),
                        headers=auth) or {}
            except net.HttpError as err:
                # One catalogue failing costs that catalogue, not the whole Video klub — and it says so
                # rather than looking like a store that happens to be short.
                diag.log("EON: VOD catalogue %s stopped at page %d with %d titles (%s)"
                         % (catalogue_id, page, len(out), err), "ERROR")
                break
            items = data.get("content") or []
            if not items:
                return out
            for asset in items:
                entry = self._vod_entry(asset)
                if entry:
                    out.append(entry)
            # A SHORT PAGE is the only trustworthy end marker. EON also sends `last`, `totalPages` and
            # `totalElements`, and all three are worthless: measured against the live backend, `last`
            # is True on every single page, `totalPages` is always the current page plus one, and
            # `totalElements` is however many rows have been served so far. Believing `last` made this
            # stop after page 0 and silently drop 1,200 of a catalogue's 1,263 titles.
            if len(items) < VOD_PAGE_SIZE:
                return out
            page += 1

        # The batch ran out rather than the catalogue. Whether anything actually follows cannot be read
        # off the reply — see above — so it is asked, with a one-row request. Measured at about half a
        # second against a screen that already costs two, and it is the difference between a "next
        # page" row that works and one that opens an empty screen on any catalogue whose length is an
        # exact multiple of the batch.
        if page < VOD_MAX_PAGES and self._has_more(catalogue_id, auth, page, category_id):
            # The chosen category has to survive the jump, or page two of "Filmovi" quietly becomes page
            # two of everything.
            addressed = "%s+%s" % (catalogue_id, category_id) if category_id else catalogue_id
            out.append({"kind": "dir", "name": T("Sledeca strana") + "  ▸",
                        "node": "cat:%s@%d" % (addressed, page)})
        return out

    def _has_more(self, catalogue_id, auth, page, category_id=""):
        """Is there anything on [page]? One row is enough to know, and cheap enough to ask every time."""
        try:
            data = self.session.get(
                self.api + "v1/vodassets?catalogueId=%s&page=%d&size=1%s"
                % (catalogue_id, page * VOD_PAGE_SIZE, _category_param(category_id)),
                headers=auth) or {}
        except net.HttpError:
            return False
        return bool(data.get("content"))

    def search(self, term):
        """
        EON's own unified search — `v1/search?q=`, which answers in a third of a second.

        Finding it took some doing and the dead ends are worth recording, because the obvious approach
        looks like it works: `v1/vodassets` ACCEPTS `search=`, `title=`, `query=`, `name=`, `q=`,
        `text=`, `keyword=` and `filter=` — and ignores every one of them, returning the unfiltered
        catalogue with a 200. A search built on that would have looked fine in a test and shown the
        user the same first page of the store no matter what they typed. Walking all 31 catalogues
        instead did work, and took 34 seconds.

        The reply is split into VOD, TV (upcoming) and CUTV (catch-up). Only VOD is taken here: the
        other two are guide entries, and search.py already answers those from the XMLTV on disk without
        a request at all.
        """
        if not self.token:
            self.login()
        cleaned = (term or "").strip()
        if not cleaned:
            return []
        data = self.session.get(self.api + "v1/search?q=%s" % quote(cleaned),
                                headers=self._auth()) or {}
        out = []
        for asset in data.get("VOD") or []:
            entry = self._vod_entry(asset or {})
            if entry:
                out.append(entry)
        diag.log("EON: search %r -> %d titles" % (term, len(out)))
        return out

    def _vod_entry(self, asset):
        asset_id = str(asset.get("id") or "")
        title = asset.get("title") or ""
        if not asset_id or not title:
            return None
        # REPLAY_SERIES is a catch-up-sourced show and exposes the same seasons/episodes shape as an
        # ordinary series, so it opens like one instead of being dropped.
        series = asset.get("contentType") in ("SERIES", "REPLAY_SERIES")
        poster = self._image(asset.get("images"), "")
        entry = {"kind": "dir" if series else "item",
                 "name": title if asset.get("subscribed", True) else (title + "  [*]"),
                 "logo": poster,
                 "plot": asset.get("shortDescription") or ""}
        if series:
            entry["node"] = "series:%s" % asset_id
        else:
            entry["id"] = asset_id
        return entry

    def _vod_episodes(self, asset_id, auth):
        """Seasons and their episodes, flattened — a season with one episode is not worth a level."""
        seasons = self.session.get(self.api + "v1/vodassets/%s/seasons" % asset_id, headers=auth) or []
        out = []
        for season in seasons:
            season_no = int((season or {}).get("seasonNumber") or 0)
            for episode in (season or {}).get("episodes") or []:
                episode_id = str((episode or {}).get("id") or "")
                if not episode_id:
                    continue
                number = int(episode.get("episodeNumber") or (len(out) + 1))
                # EON leaves an episode's own title blank on plenty of shows — its own app shows
                # "1, 2, 3…" — so a readable label beats an empty row.
                out.append({"kind": "item", "id": episode_id,
                            "name": "%dx%02d  %s" % (int(episode.get("seasonNumber") or season_no), number,
                                                     episode.get("title") or ("Epizoda %d" % number)),
                            "logo": self._image(episode.get("images"), ""),
                            "plot": episode.get("shortDescription") or "",
                            "_sort": (int(episode.get("seasonNumber") or season_no), number)})
        # The provider answers newest-first, which reads backwards in a list of episodes — 9x31 above
        # 9x30 above 9x29. Sorted here rather than left to Kodi, which would sort them as text.
        return sorted(out, key=lambda e: e.pop("_sort"))

    def _resolve_vod(self, asset_id):
        """
        A signed URL for one on-demand title.

        Almost the live path, with three differences that all come from the same place — the asset's own
        `v1/vodassets/{id}` detail rather than the channel list: the publishing point, the `vod` player
        signature (NOT the `live` one — they are per pool and the edge rejects the wrong one), and the
        VOD server pool, which falls back to the live pool because a provider that exposes none would
        otherwise have an unplayable store.
        """
        auth = self._auth()
        detail = self.session.get(self.api + "v1/vodassets/%s" % asset_id, headers=auth) or {}
        points = detail.get("publishingPoint") or []
        point = points[0] if points else {}
        publishing_point = str(point.get("publishingPoint") or "")
        if not publishing_point:
            raise ProviderError("EON: taj naslov nema tačku objavljivanja — verovatno nije u tvom paketu.")

        sig = ""
        for cfg in point.get("playerCfgs") or []:
            if (cfg or {}).get("type") == "vod":
                sig = cfg.get("sig") or ""
                break
        profile_ids = [int(p) for p in (point.get("profileIds") or []) if str(p).isdigit()]
        best = None
        for profile_id in profile_ids:
            profile = self.profiles.get(profile_id)
            if profile and (best is None or profile["video_bitrate"] > best["video_bitrate"]):
                best = profile
        if not best:
            raise ProviderError("EON: za taj naslov nema nijednog profila koji ovaj nalog može da pusti.")

        servers = self.vod_servers or self.servers
        if not servers:
            raise ProviderError("EON: nalog nema nijedan server za video klub.")
        server = servers[0]
        ctime = self._ctime(auth)
        url = _sign_stream(
            stream_key=self.stream_key,
            plain=_plain_params(
                publishing_point=publishing_point, core_stream_id=best["core_stream_id"],
                service_provider=self.service_provider, stream_un=self.stream_un,
                stream_key=self.stream_key, player=PLAYER_VOD, sig=sig,
                session=_SESSION_PLACEHOLDER, server_ip=server.get("ip") or "",
                device_number=self.device_number, ctime=ctime, aa_enabled=False, vod=True),
            hostname=server.get("hostname") or "", service_provider=self.service_provider,
            stream_un=self.stream_un, player=PLAYER_VOD, sig=sig)
        headers = {k: v for k, v in self.session.headers_for().items()
                   if k in ("User-Agent", "Referer", "Origin")}

        # Every Video klub title is Widevine-protected — proven by fetching one of these manifests and
        # reading it: it carries `#EXT-X-SESSION-KEY:METHOD=SAMPLE-AES` for Widevine, PlayReady and
        # FairPlay. Returning a bare URL here (which is what this did) hands the player a protected
        # stream with no way to open it, and on a real box that surfaces as "Failed to parse the manifest
        # file" — a message that points at the manifest and not at the missing licence.
        # Ask the edge before handing the URL to the player, because EON's catalogue lists titles its own
        # CDN does not have. Measured on a real account: "Vladalac — prvi deo" is `subscribed: true` with
        # a normal publishing point, and every one of the 22 VOD servers and all four quality profiles
        # answer `403.2700 / Nonexisting VOD stream`. Its `originalTitle` gives it away — a raw ingest
        # name ("BG-DOK-VLADALAC-PRVI DEO-170220-3_9069256_2022-01-28T140136.397") that was catalogued
        # without a stream behind it. Nothing in the asset detail says so, so asking is the only way to
        # know, and one extra request buys a message that names the cause instead of a player that just
        # gives up.
        self._assert_playable(url, headers)

        result = {"url": url, "headers": headers, "manifest_type": "hls"}
        pre_auth = self._vod_pre_auth(publishing_point, auth)
        if self.widevine_url and pre_auth:
            result["license_type"] = "com.widevine.alpha"
            # inputstream.adaptive's licence key is `url|request headers|request body|response`, the same
            # shape Iris already uses here. `R{SSM}` posts the raw challenge back.
            result["license_key"] = "%s|%s|R{SSM}|" % (
                self.widevine_url,
                "&".join(["PreAuthorization=" + quote(pre_auth, safe=""),
                          "User-Agent=" + quote(headers.get("User-Agent", ""), safe=""),
                          "Content-Type=application/octet-stream"]))
        return result

    def _assert_playable(self, url, headers):
        """
        Raise with EON's OWN reason when the edge refuses the minted URL.

        Deliberately fail-open: only a 403 stops playback. A timeout, a DNS failure or a 5xx is the
        network or the CDN having a moment, and refusing to play on those would turn a blip into a
        broken title — the player retries and recovers where this cannot.
        """
        try:
            self.session.get(url, headers=headers, expect_json=False)
        except net.HttpError as err:
            if err.status != 403:
                return
            # The edge answers a one-line HTML page: "403.2700 / Nonexisting VOD stream". Carrying that
            # code through is what makes a support message answerable — it distinguishes a title EON
            # never encoded from an entitlement problem, which look identical from the sofa.
            reason = ""
            for part in (err.body or "").replace("<", ">").split(">"):
                if "403." in part:
                    reason = part.strip()
                    break
            diag.log("EON: the CDN refused this title (%s)" % (reason or "403"), "ERROR")
            if "2700" in reason or "6500" in reason:
                raise ProviderError(
                    "EON nema snimak za ovaj naslov — stoji u katalogu, ali ga njihov server ne "
                    "servira (%s). Nije do tvoje pretplate i ne moze se popraviti sa ove strane."
                    % (reason or "403"))
            raise ProviderError("EON je odbio ovaj naslov (%s)." % (reason or "403"))

    def _vod_pre_auth(self, publishing_point, auth):
        """
        The per-title DRM pre-authorization JWT the licence endpoint demands as a `PreAuthorization`
        header. Scoped to ONE publishing point and short-lived, so it is minted per play rather than
        cached with the session.

        Best effort: a title served in the clear, or an account whose provider exposes no Widevine
        endpoint, still plays — the caller simply attaches no DRM when this comes back empty.
        """
        try:
            data = self.session.post(
                self.entitlement + "v1/drm/preAuthTokenVod",
                body=json.dumps({"vodPublishingPoint": publishing_point, "mode": "STREAMING"}),
                headers=dict(auth, **{"Content-Type": "application/json"})) or {}
        except net.HttpError as err:
            diag.log("EON: no DRM pre-authorization for this title (%s)" % err, "ERROR")
            return ""
        return data.get("preAuthToken") or ""

    # ---- diagnostics ------------------------------------------------------

    def diagnose(self):
        rows = []
        ok, detail = net.probe(self.session, BROKER + "v1/time")
        rows.append(("Broker reachable", ok, detail))
        if not ok:
            return rows
        try:
            generic = self._generic_token()
            rows.append(("Client credentials", True, "token obtained"))
        except Exception as err:                                  # noqa: BLE001 - reported, not raised
            rows.append(("Client credentials", False, str(err)))
            return rows
        try:
            api, base = self._resolve_api(generic)
            rows.append(("API host for brand", True, base))
        except Exception as err:                                  # noqa: BLE001
            rows.append(("API host for brand", False, str(err)))
            return rows
        try:
            self.login()
            rows.append(("Account login", True, "device %s" % self.setting("device_id")))
            rows.append(("Stream key", bool(self.stream_key), "present" if self.stream_key else "missing"))
        except Exception as err:                                  # noqa: BLE001
            rows.append(("Account login", False, str(err)))
            return rows
        try:
            channels = self.channels()
            rows.append(("Channel list", bool(channels), "%d subscribed channels" % len(channels)))
        except Exception as err:                                  # noqa: BLE001
            rows.append(("Channel list", False, "%s: %s" % (type(err).__name__, err)))
        return rows


# ---- channel play descriptor -----------------------------------------------

def _play_descriptor(channel, kind="TV"):
    """
    The four values a tune needs, pulled off one channel entry. None when the channel cannot be played.

    `publishingPoint` is an ARRAY of variants (audio language, burned-in subtitles); the first is the
    default the official client uses. Its `playerCfgs` carry a per-POOL signature — `live` for TV,
    `radio` for the audio-only stations, `cutv` for the archive — and picking the wrong one, or none,
    produces a URL the edge rejects rather than an obvious error here.

    WHICH ONE IS WANTED DEPENDS ON THE POOL THE CHANNEL CAME FROM, so `kind` is passed in rather than
    the order being a fixed ("live", "radio") for everything. Measured on a live account, this changes
    no signature today — every radio station there advertises only its `radio` cfg, so the old order
    reached the same value by falling through. It is correctness insurance, not a fix: a station that
    ever advertises both would silently have been handed the live signature.
    """
    points = channel.get("publishingPoint")
    if not isinstance(points, list) or not points:
        return None
    pp = points[0]
    if not isinstance(pp, dict):
        return None
    publishing_point = pp.get("publishingPoint") or ""
    if not publishing_point:
        return None
    cfgs = [c for c in (pp.get("playerCfgs") or []) if isinstance(c, dict)]
    sig = ""
    # The pool's own type first, the other as a fallback — a channel that carries only the "wrong" one
    # still plays rather than failing on principle.
    order = ("radio", "live") if kind == "RADIO" else ("live", "radio")
    for wanted in order:
        match = next((c for c in cfgs if c.get("type") == wanted), None)
        if match:
            sig = match.get("sig") or ""
            break
    if not sig and cfgs:
        sig = cfgs[0].get("sig") or ""
    return {
        "publishing_point": publishing_point,
        "profile_ids": [int(p) for p in (pp.get("profileIds") or []) if str(p).isdigit()],
        "sig": sig,
        "aa_enabled": bool(channel.get("aaEnabled")),
        # Which POOL this came from, carried through to the tune. A station is not a video stream
        # with the picture missing: it must not be handed to inputstream.adaptive, which is what
        # the play route does with everything else. Recorded here because the pool is only known
        # while the channel list is being built, and the tune happens in another process entirely.
        "audio_only": kind == "RADIO",
    }


# ---- stream signing --------------------------------------------------------

#: The session id appears twice — once inside the encrypted blob and once in the query string — and the
#: edge checks that they agree. Minted once per tune and substituted into both.
_SESSION_PLACEHOLDER = "{session}"


def _plain_params(publishing_point, core_stream_id, service_provider, stream_un, stream_key, player,
                  sig, session, server_ip, device_number, ctime, aa_enabled, at_utc=None, vod=False,
                  minvbr=100):
    """
    The parameter blob that gets encrypted, field for field as the official web client builds it.

    Semicolon-separated `key=value`, order significant. Catch-up differs from live by exactly one
    inserted segment — `t=<epoch seconds>000` — which is why one signer covers both. The stream key is
    sent INSIDE the blob as `ss=` as well as being the key the blob is encrypted with; that is not a
    redundancy to tidy away, it is how the edge knows which account minted the request.
    """
    # `asset=` for on demand, `channel=` for live — confirmed by AES-decrypting the official web
    # client's own VOD request with this account's stream key. Everything else in the blob is identical,
    # which is why one signer covers both; get this one word wrong and the edge answers 403 with no clue.
    # `minvbr` is the FLOOR the client asks the edge to stay above, and it used to be hardcoded at 100.
    # That is a fine default for television and wrong for one specific case: EON's audio-only radio
    # profile `ao96` (id 17) carries videoBitrate 0, so demanding 100 asks for video the stream does not
    # contain. The edge answers 403 with "Streamable bandwidth exceeded" — a message about bandwidth for
    # what is really "no rendition satisfies your floor", which is why it reads like a quota problem and
    # sends you looking at the subscription instead of at this line. Exactly the 23 stations on profile
    # 17 failed; the 42 on `av96` (id 18, videoBitrate 200) played, which is what made "the radio does
    # not work" look intermittent rather than systematic.
    base = ("%s=%s;stream=%s;sp=%s;u=%s;ss=%s;minvbr=%d;adaptive=true;player=%s;"
            "sig=%s;session=%s;m=%s;device=%s;ctime=%s;conn=%s;"
            % ("asset" if vod else "channel",
               publishing_point, core_stream_id, service_provider, stream_un, stream_key,
               int(minvbr), player,
               sig, session, server_ip, device_number, ctime, CONN_TYPE))
    if at_utc:
        base += "t=%d000;" % int(at_utc)
    return base + "aa=%s" % ("true" if aa_enabled else "false")


def _sign_stream(stream_key, plain, hostname, service_provider, stream_un, player, sig):
    """
    AES-CBC over the parameter blob with the account's own stream key, exactly as the web client does.

    The cipher is OURS (resources/lib/aes.py), not pycryptodome. That was the original plan and it died
    on the first real box: Kodi reported `script.module.pycryptodome v3.4.3 installed` and the import
    still failed, because that Android build ships the module as an addon.xml with no `lib` directory —
    and Kodi will not install the real one over a dependency it already believes is satisfied. See the
    docstring in aes.py.
    """
    session = str(uuid.uuid4())
    plain = plain.replace(_SESSION_PLACEHOLDER, session)
    key = base64.urlsafe_b64decode(_pad_b64(stream_key))
    iv = os.urandom(16)
    data = plain.encode("utf-8")
    pad = 16 - (len(data) % 16)
    data += bytes([pad]) * pad
    enc = aes.cbc_encrypt(key, iv, data)
    return ("https://%s/stream?i=%s&a=%s&sp=%s&u=%s&player=%s&session=%s&sig=%s"
            "&lang=%s&nofps-info=%s"
            % (hostname, _b64url(iv), _b64url(enc), service_provider, stream_un,
               player, session, sig, STREAM_LANG, STREAM_NOFPS_INFO))


def _b64url(raw):
    return base64.urlsafe_b64encode(raw).decode("ascii").rstrip("=")


def _pad_b64(value):
    return value + "=" * (-len(value) % 4)


def _xmltv_time(millis):
    return time.strftime("%Y%m%d%H%M%S +0000", time.gmtime(int(millis) / 1000.0))
