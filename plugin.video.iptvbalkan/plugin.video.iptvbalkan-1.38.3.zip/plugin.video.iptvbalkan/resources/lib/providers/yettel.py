# -*- coding: utf-8 -*-
"""
Yettel TV (ytv.rs) — Kaltura OTT, partner 3200. Ported from the Android client's `YettelApi.kt`, which
was itself verified end to end against this account.

A third backend, unrelated to EON's United Cloud and Iris' Huawei VSP, and in two ways the easiest of
the three: Kaltura hands back an already-tokenised DASH manifest AND a ready-to-use Widevine licence URL
from ONE call, so there is no request signing here at all (EON) and no licence header to smuggle (Iris);
and the guide comes back for EVERY channel in one batched request instead of one call per channel.

The hard part is the opposite way round — LOGIN. Yettel's credential check happens on Yettel's own SSO
behind SMS 2FA, and `grant_type=password` is flatly refused (`unsupported_grant_type`, confirmed live).
The only way in is the OAuth 2.0 Device Authorization Grant (RFC 8628) — the "type this code on your
phone" flow Netflix and YouTube use — which runs ONCE per account and yields a Kaltura app-token
(id + secret). After that, every launch and every other install mints its own session silently from that
token, with no SMS and no user interaction. That is why this provider has no username or password
setting: there is nothing useful to put in one.

    resources/lib/pairing.py serves the pairing screen; this file owns the protocol.
"""

import hashlib
import io
import json
import os
import re
import threading
import time
import uuid

from .. import diag, net
from ..i18n import T
from ..provider import Provider, ProviderError, register

BASE = "https://3200.frp1.ott.kaltura.com/api_v3/service"
IMAGES_BASE = "https://images.frp1.ott.kaltura.com/Service.svc/GetImage"
OAUTH_BASE = "https://www.yettel.rs/nalog/api"
PARTNER_ID = 3200
CLIENT_TAG = "9.54.0-PC"
API_VERSION = "5.4.0"
OAUTH_CLIENT_ID = "tv-public"

#: Confirmed live: the account's own real "Yettel TV Box" entries carry this. 22 (PC web) and 32 (mobile)
#: are other clients' types and are untested for registration — a box-shaped client registers as 337.
DEVICE_BRAND_ID = 337

#: Brand ids seen in this household, for the device screen. A slot list that reads "337, 22, 32" tells
#: nobody which entry is the old laptop; an unknown id falls back to its number rather than guessing.
BRAND_NAMES = {22: "PC / web", 32: "telefon", 337: "TV box"}

#: The account's own PC-web device id, which has been in this household since long before this addon
#: existed. It is the default "borrow a session from something already registered" entry, needed because
#: talking to the household at all requires a session and a brand-new install has none. Overridable in
#: settings (`yettel_known_udid`) for any other account.
PC_WEB_UDID = "04638A2E2EAE5243"

#: Kaltura asset types. 601 is Linear TV; the rest are here because the numbering came from the
#: provider's own `configurations/serveByDevice` response and guessing at it later would be worse.
ASSET_LINEAR = "601"
#: The minted session, kept between processes. A tune ran anonymousLogin + startSession + a user lookup
#: before it could ask for the stream, every time, because the plugin process lives for one channel.
SESSION_CACHE = "yettel_session.json"
#: Kaltura does not say how long a ks lasts; this is deliberately short of any plausible answer, and a
#: stale one costs a single retried call rather than a failed tune (see _post).
SESSION_MAX_AGE = 6 * 3600
#: Kaltura's own codes for "this session is no good". Matched by CODE rather than by message, because
#: the message is a sentence that can be reworded in any release.
KS_ERROR_CODES = ("500015", "500016", "500004", "500017")
ASSET_MOVIE = "602"
ASSET_EPISODE = "603"
ASSET_SERIES = "604"

CHANNEL_PAGE_SIZE = 100
#: One page is plenty for a search: a remote-control list nobody scrolls past is not a better answer.
SEARCH_PAGE_SIZE = 60
#: How long the stored Video klub catalogue is trusted. A day: a store that gains a few titles
#: overnight is not a store anyone is waiting on, and the alternative is 17 seconds per screen.
VOD_CACHE_SECONDS = 24 * 3600
#: Bumped whenever the reduced shape changes, so an old file is ignored instead of misread.
VOD_CACHE_VERSION = 1
#: Rows per request while walking the Video klub. Kaltura caps the pager at 500 and ignores anything
#: larger, and 500 is measurably better per title than the 100 used for channels: one 500-row page takes
#: 1.36 s against 0.63 s for a 100-row one, so the same catalogue arrives in well under half the time.
#: Separate from CHANNEL_PAGE_SIZE on purpose — the channel path is proven and not worth disturbing.
VOD_FETCH_PAGE_SIZE = 500
CHANNEL_MAX_PAGES = 60
EPG_PAGE_SIZE = 100
#: Channel ids per batched guide request. Kaltura accepted the whole line-up in one call during testing,
#: so this is defensive rather than a known ceiling — it stops one request growing without bound.
EPG_CHANNEL_CHUNK = 80
#: Safety ceiling PER CHUNK, and the number itself is the lesson. On the Android side this was 4000,
#: chosen as "well above one channel's programmes" — but it is applied per chunk of 80 channels, where a
#: real window returns 6500-10800 rows. Results come back in chronological order ACROSS the whole chunk,
#: so truncating cut the window off before reaching "now": most channels silently had no current
#: programme and catch-up looked completely broken. Sized well above the highest figure ever measured.
EPG_MAX_PER_CHUNK = 40000

#: Catch-up needs the PROGRAMME's asset id, not an instant — Kaltura's START_OVER context is tied to a
#: programme. IPTV Simple can only give us a timestamp, so the guide's programme ids are written here at
#: refresh time and looked up at tune time. Same trick as EON's play cache, for the same reason.
EPG_INDEX = "yettel_epg.json"
#: How far back the guide reaches, and therefore how far catch-up can go.
CATCHUP_DAYS = 3

#: Fewest titles a genre needs to get its own row in the Video klub; the rest are folded together.
GENRE_MIN = 8
OTHER_GENRE = "Ostalo"


def _is_ks_error(data):
    """Whether a Kaltura answer is refusing the SESSION rather than the request. Read straight off the
    body, because _post has to decide before any caller has seen it."""
    try:
        code = str(((data or {}).get("result") or {}).get("error", {}).get("code") or "")
    except AttributeError:
        return False
    return code in KS_ERROR_CODES


@register
class YettelProvider(Provider):

    key = "yettel"
    label = "Yettel"
    supports_vod = True
    supports_search = True
    supports_devices = True
    can_free_device = True
    #: Yettel has no password — the app-token secret minted at pairing IS the credential, so it is what
    #: the vault has to protect. Every other provider keeps the base class's ("password",).
    secret_fields = ("app_token_secret",)
    default_identity = {
        # The reference web client's own string, reused verbatim and deliberately not varied per install:
        # several installs sharing one household device slot should look like one consistent client.
        "user_agent": ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                       "(KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36"),
        "extra_headers": {"Accept": "application/json"},
    }

    def __init__(self, settings):
        Provider.__init__(self, settings)
        self.session = net.Session(self.identity(), trace=settings.verbose())
        self.ks = ""
        self.user_id = ""
        #: True while login() is running, so the guard in _post cannot call it again from inside itself.
        self._logging_in = False
        #: Held while a session is being established or replaced — see the note in _post. Re-entrant,
        #: because the login chain makes its own _post calls on the thread that holds it.
        self._login_lock = threading.RLock()
        #: True when the session came off the disk. A KS error on one of those is worth one silent
        #: retry; the same error on a session minted seconds ago is the answer.
        self.session_restored = False

    # ---- transport --------------------------------------------------------

    def _post(self, action, body, _retried=False):
        """
        One Kaltura call — and the ONE place that guarantees there is a session behind it.

        Kaltura reports API-level failures INSIDE a 200 as `result.error`, so a bare status check proves
        nothing — every response goes through [_result], which is what turns a code like 1003 into
        something a caller can act on.

        TWO THINGS HAPPEN HERE THAT USED TO BE THE CALLER'S JOB, and the first was a real defect:

        * **a call whose body carries an empty `ks` logs in first.** Six entry points wrote
          `if not self.ks: self.login()` by hand and TWO — `channels()` and `epg()` — did not. They
          worked only because `catalog.build` happens to call `login()` before `channels()`, so the hole
          was invisible from the one path anybody exercised. Called any other way, Yettel answered
          `[500015] Invalid KS format`, which reads like a broken pairing and sends somebody to link
          their account again over a missing line of code. A guard that six callers must remember is a
          guard that the seventh will not — so it lives here, where the body is, once.
        * **a KS error on a RESTORED session is retried once, silently.** The session is cached between
          processes (see _load_session); the price of not proving it up front is that the first call may
          be the one that finds it dead.
        """
        # ONE LOGIN AT A TIME, both here and below. Up to `epg_workers` threads share this instance
        # while the guide is fetched, and "no ks yet, log in" is a test followed by an action with a
        # gap in between — so several workers starting together each began their own chain. The lock
        # closes the gap; the second check inside it means the ones that waited take the session the
        # first one established instead of making another.
        if (not self._logging_in and isinstance(body, dict)
                and "ks" in body and not body.get("ks")):
            with self._login_lock:
                if not self.ks and not self._logging_in:
                    self.login()
            body = dict(body, ks=self.ks)
        url = "%s/%s?format=1&clientTag=%s" % (BASE, action, CLIENT_TAG)
        payload = dict(body)
        payload.setdefault("clientTag", CLIENT_TAG)
        payload.setdefault("apiVersion", API_VERSION)
        data = self.session.post(url, body=json.dumps(payload),
                                 headers={"Content-Type": "application/json"})
        if (not _retried and self.session_restored and not self._logging_in
                and _is_ks_error(data)):
            with self._login_lock:
                if self.session_restored and not self._logging_in:
                    diag.log("Yettel: the stored session was refused — logging in again")
                    self.forget_session()
                    self.login()
            return self._post(action, dict(body, ks=self.ks), _retried=True)
        return data

    @staticmethod
    def _result(data, action):
        if not isinstance(data, dict):
            raise YettelError("", "Yettel %s: empty response" % action)
        result = data.get("result")
        if not isinstance(result, dict):
            raise YettelError("", "Yettel %s: no result in the response" % action)
        error = result.get("error")
        if isinstance(error, dict):
            raise YettelError(str(error.get("code") or ""),
                              "Yettel %s [%s]: %s" % (action, error.get("code"),
                                                      error.get("message") or "unknown error"))
        return result

    # ---- login ------------------------------------------------------------

    def device_id(self):
        """
        Yettel's device identity is its household `udid`, not the generic one the base class mints.

        Without this override the base helper ran anyway — anything that asks a provider for its device
        id got a freshly minted uuid, wrote it into settings and logged "paste it into another install
        to share the same device slot", which is advice for a value nothing here reads. Harmless, and
        exactly the kind of harmless that costs half an hour when someone believes the log.
        """
        return self.setting("udid").strip()

    def _anonymous_ks(self):
        data = self._post("ottuser/action/anonymousLogin",
                          {"language": "*", "partnerId": PARTNER_ID})
        return self._result(data, "anonymousLogin").get("ks") or ""

    def _session_path(self):
        return self.cache_path(SESSION_CACHE)

    def _load_session(self):
        """The stored session, or False. No probe — proving it costs the very round trip this saves, and
        `_post` already retries once when a restored session turns out to be dead."""
        try:
            with io.open(self._session_path(), "r", encoding="utf-8") as handle:
                data = json.loads(handle.read())
        except (OSError, IOError, ValueError):
            return False
        if not isinstance(data, dict) or time.time() >= (data.get("expires_at") or 0):
            return False
        # Bound to the household device this session was minted for: borrowing another udid is a normal
        # thing here (see _join_household), and a session for a different one is not ours to reuse.
        if data.get("udid") != self.setting("udid").strip():
            return False
        if not data.get("ks"):
            return False
        self.ks = data["ks"]
        self.user_id = data.get("user_id") or ""
        self.session_restored = True
        return True

    def _store_session(self):
        payload = {"udid": self.setting("udid").strip(), "expires_at": time.time() + SESSION_MAX_AGE,
                   "ks": self.ks, "user_id": self.user_id}
        try:
            with io.open(self._session_path(), "w", encoding="utf-8") as handle:
                handle.write(json.dumps(payload, ensure_ascii=False))
        except (OSError, IOError, ValueError) as err:
            diag.log("Yettel: the session could not be stored (%s) — the next tune logs in again" % err)

    def forget_session(self):
        try:
            os.remove(self._session_path())
        except OSError:
            pass
        self.ks = ""
        self.user_id = ""
        self.session_restored = False

    def login(self):
        """
        Mint a session from the stored app-token. No credentials, no SMS, no user interaction.

        The token hash is `SHA256(anonymousKs + appTokenSecret)` — that order, confirmed by trial; the
        other way round is refused with `50022 app token is not valid`, which reads like a bad token
        rather than a bad recipe and would send anyone re-pairing for no reason.
        """
        if self._load_session():
            diag.log("Yettel: reusing the stored session (device %s…)"
                     % (self.setting("udid").strip()[:8] or "?"))
            return
        self._logging_in = True
        try:
            self._login_now()
        finally:
            self._logging_in = False

    def _login_now(self):
        token_id = self.setting("app_token_id").strip()
        secret = self.setting("app_token_secret").strip()
        udid = self.setting("udid").strip()
        if not token_id or not secret:
            raise ProviderError(
                "Yettel: nalog nije povezan. Otvori Add-ons -> IPTV Balkan -> 'Poveži Yettel nalog' i "
                "prati kod na ekranu — to se radi jednom.")
        if not udid:
            # Generated once and written back. A fresh udid per launch would register a new household
            # device every time and fill the account's slots.
            udid = str(uuid.uuid4()).upper()
            self.remember("udid", udid)
            diag.log("Yettel: minted a device id for this install (%s…)" % udid[:8])

        anon = self._anonymous_ks()
        if not anon:
            raise ProviderError("Yettel: anonimna prijava nije vratila sesiju.")
        token_hash = hashlib.sha256((anon + secret).encode("utf-8")).hexdigest()
        try:
            data = self._post("apptoken/action/startSession",
                              {"id": token_id, "tokenHash": token_hash, "ks": anon, "udid": udid})
            self.ks = self._result(data, "apptoken/action/startSession").get("ks") or ""
        except YettelError as err:
            if err.code == "1003":
                # The token is fine; this install's device id is simply not in the household. Adding it
                # is one call — unless the slots are full, and on a real account they usually are. Then
                # an existing device id is borrowed instead, which costs nothing and disturbs nothing:
                # opening a session against a registered udid does not evict or interrupt whatever that
                # device is doing.
                udid = self._join_household(anon, token_id, secret, udid)
                token_hash = hashlib.sha256((anon + secret).encode("utf-8")).hexdigest()
                data = self._post("apptoken/action/startSession",
                                  {"id": token_id, "tokenHash": token_hash, "ks": anon, "udid": udid})
                self.ks = self._result(data, "apptoken/action/startSession").get("ks") or ""
            elif err.code == "500055":
                raise ProviderError(
                    "Yettel: veza sa nalogom je istekla (token je poništen). Poveži nalog ponovo: "
                    "Add-ons -> IPTV Balkan -> 'Poveži Yettel nalog'.")
            else:
                raise ProviderError(err.message)
        if not self.ks:
            raise ProviderError("Yettel: prijava nije vratila sesiju.")
        self.user_id = self._user_id()
        self.session_restored = False
        diag.log("Yettel: logged in (user %s, device %s…)" % (self.user_id, udid[:8]))
        self._store_session()

    def _join_household(self, anon_ks, token_id, secret, udid):
        """
        Get this install a device id the household accepts, and return it.

        Adding our own is preferred and is what an account with a free slot gets. When there is no free
        slot the add is refused, and rather than stopping there an existing device id is adopted — the
        session that follows works exactly the same and the real device keeps working untouched. The
        chosen id is written back so the next launch goes straight through.

        A session is needed to talk to the household at all, and we have none — the one thing that
        always opens is the app-token against a device that IS registered, which is what
        `yettel_known_udid` is for. It defaults to the PC-web entry this account has had all along.
        """
        borrow_from = self.setting("known_udid").strip() or PC_WEB_UDID
        hash_for = hashlib.sha256((anon_ks + secret).encode("utf-8")).hexdigest()
        try:
            data = self._post("apptoken/action/startSession",
                              {"id": token_id, "tokenHash": hash_for, "ks": anon_ks,
                               "udid": borrow_from})
            ks = self._result(data, "apptoken/action/startSession").get("ks") or ""
        except (YettelError, net.HttpError) as err:
            raise ProviderError(
                "Yettel: ovaj uređaj nije u domaćinstvu, a nijedan poznat uređaj nije prihvaćen da ga "
                "doda (%s). Upiši u podešavanja ID nekog uređaja koji je već u domaćinstvu, ili poveži "
                "nalog ponovo." % err)

        try:
            self._post("householddevice/action/add", {
                "ks": ks,
                "device": {"objectType": "KalturaHouseholdDevice", "udid": udid,
                           "name": "IPTV Balkan", "brandId": DEVICE_BRAND_ID},
            })
            diag.log("Yettel: registered this install as a household device")
            return udid
        except (YettelError, net.HttpError) as err:
            adopted = _borrow_household_udid(
                lambda action, body: self._result(self._post(action, body), action), ks)
            if not adopted:
                raise ProviderError(
                    "Yettel: nema slobodnog mesta za nov uređaj (%s), a nijedan postojeći nije nađen "
                    "da se pozajmi." % err)
            self.remember("udid", adopted)
            diag.log("Yettel: no free device slot — adopted the existing device %s…" % adopted[:8])
            return adopted

    def _user_id(self):
        try:
            data = self._post("ottuser/action/get", {"ks": self.ks})
            return str(self._result(data, "ottuser/action/get").get("id") or "")
        except (YettelError, net.HttpError):
            return ""

    # ---- catalogue --------------------------------------------------------

    def channels(self):
        out = []
        page = 1
        while page <= CHANNEL_MAX_PAGES:
            data = self._post("asset/action/list", {
                "ks": self.ks,
                "filter": {"objectType": "KalturaSearchAssetFilter",
                           "kSql": "(and asset_type='%s')" % ASSET_LINEAR},
                "pager": {"objectType": "KalturaFilterPager", "pageIndex": page,
                          "pageSize": CHANNEL_PAGE_SIZE},
            })
            items = self._result(data, "asset/action/list").get("objects") or []
            if not items:
                break
            for asset in items:
                entry = self._channel_from(asset, len(out) + 1)
                if entry:
                    out.append(entry)
            if len(items) < CHANNEL_PAGE_SIZE:
                break
            page += 1
        if not out:
            raise ProviderError("Yettel: lista kanala je stigla prazna.")
        diag.log("Yettel: %d channels" % len(out))
        return out

    def _channel_from(self, asset, fallback_number):
        asset_id = str(asset.get("id") or "")
        if not asset_id:
            return None
        return {
            "id": self.scoped("yettel_%s" % asset_id),
            "tvg_id": self.scoped("yettel_%s" % asset_id),
            "provider_ref": asset_id,
            "name": asset.get("name") or ("Channel %s" % asset_id),
            "number": _channel_number(asset, fallback_number),
            "group": _genre_of(asset),
            "logo": _image_url(asset.get("images")),
            "url": ("plugin://plugin.video.iptvbalkan/?action=play&provider=yettel&id=%s%s"
                    % (asset_id, self._account_param())),
            # Every channel is offered as catch-up capable. The provider does expose per-channel
            # enableCatchUp flags, but they read `true` even on channels this account cannot watch at
            # all, so they are not an entitlement signal — the honest gate is the play-time answer.
            "catchup_days": CATCHUP_DAYS,
            "catchup_source": ("plugin://plugin.video.iptvbalkan/?action=play&provider=yettel"
                               "&id=%s&utc={utc}" % asset_id),
            # `vod`, for the same reason Iris uses it: resolve() now asks Kaltura for the CATCHUP
            # context, which answers a STATIC manifest bounded to the programme. With `default` IPTV
            # Simple would re-request our `plugin://` source on every nudge of the bar — re-entering the
            # addon, re-running getPlaybackContext and re-negotiating Widevine — so playback restarted
            # instead of moving. One resolve, and the player seeks inside the manifest it already has.
            "catchup_mode": "vod",
            # And the bar itself: without this Kodi throws the EPG tag away and plays the channel live,
            # so the overlay is a rolling window rather than the programme's own length. The cost is the
            # PVR overlay during a replay, which is the same trade Iris makes and is the owner's setting
            # (archive_exact_bar) rather than ours.
            "catchup_play_as_live": False,
            "provider_label": self.label,
        }

    def epg(self, channels, hours_back=None, hours_forward=None):
        """
        The guide for EVERY channel in batched calls — one request per 80 channels, not per channel.

        The programme ids are kept as well as written out: catch-up on this platform addresses a
        PROGRAMME, and by tune time all IPTV Simple can tell us is a timestamp.
        """
        hours_back = CATCHUP_DAYS * 24 if hours_back is None else hours_back
        hours_forward = 48 if hours_forward is None else hours_forward
        now = int(time.time())
        start, end = now - hours_back * 3600, now + hours_forward * 3600

        refs = [c["provider_ref"] for c in channels if c.get("provider_ref")]
        chunks = [refs[offset:offset + EPG_CHANNEL_CHUNK]
                  for offset in range(0, len(refs), EPG_CHANNEL_CHUNK)]
        out, index = [], {}

        # A FEW CHUNKS AT ONCE. Batching already made this one request per eighty channels rather than
        # per channel — but each of those requests is enormous and slow (measured on the owner's box:
        # 204 seconds for 244 channels, i.e. about fifty seconds each), and they do not depend on one
        # another. Running a few in parallel is the only thing left that shortens it.
        #
        # Order is preserved by index rather than by arrival, and each worker fills its OWN programme
        # index which is merged here in order — the merged file is what catch-up looks a programme up
        # in at tune time, so "whichever finished last wins" is not an acceptable way to build it.
        # Ceiling raised 8 -> 12 and the default 4 -> 8 together with settings.xml: the guide is
        # where the minutes go, and on a four-account box EON alone spent 466s of its 480s
        # budget. Both numbers live in two places, so they move in two places.
        # FOUR, AND THE CEILING IS TWELVE. The default went 4 -> 8 on the theory that "four parallel
        # requests leave the connection mostly idle". Measured on the owner's box, same build, same
        # account, one variable changed:
        #
        #     4 workers -> EON 449 s      8 workers -> EON 479 s
        #
        # and the request log says why: at 4 the box was already moving 0.69 requests a second, and at 8
        # it moved 0.69 a second with each request taking twice as long. The link was never idle — EON's
        # guide is ~353 KB per channel over 302 channels, about 107 MB, and that is the whole 449 s at
        # roughly 240 KB/s. Concurrency cannot buy anything that bandwidth is already spending.
        #
        # The ceiling stays at 12 so a box on a fatter connection can still be told to try. Boxes that
        # already had this raised to 8 are LEFT there rather than migrated back: the difference is small,
        # and a setting that flips between releases is worse than a setting that is slightly wrong.
        workers = max(1, min(12, self.settings.get_int("epg_workers", 4)))
        results, threads = {}, []
        pending = list(enumerate(chunks))

        def fetch(position, chunk):
            own = {}
            try:
                results[position] = (self._epg_chunk(chunk, start, end, own), own, None)
            except Exception as err:                               # noqa: BLE001 - re-raised below
                results[position] = ([], {}, err)

        while pending:
            if self.stopping():
                diag.log("Yettel: Kodi is closing — the guide stops after %d/%d channels"
                         % (len(results) * EPG_CHANNEL_CHUNK, len(refs)))
                break
            window, pending = pending[:workers], pending[workers:]
            threads = [threading.Thread(target=fetch, args=(position, chunk))
                       for position, chunk in window]
            for thread in threads:
                thread.daemon = True            # never hold Kodi's shutdown on a guide request
                thread.start()
            for thread in threads:
                thread.join()

        for position in sorted(results):
            programmes, own, err = results[position]
            if err is not None:
                # One bad chunk is eighty channels without a guide, not a failed refresh — the same
                # judgement the sequential version made by letting _epg_chunk swallow its own errors.
                diag.log("Yettel: a guide batch failed (%s) — those channels have no programmes this "
                         "round" % err, "ERROR")
                continue
            out.extend(programmes)
            index.update(own)
        _write_json(self._cache_path(EPG_INDEX), index)
        diag.log("Yettel: %d programmes over %d channels" % (len(out), len(refs)))
        return out

    def _epg_chunk(self, refs, start, end, index):
        out = []
        page, seen = 1, 0
        ksql = ("(and linear_media_id:'%s' end_date >= '%d' start_date <= '%d' "
                "asset_type='epg' auto_fill= true)" % (",".join(refs), start, end))
        while seen < EPG_MAX_PER_CHUNK:
            try:
                data = self._post("asset/action/list", {
                    "ks": self.ks,
                    "filter": {"objectType": "KalturaSearchAssetFilter",
                               "orderBy": "START_DATE_ASC", "kSql": ksql},
                    "pager": {"objectType": "KalturaFilterPager", "pageSize": EPG_PAGE_SIZE,
                              "pageIndex": page},
                })
                items = self._result(data, "asset/action/list").get("objects") or []
            except (YettelError, net.HttpError) as err:
                # One chunk failing costs those channels their guide, not the whole refresh.
                diag.log("Yettel: guide chunk failed (%s)" % err, "ERROR")
                break
            if not items:
                break
            for entry in items:
                programme = self._programme_from(entry, index)
                if programme:
                    out.append(programme)
            seen += len(items)
            if len(items) < EPG_PAGE_SIZE:
                break
            page += 1
        return out

    def _programme_from(self, entry, index):
        linear = entry.get("linearAssetIds") or []
        channel_ref = str(linear[0]) if linear else str(entry.get("linearAssetId") or "")
        start = int(entry.get("startDate") or 0)
        end = int(entry.get("endDate") or 0)
        title = entry.get("name") or ""
        if not channel_ref or start <= 0 or end <= 0 or not title:
            return None
        programme_id = str(entry.get("id") or "")
        if programme_id:
            index.setdefault(channel_ref, []).append([start, end, programme_id])
        return {
            "channel_id": self.scoped("yettel_%s" % channel_ref),
            "start": time.strftime("%Y%m%d%H%M%S +0000", time.gmtime(start)),
            "stop": time.strftime("%Y%m%d%H%M%S +0000", time.gmtime(end)),
            "title": title,
            "desc": entry.get("description") or "",
            "icon": _image_url(entry.get("images")),
        }

    # ---- on demand --------------------------------------------------------

    def vod(self, node=None):
        """
        The Video klub, three levels deep: kind -> genre -> title (and a series opens into episodes).

        Genres come from the SAME `tags.Genre` the live channels use, so "Filmovi: Akcija" reads the way
        the provider's own app does. The catalogue is fetched once per level and cached for the session,
        because a Kaltura page is 100 rows and this library runs to thousands — walking it again for
        every genre a user opens would make the screen feel broken.
        """
        if not self.ks:
            self.login()
        node = node or ""
        if not node:
            return [{"kind": "dir", "name": T("Filmovi"), "node": "kind:%s" % ASSET_MOVIE},
                    {"kind": "dir", "name": T("Serije"), "node": "kind:%s" % ASSET_SERIES}]

        if node.startswith("kind:"):
            asset_type = node.split(":", 1)[1]
            groups = {}
            for asset in self._vod_assets(asset_type):
                genre = asset.get("genre") or OTHER_GENRE
                groups[genre] = groups.get(genre, 0) + 1
            # This catalogue carries 135 film genres and 174 series genres, most of them with a handful
            # of titles — sorted alphabetically that is a wall nobody reads. Biggest first, and anything
            # under a handful folded into one bucket at the end: the genres a person actually browses
            # sit at the top, and nothing is hidden.
            big = sorted(((g, n) for g, n in groups.items() if n >= GENRE_MIN and g != OTHER_GENRE),
                         key=lambda pair: (-pair[1], pair[0].lower()))
            small = sum(n for g, n in groups.items() if n < GENRE_MIN or g == OTHER_GENRE)
            out = [{"kind": "dir", "name": "%s (%d)" % (genre, count),
                    "node": "genre:%s:%s" % (asset_type, genre)} for genre, count in big]
            if small:
                # The LABEL is translated, the node is not: that string is this bucket's identity and
                # travels back in the next request, so a translated node would stop matching.
                out.append({"kind": "dir", "name": "%s (%d)" % (T(OTHER_GENRE), small),
                            "node": "genre:%s:%s" % (asset_type, OTHER_GENRE)})
            return out

        if node.startswith("genre:"):
            _, asset_type, genre = node.split(":", 2)
            series = asset_type == ASSET_SERIES
            # The catch-all bucket is defined by what it is NOT: everything whose own genre was too
            # small to earn a row of its own. Computed the same way the list above computed it, so a
            # title can never fall between the two.
            counts = {}
            for asset in self._vod_assets(asset_type):
                key = asset.get("genre") or OTHER_GENRE
                counts[key] = counts.get(key, 0) + 1
            out = []
            for asset in self._vod_assets(asset_type):
                own = asset.get("genre") or OTHER_GENRE
                if genre == OTHER_GENRE:
                    if own != OTHER_GENRE and counts.get(own, 0) >= GENRE_MIN:
                        continue
                elif own != genre:
                    continue
                asset_id = asset.get("id") or ""
                entry = {"kind": "dir" if series else "item",
                         "name": asset.get("name") or asset_id,
                         "logo": asset.get("logo") or "",
                         "plot": asset.get("plot") or ""}
                if series:
                    entry["node"] = "series:%s" % asset_id
                else:
                    entry["id"] = asset_id
                out.append(entry)
            return sorted(out, key=lambda e: e["name"].lower())

        if node.startswith("series:"):
            return self._episodes(node.split(":", 1)[1])
        return []

    def search(self, term):
        """
        Kaltura answers a title search in one request, so this never walks the catalogue.

        The type restriction is a `typeIn` on the FILTER, not a term in the KSQL. Kaltura rejects
        `asset_type` as a KSQL key here (error 4002, "Invalid search value or operator"), and without
        the restriction the reply is dominated by guide entries — a bare `name ~ 'ratovi'` answers 497
        objects, all of them KalturaProgramAsset, one show repeated across every airing, with the two
        actual films buried pages deep. With `typeIn` the same query answers those two and nothing
        else. Films and series in one request, which is what a person typing a title wants.
        """
        if not self.ks:
            self.login()
        # A quote would end the KSQL string and change the query into something else entirely; the
        # backend has no placeholder syntax to bind through, so the character simply cannot be sent.
        cleaned = re.sub(r"['\\\"]", " ", term or "").strip()
        if not cleaned:
            return []
        data = self._post("asset/action/list", {
            "ks": self.ks,
            "filter": {"objectType": "KalturaSearchAssetFilter", "kSql": "name ~ '%s'" % cleaned,
                       "typeIn": "%s,%s" % (ASSET_MOVIE, ASSET_SERIES)},
            "pager": {"objectType": "KalturaFilterPager", "pageIndex": 1,
                      "pageSize": SEARCH_PAGE_SIZE},
        })
        out = []
        for asset in self._result(data, "asset/action/list").get("objects") or []:
            asset_id = str(asset.get("id") or "")
            if not asset_id:
                continue
            asset_type = str(asset.get("type") or "")
            # Live channels come back from the same query and are not the Video klub's business — the
            # channel search already covers them, from a local file and without a request.
            if asset_type not in (ASSET_MOVIE, ASSET_SERIES):
                continue
            series = asset_type == ASSET_SERIES
            entry = {"kind": "dir" if series else "item",
                     "name": asset.get("name") or asset_id,
                     "logo": _image_url(asset.get("images")),
                     "plot": _meta_text(asset, "ShortSummary")}
            if series:
                entry["node"] = "series:%s" % asset_id
            else:
                entry["id"] = asset_id
            out.append(entry)
        diag.log("Yettel: search %r -> %d titles" % (term, len(out)))
        return out

    def _vod_assets(self, asset_type):
        """
        Every title of one type, reduced to the five fields the Video klub needs, cached ON DISK.

        The whole catalogue really is needed: genres are counted across all of it to decide which earn
        a row and which fold into "Ostalo", and a count taken from a partial list would move titles
        between screens. What is NOT acceptable is paying for it repeatedly — measured live, "Filmovi"
        took 17 seconds and opening a genre inside it took 17 seconds AGAIN, because the cache lived on
        the provider instance and the plugin process ends after every screen. So it lives beside the
        playlist instead, and only the first screen of the day pays.

        Reduced rather than stored whole: a Kaltura asset carries dozens of fields and image variants,
        and writing thousands of them would put megabytes on a TV box's flash to answer five questions.
        """
        cached = getattr(self, "_vod_cache", None) or {}
        if asset_type in cached:
            return cached[asset_type]

        on_disk = self._read_vod_cache(asset_type)
        if on_disk is not None:
            cached[asset_type] = on_disk
            self._vod_cache = cached
            return on_disk

        out, page = [], 1
        while page <= CHANNEL_MAX_PAGES:
            try:
                data = self._post("asset/action/list", {
                    "ks": self.ks,
                    "filter": {"objectType": "KalturaSearchAssetFilter",
                               "kSql": "(and asset_type='%s')" % asset_type},
                    "pager": {"objectType": "KalturaFilterPager", "pageIndex": page,
                              "pageSize": VOD_FETCH_PAGE_SIZE},
                })
                items = self._result(data, "asset/action/list").get("objects") or []
            except (YettelError, net.HttpError) as err:
                # A partial catalogue is what a network blip on page 7 of 40 leaves behind, and in
                # silence it is indistinguishable from a provider who simply offers that much. Say so.
                diag.log("Yettel: VOD (type %s) stopped at page %d with %d titles — %s"
                         % (asset_type, page, len(out), err), "ERROR")
                break
            if not items:
                break
            for asset in items:
                asset_id = str((asset or {}).get("id") or "")
                if not asset_id:
                    continue
                out.append({"id": asset_id,
                            "name": asset.get("name") or asset_id,
                            "genre": _genre_of(asset),
                            "logo": _image_url(asset.get("images")),
                            "plot": _meta_text(asset, "ShortSummary")})
            if len(items) < VOD_FETCH_PAGE_SIZE:
                break
            page += 1
        cached[asset_type] = out
        self._vod_cache = cached
        # Only a catalogue that finished is written. A run cut short by a network blip would otherwise
        # be cached as the truth for a day, and the missing half would look like titles the account
        # does not have.
        if page <= CHANNEL_MAX_PAGES:
            self._write_vod_cache(asset_type, out)
        diag.log("Yettel: VOD type %s — %d titles" % (asset_type, len(out)))
        return out

    def _vod_cache_path(self, asset_type):
        return self.cache_path("yettel_vod_%s.json" % asset_type)

    def _read_vod_cache(self, asset_type):
        """The stored catalogue if it is still fresh, else None."""
        try:
            with open(self._vod_cache_path(asset_type), "r", encoding="utf-8") as handle:
                blob = json.loads(handle.read())
        except (OSError, IOError, ValueError):
            return None
        if not isinstance(blob, dict) or blob.get("v") != VOD_CACHE_VERSION:
            return None
        if int(time.time()) - int(blob.get("at") or 0) > VOD_CACHE_SECONDS:
            return None
        titles = blob.get("titles")
        return titles if isinstance(titles, list) else None

    def _write_vod_cache(self, asset_type, titles):
        try:
            with open(self._vod_cache_path(asset_type), "w", encoding="utf-8") as handle:
                handle.write(json.dumps({"v": VOD_CACHE_VERSION, "at": int(time.time()),
                                         "titles": titles}, ensure_ascii=False))
        except (OSError, IOError, ValueError) as err:
            diag.log("Yettel: could not store the VOD catalogue (%s)" % err, "ERROR")

    def _episodes(self, series_asset_id):
        """
        Every episode of one series, in season/episode order.

        The link is NOT the numeric asset id: a series carries `metas.SeriesID` (a provider string like
        "VOYO_RTL Direkt") and every one of its episodes carries the same string in its own metas. Note
        the detail call wants `assetReferenceType`, not `assetType` — the same word in a different shape
        than `getPlaybackContext` uses, and getting it wrong answers "missing parameter".
        """
        detail = self._post("asset/action/get", {"ks": self.ks, "id": series_asset_id,
                                                 "assetReferenceType": "media"})
        series_id = _meta_text(self._result(detail, "asset/action/get"), "SeriesID")
        if not series_id:
            return []
        out, page = [], 1
        while page <= CHANNEL_MAX_PAGES:
            data = self._post("asset/action/list", {
                "ks": self.ks,
                "filter": {"objectType": "KalturaSearchAssetFilter",
                           "kSql": "(and asset_type='%s' SeriesID='%s')"
                                   % (ASSET_EPISODE, series_id.replace("'", "\\'"))},
                "pager": {"objectType": "KalturaFilterPager", "pageIndex": page,
                          "pageSize": CHANNEL_PAGE_SIZE},
            })
            items = self._result(data, "asset/action/list").get("objects") or []
            if not items:
                break
            for asset in items:
                asset_id = str(asset.get("id") or "")
                if not asset_id:
                    continue
                season = _meta_number(asset, "SeasonNumber", 1)
                number = _meta_number(asset, "EpisodeNumber", len(out) + 1)
                out.append({"kind": "item", "id": asset_id,
                            "name": "%dx%02d  %s" % (season, number,
                                                     asset.get("name") or ("Epizoda %d" % number)),
                            "logo": _image_url(asset.get("images")),
                            "plot": _meta_text(asset, "ShortSummary"),
                            "_sort": (season, number)})
            if len(items) < CHANNEL_PAGE_SIZE:
                break
            page += 1
        # A series with no episodes is a real gap in this catalogue, not a wrong query — confirmed on at
        # least one real title. It stays empty rather than being retried in another shape.
        return sorted(out, key=lambda e: e.pop("_sort"))

    # ---- playback ---------------------------------------------------------

    def _cache_path(self, name):
        return self.cache_path(name)

    def _programme_at(self, channel_ref, at_utc):
        """Which programme covers [at_utc] on this channel — catch-up addresses a programme, not a moment."""
        wanted = int(at_utc)
        for start, end, programme_id in _read_json(self._cache_path(EPG_INDEX)).get(str(channel_ref)) or []:
            if start <= wanted < end:
                return programme_id
        return ""

    def resolve(self, channel_ref, at_utc=None, vod=False):
        if not self.ks:
            self.login()
        asset_id, asset_type, context = str(channel_ref), "media", "PLAYBACK"
        if vod:
            # An on-demand title is the same call as a live channel with the title's own asset id — the
            # platform makes no distinction, which is why there is one resolver here and not two.
            at_utc = None
        elif at_utc:
            programme_id = self._programme_at(channel_ref, at_utc)
            if not programme_id:
                raise ProviderError(
                    "Yettel: za taj trenutak nema emisije u vodiču, pa nema šta da se premota. "
                    "Osveži vodič pa probaj ponovo.")
            # CATCHUP, not START_OVER — and the difference is the whole seek bar.
            #
            # Both address the same programme and both play. START_OVER answers with a DYNAMIC manifest
            # carrying no mediaPresentationDuration: a live-shaped stream, so Kodi draws a live-shaped
            # bar (a rolling window, not the programme) and seeking inside it does nothing. CATCHUP
            # answers the SAME programme with a STATIC manifest that Kaltura bounds itself — it appends
            # its own `end=` beside `begin=` — and it carries the real duration.
            #
            # Measured on the live account, one hour back on TV Mačva:
            #     START_OVER -> dynamic, no duration
            #     CATCHUP    -> static,  mediaPresentationDuration="PT2H1.920S"
            #
            # Reported as "the timeline is not relevant, like Iris had". It is the same fault and this is
            # the same fix at its root: give the player a finite timeline instead of teaching it to
            # pretend. Iris needed `catchup="vod"` for it; so does this — see playlist.py.
            asset_id, asset_type, context = programme_id, "epg", "CATCHUP"

        data = self._post("asset/action/getPlaybackContext", {
            "ks": self.ks,
            "assetId": int(asset_id) if asset_id.isdigit() else asset_id,
            "assetType": asset_type,
            "contextDataParams": {
                "objectType": "KalturaPlaybackContextOptions",
                "context": context,
                "streamerType": "mpegdash",
                "urlType": "DIRECT",
                "adapterData": {"codec": {"value": "AVC"}, "DRM": {"value": "true"},
                                "quality": {"value": "UHD"}},
            },
        })
        result = self._result(data, "asset/action/getPlaybackContext")

        # Kaltura says "you cannot watch this" by answering 200 with an empty sources[] and a BLOCK
        # action — it is an answer, not a failure, and reading it is the difference between telling the
        # user "nije u tvom paketu" and shrugging at them.
        actions = result.get("actions") or []
        if any((a or {}).get("type") == "BLOCK" for a in actions):
            message = (result.get("messages") or [{}])[0] or {}
            raise ProviderError(_blocked_message(str(message.get("code") or ""),
                                                 message.get("message") or "", vod))

        stream, licence_url = "", ""
        for source in result.get("sources") or []:
            if (source or {}).get("format") != "mpegdash":
                continue
            stream = source.get("url") or ""
            for drm in source.get("drm") or []:
                if (drm or {}).get("scheme") == "WIDEVINE_CENC":
                    licence_url = drm.get("licenseURL") or ""
                    break
            if stream:
                break
        if not stream:
            raise ProviderError("Yettel: server nije vratio adresu strima za taj kanal.")

        resolved = {"url": stream, "manifest_type": "mpd",
                    "headers": {"User-Agent": self.identity().get("user_agent", "")}}
        if context == "CATCHUP":
            # NOT A SLIDING WINDOW, said out loud rather than left to be inferred.
            #
            # default.py sends a catch-up stream to ffmpegdirect in timeshift mode, which buffers a LIVE
            # window to disk — and FFmpeg cannot make a growing buffer out of a finished file, so a
            # static manifest handed to it fails at OpenInputStream and NOTHING plays. That is how Move
            # was broken. This provider escaped it only because `not licence_key` happened to exclude a
            # DRM-protected stream, and that is luck, not a rule: the loop above sets licence_key only
            # when the source advertises WIDEVINE_CENC, so one channel served without DRM would have hit
            # exactly the same wall. What decides this is the SHAPE of the stream, and the shape is
            # known here.
            # CATCHUP answers with a STATIC manifest carrying the real mediaPresentationDuration —
            # measured on the live account and written up a few lines above. Static is precisely
            # what timeshift mode cannot open.
            resolved["timeshift"] = False
        if licence_url:
            resolved["license_type"] = "com.widevine.alpha"
            # Unlike Iris, the licence URL already carries its own `custom_data` as a query parameter —
            # there is no JWT to smuggle in a request header, so the key is just url|headers|challenge|.
            resolved["license_key"] = "%s|Content-Type=application/octet-stream|R{SSM}|" % licence_url
        return resolved

    # ---- diagnostics ------------------------------------------------------

    # ---- device slots -----------------------------------------------------

    def devices(self):
        """
        The household's registered devices.

        Yettel is the only one of the three that lets a client free a slot; EON releases one a month
        from its own portal and Iris will list them but not remove them. That difference is why the
        screen asks the provider rather than assuming.
        """
        if not self.ks:
            self.login()
        result = self._result(self._post("householddevice/action/list", {"ks": self.ks}),
                              "householddevice/action/list")
        mine = (self.setting("udid") or "").strip()
        out = []
        for entry in result.get("objects") or []:
            if not isinstance(entry, dict):
                continue
            udid = str(entry.get("udid") or "")
            if not udid:
                continue
            bits = []
            brand = BRAND_NAMES.get(int(entry.get("brandId") or 0))
            if brand:
                bits.append(brand)
            status = str(entry.get("status") or "")
            if status and status != "ACTIVATED":
                bits.append(status.lower())
            activated = entry.get("activatedOn")
            if activated:
                bits.append("od %s" % time.strftime("%d.%m.%Y.", time.localtime(int(activated))))
            out.append({
                "id": udid,
                "name": (entry.get("name") or "").strip() or udid,
                "detail": ", ".join(bits),
                "current": bool(mine) and udid == mine,
            })
        return out

    def free_device(self, device_id):
        if not self.ks:
            self.login()
        self._result(self._post("householddevice/action/delete",
                                {"ks": self.ks, "udid": str(device_id)}),
                     "householddevice/action/delete")
        return True

    def diagnose(self):
        rows = []
        token_id = self.setting("app_token_id").strip()
        rows.append(("Account linked", bool(token_id),
                     "app-token stored" if token_id else "not paired yet — run 'Poveži Yettel nalog'"))
        if not token_id:
            return rows
        rows.append(("Device id", bool(self.setting("udid").strip()),
                     self.setting("udid").strip()[:12] or "will be minted on first login"))
        try:
            self.login()
            rows.append(("Session", True, "user %s" % (self.user_id or "?")))
        except ProviderError as err:
            rows.append(("Session", False, err.message))
            return rows
        try:
            channels = self.channels()
            rows.append(("Channel list", bool(channels), "%d channels" % len(channels)))
        except Exception as err:                                   # noqa: BLE001
            rows.append(("Channel list", False, "%s: %s" % (type(err).__name__, err)))
        return rows


class YettelError(ProviderError):
    """
    A Kaltura `result.error`, carrying its own code so `1003` (device not in household) and `500055`
    (the app-token's whole session lineage was invalidated) can be told apart from a generic failure.

    A ProviderError, and that is a FIX rather than tidiness. It descended from plain Exception, so every
    `except (ProviderError, net.HttpError)` in the addon — the convention for "a failure the user can act
    on" — walked straight past it. Seen live 2026-08-02: Kaltura answered the pairing login with its own
    internal crash ("runtime error: invalid memory address or nil pointer dereference"), the error left
    `complete_pairing` uncaught, and instead of a dialog the owner got a Python traceback and "Script
    failed" — after having already approved the one-time code, which is then spent. Catching it at that
    one call site would have left the same hole everywhere else it is raised.
    """

    def __init__(self, code, message):
        ProviderError.__init__(self, message)
        self.code = str(code or "")


def _blocked_message(code, message, vod=False):
    """Kaltura's own reason, turned into something a viewer can act on."""
    what = "naslov" if vod else "kanal"
    if code == "NotEntitled":
        return "Yettel: taj %s nije uključen u tvoj paket." % what
    if code == "NoFilesFound":
        return "Yettel: za taj naslov ne postoji fajl kod provajdera."
    return "Yettel: nije dostupno%s" % ((" — %s" % message) if message else "")


def _genre_of(asset):
    """
    `tags.Genre` — the real grouping signal, on every channel and every VOD title.

    Not `categorytree/action/getByVersion`, which looks like a taxonomy and is actually the app's
    homepage menu (hero and collection widgets) with no channel linkage in it at all. An earlier version
    of the Android client read that and produced zero groups.
    """
    try:
        objects = ((asset.get("tags") or {}).get("Genre") or {}).get("objects") or []
        return str((objects[0] or {}).get("value") or "") if objects else ""
    except (AttributeError, IndexError, TypeError):
        return ""


def _meta_text(asset, key):
    """A `metas.<key>.value` string, or "" — Kaltura wraps every meta in its own typed object."""
    try:
        return str(((asset.get("metas") or {}).get(key) or {}).get("value") or "")
    except AttributeError:
        return ""


def _meta_number(asset, key, fallback):
    try:
        return int(float(((asset.get("metas") or {}).get(key) or {}).get("value")))
    except (AttributeError, TypeError, ValueError):
        return fallback


def _channel_number(asset, fallback):
    """`metas.Lcn`, or `ChannelNumber` — the provider's own numbering, so the list reads like the
    official app rather than like whatever order the API answered in."""
    metas = asset.get("metas") or {}
    for key in ("Lcn", "ChannelNumber"):
        try:
            value = int((metas.get(key) or {}).get("value") or 0)
        except (TypeError, ValueError):
            value = 0
        if value > 0:
            return value
    return fallback


def _image_url(images):
    if not images:
        return ""
    first = images[0] if isinstance(images, list) else None
    if not isinstance(first, dict):
        return ""
    image_id = str(first.get("id") or "")
    if not image_id:
        return ""
    return "%s/p/%d/entry_id/%s/version/%s/width/0/height/0" % (
        IMAGES_BASE, PARTNER_ID, image_id, first.get("version", 0))


def _read_json(path):
    try:
        with open(path, "r", encoding="utf-8") as handle:
            data = json.loads(handle.read())
        return data if isinstance(data, dict) else {}
    except (OSError, IOError, ValueError):
        return {}


def _write_json(path, data):
    try:
        with open(path, "w", encoding="utf-8") as handle:
            handle.write(json.dumps(data, ensure_ascii=False))
    except (OSError, IOError, ValueError) as err:
        diag.log("Yettel: could not write %s (%s)" % (os.path.basename(path), err), "ERROR")


# ---- the one-time pairing, used by the addon's pairing screen -----------------

def start_pairing(session):
    """
    Begin the OAuth device flow. Returns (device_code, user_code, verification_uri, interval, expires).

    This is Yettel's own intended mechanism for TV clients, and it is the only one that works: a direct
    password grant is refused outright. The user sees a short code and a web address; everything about
    the actual login — including the SMS — happens on Yettel's page, on their phone, and this addon
    never sees a password.
    """
    body = "client_id=%s&scope=tv_info" % OAUTH_CLIENT_ID
    data = session.post(OAUTH_BASE + "/device", body=body,
                        headers={"Content-Type": "application/x-www-form-urlencoded"})
    if not isinstance(data, dict) or not data.get("device_code"):
        raise ProviderError("Yettel: nije uspelo pokretanje povezivanja naloga.")
    return {
        "device_code": data.get("device_code"),
        "user_code": data.get("user_code") or "",
        "verification_uri": data.get("verification_uri") or "https://ytl.rs/tv",
        "interval": int(data.get("interval") or 5),
        "expires_in": int(data.get("expires_in") or 600),
    }


def poll_pairing(session, device_code):
    """
    One poll. Returns the access token, or "" while the user has not finished yet.

    `authorization_pending` and `slow_down` are the flow working as designed, not errors — treating them
    as failures is the classic way to break a device-code implementation on the last step.
    """
    body = ("client_id=%s&grant_type=urn:ietf:params:oauth:grant-type:device_code&device_code=%s"
            % (OAUTH_CLIENT_ID, device_code))
    try:
        data = session.post(OAUTH_BASE + "/token", body=body,
                            headers={"Content-Type": "application/x-www-form-urlencoded"})
    except net.HttpError as err:
        text = (err.body or "")
        if "authorization_pending" in text or "slow_down" in text:
            return ""
        if "expired_token" in text or "access_denied" in text:
            raise ProviderError("Yettel: povezivanje je isteklo ili je odbijeno. Pokušaj ponovo.")
        raise ProviderError("Yettel: povezivanje nije uspelo (%s)." % err)
    return (data or {}).get("access_token") or ""


#: Kaltura brand ids seen on this platform, in the order we would rather borrow one. 22 is the PC web
#: client and 32 the mobile app — both are software that comes and goes anyway; 337 is a physical
#: set-top box, and sitting beside one of those is the last resort rather than the first.
_BORROW_ORDER = (22, 32, DEVICE_BRAND_ID)


def _borrow_household_udid(call, ks):
    """An existing device id from the household, preferring the least physical one."""
    try:
        objects = call("householddevice/action/list", {"ks": ks}).get("objects") or []
    except (YettelError, net.HttpError) as err:
        diag.log("Yettel: could not list household devices (%s)" % err, "ERROR")
        return ""
    usable = [o for o in objects if (o or {}).get("udid")]
    for brand in _BORROW_ORDER:
        for entry in usable:
            if int(entry.get("brandId") or 0) == brand:
                return str(entry["udid"])
    return str(usable[0]["udid"]) if usable else ""


def complete_pairing(settings, session, access_token):
    """
    Turn the OAuth token into the app-token pair this provider actually uses, and store it.

    The username and password sent here are literal placeholders — the real credential is the access
    token in `extraParams`. That is what the official web client sends, and it is worth knowing before
    someone tries to "fix" the dummy values.
    """
    def call(action, body):
        payload = dict(body)
        payload.setdefault("clientTag", CLIENT_TAG)
        payload.setdefault("apiVersion", API_VERSION)
        data = session.post("%s/%s?format=1&clientTag=%s" % (BASE, action, CLIENT_TAG),
                            body=json.dumps(payload),
                            headers={"Content-Type": "application/json"})
        return YettelProvider._result(data, action)

    anon = call("ottuser/action/anonymousLogin", {"language": "*", "partnerId": PARTNER_ID}).get("ks")

    def _login(udid_value):
        return call("ottuser/action/login", {
            "language": "srp", "ks": anon, "partnerId": PARTNER_ID,
            "username": "11111", "password": "11111", "udid": udid_value,
            "extraParams": {
                "loginType": {"objectType": "KalturaStringValue", "value": "accessToken"},
                "accessToken": {"objectType": "KalturaStringValue", "value": access_token},
            },
        })

    # An empty udid is what the web client sends and it is the shape that does NOT touch device slots,
    # so it stays first. But Kaltura answered it with its own internal crash on 2026-08-02 — code "1",
    # "runtime error: invalid memory address or nil pointer dereference" — and that is a server-side nil
    # pointer, not a rejection we can correct. The one-time code the owner just typed is spent either
    # way, so the retry happens HERE rather than by asking for another code: a fresh udid is the only
    # other shape the official client ever sends, and it costs one attempt.
    try:
        login = _login("")
    except YettelError as err:
        if err.code != "1":
            raise
        diag.log("Yettel: login with an empty udid failed inside Kaltura (%s) — retrying with a device "
                 "id" % err.message, "ERROR")
        login = _login(str(uuid.uuid4()).upper())

    ks = (login.get("loginSession") or {}).get("ks") or ""
    if not ks:
        raise ProviderError("Yettel: prijava je prošla ali sesija nije stigla.")

    token = call("apptoken/action/add", {"ks": ks, "appToken": {"objectType": "KalturaAppToken"}})
    token_id, secret = str(token.get("id") or ""), str(token.get("token") or "")
    if not token_id or not secret:
        raise ProviderError("Yettel: nalog je povezan ali token nije izdat.")

    # A NEW device is the tidy outcome, but it is not always available: a household whose device slots
    # are full refuses the add, and on this platform that is a normal state rather than a fault. So the
    # registration is attempted and, when it is refused, an EXISTING device id is reused instead —
    # confirmed live that a session opened against an already-registered udid works and does NOT disturb
    # whatever that device is doing (Kaltura's session issuance is stateless, not a single-session lock).
    # Preference order matters: a browser or mobile entry before a physical set-top box, so a real STB in
    # the living room is the last thing we sit beside.
    # SIT ON AN EXISTING SLOT ON PURPOSE, when the owner says so.
    #
    # Registering a new device is the tidy outcome and stays the default, but it is not always what is
    # wanted: slots are scarce, this household frees one a month, and a second box in the same house
    # should not cost one. Asked for directly ("hoću na isti slot"). With `yettel_reuse_slot` on, an
    # existing device is adopted WITHOUT attempting the add at all — the old code only ever borrowed
    # after being refused, so on a household with a free slot the wish was silently ignored.
    #
    # `yettel_known_udid` names WHICH one; empty means the borrow order decides (browser or mobile
    # before a physical set-top box, so a real STB in the living room is the last thing we sit beside).
    wanted = (settings.get("yettel_known_udid", "") or "").strip()
    reuse = str(settings.get("yettel_reuse_slot", "") or "").lower() in ("true", "1")
    udid = ""
    if reuse or wanted:
        udid = wanted or _borrow_household_udid(call, ks)
        if udid:
            diag.log("Yettel: reusing the existing device %s… as asked" % udid[:8])
        else:
            diag.log("Yettel: asked to reuse a slot but the household lists none — registering instead",
                     "ERROR")

    if not udid:
        udid = str(uuid.uuid4()).upper()
        try:
            call("householddevice/action/add", {
                "ks": ks,
                "device": {"objectType": "KalturaHouseholdDevice", "udid": udid,
                           "name": "IPTV Balkan", "brandId": DEVICE_BRAND_ID},
            })
            diag.log("Yettel: registered a new household device")
        except (YettelError, net.HttpError) as err:
            udid = _borrow_household_udid(call, ks)
            if not udid:
                raise ProviderError(
                    "Yettel: nema slobodnog mesta za nov uređaj (%s), a nijedan postojeći nije nađen da "
                    "se pozajmi. Oslobodi jedno mesto u Yettel aplikaciji pa probaj ponovo." % err)
            diag.log("Yettel: no free device slot — reusing the existing device %s…" % udid[:8])

    settings.set("yettel_app_token_id", token_id)
    settings.set("yettel_app_token_secret", secret)
    settings.set("yettel_udid", udid)
    settings.set("yettel_enabled", "true")
    # The token itself never reaches the log — only that one now exists.
    diag.log("Yettel: account linked, device registered, app-token stored")
    return udid
