# -*- coding: utf-8 -*-
"""
Bringing a box forward when the ADD-ON ID changes.

The addon was `plugin.video.iptvbox` until 1.21.0 and is `plugin.video.iptvbalkan` from it, because the
id is the zip's name, the folder Kodi unpacks it into, and the string a customer sees in Kodi's own
add-on list — three places that went on carrying a name the product no longer uses.

To Kodi that is not a rename at all: it is a DIFFERENT ADD-ON. Nothing is inherited. Without this file
the first start after an update would be a box with no accounts, no licence record, no continue-watching
and no artwork cache, while the old copy sat beside it still refreshing a playlist nobody reads. So:

  * SETTINGS are carried across one value at a time through Kodi's own settings API, and read back.
    Not by copying settings.xml — Kodi owns that file, holds its own copy of it while the settings
    dialog is open, and writes it back on close. A file copied behind that is thrown away, which this
    project has already paid for once.
  * THE PROFILE'S OWN FILES are copied. They are ours alone, nothing else reads or writes them, and
    accounts.json in particular cannot be regenerated.
  * NOTHING IS DELETED. A migration that goes wrong has to be recoverable, and a box that half-updates
    is exactly the kind that ends up on the telephone. Removing the old add-on is the owner's click.

Runs once: the marker is the presence of our own settings, so a box that has already been set up is
never touched, and a fresh install with no predecessor does nothing at all.
"""

import os
import shutil

from . import diag

try:
    import xbmc
    import xbmcaddon
    import xbmcvfs
    _IN_KODI = True
except ImportError:                                                # tooling / unit tests
    xbmc = xbmcaddon = xbmcvfs = None
    _IN_KODI = False

#: Every id this addon has shipped under, newest first. A list rather than one string because the next
#: rename must not have to remember how this one was written.
PREVIOUS_IDS = ("plugin.video.iptvbox",)

#: Files in the profile that are worth carrying. `accounts.json` is the one that cannot be rebuilt;
#: the caches are here because re-fetching 2 MB of artwork and a whole EON catalogue on a television
#: that was working perfectly five minutes ago is a poor first impression of an update.
CARRIED_FILES = (
    "accounts.json",            # extra provider accounts — NOT regenerable
    "licence.json",             # the device's verdict, its serial and the vault key
    "resume.json",              # continue-watching
    "tmdb.db",                  # artwork and plots, plus the manual title corrections
    "catchup-token.txt",        # the loopback's token, so existing playlist URLs still answer
    "eon-session.json",
    "eon_play.json",
    "iris_play.json",
    "yettel_epg.json",
    "tmdb_queue.json",
)

#: Settings that must NOT travel. `playlist_built_by` is what makes a new release rebuild the playlist
#: once; carried over, the new id would inherit "already built by this version" and keep serving a
#: playlist full of the OLD id's plugin:// URLs — every Iris channel and every radio station dead until
#: the next scheduled refresh, up to a day later.
SKIPPED_SETTINGS = ("playlist_built_by",)


def previous_profile():
    """The addon_data folder of the newest previous id that actually has something in it."""
    if not _IN_KODI:
        return ""
    for old in PREVIOUS_IDS:
        path = xbmcvfs.translatePath("special://profile/addon_data/%s" % old)
        if os.path.isdir(path) and os.listdir(path):
            return path
    return ""


def _previous_settings(path):
    """Read the old addon's settings.xml directly — the old addon is not loaded and cannot be asked."""
    import xml.etree.ElementTree as ET
    out = {}
    source = os.path.join(path, "settings.xml")
    if not os.path.isfile(source):
        return out
    try:
        root = ET.parse(source).getroot()
    except Exception as err:                                       # noqa: BLE001
        diag.log("Migration: the previous settings.xml could not be read (%s)" % err, "ERROR")
        return out
    for node in root.findall("setting"):
        name = node.get("id")
        if not name or name in SKIPPED_SETTINGS:
            continue
        value = node.text
        if value is None:
            value = ""
        out[name] = value
    return out


def needed(settings):
    """True when there is a predecessor to inherit from and we have not been set up ourselves."""
    if not _IN_KODI:
        return False
    mine = os.path.join(settings.profile_dir(), "settings.xml")
    if os.path.isfile(mine) and os.path.getsize(mine) > 200:
        return False                                               # this box is already configured
    return bool(previous_profile())


def bring_forward(settings):
    """
    Carry the previous id's box across. Returns a short description of what moved, or "".

    Deliberately tolerant: every step is independent, and a file that will not copy is logged and
    skipped rather than taking the rest of the migration down with it. A box that inherits its accounts
    but not its artwork cache is a working box.
    """
    if not needed(settings):
        return ""
    source = previous_profile()
    diag.log("Migration: found the previous installation at %s" % source)

    values = _previous_settings(source)
    carried, refused = 0, []
    for name, value in sorted(values.items()):
        if value == "":
            continue
        try:
            if settings.set(name, value):
                carried += 1
            else:
                refused.append(name)
        except Exception as err:                                   # noqa: BLE001
            refused.append("%s (%s)" % (name, err))
    if refused:
        # Named, because the usual cause is Kodi's settings dialog being open over the top of this and
        # writing its own copy back — and a silently missing password sends someone to retype an
        # account that was never wrong.
        diag.log("Migration: %d setting(s) could not be written: %s"
                 % (len(refused), ", ".join(refused[:8])), "ERROR")

    copied = []
    for name in CARRIED_FILES:
        old = os.path.join(source, name)
        if not os.path.isfile(old):
            continue
        try:
            shutil.copy2(old, os.path.join(settings.profile_dir(), name))
            copied.append(name)
        except (OSError, IOError) as err:
            diag.log("Migration: %s could not be copied (%s)" % (name, err), "ERROR")

    diag.log("Migration: %d settings and %d file(s) brought over from the previous version (%s)"
             % (carried, len(copied), ", ".join(copied) or "none"))
    return "%d podesavanja i %d fajl(ova)" % (carried, len(copied))


def owns_path(path):
    """
    Is this M3U path one WE wrote — under our profile, or under a previous id's?

    IPTV Simple keeps the playlist address in its instance settings, and the rule there has always been
    "fill it if blank, never take over somebody else's". After a rename the old address is neither: it
    is ours, under a name we no longer use, and reading it as a stranger's leaves the television on a
    playlist that nothing refreshes any more — the exact failure this whole file exists to prevent.
    """
    text = (path or "").replace("\\", "/")
    if not text:
        return False
    return any(("addon_data/%s/" % old) in text for old in PREVIOUS_IDS)

#: Settings whose DEFAULT changed for a reason that has nothing to do with what the user wanted, moved
#: forward once on installs that still carry the old default.
#:
#: `(name, old default, new default)`. The rule is narrow on purpose: the value is only touched when it
#: is still EXACTLY the old default, so anybody who has moved that slider themselves — for any reason,
#: including "my provider does not like it" — keeps their number.
RAISED_DEFAULTS = (
    # 1.30.0. The EON guide is fetched a few channels at a time now, so the same wall clock buys about
    # four times as many channels. Measured on a real box: 240 s reached 165 of 302 channels, and the
    # rest simply had no guide until some later refresh happened to get to them. Changing the default in
    # settings.xml alone does nothing here — Kodi has already written 240 into every existing profile.
    ("eon_epg_budget_sec", "240", "480"),
    # 1.37.0. Four provider accounts on one box, walked one after another, and the guide is where the
    # minutes are: measured on the owner's box, EON alone took 466s of its 480s budget, Move 85s and
    # Iris 20s, with Yettel still running. Four parallel guide requests were leaving the connection
    # mostly idle. Eight halves the wall clock without changing what gets fetched, and the ceiling went
    # to 12 for anyone whose provider tolerates it. Same reasoning as the budget above: settings.xml
    # alone does nothing, Kodi has already written 4 into every existing profile.
    ("epg_workers", "4", "8"),
    # 1.34.0, and this one is a JUDGEMENT the owner made rather than a number that grew. Kodi will not
    # draw a truthful timeline over a stream it is treating as live, and it will not draw the live
    # overlay (mini guide, channel list) over one it is not — only one of the two can be true at a time,
    # per channel, and the addon has always been able to do either. His call, in his words: a real
    # timeline and no buttons beats a wrong timeline that also cannot seek.
    #
    # Honest limitation of moving a BOOLEAN default: "never touched it" and "deliberately turned it off"
    # are the same stored value, so somebody who had switched it off gets it back on once. With the
    # product this new, that is the right side to err on.
    ("archive_exact_bar", "false", "true"),
)


def raise_defaults(settings):
    """Move the settings in [RAISED_DEFAULTS] forward, once. Returns the names it changed."""
    done = settings.get("defaults_raised", "")
    changed = []
    for name, old, new in RAISED_DEFAULTS:
        if name in done.split(","):
            continue
        if str(settings.get(name, "")).strip() == old:
            settings.set(name, new)
            changed.append(name)
            diag.log("Migrate: %s was still the old default (%s) — raised to %s" % (name, old, new))
        done = ",".join([part for part in (done, name) if part])
    if done != settings.get("defaults_raised", ""):
        settings.set("defaults_raised", done)
    return changed
