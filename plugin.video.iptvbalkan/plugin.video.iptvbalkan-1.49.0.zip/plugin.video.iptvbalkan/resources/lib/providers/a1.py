# -*- coding: utf-8 -*-
"""
A1 Xplore TV (`xploretv.rs`) — the sixth backend, and the first one that is **GraphQL**.

Ported from the Android edition's `A1Api.kt`, which was itself written from a live logged-in session on
2026-08-08 and is documented in `A1-XPLORE-API.md`. Nothing here is guessed: this project has twice paid
for "written but unproven", and both times it meant written against a shape the service does not serve.

The platform is **Zappware NeXX 4.0** — not EON's United Cloud, not Iris' Huawei VSP, not Yettel's
Kaltura, not Move's MTS-SI. Private edition only, like the other operator sources.

FIVE THINGS THAT ARE UNUSUAL ENOUGH TO STATE UP FRONT
=====================================================

**1. There is no login operation in the GraphQL schema.** Sign-in is one REST call on a different port
(8843), and the subscriber's username and password travel in the QUERY STRING. That is the service's
design, not a choice available here — and it is why `diag`'s redaction had to learn the word `pwd`
before this file could exist. A traced login would otherwise have written a working password into the
last 55 kB of the log, which is exactly the part that rides along with every support report.

**2. The device id is invented by the CLIENT, and every new one costs a subscription slot.** The web
stores a 32-hex `fingerprint` in localStorage and presents it as `devId`; the server does not issue it.
So a client that mints a fresh one per launch registers a new device per launch. That is not a
hypothesis — `DeviceIdentity` in IptvBoxWin did precisely that. Minted once, written back through
`Provider.remember` (which SAYS SO when the write does not stick), and adoptable: paste the id your
browser or another box already uses and no new slot is spent. Same pattern as `yettel_known_udid`, for
the same reason. Never compiled in — see what shipping the owner's own Yettel udid cost.

**3. Playback is a SESSION with three parts, and the third is not optional.** `playChannel` mints it,
`keepAlive` holds it open, `stopPlayback` releases it. Skip the release and the session lingers until
the service times it out, quietly holding one of the account's concurrent-stream slots; a viewer who
zaps a few times and then cannot start anything is the symptom, and the cause is something that was not
sent minutes earlier. `service.py`'s keepalive loop drives both — this provider is in
`_KEEPALIVE_PROVIDERS` beside Iris.

**4. `keepAlive` takes no arguments and returns `sessionTimeout`** — the service itself says how many
seconds are left. Iris' fixed 45 s is the weaker version of the same idea.

**5. Catch-up is addressed by EVENT ID, not by a timestamp.** IPTV Simple hands us `{utc}`, so the two
have to be bridged: the guide pass writes a small map of (channel, start, end) -> event id, and a replay
looks the instant up in it. A miss is answered with a sentence a viewer can act on rather than a
failure, and it falls back to asking the service for a narrow window before giving up. The reply carries
`streamStart`/`streamEnd`, so unlike EON the seek bar is TRUTHFUL and one mint covers the whole
programme — that is the Iris model, `catchup_mode="vod"`, and it must not be re-minted per seek.

THE VIDEO CLUB IS THE ARCHIVE
============================

There is no film store on this account: the club is past broadcasts that catch-up can still play, and a
club row's id is an EVENT id. See `vod` for why asking the wrong types left it empty and silent.

WHAT IS DELIBERATELY NOT HERE
=============================

**Device management.** The schema has `createDevice`, `deleteDevice` and `deleteForeignDevice`, so
freeing a slot from here is possible and worth having. The INPUT SHAPES were never captured, and
inventing an argument name to try is guessing with somebody's subscription. `supports_devices` stays
False until one real capture exists.
"""

import io
import json
import os
import re
import time
import uuid

from .. import diag, net, store
from ..provider import Provider, ProviderError, register

#: The GraphQL endpoint, and the REST auth service — different ports, and that is the service's layout.
GRAPHQL = "https://web.xploretv.rs:8443/sdsmiddleware/A1_Serbia/graphql/4.0"
AUTH_BASE = "https://web.xploretv.rs:8843/ext_dev_facade/auth"

#: VERBATIM FROM A LIVE CAPTURE, trailing "null" included — that word is part of the real value.
#:
#: This was invented in the first version of this file ("nexx4web/30.0.4 (Chrome)") and it is the fault
#: that hurts most, because reading goes on working: the service licenses VIDEO per device type, so an
#: unknown client is answered normally for the channel list and the guide and then refused a stream. A
#: provider that lists 194 channels and plays none of them looks like a DRM problem, and it is not.
ZAPPWARE_UA = "windows_pc_chrome/v30.0.4 (Nexx 4.0 windows_pc_chrome; Windows; 10) null"

#: The session header is a WRAPPED token: this prefix followed by the token from the login. Sending the
#: token bare is a 401 on the very first GraphQL call — with the login having succeeded a moment earlier,
#: which reads as "the password is fine but nothing works".
SESSION_PREFIX = "[sedt=0]"

#: The web's own origin, and it is NOT the API host: `xploretv.rs`, not `web.xploretv.rs`.
WEB_ORIGIN = "https://xploretv.rs"

#: Programmes per day, for turning Kodi's "days back / days forward" into what this service actually
#: takes — see `epg`. 30 is the Android edition's number, raised from 15 after RTS1 reached only 3.4 of
#: the seven days asked for: the guide is a COUNT either side of an instant, so a channel with long
#: programmes runs out of days before a channel with short ones.
EVENTS_PER_DAY = 30
#: Measured horizons on a live account: following=400 reaches seven days ahead, previous=200 reaches six
#: days back, which is the archive's own limit. Asking for more simply returns what exists.
MAX_FOLLOWING, MAX_PREVIOUS = 400, 200

#: Widevine, on A1's own proxy — from the site's public `config_395.js`. NOT castLabs DRMtoday: castLabs
#: is only the web player, so there is no `dt-custom-data` header of the kind Iris needs.
WIDEVINE_LICENCE_URL = "https://wvps.a1xploretv.bg:8063"

#: Cursor-paged, Relay style. 100 is what the web asks for.
PAGE = 100
#: A stop for the paging walks. A service that always reported another page would otherwise spin for
#: ever, and a refresh that never ends is worse than one that stops short and says so.
MAX_PAGES = 60

#: Logo size is requested rather than scaled — the path itself carries it (`76x28_channel`).
LOGO_W, LOGO_H, LOGO_FLAVOUR = 76, 28, "DARK"

#: The signed-in session, kept between PROCESSES. The plugin runs for one action — one tune, one screen
#: — so a token held only in memory is thrown away at the moment it becomes useful.
SESSION_CACHE = "a1_session.json"
#: `exp_period` comes back from the login and is respected; this is the ceiling when it does not.
SESSION_MAX_AGE = 6 * 3600

#: (channel, start, end) -> event id, written by the guide pass so a replay can be addressed at all.
#: See the module docstring, point 5.
ARCHIVE_CACHE = "a1_events.json"

#: What this provider last handed the player, so the service's keepalive knows whether the stream on
#: screen is ours — and so `stopPlayback` can name the session it is releasing.
NOW_PLAYING = "a1_playing.json"

#: What a client-minted device identity looks like: 32 lowercase hex, exactly as the web's fingerprint.
_DEVICE_SHAPE = re.compile(r"^[0-9a-f]{32}$")


# ---- the GraphQL documents --------------------------------------------------
#
# ONLY FIELDS THAT WERE ACTUALLY SEEN ARE ASKED FOR, and that rule is load-bearing. GraphQL rejects the
# WHOLE query when it names a field the schema does not have — not that field, the whole operation. So
# one hopeful extra field turns "the channel list" into "no channels", with an error that reads like a
# login problem.
#
# EVERY DECLARED VARIABLE MUST ALSO BE USED. The spec's "All Variables Used" rule (5.8.4) is a MUST, so
# a query declaring a variable its body never references is refused whole. When the Android version's
# selection sets were narrowed to the observed fields, the orphaned declarations were left behind and
# would have failed on the first live call, looking exactly like "A1 does not work".

Q_CHANNEL_LIST = """
query channelList($channelListId: ID!, $first: Int, $after: String, $profileId: ID!) {
  channelList(id: $channelListId) {
    channels(first: $first, after: $after) {
      totalCount
      pageInfo { hasNextPage endCursor }
      edges { node {
        id title kind defaultNumber
        logo(width: 90, height: 33, flavour: NORMAL) { url }
        userInfo { subscribed }
        personalInfo(profileId: $profileId) { blocked }
      } }
    }
  }
}
"""

#: THE GUIDE IS CENTRED ON AN INSTANT AND COUNTED, not asked for as a window.
#:
#: `eventsAt(time:, previous:, following:)` — and it answers `items[]`, NOT the `edges/node` shape the
#: channel list uses. The first version of this file asked `events(windowStart:, windowDuration:)`, which
#: does not exist here; the whole operation is refused and the provider looks dead.
#:
#: `entitlements { catchupTV }` is the field that ends the "archive is broken" report. About a third of
#: rows carry `catchupTV: false` — rights the operator does not hold — and minting one of those earns
#: `0x02000703`, access denied, which from the sofa is indistinguishable from a broken player.
Q_GRID_GUIDE = """
query gridGuide($channelListId: ID!, $first: Int, $after: String,
                $currentTime: Date!, $previous: Int!, $following: Int!) {
  channelList(id: $channelListId) {
    channels(first: $first, after: $after) {
      pageInfo { hasNextPage endCursor }
      edges { node {
        id
        events: eventsAt(time: $currentTime, previous: $previous, following: $following) {
          itemCount
          items { id start end metadata { title } entitlements { catchupTV } }
        }
      } }
    }
  }
}
"""

Q_PLAY_CHANNEL = """
mutation playChannel($input: PlayChannelInput!) {
  playChannel(input: $input) { playbackInfo {
    sessionId url trickplayRestrictions
    heartbeat { ... on HttpHeartbeat { url interval includeAuthHeaders } }
  } }
}
"""

Q_CATCHUP_EVENT = """
mutation catchupEvent($input: CatchupEventInput!) {
  catchupEvent(input: $input) { playbackInfo {
    sessionId url streamStart streamEnd trickplayRestrictions
    heartbeat { ... on HttpHeartbeat { url interval includeAuthHeaders } }
  } }
}
"""

#: THE VIDEO CLUB'S ROOTS, and they are not where a menu suggests. `vodRootContentFolderList` exists and
#: answers, but on this account it holds only an adult folder; the real tree hangs off the HOME shelves.
Q_HOME = """
query home($profileId: ID!) {
  homeRows(profileId: $profileId) {
    folders(first: 40) { edges { node { title
      items(first: 20) { edges { node { __typename ... on VODFolder { id title } } } } } } }
  }
}
"""

#: ONE LEVEL OF THE CLUB, and `... on Event` is the line that matters.
#:
#: The films here ARE archive events — past broadcasts catch-up can still play — and an earlier version
#: of this query asked only for VODFolder, VODAsset and Series. A node whose type matches no inline
#: fragment is answered with a bare `__typename` and NOTHING ELSE: no error, no id, no title. So every
#: film arrived as an empty shell and the club drew the handful of real Series and nothing else, which is
#: exactly the "40 series and no films" that was reported. They were never missing; they were never asked
#: for, and GraphQL said nothing because nothing was invalid.
Q_VOD_FOLDER = """
query getVODFolderDetail($id: ID!, $firstFolders: Int, $firstItems: Int, $thumbnailHeight: Int!) {
  vodFolder(id: $id) {
    id title
    content {
      folders(first: $firstFolders) { edges { node {
        id title
        items(first: $firstItems) { totalCount edges { node {
          __typename
          ... on Event     { id title start end thumbnail(height: $thumbnailHeight) { url }
                             channel { id title }
                             entitlements { catchupTV catchupTVAvailableUntil } }
          ... on Series    { id title thumbnail(height: $thumbnailHeight) { url } }
          ... on VODAsset  { id title duration thumbnail(height: $thumbnailHeight) { url } }
          ... on VODFolder { id title thumbnail(height: $thumbnailHeight) { url } }
        } } }
      } } }
    }
  }
}
"""

Q_KEEP_ALIVE = "mutation keepAlive { keepSessionAlive { sessionTimeout } }"
Q_STOP_PLAYBACK = ("mutation stopPlayback($input: StopPlaybackInput!) "
                   "{ stopPlayback(input: $input) { success } }")
#: The profile id, and it is NOT at `setupSteps { profileId }` — that shape was invented. It lives on the
#: signed-in device itself.
Q_SETUP_STEPS = "query getSetupSteps { me { device { activeProfile { id } } } }"
Q_INITIAL_CHANNEL_LISTS = "query getInitialChannelLists { initialChannelList { id } }"


@register
class A1Provider(Provider):

    key = "a1"
    label = "A1 Xplore"
    #: See the module docstring on both of these. Declared rather than left to be discovered.
    supports_vod = True
    supports_devices = False
    #: ONE DEEPER THAN THE DEFAULT, because this club genuinely is: shelf -> genre -> titles. At the
    #: default two, a search could match the name of a shelf or a genre and never a single title — a
    #: search that appears to work and cannot find anything. The extra level is cheap here: a genre is
    #: answered by the same single call as its parent folder.
    vod_walk_depth = 3

    default_identity = {
        "user_agent": ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                       "(KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36"),
        "origin": WEB_ORIGIN,
        "referer": WEB_ORIGIN + "/",
        "extra_headers": {"Accept": "application/json"},
    }

    def __init__(self, settings):
        Provider.__init__(self, settings)
        self.session = net.Session(self.identity(), trace=settings.verbose())
        self.sid = ""                                              # SDSEVO_SESSION_ID
        self.did = ""                                              # SDSEVO_DEVICE_ID
        self.uid = ""                                              # SDSEVO_USER_ID
        self.profile_id = ""
        self.channel_list_id = ""
        #: True when the session came off disk. A refusal on one of those is worth one silent re-login;
        #: the same refusal on a session minted seconds ago is the real answer.
        self.session_restored = False
        #: True while the login chain runs, so the retry in _call cannot fire from inside it.
        self._logging_in = False

    # ---- server-steerable constants ----------------------------------------
    #
    # Every value that decides whether this backend answers at all, steerable from the panel — see
    # `Provider.tuned`. A Zappware client tag and a middleware path are exactly the kind of thing that
    # changes on the provider's release schedule rather than ours.

    def graphql_url(self):
        return self.tuned("a1_graphql", GRAPHQL)

    def auth_base(self):
        return self.tuned("a1_auth_base", AUTH_BASE).rstrip("/")

    def client_tag(self):
        return self.tuned("a1_client_tag", ZAPPWARE_UA)

    def widevine_url(self):
        return self.tuned("a1_widevine", WIDEVINE_LICENCE_URL)

    # ---- device identity ---------------------------------------------------

    def device_fingerprint(self):
        """
        The 32-hex identity this install presents as `devId`, minted once and remembered.

        A NEW VALUE IS A NEW REGISTERED DEVICE and costs one of the subscription's slots, so this must
        never mint on every launch — see the module docstring. The user's own setting wins: pasting the
        id their browser or another box already uses adopts that device instead of registering another.

        A stored value of the wrong shape is replaced rather than sent. The service takes 32 hex; handing
        it a uuid with dashes (which an earlier draft of this did, by reusing `Provider.device_id`) is a
        request that fails in a way that reads like bad credentials.
        """
        existing = str(self.setting("device_id") or "").strip().lower()
        if _DEVICE_SHAPE.match(existing):
            return existing
        if existing:
            diag.log("A1: the stored device id is not 32 hex — minting a new one. If you meant to adopt "
                     "an existing device, paste its id exactly as the browser shows it.", "ERROR")
        fresh = uuid.uuid4().hex
        # Through `remember`, which says so out loud when the write does not stick: an id that is lost
        # means the next login registers ANOTHER device and spends another slot, silently, for ever.
        self.remember("device_id", fresh)
        diag.log("A1: minted a device identity for this install (%s…) — paste it into another install "
                 "to share the same device slot" % fresh[:8])
        return fresh

    # ---- transport ---------------------------------------------------------

    def _headers(self):
        """The three headers every call carries. Absent before login, which is what bootstrap is for."""
        out = {"Zappware-User-Agent": self.client_tag(),
               # Per-request id. The service logs it, so a support report is traceable on their side and
               # not only on ours.
               "X-Correlation-Id": str(uuid.uuid4()),
               "Content-Type": "application/json"}
        if self.sid:
            # WRAPPED, never bare — see SESSION_PREFIX.
            out["SDSEVO_SESSION_ID"] = SESSION_PREFIX + self.sid
            out["SDSEVO_DEVICE_ID"] = self.did
            out["SDSEVO_USER_ID"] = self.uid
        return out

    def _call(self, operation, query, variables=None, _retried=False):
        """
        One GraphQL call.

        A 200 IS NOT SUCCESS. GraphQL answers `200` with an `errors` array for a refused request, and
        reading only the status code loses the reason — the exact mistake Move's `success:false` already
        cost this project once. The message is the useful half and is safe to show; `extensions` can
        carry account detail and is deliberately left out.
        """
        if not self.sid and not self._logging_in:
            self.login()
        body = json.dumps({"operationName": operation, "query": query,
                           "variables": variables or {}})
        try:
            answer = self.session.post(self.graphql_url(), body=body, headers=self._headers())
        except net.HttpError as err:
            # A REFUSAL AT THE HTTP LEVEL, which this used to let escape as a bare HttpError — no
            # sentence for the viewer, no retry, and a catalogue line reading "HttpError: 401" for
            # something that is simply a session that has gone stale. 401/403 here means the token
            # this process restored from disk is no longer good; everything else is the service being
            # unreachable and is said as much.
            if err.status in (401, 403):
                if not _retried and not self._logging_in:
                    diag.log("A1: the session was refused (HTTP %s) — signing in again" % err.status)
                    self._forget_session()
                    self.login()
                    return self._call(operation, query, variables, _retried=True)
                raise ProviderError(
                    "A1: servis je odbio prijavu ovog uređaja. Proveri korisničko ime i lozinku; ako "
                    "su tačni, uređaj možda nije u domaćinstvu — upiši ID uređaja koji već koristiš.")
            raise ProviderError("A1: %s nije prošao (HTTP %s)." % (operation, err.status))
        if not isinstance(answer, dict):
            raise ProviderError("A1: %s je odgovorio necim sto nije JSON." % operation)

        errors = answer.get("errors")
        if errors:
            first = ""
            if isinstance(errors, list) and errors and isinstance(errors[0], dict):
                first = str(errors[0].get("message") or "")
            # A session that died between processes looks like any other refusal, so a RESTORED one is
            # worth exactly one silent re-login. A fresh session refusing is the real answer.
            if (not _retried and self.session_restored and not self._logging_in
                    and _looks_like_session_error(first)):
                diag.log("A1: the stored session was refused — signing in again")
                self._forget_session()
                self.login()
                return self._call(operation, query, variables, _retried=True)
            raise ProviderError("A1: %s je odbijen — %s" % (operation, first or "bez objasnjenja"))

        data = answer.get("data")
        if not isinstance(data, dict):
            raise ProviderError("A1: %s nije vratio podatke." % operation)
        return data

    # ---- sign in -----------------------------------------------------------

    def login(self):
        """
        Sign in, then fetch the two ids every content call needs.

        ONE REST CALL, not GraphQL: there is no login operation anywhere in the schema (147 operations
        in the web bundle, none of them a login). The three fields it answers with map straight onto the
        three headers — `token` is the session, `device_id` the device, `user_id` the user.

        The username and password travel in the query string. `diag` redacts `user=` and `pwd=` out of
        traced URLs; if you ever add another parameter here, check that it is covered before shipping.
        """
        if self.sid:
            return
        if self._restore_session():
            return
        username = self.setting("username")
        password = self.setting("password")
        if not username or not password:
            raise ProviderError("A1: unesi korisničko ime i lozinku u podešavanjima.")

        self._logging_in = True
        try:
            device = self.device_fingerprint()
            url = ("%s/Login?devId=%s&user=%s&pwd=%s&rqT=true&refr=true"
                   % (self.auth_base(), _q(device), _q(username), _q(password)))
            try:
                answer = self.session.post(url, body=b"",
                                           headers={"Zappware-User-Agent": self.client_tag()})
            except net.HttpError as err:
                # The URL is deliberately absent from this message: it carries the password, and an
                # exception text is not put through the log's redaction.
                if err.status in (401, 403):
                    raise ProviderError("A1: prijava odbijena — proveri korisničko ime i lozinku.")
                raise ProviderError("A1: prijava nije uspela (HTTP %s)." % err.status)
            if not isinstance(answer, dict):
                raise ProviderError("A1: prijava je odgovorila necim sto nije JSON.")

            self.sid = str(answer.get("token") or "")
            self.uid = str(answer.get("user_id") or "")
            self.did = str(answer.get("device_id") or device)
            if not self.sid or not self.uid or self.uid == "None":
                raise ProviderError("A1: prijava je prošla ali nije vratila sesiju.")
            # The service may hand back a device id of its own; that one is what later calls must use,
            # and remembering it is what stops the next launch registering another device.
            if self.did and self.did != device:
                self.remember("device_id", self.did)
            ttl = int(answer.get("exp_period") or 0)
        finally:
            self._logging_in = False

        self._bootstrap()
        self._save_session(ttl)
        diag.log("A1: signed in (device %s…, profile %s)" % (self.did[:8], self.profile_id))

    def _bootstrap(self):
        """
        The two ids nothing works without.

        `profileId` is NOT in the login answer, and it is NOT at `setupSteps { profileId }` — that shape
        was invented and the whole operation is refused over it. It hangs off the signed-in device:
        `me { device { activeProfile { id } } }`.

        `getInitialChannelLists` takes no arguments and answers one id. Hardcoding `1-1` works on one
        account and silently answers an empty line-up on the next, which reads as an empty subscription.
        """
        setup = self._call("getSetupSteps", Q_SETUP_STEPS)
        device = ((setup.get("me") or {}).get("device") or {})
        self.profile_id = str((device.get("activeProfile") or {}).get("id") or "")
        if not self.profile_id:
            raise ProviderError("A1: nalog nije vratio profil.")
        data = self._call("getInitialChannelLists", Q_INITIAL_CHANNEL_LISTS)
        initial = data.get("initialChannelList") or {}
        self.channel_list_id = str(initial.get("id") or "") if isinstance(initial, dict) else ""
        if not self.channel_list_id:
            raise ProviderError("A1: nalog nije vratio nijednu listu kanala.")
        # NO "release whatever was left open" CALL HERE any more. `StopPlaybackInput` wants a session id;
        # an empty one is a refusal, so the old version spent a round trip on every single login to be
        # told no. A session this box actually opened is released by `stop_heartbeat`, which knows its id.

    # ---- session across processes ------------------------------------------

    def _restore_session(self):
        block = _read_json(self.cache_path(SESSION_CACHE)) or {}
        if not isinstance(block, dict):
            return False
        age = time.time() - float(block.get("at") or 0)
        ttl = float(block.get("ttl") or 0) or SESSION_MAX_AGE
        if age > min(ttl, SESSION_MAX_AGE):
            return False
        self.sid = str(block.get("sid") or "")
        self.did = str(block.get("did") or "")
        self.uid = str(block.get("uid") or "")
        self.profile_id = str(block.get("profile") or "")
        self.channel_list_id = str(block.get("list") or "")
        if not (self.sid and self.uid and self.profile_id and self.channel_list_id):
            self.sid = ""
            return False
        self.session_restored = True
        return True

    def _save_session(self, ttl=0):
        store.write_json(self.cache_path(SESSION_CACHE),
                         {"sid": self.sid, "did": self.did, "uid": self.uid,
                          "profile": self.profile_id, "list": self.channel_list_id,
                          "ttl": ttl, "at": time.time()})

    def _forget_session(self):
        self.sid = self.uid = self.profile_id = self.channel_list_id = ""
        self.session_restored = False
        try:
            os.remove(self.cache_path(SESSION_CACHE))
        except OSError:
            pass

    # ---- channels ----------------------------------------------------------

    def channels(self):
        """
        The line-up, walked by cursor.

        THE NUMBER IS THE POSITION — the node carries none, and the order of `channels.edges` IS the
        line-up, exactly as with Iris.

        `userInfo.subscribed` and `personalInfo.blocked` are read and HONOURED. A line-up that includes
        what the subscription does not carry is a list where a third of the presses answer an error; a
        blocked channel is the owner's own parental decision on their A1 profile and this addon has no
        business quietly undoing it.
        """
        self.login()
        out, cursor, pages, total, skipped = [], None, 0, 0, 0
        while pages < MAX_PAGES:
            if self.stopping():
                diag.log("A1: Kodi is closing — the channel list stops here")
                break
            pages += 1
            variables = {"channelListId": self.channel_list_id, "first": PAGE,
                         "profileId": self.profile_id}
            if cursor:
                variables["after"] = cursor
            data = self._call("channelList", Q_CHANNEL_LIST, variables)
            connection = ((data.get("channelList") or {}).get("channels")) or {}
            total = int(connection.get("totalCount") or 0) or total
            edges = connection.get("edges") or []
            if not edges:
                break
            for edge in edges:
                node = (edge or {}).get("node") or {}
                if not (node.get("userInfo") or {}).get("subscribed", True):
                    skipped += 1
                    continue
                if (node.get("personalInfo") or {}).get("blocked"):
                    skipped += 1
                    continue
                entry = self._channel_entry(node, len(out) + 1)
                if entry:
                    out.append(entry)
            info = connection.get("pageInfo") or {}
            if not info.get("hasNextPage"):
                break
            cursor = info.get("endCursor") or ""
            if not cursor:
                break
        diag.log("A1: %d channels (of %d in the list; %d not subscribed or blocked)"
                 % (len(out), total or len(out) + skipped, skipped))
        return out

    def _channel_entry(self, node, position):
        """
        One channel row.

        THE NUMBER IS THE SERVICE'S OWN, when it gives one. `defaultNumber` is in the schema and the
        first version of this file did not ask for it — it numbered by position, so A1's channels came
        out 1..156 and matched nothing the household is used to. The Android note that said "the node
        carries no number" was written from a browser capture, which is a different thing from the
        schema; introspection is open here and it settles it. Position is still the fallback, because a
        channel with no number of its own must not collide with one that has.

        `kind` is TV or RADIO — the service says which, so the audio-only stations no longer have to be
        guessed at from their names.
        """
        cid = str(node.get("id") or "")
        name = str(node.get("title") or "")
        if not cid or not name:
            return None
        logo = ""
        if isinstance(node.get("logo"), dict):
            logo = str(node["logo"].get("url") or "")
        number = node.get("defaultNumber")
        number = int(number) if isinstance(number, int) and number > 0 else position
        audio_only = str(node.get("kind") or "").upper() == "RADIO"
        return {
            "id": self.scoped("a1_%s" % cid),
            "tvg_id": self.scoped("a1_%s" % cid),
            "provider": self.key,
            "provider_label": self.label,
            "provider_ref": cid,
            "name": name,
            "number": number,
            "logo": logo,
            # The provider names no genres — checked against the schema, `Channel` has no such field —
            # so the only grouping A1 channels get is the provider's own name, which `playlist.write_m3u`
            # adds when `group_by_provider` is on. Radio is the one distinction the service DOES make.
            "group": "Radio" if audio_only else "",
            "radio": self.radio_flag(audio_only),
            "url": ("plugin://plugin.video.iptvbalkan/?action=play&provider=a1&id=%s%s"
                    % (cid, self._account_param())),
            # ARCHIVE IS PER EVENT on this service, so the channel offers one and the per-programme
            # answer decides. What stops a viewer being offered something that cannot play is the
            # guide: an event id is written into the map ONLY where `entitlements.catchupTV` allows
            # replay, so a refused programme never reaches a Replay button. See `epg`.
            "catchup_days": self.settings.epg_days_back() or 7,
            "catchup_source": ("plugin://plugin.video.iptvbalkan/?action=play&provider=a1&id=%s%s"
                               "&utc={utc}" % (cid, self._account_param())),
            # ONE MINT PER PROGRAMME, seeked inside — `catchupEvent` answers a manifest with its own
            # streamStart/streamEnd. Iris' model, not EON's sliding window: re-minting per seek would
            # restart playback instead of moving it.
            "catchup_mode": "vod",
            "catchup_play_as_live": False,
        }

    # ---- guide -------------------------------------------------------------

    def epg(self, channels, hours_back=24, hours_forward=48):
        """
        The guide — an INSTANT with a COUNT either side, which is what this service takes.

        Not a window. `eventsAt(time:, previous:, following:)`, answering `items[]` rather than the
        `edges/node` shape the channel list uses. Kodi thinks in days, so the days are turned into counts
        here at [EVENTS_PER_DAY] and clamped to the horizons the archive actually has.

        A COUNT IS NOT THE SAME AS A WINDOW, and the difference bit the Android edition: at 15 events a
        day, seven days asked for 105 programmes and RTS1 — whose programmes are long — reached 3.4 days,
        so replay worked on some channels and not others depending on how long their shows are.

        THE EVENT ID IS WRITTEN OUT ONLY WHERE REPLAY IS PERMITTED. `entitlements.catchupTV` is false on
        about a third of archive rows (rights the operator does not hold), and those carry the deliberate
        never-date `catchupTVAvailableUntil = 2000-01-01`. Minting one earns `0x02000703`, access denied
        — which is what "the archive is broken" was, for three rounds. Refusing before the round trip
        costs nothing and is honest.
        """
        del channels                                               # the query is per channel LIST
        self.login()
        previous = min(MAX_PREVIOUS, max(1, int(round(hours_back / 24.0 * EVENTS_PER_DAY))))
        following = min(MAX_FOLLOWING, max(1, int(round(hours_forward / 24.0 * EVENTS_PER_DAY))))
        now = _iso(time.time())
        out, archive, cursor, pages, denied = [], {}, None, 0, 0
        while pages < MAX_PAGES:
            # ASKED INSIDE THE LONG LOOP, as `Provider.stopping` requires. This is the loop that costs
            # minutes — up to 60 pages of 100 channels, each carrying hundreds of events — and Kodi
            # waits for the service thread to return before it will shut down. Whatever has been
            # collected is still written below, so a refresh interrupted here is short, not lost.
            if self.stopping():
                diag.log("A1: Kodi is closing — the guide stops with %d programmes collected" % len(out))
                break
            pages += 1
            variables = {"channelListId": self.channel_list_id, "first": PAGE,
                         "currentTime": now, "previous": previous, "following": following}
            if cursor:
                variables["after"] = cursor
            data = self._call("gridGuide", Q_GRID_GUIDE, variables)
            connection = ((data.get("channelList") or {}).get("channels")) or {}
            edges = connection.get("edges") or []
            if not edges:
                break
            for edge in edges:
                node = (edge or {}).get("node") or {}
                cid = str(node.get("id") or "")
                if not cid:
                    continue
                for event in ((node.get("events") or {}).get("items")) or []:
                    programme = self._programme(event, cid)
                    if not programme:
                        continue
                    out.append(programme)
                    if not (event.get("entitlements") or {}).get("catchupTV"):
                        denied += 1
                        continue
                    archive.setdefault(cid, []).append(
                        [int(_epoch(event.get("start"))), int(_epoch(event.get("end"))),
                         str(event.get("id") or "")])
            info = connection.get("pageInfo") or {}
            if not info.get("hasNextPage"):
                break
            cursor = info.get("endCursor") or ""
            if not cursor:
                break
        store.write_json(self.cache_path(ARCHIVE_CACHE), archive)
        diag.log("A1: %d programmes over %d channels (%d asked for either side of now); %d cannot be "
                 "replayed and are not offered" % (len(out), len(archive), previous + following, denied))
        return out

    def _programme(self, event, channel_id):
        """
        One guide row.

        A programme with no time would land at 1970 in the middle of the guide, so it is dropped rather
        than published. `shortDescription` is not asked for: it was never seen on a guide event (only on
        `getEventDetail`, a different query), and this service answers a node that matches nothing with a
        bare `__typename` and no error at all — silence being the expensive failure mode here.
        """
        start, end = _epoch(event.get("start")), _epoch(event.get("end"))
        title = str(((event.get("metadata") or {}).get("title")) or "")
        if not start or not end or not title:
            return None
        return {
            "channel_id": self.scoped("a1_%s" % channel_id),
            "start": time.strftime("%Y%m%d%H%M%S +0000", time.gmtime(start)),
            "stop": time.strftime("%Y%m%d%H%M%S +0000", time.gmtime(end)),
            "title": title,
            "desc": "",
        }

    # ---- playback ----------------------------------------------------------

    def resolve(self, channel_ref, at_utc=None, vod=False):
        """
        A tune, live or from the archive.

        THREE ROUTES, ONE MINT EACH. Live goes to `playChannel`; a replay and a video-club title both
        go to `catchupEvent`, because on this account they are the same thing — the club is built out of
        past broadcasts and a club row's id IS an event id.
        """
        if vod:
            # A CLUB TITLE IS AN ARCHIVE EVENT, so it takes the same mint. Not a
            # shortcut: on this account the club is built out of past broadcasts and
            # the id in the row IS an event id. One resolver, because there is
            # genuinely one thing to resolve.
            self.login()
            return self._mint_catchup(str(channel_ref))
        self.login()
        if at_utc:
            return self._resolve_archive(str(channel_ref), int(at_utc))
        return self._resolve_live(str(channel_ref))

    def _resolve_live(self, channel_ref):
        data = self._call("playChannel", Q_PLAY_CHANNEL, {"input": {"channelId": channel_ref}})
        info = ((data.get("playChannel") or {}).get("playbackInfo")) or {}
        return self._playback(info, channel_ref)

    def _resolve_archive(self, channel_ref, at_utc):
        """
        A replay, addressed by the EVENT that was on at that instant.

        IPTV Simple gives us a timestamp; this service takes an event id. The guide pass wrote the map,
        so the ordinary case is a lookup. When it misses — a guide older than the map, a profile that
        lost the file — one narrow window is asked for rather than giving up, because a viewer pressing
        Replay does not care which of our files is stale.
        """
        event_id = self._event_at(channel_ref, at_utc) or self._event_from_service(channel_ref, at_utc)
        if not event_id:
            raise ProviderError(
                "A1: arhiva se traži po emisiji, a za to vreme nijedna nije u vodiču. "
                "Osveži vodič pa pokušaj ponovo.")
        return self._mint_catchup(event_id)

    #: How many playback sessions this kind of account may hold at once.
    #:
    #: MEASURED on a quiet account, not assumed: the FOURTH mint is refused with
    #: `0x02000704, maximum number of playback sessions reached`. (An earlier measurement said TWO — it
    #: was taken while a test box was itself holding one, so it counted the wrong number. A concurrency
    #: limit can only be measured from an account nobody else is using.)
    #:
    #: Worth naming here because the refusal is otherwise a mystery: three is small enough that one
    #: un-released session costs a third of the household, which is exactly what `stop_heartbeat` and
    #: `stopPlayback` exist to prevent.
    CONCURRENT_SESSIONS = 3

    def _mint_catchup(self, event_id):
        data = self._call("catchupEvent", Q_CATCHUP_EVENT, {"input": {"eventId": event_id}})
        info = ((data.get("catchupEvent") or {}).get("playbackInfo")) or {}
        return self._playback(info, event_id)

    def _event_at(self, channel_ref, at_utc):
        """The event covering [at_utc] on this channel, out of the map the guide pass wrote."""
        rows = (_read_json(self.cache_path(ARCHIVE_CACHE)) or {}).get(channel_ref) or []
        for row in rows:
            try:
                start, end, event_id = int(row[0]), int(row[1]), str(row[2])
            except (IndexError, TypeError, ValueError):
                continue
            if start <= at_utc < end and event_id:
                return event_id
        return ""

    def _event_from_service(self, channel_ref, at_utc):
        """
        The same question asked of the SERVICE, centred on the instant itself.

        `eventsAt` is exactly the right call for this: an instant with a small count either side. Used
        when the map the guide wrote does not cover the moment — a guide older than the map, a profile
        that lost the file — because a viewer pressing Replay does not care which of our files is stale.
        """
        cursor, pages = None, 0
        while pages < MAX_PAGES:
            pages += 1
            variables = {"channelListId": self.channel_list_id, "first": PAGE,
                         "currentTime": _iso(at_utc), "previous": 2, "following": 2}
            if cursor:
                variables["after"] = cursor
            try:
                data = self._call("gridGuide", Q_GRID_GUIDE, variables)
            except (ProviderError, net.HttpError) as err:
                diag.log("A1: the archive lookup could not ask the service (%s)" % err)
                return ""
            connection = ((data.get("channelList") or {}).get("channels")) or {}
            for edge in connection.get("edges") or []:
                node = (edge or {}).get("node") or {}
                if str(node.get("id") or "") != channel_ref:
                    continue
                for event in ((node.get("events") or {}).get("items")) or []:
                    if not (_epoch(event.get("start")) <= at_utc < _epoch(event.get("end"))):
                        continue
                    if not (event.get("entitlements") or {}).get("catchupTV"):
                        # The service says no in advance and for free. Minting anyway is what produced
                        # `0x02000703`, access denied, and looked like a broken player.
                        diag.log("A1: that programme carries no replay rights — not offering it")
                        return ""
                    return str(event.get("id") or "")
                return ""                                          # found the channel, no such event
            info = connection.get("pageInfo") or {}
            if not info.get("hasNextPage"):
                break
            cursor = info.get("endCursor") or ""
            if not cursor:
                break
        return ""

    # ---- the video club ----------------------------------------------------

    def vod(self, node=None):
        """
        The on-demand tree — which on this account IS THE ARCHIVE.

        There is no film store here. The club is built out of past broadcasts that catch-up can still
        play, and the tree is: home shelves -> VODFolder (Sport, Filmovi, Deciji program, Zabava) ->
        `content.folders` (genres) -> items, which are `Event`s and a handful of `Series`.

        That last fact is the whole reason the club was empty for three rounds: the query asked for
        VODFolder, VODAsset and Series and NOT `Event`, and a node matching no inline fragment comes back
        as a bare `__typename` with no error at all. The films were never missing — they were never asked
        for, and nothing was invalid, so nothing complained.

        A title is played through the SAME route a replay uses, because it IS one: `vod=<eventId>`.
        """
        self.login()
        if not node:
            return self._vod_roots()
        return self._vod_level(str(node))

    def _vod_roots(self):
        """
        The top folders, found on the HOME shelves.

        `vodRootContentFolderList` exists and answers, and it is the obvious place to look — but on this
        account it holds only an adult folder. The real tree hangs off the home shelf.
        """
        data = self._call("home", Q_HOME, {"profileId": self.profile_id})
        rows = ((data.get("homeRows") or {}).get("folders") or {}).get("edges") or []
        out, seen = [], set()
        for row in rows:
            for entry in (((row or {}).get("node") or {}).get("items") or {}).get("edges") or []:
                item = (entry or {}).get("node") or {}
                if item.get("__typename") != "VODFolder":
                    continue
                folder_id = str(item.get("id") or "")
                if not folder_id or folder_id in seen:
                    continue
                seen.add(folder_id)
                out.append({"kind": "dir", "name": str(item.get("title") or folder_id),
                            "node": folder_id})
        diag.log("A1: video club — %d top folders" % len(out))
        return out

    def _vod_level(self, node):
        """
        One screen of the club.

        THE GENRE IS NOT A FOLDER OF ITS OWN. `vodFolder(id:)` takes the id of a top folder, and ONE call
        answers both its genres and their titles — `content.folders[].items[]`. Handing a genre's id back
        to `vodFolder` is refused (`0x02001100`, "content folder not found"), which is what the first
        version of this did: it read the tree correctly and then asked the wrong question about it.

        So the node this provider hands out is `<folderId>` for a top folder and `<folderId>/<genreId>`
        for a genre, and both are answered by the same single call. No id is invented and nothing is
        cached between screens — the plugin process does not live long enough for a cache to help.
        """
        folder_id, _, genre_id = str(node).partition("/")
        data = self._call("getVODFolderDetail", Q_VOD_FOLDER,
                          {"id": folder_id, "firstFolders": 40, "firstItems": 60,
                           "thumbnailHeight": 300})
        folder = data.get("vodFolder") or {}
        genres = (((folder.get("content") or {}).get("folders") or {}).get("edges")) or []

        if genre_id:
            for edge in genres:
                node_genre = (edge or {}).get("node") or {}
                if str(node_genre.get("id") or "") == genre_id:
                    return self._vod_items(node_genre)
            return []

        out = []
        for edge in genres:
            genre = (edge or {}).get("node") or {}
            title = str(genre.get("title") or "")
            gid = str(genre.get("id") or "")
            if not title or not gid:
                continue
            total = int(((genre.get("items") or {}).get("totalCount")) or 0)
            out.append({"kind": "dir",
                        "name": "%s (%d)" % (title, total) if total else title,
                        "node": "%s/%s" % (folder_id, gid)})
        if out:
            return out
        # A LEAF: no genres under it, so its own items are the answer.
        return [row for edge in genres
                for row in self._vod_items((edge or {}).get("node") or {})]

    def _vod_items(self, genre):
        """The titles of one genre, with everything the account cannot replay left out."""
        rows, denied = [], 0
        for entry in ((genre.get("items") or {}).get("edges")) or []:
            item = (entry or {}).get("node") or {}
            kind = item.get("__typename")
            title = str(item.get("title") or "")
            if not title:
                continue
            thumb = ((item.get("thumbnail") or {}).get("url") or "")
            if kind == "Event":
                # THE ONE CHECK THAT MATTERS. About a third of these carry no replay rights, with the
                # deliberate never-date 2000-01-01, and offering one earns access denied at the exact
                # moment somebody presses play — which is what "the archive is broken" turned out to be.
                if not (item.get("entitlements") or {}).get("catchupTV"):
                    denied += 1
                    continue
                rows.append({"kind": "item", "name": title, "id": str(item.get("id") or ""),
                             "logo": thumb,
                             "plot": str((item.get("channel") or {}).get("title") or "")})
            elif kind == "VODAsset":
                rows.append({"kind": "item", "name": title, "id": str(item.get("id") or ""),
                             "logo": thumb, "duration": int(item.get("duration") or 0)})
            # `Series` and `VODFolder` are skipped here rather than offered as directories: their ids are
            # not `vodFolder` ids either (see _vod_level), and offering a row that answers nothing is
            # worse than a shorter list. They are a handful next to the films.
        if denied:
            diag.log("A1: video club — %d titles hidden because they carry no replay rights" % denied)
        return rows

    def _playback(self, info, channel_ref):
        url = str(info.get("url") or "")
        if not url:
            raise ProviderError("A1: servis nije vratio adresu strima za taj kanal.")
        session_id = str(info.get("sessionId") or "")
        heartbeat = info.get("heartbeat") or {}
        # RECORDED BEFORE THE STREAM IS HANDED OVER, because the service's keepalive loop runs in
        # ANOTHER process and this one is about to end. Without the session id there is nothing to
        # release, and an un-released session holds a concurrency slot until it times out.
        store.write_json(self.cache_path(NOW_PLAYING), {
            "url": url, "session": session_id, "channel": channel_ref,
            "hb_url": str(heartbeat.get("url") or ""),
            "hb_interval": int(heartbeat.get("interval") or 0),
            "hb_auth": bool(heartbeat.get("includeAuthHeaders")),
            "at": time.time(),
        })
        result = {
            "url": url,
            "manifest_type": "mpd",
            "license_type": "com.widevine.alpha",
            "headers": {"SDSEVO_SESSION_ID": self.sid, "SDSEVO_DEVICE_ID": self.did,
                        "SDSEVO_USER_ID": self.uid},
        }
        # NO TIMESHIFT BUFFER FOR A REPLAY, declared rather than left to the default. `catchupEvent`
        # answers a manifest with its own `streamStart`/`streamEnd`, so the programme is a BOUNDED
        # video that the player seeks inside — Iris' model, not EON's twelve-second sliding window,
        # which is the one case that genuinely needs the buffer. `test-tune.py` keeps a table of which
        # provider is which shape, and refuses any provider that does not say.
        if info.get("streamStart") or info.get("streamEnd"):
            result["timeshift"] = False
        # THE LICENCE KEY, AND THE ONE CHARACTER THAT BROKE IT.
        #
        # inputstream.adaptive parses this field by splitting on `|`: url | request headers | challenge |
        # response. The headers were joined RAW — and A1's session token is a base64 blob with an ECDSA
        # signature appended after a literal `|`:
        #
        #     …bWFpbC5jb218MQ==|MEYCIQCSIjzJueE9BT/FbykB/rDHeQj05KlD…
        #
        # so the token cut the field in half. Everything after its `|` became the challenge and response
        # slots, the licence request went out malformed, and Kodi answered with a decrypter error while
        # the manifest, the session and the mint were all perfectly healthy. From the sofa that is
        # "problem sa DRM dekripterom", on a loop, with no way out. Read off the owner's own log,
        # 2026-08-09.
        #
        # `playlist.header_blob` is the fix and it already existed for exactly this: it urlencodes each
        # value, and inputstream.adaptive urldecodes them. Its own note names the same trap on Move's
        # base64 `X-Play-Auth` — "the value that eventually will" contain one of `&`, `+`, `%`. It did.
        #
        # `Content-Type` rides along because every working licence request in this addon sends it (see
        # iris.py and yettel.py); a Widevine POST without it is refused by some proxies.
        from .. import playlist
        result["license_key"] = "%s|%s|R{SSM}|" % (
            self.widevine_url(),
            playlist.header_blob(dict(result["headers"], **{"Content-Type": "application/octet-stream"})))
        return result

    # ---- session lifecycle -------------------------------------------------

    def playing_url(self):
        return (_read_json(self.cache_path(NOW_PLAYING)) or {}).get("url") or ""

    def heartbeat(self):
        """
        Holds the playback session open. Driven by service.py while our stream is the one on screen.

        The service SAYS how long it has left, so a returned timeout that is shorter than the loop's own
        tick is worth naming — it is the only warning anybody would get before streams start dropping.
        """
        state = _read_json(self.cache_path(NOW_PLAYING)) or {}
        if not state.get("session"):
            return False
        try:
            data = self._call("keepAlive", Q_KEEP_ALIVE)
            left = int(((data.get("keepSessionAlive") or {}).get("sessionTimeout")) or 0)
            if 0 < left < 45:
                diag.log("A1: the service says this session has %ds left, which is less than the "
                         "keepalive interval — the stream may drop" % left)
        except (ProviderError, net.HttpError) as err:
            diag.log("A1: keepalive failed (%s)" % err)
        return True

    def stop_heartbeat(self):
        """
        Releases the playback session — and this one is NOT housekeeping.

        An un-released session holds one of the account's concurrent-stream slots until the service
        times it out on its own, so skipping it turns a few channel changes into "nothing will play".
        Best effort: this runs while the player is being torn down and must never surface to the viewer,
        but it must still be ATTEMPTED.
        """
        path = self.cache_path(NOW_PLAYING)
        state = _read_json(path)
        session_id = str(state.get("session") or "")
        try:
            os.remove(path)
        except OSError:
            pass
        if not session_id:
            return
        try:
            self.login()
            self._call("stopPlayback", Q_STOP_PLAYBACK, {"input": {"sessionId": session_id}})
        except (ProviderError, net.HttpError) as err:
            diag.log("A1: the playback session could not be released (%s) — it will free itself when "
                     "the service times it out" % err)

    # ---- diagnostics -------------------------------------------------------

    def diagnose(self):
        rows = []
        ok, detail = net.probe(self.session, self.auth_base() + "/GetToken")
        rows.append(("Reachable", ok, detail))
        rows.append(("Credentials", bool(self.setting("username") and self.setting("password")),
                     self.setting("username") or "not set"))
        device = str(self.setting("device_id") or "")
        rows.append(("Device identity", bool(_DEVICE_SHAPE.match(device.lower())),
                     (device[:12] + "…") if device else "will be minted on first login"))
        try:
            self.login()
            rows.append(("Login", True, "profile %s, list %s" % (self.profile_id,
                                                                 self.channel_list_id)))
        except ProviderError as err:
            rows.append(("Login", False, err.message))
            return rows
        try:
            channels = self.channels()
            rows.append(("Channel list", bool(channels), "%d channels" % len(channels)))
        except Exception as err:                                   # noqa: BLE001
            rows.append(("Channel list", False, "%s: %s" % (type(err).__name__, err)))
            return rows
        # And then actually mint one — see Provider.diagnose_playback. On this service that row proves
        # something no other row can: the concurrency slots. A login succeeds while every slot is held
        # by a session an earlier crash never released, and only the mint finds out.
        rows.extend(self.diagnose_playback(channels))
        return rows


# ---- helpers ---------------------------------------------------------------

def _q(value):
    try:
        from urllib.parse import quote
    except ImportError:                                            # pragma: no cover
        from urllib import quote
    return quote(str(value or ""), safe="")


def _iso(epoch):
    """The service takes ISO-8601 in UTC, with the Z — the shape `Instant.toString()` produces."""
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(int(epoch)))


def _epoch(text):
    """
    An ISO-8601 stamp as a unix time, or 0.

    Zero on anything unparseable rather than an exception: one malformed programme must not cost the
    whole guide, and the caller drops a programme with no time.
    """
    text = str(text or "").strip()
    if not text:
        return 0
    if text.endswith("Z"):
        text = text[:-1] + "+0000"
    elif len(text) > 6 and text[-3] == ":" and text[-6] in "+-":
        text = text[:-3] + text[-2:]
    for shape in ("%Y-%m-%dT%H:%M:%S.%f%z", "%Y-%m-%dT%H:%M:%S%z"):
        try:
            import datetime
            return int(datetime.datetime.strptime(text, shape).timestamp())
        except (ValueError, TypeError):
            continue
    return 0


def _looks_like_session_error(message):
    """Whether a GraphQL refusal reads like a dead session rather than a real 'no'."""
    lowered = str(message or "").lower()
    return any(word in lowered for word in
               ("session", "token", "unauthorized", "unauthenticated", "not logged", "expired"))


def _read_json(path):
    """One small file back as a dict, or {} — never an exception. Same shape every provider here uses;
    the WRITES all go through `store.write_json`, which is atomic."""
    try:
        with io.open(path, "r", encoding="utf-8") as handle:
            data = json.loads(handle.read())
        return data if isinstance(data, dict) else {}
    except (OSError, IOError, ValueError):
        return {}
