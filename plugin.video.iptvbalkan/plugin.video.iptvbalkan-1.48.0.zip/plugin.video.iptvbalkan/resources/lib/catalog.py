# -*- coding: utf-8 -*-
"""
Builds the playlist and guide from whichever providers are enabled.

One rule runs through all of it: **a provider that fails must never take the others down.** A user with
EON, Move and an Xtream account has three independent subscriptions, and an expired one, a provider
outage or a blocked User-Agent on any of them must leave the other two working. So each provider is
wrapped, its failure is recorded as a row in the status the settings screen shows, and the build carries
on with whatever succeeded.

The second rule: **never publish an empty playlist over a good one.** A refresh that produces nothing —
every provider down, the network gone — must leave yesterday's file alone, because an empty M3U wipes
the user's channel list until the next successful refresh.
"""

import io
import os
import time

from . import catcache, diag, kodisettings, licence, playlist
from .i18n import T
from .provider import enabled_providers, ProviderError


#: How far apart two providers' channel numbers are kept. Wide enough for the biggest line-up seen
#: (EON runs to ~1065 once its radio block is counted) with room to grow.
NUMBER_BLOCK = 2000


#: Where each provider's number block is remembered, so it stays the same block for ever. See
#: [_block_index]. A plain string setting ("eon=0,iris=1"), because it is small, it has to survive a
#: reinstall of nothing in particular, and it is worth being able to read it by eye.
BLOCKS_SETTING = "channel_blocks"


def _block_key(provider):
    """One provider ACCOUNT, since two accounts of the same provider are two line-ups."""
    return "%s%s" % (provider.key, ("#%s" % provider.account_id) if provider.account_id else "")


def _read_blocks(settings):
    out = {}
    for pair in str(settings.get(BLOCKS_SETTING, "") or "").split(","):
        name, _, index = pair.partition("=")
        if name.strip() and index.strip().isdigit():
            out[name.strip()] = int(index.strip())
    return out


def _block_index(settings, provider, assigned):
    """
    Which block of channel numbers this provider owns — the SAME one every time.

    THE BUG THIS REPLACES. The block used to be the provider's POSITION in the enabled list, and that
    position moves. Disable Iris on a box running EON, Iris and Move and Move's channels all shift down
    by 2000: every number the household has learned is wrong, every PVR favourite and every channel
    group Kodi keeps by number points somewhere else, and nothing on screen connects it to the checkbox
    that was just unticked. Re-enable it and they move back, which makes it look intermittent.

    So the block is assigned ONCE per provider account and remembered. A new provider takes the lowest
    block nobody holds — which is also what keeps a single-provider install on block 0, i.e. exactly
    the provider's own numbering, as before.

    [assigned] is this refresh's map, updated in place, so two providers in one pass cannot both be
    handed the same free block.
    """
    key = _block_key(provider)
    if key in assigned:
        return assigned[key]
    taken = set(assigned.values())
    index = 0
    while index in taken:
        index += 1
    assigned[key] = index
    return index


def _number_block(channels, index, label):
    """
    Give each provider after the first its own block of channel numbers.

    Every provider numbers its own line-up from 1, so two enabled at once produce two channels numbered
    1, two numbered 2, and so on. IPTV Simple takes those numbers at face value: the duplicates are the
    ones you cannot reach by typing a number on the remote, and nothing reports the clash — the list
    just quietly has two entries fighting over each slot.

    The provider holding block 0 keeps its own numbering untouched, so a single-provider install (which
    is most of them) looks exactly like the provider's own app.
    """
    if index <= 0:
        return
    offset = index * NUMBER_BLOCK
    for channel in channels:
        channel["number"] = int(channel.get("number") or 0) + offset
    diag.log("Catalogue: %s numbered from %d so it does not collide with the provider(s) above it"
             % (label, offset + 1))


#: The settings that are WRITTEN INTO the playlist rather than read when a channel is played.
#:
#: Nothing here can take effect without a rebuild, which is not obvious from the settings screen: the
#: archive toggle in particular emits a per-channel `#KODIPROP` line at refresh time. Somebody switching
#: it and then pressing play is entitled to see the difference, so the service compares this fingerprint
#: and rebuilds — see service._first_run_at and its settings-changed handler.
PLAYLIST_SETTINGS = ("group_by_provider", "archive_exact_bar", "epg_days_back", "epg_days_forward")


def playlist_fingerprint(settings):
    """What the playlist on disk was built with. A plain string, because it is written into a setting
    and read back by eye when something looks stale."""
    return "|".join("%s=%s" % (name, settings.get(name, "")) for name in PLAYLIST_SETTINGS)


class BuildResult(object):

    def __init__(self):
        self.channels = 0
        self.programmes = 0
        self.per_provider = []      # (label, ok, detail)
        self.written = False

    @property
    def ok(self):
        return self.written and self.channels > 0



def _write_files(settings, channels, programmes):
    """
    Put a playlist and a guide on disk, atomically.

    Written to temporary files and moved into place: IPTV Simple can be reading either at any moment,
    and a half-written playlist is a channel list that vanishes mid-refresh.
    """
    m3u_path, epg_path = settings.playlist_path(), settings.epg_path()
    tmp_m3u, tmp_epg = m3u_path + ".tmp", epg_path + ".tmp"
    playlist.write_m3u(tmp_m3u, channels, epg_url=epg_path,
                       group_by_provider=settings.get_bool("group_by_provider", True),
                       exact_archive_bar=settings.get_bool("archive_exact_bar", False))
    playlist.write_xmltv(tmp_epg, channels, programmes)
    os.replace(tmp_m3u, m3u_path)
    os.replace(tmp_epg, epg_path)


#: What "emptied" looks like on disk. Valid files with nothing in them, not missing ones — IPTV Simple
#: reads both on a schedule of its own and answers a MISSING playlist with an error per channel.
EMPTY_PLAYLIST = u"#EXTM3U\n"
EMPTY_GUIDE = u'<?xml version="1.0" encoding="UTF-8"?>\n<tv></tv>\n'


def clear_playlist(settings):
    """
    Take the channel list and the guide away, atomically. Returns True if there was anything to take.

    THE LAST DOOR THE KILL SWITCH COULD NOT REACH. Xtream and M3U channels are played from a DIRECT
    address — Kodi opens the panel itself and nothing of this addon is in that path, so unlike EON,
    Iris, Yettel and Move there is no moment at which a licence can be checked. A blocked box went on
    watching those channels from the playlist already on disk for as long as it stayed installed.

    Emptying the file is the only lever that exists for them, and it is a real one: IPTV Simple reloads
    and the channels are gone. Deliberately NOT how a blocked box was treated before — `build` refuses
    to REFRESH and leaves the file alone, on the reasoning that somebody who pays on Tuesday should
    find their list where they left it. That reasoning still holds for an EXPIRED trial, which is why
    this is not called from there; it is called for a device the owner has deliberately blocked.

    The cost, and it is the owner's to accept: unlocking is followed by a full rebuild (minutes on a
    five-provider box) rather than an instant return. Accounts, settings, resume positions and the
    licence state are untouched — only the two derived files go.
    """
    removed = False
    for path in (settings.playlist_path(), settings.epg_path()):
        blank = (EMPTY_PLAYLIST if path.endswith(".m3u") else EMPTY_GUIDE)
        try:
            if not os.path.exists(path):
                continue
            # ALREADY EMPTY IS NOTHING TO DO, and it has to be measured against the blank file rather
            # than against zero bytes: what is written here is a valid-but-empty M3U and XMLTV, so
            # `size > 0` is true forever afterwards. Without this the service rewrote both files on
            # every single pass of its loop for as long as the box stayed blocked, and told IPTV Simple
            # to reload each time.
            with io.open(path, "r", encoding="utf-8") as handle:
                if handle.read() == blank:
                    continue
            # Emptied through a replace rather than deleted: IPTV Simple may have either file open
            # at this instant, and a path that disappears underneath it is the one shape that makes
            # it log an error per channel instead of simply finding nothing.
            with io.open(path + ".tmp", "w", encoding="utf-8", newline="") as handle:
                handle.write(blank)
            os.replace(path + ".tmp", path)
            removed = True
        except (OSError, IOError, ValueError) as err:
            diag.log("Licence: the channel list could not be cleared (%s)" % err, "ERROR")
    if removed:
        diag.log("Licence: this device is blocked — the channel list and guide have been emptied. "
                 "They are rebuilt in full once it is unlocked.", "ERROR")
    return removed


def _has_playlist(settings):
    """Whether this box already has something to watch. False on a fresh install, and on one whose
    playlist was wiped — both are the case the early publish below exists for."""
    try:
        return os.path.getsize(settings.playlist_path()) > 0
    except OSError:
        return False


def build(settings, should_stop=None, only=None):
    """
    [should_stop] answers "has Kodi asked this process to go away" — `Monitor.abortRequested`, passed in
    by both callers. A build is the longest thing this addon does (two and a half minutes on the owner's
    box with EON and Iris enabled) and Kodi does not kill a running script on shutdown, it waits for it:
    on Android that wait sits on the UI thread, so a refresh that ignores the request IS the box that
    will not close. Nothing partial is ever written — a stopped build leaves the previous playlist alone,
    exactly like a failed one.

    [only] names the provider keys this rebuild is actually ABOUT — linking Yettel concerns Yettel, and
    fetching EON's three hundred guides again to find that out is six minutes spent proving nothing
    changed. The others are served from their cached block when there is a recent one, and fetched
    normally when there is not, so the worst case is the ordinary refresh. None (the default) fetches
    everything, which is what a scheduled refresh and a manual "refresh now" both mean.
    """
    result = BuildResult()

    # The licence gate sits HERE rather than only in front of playback, because a refresh is the
    # expensive half: an expired install that kept rebuilding a 300-channel catalogue with its guide
    # would go on hammering the provider every night for as long as it stayed installed. The existing
    # playlist is deliberately left alone — a user who pays on Tuesday should find their channel list
    # where they left it, not have to rebuild from nothing.
    verdict = licence.check(settings)
    if not verdict.allowed:
        result.per_provider.append(("Licenca", False, verdict.message or "Uredjaj nije otkljucan."))
        diag.log("Catalogue: refresh skipped — device %s is not unlocked" % (verdict.serial or "?"),
                 "ERROR")
        return result

    providers = enabled_providers(settings)
    if not providers:
        diag.log("Catalogue: no providers enabled — nothing to build")
        return result

    def stopping():
        try:
            return bool(should_stop and should_stop())
        except Exception:                                          # noqa: BLE001
            return False

    #: Read BEFORE anything is written, or the first early publish would make every later provider
    #: think the box already had a playlist.
    first_run = not _has_playlist(settings)
    #: What each provider cost, in the words the diagnostics screen shows. Every "it is slow" report so
    #: far has been answered by somebody going to the box and measuring; this is that measurement,
    #: taken while it is happening and kept where the person with the problem can read it out.
    timings = []
    started_all = time.time()
    all_channels, all_programmes = [], []
    # Never download more past guide than Kodi will keep — see kodisettings.past_guide_days. Read once
    # per refresh rather than per provider: it is a JSON-RPC round trip, and the answer cannot change
    # while a refresh runs.
    days_back = settings.epg_days_back()
    guide_days_back = kodisettings.past_guide_days(days_back)
    if guide_days_back < days_back:
        diag.log("Guide: %d day(s) back are set here but Kodi keeps %d, so %d is what gets downloaded "
                 "— the rest would be dropped on import. Raise it in Settings -> PVR -> Guide if you "
                 "want more." % (days_back, guide_days_back, guide_days_back))
    #: Providers that failed AND had nothing cached to stand in for them. Only these can still cost the
    #: whole refresh — see the guard below.
    uncovered = []
    #: Which number block each provider owns — read once, extended as new providers appear, written
    #: back at the end. See [_block_index] for why this is remembered rather than counted.
    blocks = _read_blocks(settings)
    for provider in providers:
        if stopping():
            diag.log("Catalogue: Kodi is closing — the refresh stops before %s" % provider.label)
            return result
        position = _block_index(settings, provider, blocks)
        started = time.time()
        # Reaches the long loops inside the provider: the guide is where the minutes are, and a check
        # between providers alone would still leave a 301-channel EON pass running through shutdown.
        provider.should_stop = should_stop

        def take_cached(note, ok, keep_days=catcache.KEEP_DAYS):
            """Merge this provider's last good block, if it has one. Returns True when it did."""
            block = catcache.load(provider, keep_days=keep_days)
            if not block:
                return False
            channels = block["channels"]
            _number_block(channels, position, provider.label)
            all_channels.extend(channels)
            all_programmes.extend(block["programmes"])
            # Through T() with the rest of the sentence, so the cached line stops being the one that
            # reads half in English and half in Serbian on the refresh screen.
            # [note] arrives already translated — see the call sites. Translating it HERE would have
            # been the trap this project has paid for before: two of the three notes are built by
            # interpolation, so no table entry can ever match them and T() over one is a no-op that
            # looks like coverage.
            detail = T("%d kanala, %d emisija, %s (%s)") % (
                len(channels), len(block["programmes"]), note, catcache.age_text(block["age"]))
            result.per_provider.append((provider.label, ok, detail))
            diag.log("Catalogue: %s -> %s" % (provider.label, detail), "INFO" if ok else "ERROR")
            return True

        # The cheap rebuild. A block is only reused here while it is younger than the refresh interval
        # the box is set to — past that it was due to be fetched anyway, and "only" must not be a way to
        # keep a week-old guide alive by linking an account every day.
        if only is not None and provider.key not in only:
            if take_cached(T("iz kesa"), True, keep_days=settings.refresh_hours() / 24.0):
                continue
            diag.log("Catalogue: %s has no recent cached block — fetching it after all" % provider.label)

        try:
            provider.login()
            channels = provider.channels()
            # Copied BEFORE the numbers are shifted: what is cached is the provider's own numbering, so
            # the block survives a provider being added, removed or disabled ahead of it. Shallow copies
            # — _number_block rewrites one key and nothing else here is mutated.
            raw = [dict(channel) for channel in channels]
            _number_block(channels, position, provider.label)
            all_channels.extend(channels)

            # CHANNELS NOW, GUIDE IN A MINUTE — but only on a box that has nothing.
            #
            # The guide is about ninety-five per cent of a refresh (one request per channel for EON,
            # minutes of them), and until this function reached its end a NEW install had no playlist at
            # all: somebody who has just typed in their account watches an empty TV list for five
            # minutes with nothing saying why. The channels themselves take about ten seconds.
            #
            # So on a box with no playlist, each provider's line-up is published the moment it arrives,
            # with an empty guide beside it, and the real guide replaces it at the end. Deliberately
            # NOT done on a box that already has a playlist: there the user is already watching
            # something, and rewriting the file mid-refresh would make Kodi reload its channel list for
            # no gain — see the watcher in service.py.
            if first_run and all_channels and not stopping():
                try:
                    _write_files(settings, sorted(all_channels,
                                                  key=lambda c: (int(c.get("number") or 0) or 10 ** 6,
                                                                 c["name"].lower())), [])
                    diag.log("Catalogue: first run — %d channels are watchable now, the guide follows"
                             % len(all_channels))
                except OSError as err:
                    # Never fatal: this is a courtesy, and the real write at the end is the one that
                    # matters. A full disk should fail there, where it is reported.
                    diag.log("Catalogue: the early channel list could not be written (%s)" % err)

            programmes = provider.epg(
                channels,
                hours_back=guide_days_back * 24,
                hours_forward=settings.epg_days_forward() * 24,
            )
            all_programmes.extend(programmes)
            detail = "%d channels, %d programmes, %.0fs" % (len(channels), len(programmes),
                                                            time.time() - started)
            timings.append("%s %.0fs (%d kanala, %d emisija)"
                           % (provider.label, time.time() - started, len(channels), len(programmes)))
            result.per_provider.append((provider.label, True, detail))
            diag.log("Catalogue: %s -> %s" % (provider.label, detail))
            # Stored only when the fetch produced something. A provider that answers an empty line-up is
            # not a reason to throw away the block that would cover it next time.
            if channels and not stopping():
                catcache.save(provider, raw, programmes)
        except ProviderError as err:
            # Expected, actionable failures (wrong password, expired subscription, blocked agent).
            diag.log("Catalogue: %s FAILED — %s" % (provider.label, err.message), "ERROR")
            if not take_cached(T("%s — zadrzan spisak") % err.message, False):
                result.per_provider.append((provider.label, False, err.message))
                uncovered.append(provider.label)
        except Exception as err:                                   # noqa: BLE001
            # Anything unexpected is still just one provider's problem.
            crash = "%s: %s" % (type(err).__name__, err)
            diag.log("Catalogue: %s crashed — %s" % (provider.label, crash), "ERROR")
            if not take_cached(T("%s — zadrzan spisak") % crash, False):
                result.per_provider.append((provider.label, False, crash))
                uncovered.append(provider.label)

    result.channels = len(all_channels)
    result.programmes = len(all_programmes)

    # Stopped part-way, so what is in hand is a SHORT guide — every provider's loop breaks where it
    # stands. Writing that over a complete one would trade a slow shutdown for a box that comes back up
    # missing half its programmes, and the next refresh is fifteen minutes away at worst.
    if stopping():
        diag.log("Catalogue: Kodi is closing — nothing written, the previous playlist stands")
        return result

    if not all_channels:
        diag.log("Catalogue: every provider produced nothing — keeping the previous playlist", "ERROR")
        return result

    # A provider that failed must not have its channels DELETED by the providers that succeeded.
    #
    # The guard above only covers "everything failed". With two providers enabled and one of them
    # refused — a lapsed token, a network blip mid-refresh — the playlist was rewritten from the
    # survivor alone, and the other one's few hundred channels simply vanished. Nothing said so: the
    # refresh reported success for the provider that worked.
    #
    # A failure whose block was found in the cache is already covered: those channels and their guide
    # are in hand, so the refresh goes ahead and everyone else gets a fresh one. What is left here is
    # the case the cache cannot answer — a provider that failed on the very first refresh after being
    # added, or one whose block has aged out. Retaining just its old entries would mean rewriting its
    # guide too, and a channel list without a guide is its own complaint. Keeping the WHOLE previous
    # pair is the honest trade: one refresh is skipped, everything the user had still works, and the
    # next refresh fixes it once the provider answers again.
    if uncovered:
        from . import search
        previous = search.parse_playlist(settings.playlist_path())
        kept = set(row.get("provider") or "" for row in previous)
        stranded = [label for label in uncovered if label in kept]
        if stranded:
            diag.log("Catalogue: %s failed but already had channels — keeping the previous playlist "
                     "rather than writing one without them" % ", ".join(stranded), "ERROR")
            return result

    # Stable order so the channel list does not reshuffle itself between refreshes: by number when the
    # provider gives one, then by name. A list that renumbers itself overnight is its own bug report.
    all_channels.sort(key=lambda c: (int(c.get("number") or 0) or 10 ** 6, c["name"].lower()))

    _write_files(settings, all_channels, all_programmes)
    result.written = True
    # After the write, never before: a box that is short of space should lose an unusable old block
    # rather than have the refresh it is in the middle of fail for the sake of housekeeping.
    catcache.prune(settings)

    # The number blocks, including any handed out this pass. Written after the playlist rather than
    # before: if the build failed and the playlist was not replaced, the numbering on disk is still the
    # old one, and a block assignment recorded for a provider whose channels never landed would be a
    # promise about a list nobody has.
    settings.set(BLOCKS_SETTING, ",".join("%s=%d" % (name, index)
                                          for name, index in sorted(blocks.items())))
    settings.set("last_refresh", time.strftime("%Y-%m-%d %H:%M"))
    timings.append("ukupno %.0fs" % (time.time() - started_all))
    settings.set("last_refresh_timings", " · ".join(timings))
    settings.set("last_channel_count", str(result.channels))
    # Recorded HERE rather than by the caller, so a manual refresh counts too: whoever rebuilt it, this
    # file now carries these values.
    settings.set("playlist_built_with", playlist_fingerprint(settings))
    # The SIZE of the guide is logged as well as its programme count, because it is the number to
    # compare against IPTV Simple's own "EPG Loaded - N (ms)" line when a box is slow to open its TV
    # section. Measured once on an ARM 32-bit box: 18 MB imported in 1,024 ms, so this is rarely the
    # answer — but it is cheap to know rather than guess.
    try:
        guide_mb = os.path.getsize(settings.epg_path()) / (1024.0 * 1024.0)
    except OSError:
        guide_mb = 0.0
    diag.log("Catalogue: wrote %d channels and %d programmes (guide %.1f MB, %d days back / %d forward)"
             % (result.channels, result.programmes, guide_mb,
                settings.epg_days_back(), settings.epg_days_forward()))
    return result
