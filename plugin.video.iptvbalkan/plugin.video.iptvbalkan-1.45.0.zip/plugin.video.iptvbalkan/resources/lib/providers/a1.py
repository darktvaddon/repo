# -*- coding: utf-8 -*-
"""
A1 Xplore TV (`xploretv.rs`) — the sixth backend, and the first one that is **GraphQL**.

Ported from the Android edition's `A1Api.kt`, which was itself written from a live logged-in session on
2026-08-08 and is documented in `A1-XPLORE-API.md`. Nothing here is guessed: this project has twice paid
for "written but unproven", and both times it meant written against a shape the service does not serve.

The platform is **Zappware NeXX 4.0** — not EON's United Cloud, not Iris' Huawei VSP, not Yettel's
Kaltura, not Move's MTS-SI. Private edition only, like the other operator sources.

FIVE THINGS THAT ARE UNUSUAL ENOUGH TO STATE UP FRONT
=====================================================

**1. There is no login operation in the GraphQL schema.** Sign-in is one REST call on a different port
(8843), and the subscriber's username and password travel in the QUERY STRING. That is the service's
design, not a choice available here — and it is why `diag`'s redaction had to learn the word `pwd`
before this file could exist. A traced login would otherwise have written a working password into the
last 55 kB of the log, which is exactly the part that rides along with every support report.

**2. The device id is invented by the CLIENT, and every new one costs a subscription slot.** The web
stores a 32-hex `fingerprint` in localStorage and presents it as `devId`; the server does not issue it.
So a client that mints a fresh one per launch registers a new device per launch. That is not a
hypothesis — `DeviceIdentity` in IptvBoxWin did precisely that. Minted once, written back through
`Provider.remember` (which SAYS SO when the write does not stick), and adoptable: paste the id your
browser or another box already uses and no new slot is spent. Same pattern as `yettel_known_udid`, for
the same reason. Never compiled in — see what shipping the owner's own Yettel udid cost.

**3. Playback is a SESSION with three parts, and the third is not optional.** `playChannel` mints it,
`keepAlive` holds it open, `stopPlayback` releases it. Skip the release and the session lingers until
the service times it out, quietly holding one of the account's concurrent-stream slots; a viewer who
zaps a few times and then cannot start anything is the symptom, and the cause is something that was not
sent minutes earlier. `service.py`'s keepalive loop drives both — this provider is in
`_KEEPALIVE_PROVIDERS` beside Iris.

**4. `keepAlive` takes no arguments and returns `sessionTimeout`** — the service itself says how many
seconds are left. Iris' fixed 45 s is the weaker version of the same idea.

**5. Catch-up is addressed by EVENT ID, not by a timestamp.** IPTV Simple hands us `{utc}`, so the two
have to be bridged: the guide pass writes a small map of (channel, start, end) -> event id, and a replay
looks the instant up in it. A miss is answered with a sentence a viewer can act on rather than a
failure, and it falls back to asking the service for a narrow window before giving up. The reply carries
`streamStart`/`streamEnd`, so unlike EON the seek bar is TRUTHFUL and one mint covers the whole
programme — that is the Iris model, `catchup_mode="vod"`, and it must not be re-minted per seek.

WHAT IS DELIBERATELY NOT HERE
=============================

**Video klub.** A1 has one (folder tree behind `getVODFolderDetail`, reached from the home screen rather
than a menu), and the Android edition does not implement it either. `supports_vod` stays False: a
provider that claims on-demand and cannot play it sends every press down the live path and answers a
film with "that channel is not in the list" — the exact fault Move shipped once.

**Device management.** The schema has `createDevice`, `deleteDevice` and `deleteForeignDevice`, so
freeing a slot from here is possible and worth having. The INPUT SHAPES were never captured, and
inventing an argument name to try is guessing with somebody's subscription. `supports_devices` stays
False until one real capture exists.
"""

import io
import json
import os
import re
import time
import uuid

from .. import diag, net, store
from ..provider import Provider, ProviderError, register

#: The GraphQL endpoint, and the REST auth service — different ports, and that is the service's layout.
GRAPHQL = "https://web.xploretv.rs:8443/sdsmiddleware/A1_Serbia/graphql/4.0"
AUTH_BASE = "https://web.xploretv.rs:8843/ext_dev_facade/auth"

#: Sent verbatim, as the web client does — the platform's own client-identity header.
ZAPPWARE_UA = "nexx4web/30.0.4 (Chrome)"

#: Widevine, on A1's own proxy — from the site's public `config_395.js`. NOT castLabs DRMtoday: castLabs
#: is only the web player, so there is no `dt-custom-data` header of the kind Iris needs.
WIDEVINE_LICENCE_URL = "https://wvps.a1xploretv.bg:8063"

#: Cursor-paged, Relay style. 100 is what the web asks for.
PAGE = 100
#: A stop for the paging walks. A service that always reported another page would otherwise spin for
#: ever, and a refresh that never ends is worse than one that stops short and says so.
MAX_PAGES = 60

#: Logo size is requested rather than scaled — the path itself carries it (`76x28_channel`).
LOGO_W, LOGO_H, LOGO_FLAVOUR = 76, 28, "DARK"

#: The signed-in session, kept between PROCESSES. The plugin runs for one action — one tune, one screen
#: — so a token held only in memory is thrown away at the moment it becomes useful.
SESSION_CACHE = "a1_session.json"
#: `exp_period` comes back from the login and is respected; this is the ceiling when it does not.
SESSION_MAX_AGE = 6 * 3600

#: (channel, start, end) -> event id, written by the guide pass so a replay can be addressed at all.
#: See the module docstring, point 5.
ARCHIVE_CACHE = "a1_events.json"

#: What this provider last handed the player, so the service's keepalive knows whether the stream on
#: screen is ours — and so `stopPlayback` can name the session it is releasing.
NOW_PLAYING = "a1_playing.json"

#: What a client-minted device identity looks like: 32 lowercase hex, exactly as the web's fingerprint.
_DEVICE_SHAPE = re.compile(r"^[0-9a-f]{32}$")


# ---- the GraphQL documents --------------------------------------------------
#
# ONLY FIELDS THAT WERE ACTUALLY SEEN ARE ASKED FOR, and that rule is load-bearing. GraphQL rejects the
# WHOLE query when it names a field the schema does not have — not that field, the whole operation. So
# one hopeful extra field turns "the channel list" into "no channels", with an error that reads like a
# login problem.
#
# EVERY DECLARED VARIABLE MUST ALSO BE USED. The spec's "All Variables Used" rule (5.8.4) is a MUST, so
# a query declaring a variable its body never references is refused whole. When the Android version's
# selection sets were narrowed to the observed fields, the orphaned declarations were left behind and
# would have failed on the first live call, looking exactly like "A1 does not work".

Q_LIVE_TV = """
query liveTV($channelListId: ID!, $firstChannels: Int, $channelAfterCursor: String,
             $logoWidth: Int!, $logoHeight: Int!, $logoFlavour: ImageFlavour) {
  channelList(id: $channelListId) {
    channels(first: $firstChannels, after: $channelAfterCursor) {
      pageInfo { hasNextPage endCursor }
      edges {
        node {
          id
          title
          logo(width: $logoWidth, height: $logoHeight, flavour: $logoFlavour) { url }
        }
      }
    }
  }
}
"""

Q_GRID_GUIDE = """
query gridGuide($channelListId: ID!, $firstChannels: Int, $channelAfterCursor: String,
                $windowStart: DateTime!, $windowDuration: Duration!) {
  channelList(id: $channelListId) {
    channels(first: $firstChannels, after: $channelAfterCursor) {
      pageInfo { hasNextPage endCursor }
      edges {
        node {
          id
          events(windowStart: $windowStart, windowDuration: $windowDuration) {
            edges {
              node {
                id
                start
                end
                metadata { title }
              }
            }
          }
        }
      }
    }
  }
}
"""

Q_PLAY_CHANNEL = """
mutation playChannel($input: PlayChannelInput!, $profileId: ID!) {
  playChannel(input: $input) {
    playbackInfo {
      sessionId
      url
      trickplayRestrictions
      channel { id personalInfo(profileId: $profileId) { audioLanguage subtitleLanguage } }
      heartbeat { ... on HttpHeartbeat { url interval includeAuthHeaders } }
    }
  }
}
"""

Q_CATCHUP_EVENT = """
mutation catchupEvent($input: CatchupEventInput!) {
  catchupEvent(input: $input) {
    playbackInfo {
      sessionId
      url
      streamStart
      streamEnd
      trickplayRestrictions
      event {
        id
        startOverTVBeforeTime
        startOverTVAfterTime
        metadata { title seriesInfo { id title } episodeInfo { number season title } }
      }
      heartbeat { ... on HttpHeartbeat { url interval includeAuthHeaders } }
    }
  }
}
"""

Q_KEEP_ALIVE = "mutation keepAlive { keepSessionAlive { sessionTimeout } }"
Q_STOP_PLAYBACK = ("mutation stopPlayback($input: StopPlaybackInput!) "
                   "{ stopPlayback(input: $input) { success } }")
Q_SETUP_STEPS = "query getSetupSteps { setupSteps { profileId } }"
Q_INITIAL_CHANNEL_LISTS = "query getInitialChannelLists { initialChannelList { id } }"


@register
class A1Provider(Provider):

    key = "a1"
    label = "A1 Xplore"
    #: See the module docstring on both of these. Declared rather than left to be discovered.
    supports_vod = False
    supports_devices = False

    default_identity = {
        "user_agent": ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                       "(KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36"),
        "origin": "https://web.xploretv.rs",
        "referer": "https://web.xploretv.rs/",
        "extra_headers": {"Accept": "application/json"},
    }

    def __init__(self, settings):
        Provider.__init__(self, settings)
        self.session = net.Session(self.identity(), trace=settings.verbose())
        self.sid = ""                                              # SDSEVO_SESSION_ID
        self.did = ""                                              # SDSEVO_DEVICE_ID
        self.uid = ""                                              # SDSEVO_USER_ID
        self.profile_id = ""
        self.channel_list_id = ""
        #: True when the session came off disk. A refusal on one of those is worth one silent re-login;
        #: the same refusal on a session minted seconds ago is the real answer.
        self.session_restored = False
        #: True while the login chain runs, so the retry in _call cannot fire from inside it.
        self._logging_in = False

    # ---- server-steerable constants ----------------------------------------
    #
    # Every value that decides whether this backend answers at all, steerable from the panel — see
    # `Provider.tuned`. A Zappware client tag and a middleware path are exactly the kind of thing that
    # changes on the provider's release schedule rather than ours.

    def graphql_url(self):
        return self.tuned("a1_graphql", GRAPHQL)

    def auth_base(self):
        return self.tuned("a1_auth_base", AUTH_BASE).rstrip("/")

    def client_tag(self):
        return self.tuned("a1_client_tag", ZAPPWARE_UA)

    def widevine_url(self):
        return self.tuned("a1_widevine", WIDEVINE_LICENCE_URL)

    # ---- device identity ---------------------------------------------------

    def device_fingerprint(self):
        """
        The 32-hex identity this install presents as `devId`, minted once and remembered.

        A NEW VALUE IS A NEW REGISTERED DEVICE and costs one of the subscription's slots, so this must
        never mint on every launch — see the module docstring. The user's own setting wins: pasting the
        id their browser or another box already uses adopts that device instead of registering another.

        A stored value of the wrong shape is replaced rather than sent. The service takes 32 hex; handing
        it a uuid with dashes (which an earlier draft of this did, by reusing `Provider.device_id`) is a
        request that fails in a way that reads like bad credentials.
        """
        existing = str(self.setting("device_id") or "").strip().lower()
        if _DEVICE_SHAPE.match(existing):
            return existing
        if existing:
            diag.log("A1: the stored device id is not 32 hex — minting a new one. If you meant to adopt "
                     "an existing device, paste its id exactly as the browser shows it.", "ERROR")
        fresh = uuid.uuid4().hex
        # Through `remember`, which says so out loud when the write does not stick: an id that is lost
        # means the next login registers ANOTHER device and spends another slot, silently, for ever.
        self.remember("device_id", fresh)
        diag.log("A1: minted a device identity for this install (%s…) — paste it into another install "
                 "to share the same device slot" % fresh[:8])
        return fresh

    # ---- transport ---------------------------------------------------------

    def _headers(self):
        """The three headers every call carries. Absent before login, which is what bootstrap is for."""
        out = {"Zappware-User-Agent": self.client_tag(),
               # Per-request id. The service logs it, so a support report is traceable on their side and
               # not only on ours.
               "X-Correlation-Id": str(uuid.uuid4()),
               "Content-Type": "application/json"}
        if self.sid:
            out["SDSEVO_SESSION_ID"] = self.sid
            out["SDSEVO_DEVICE_ID"] = self.did
            out["SDSEVO_USER_ID"] = self.uid
        return out

    def _call(self, operation, query, variables=None, _retried=False):
        """
        One GraphQL call.

        A 200 IS NOT SUCCESS. GraphQL answers `200` with an `errors` array for a refused request, and
        reading only the status code loses the reason — the exact mistake Move's `success:false` already
        cost this project once. The message is the useful half and is safe to show; `extensions` can
        carry account detail and is deliberately left out.
        """
        if not self.sid and not self._logging_in:
            self.login()
        body = json.dumps({"operationName": operation, "query": query,
                           "variables": variables or {}})
        answer = self.session.post(self.graphql_url(), body=body, headers=self._headers())
        if not isinstance(answer, dict):
            raise ProviderError("A1: %s je odgovorio necim sto nije JSON." % operation)

        errors = answer.get("errors")
        if errors:
            first = ""
            if isinstance(errors, list) and errors and isinstance(errors[0], dict):
                first = str(errors[0].get("message") or "")
            # A session that died between processes looks like any other refusal, so a RESTORED one is
            # worth exactly one silent re-login. A fresh session refusing is the real answer.
            if (not _retried and self.session_restored and not self._logging_in
                    and _looks_like_session_error(first)):
                diag.log("A1: the stored session was refused — signing in again")
                self._forget_session()
                self.login()
                return self._call(operation, query, variables, _retried=True)
            raise ProviderError("A1: %s je odbijen — %s" % (operation, first or "bez objasnjenja"))

        data = answer.get("data")
        if not isinstance(data, dict):
            raise ProviderError("A1: %s nije vratio podatke." % operation)
        return data

    # ---- sign in -----------------------------------------------------------

    def login(self):
        """
        Sign in, then fetch the two ids every content call needs.

        ONE REST CALL, not GraphQL: there is no login operation anywhere in the schema (147 operations
        in the web bundle, none of them a login). The three fields it answers with map straight onto the
        three headers — `token` is the session, `device_id` the device, `user_id` the user.

        The username and password travel in the query string. `diag` redacts `user=` and `pwd=` out of
        traced URLs; if you ever add another parameter here, check that it is covered before shipping.
        """
        if self.sid:
            return
        if self._restore_session():
            return
        username = self.setting("username")
        password = self.setting("password")
        if not username or not password:
            raise ProviderError("A1: unesi korisničko ime i lozinku u podešavanjima.")

        self._logging_in = True
        try:
            device = self.device_fingerprint()
            url = ("%s/Login?devId=%s&user=%s&pwd=%s&rqT=true&refr=true"
                   % (self.auth_base(), _q(device), _q(username), _q(password)))
            try:
                answer = self.session.post(url, body=b"",
                                           headers={"Zappware-User-Agent": self.client_tag()})
            except net.HttpError as err:
                # The URL is deliberately absent from this message: it carries the password, and an
                # exception text is not put through the log's redaction.
                if err.status in (401, 403):
                    raise ProviderError("A1: prijava odbijena — proveri korisničko ime i lozinku.")
                raise ProviderError("A1: prijava nije uspela (HTTP %s)." % err.status)
            if not isinstance(answer, dict):
                raise ProviderError("A1: prijava je odgovorila necim sto nije JSON.")

            self.sid = str(answer.get("token") or "")
            self.uid = str(answer.get("user_id") or "")
            self.did = str(answer.get("device_id") or device)
            if not self.sid or not self.uid or self.uid == "None":
                raise ProviderError("A1: prijava je prošla ali nije vratila sesiju.")
            # The service may hand back a device id of its own; that one is what later calls must use,
            # and remembering it is what stops the next launch registering another device.
            if self.did and self.did != device:
                self.remember("device_id", self.did)
            ttl = int(answer.get("exp_period") or 0)
        finally:
            self._logging_in = False

        self._bootstrap()
        self._save_session(ttl)
        diag.log("A1: signed in (device %s…, profile %s)" % (self.did[:8], self.profile_id))

    def _bootstrap(self):
        """
        The two ids nothing works without.

        `profileId` is NOT in the login answer and NOT from `getProfiles` — that one exists but belongs
        to the profile-management screen and is never called during an ordinary start. It comes from
        `getSetupSteps`, found by tracing which response first carries the value the later queries send.

        `getInitialChannelLists` takes no arguments and answers one id. Hardcoding `1-1` — which an early
        draft of the Android client did — works on one account and silently answers an empty line-up on
        the next, which reads as an empty subscription.
        """
        setup = self._call("getSetupSteps", Q_SETUP_STEPS)
        steps = setup.get("setupSteps") or {}
        self.profile_id = str((steps.get("profileId") if isinstance(steps, dict) else "")
                              or setup.get("profileId") or "")
        if not self.profile_id:
            raise ProviderError("A1: nalog nije vratio profil.")
        data = self._call("getInitialChannelLists", Q_INITIAL_CHANNEL_LISTS)
        initial = data.get("initialChannelList") or {}
        self.channel_list_id = str(initial.get("id") or "") if isinstance(initial, dict) else ""
        if not self.channel_list_id:
            raise ProviderError("A1: nalog nije vratio nijednu listu kanala.")
        # WHAT THE WEB CLIENT DOES AT START, and the cheapest protection there is: release whatever a
        # crash left open, before it holds a concurrency slot until it times out on its own.
        self._release_stale()

    def _release_stale(self):
        try:
            self._call("stopPlayback", Q_STOP_PLAYBACK, {"input": {}})
        except (ProviderError, net.HttpError):
            pass                                                   # best effort, by design

    # ---- session across processes ------------------------------------------

    def _restore_session(self):
        block = _read_json(self.cache_path(SESSION_CACHE)) or {}
        if not isinstance(block, dict):
            return False
        age = time.time() - float(block.get("at") or 0)
        ttl = float(block.get("ttl") or 0) or SESSION_MAX_AGE
        if age > min(ttl, SESSION_MAX_AGE):
            return False
        self.sid = str(block.get("sid") or "")
        self.did = str(block.get("did") or "")
        self.uid = str(block.get("uid") or "")
        self.profile_id = str(block.get("profile") or "")
        self.channel_list_id = str(block.get("list") or "")
        if not (self.sid and self.uid and self.profile_id and self.channel_list_id):
            self.sid = ""
            return False
        self.session_restored = True
        return True

    def _save_session(self, ttl=0):
        store.write_json(self.cache_path(SESSION_CACHE),
                         {"sid": self.sid, "did": self.did, "uid": self.uid,
                          "profile": self.profile_id, "list": self.channel_list_id,
                          "ttl": ttl, "at": time.time()})

    def _forget_session(self):
        self.sid = self.uid = self.profile_id = self.channel_list_id = ""
        self.session_restored = False
        try:
            os.remove(self.cache_path(SESSION_CACHE))
        except OSError:
            pass

    # ---- channels ----------------------------------------------------------

    def channels(self):
        """
        The line-up, walked by cursor.

        THE NUMBER IS THE POSITION. The channel node carries no number and no genre — checked against
        the live capture, which shows `id, title, logo, logoInverted, userInfo, personalInfo,
        currentEvent` and nothing else. The order of `channels.edges` IS the line-up, exactly as with
        Iris, so numbering by position is reading the data rather than inventing it.
        """
        self.login()
        out, cursor, pages = [], None, 0
        while pages < MAX_PAGES:
            pages += 1
            variables = {"channelListId": self.channel_list_id, "firstChannels": PAGE,
                         "logoWidth": LOGO_W, "logoHeight": LOGO_H, "logoFlavour": LOGO_FLAVOUR}
            if cursor:
                variables["channelAfterCursor"] = cursor
            data = self._call("liveTV", Q_LIVE_TV, variables)
            connection = ((data.get("channelList") or {}).get("channels")) or {}
            edges = connection.get("edges") or []
            if not edges:
                break
            for edge in edges:
                node = (edge or {}).get("node") or {}
                entry = self._channel_entry(node, len(out) + 1)
                if entry:
                    out.append(entry)
            info = connection.get("pageInfo") or {}
            if not info.get("hasNextPage"):
                break
            cursor = info.get("endCursor") or ""
            if not cursor:
                break
        diag.log("A1: %d channels" % len(out))
        return out

    def _channel_entry(self, node, position):
        cid = str(node.get("id") or "")
        name = str(node.get("title") or node.get("name") or "")
        if not cid or not name:
            return None
        logo = ((node.get("logo") or {}).get("url") or "") if isinstance(node.get("logo"), dict) else ""
        return {
            "id": self.scoped("a1_%s" % cid),
            "tvg_id": self.scoped("a1_%s" % cid),
            "provider": self.key,
            "provider_label": self.label,
            "provider_ref": cid,
            "name": name,
            "number": position,
            "logo": logo,
            "url": ("plugin://plugin.video.iptvbalkan/?action=play&provider=a1&id=%s%s"
                    % (cid, self._account_param())),
            # ARCHIVE IS PER EVENT ON THIS SERVICE (`eventEntitlements.catchupTV`), not per channel, and
            # the channel query deliberately does not ask for a channel-level hint that was never
            # observed. So every channel is offered an archive and the per-programme answer decides.
            # The opposite default would hide a feature the account actually has, which is the worse of
            # the two mistakes and much the harder to notice.
            "catchup_days": self.settings.epg_days_back() or 7,
            "catchup_source": ("plugin://plugin.video.iptvbalkan/?action=play&provider=a1&id=%s%s"
                               "&utc={utc}" % (cid, self._account_param())),
            # ONE MINT PER PROGRAMME, seeked inside — the reply carries streamStart/streamEnd so the
            # manifest has its own bounds. That is Iris' model, not EON's sliding window: re-minting per
            # seek would restart playback instead of moving it. The matching half is below.
            "catchup_mode": "vod",
            "catchup_play_as_live": False,
        }

    # ---- guide -------------------------------------------------------------

    def epg(self, channels, hours_back=24, hours_forward=48):
        """
        The guide, asked for as a WINDOW rather than a day count — `windowStart` + `windowDuration`.

        No probing needed here: unlike Move, whose `backwards` ceiling had to be discovered by stepping
        down until something answered, this service takes the window it is given.

        THE EVENT IDS ARE WRITTEN OUT AS WELL, and that is not a side effect — it is the only bridge
        between IPTV Simple's `{utc}` and a service that addresses replay by event id. See `resolve`.
        """
        del channels                                               # the query is per channel LIST
        self.login()
        start = time.time() - (hours_back * 3600)
        minutes = int((hours_back + hours_forward) * 60)
        out, archive, cursor, pages = [], {}, None, 0
        while pages < MAX_PAGES:
            pages += 1
            variables = {"channelListId": self.channel_list_id, "firstChannels": PAGE,
                         "windowStart": _iso(start), "windowDuration": "PT%dM" % minutes}
            if cursor:
                variables["channelAfterCursor"] = cursor
            data = self._call("gridGuide", Q_GRID_GUIDE, variables)
            connection = ((data.get("channelList") or {}).get("channels")) or {}
            edges = connection.get("edges") or []
            if not edges:
                break
            for edge in edges:
                node = (edge or {}).get("node") or {}
                cid = str(node.get("id") or "")
                if not cid:
                    continue
                rows = ((node.get("events") or {}).get("edges")) or []
                for row in rows:
                    event = (row or {}).get("node") or {}
                    programme = self._programme(event, cid)
                    if programme:
                        out.append(programme)
                        archive.setdefault(cid, []).append(
                            [int(_epoch(event.get("start"))), int(_epoch(event.get("end"))),
                             str(event.get("id") or "")])
            info = connection.get("pageInfo") or {}
            if not info.get("hasNextPage"):
                break
            cursor = info.get("endCursor") or ""
            if not cursor:
                break
        store.write_json(self.cache_path(ARCHIVE_CACHE), archive)
        diag.log("A1: %d programmes over %d channels" % (len(out), len(archive)))
        return out

    def _programme(self, event, channel_id):
        start, end = _epoch(event.get("start")), _epoch(event.get("end"))
        title = str(((event.get("metadata") or {}).get("title")) or "")
        if not start or not end or not title:
            # A programme with no time would land at 1970 in the middle of the guide.
            return None
        return {
            "channel_id": self.scoped("a1_%s" % channel_id),
            "start": time.strftime("%Y%m%d%H%M%S +0000", time.gmtime(start)),
            "stop": time.strftime("%Y%m%d%H%M%S +0000", time.gmtime(end)),
            "title": title,
            # `shortDescription` was never observed on a gridGuide event — only on `getEventDetail`,
            # which is a different query. Left out rather than asked for: see the note above the
            # documents on what one unverified field costs.
            "desc": "",
        }

    # ---- playback ----------------------------------------------------------

    def resolve(self, channel_ref, at_utc=None, vod=False):
        """
        A tune, live or from the archive.

        `vod` is accepted and refused: `supports_vod` is False, so `default.play` never sets it, and a
        provider that quietly played something else when it did would be the harder bug to find.
        """
        if vod:
            raise ProviderError("A1: Video klub još nije podržan na ovom izvoru.")
        self.login()
        if at_utc:
            return self._resolve_archive(str(channel_ref), int(at_utc))
        return self._resolve_live(str(channel_ref))

    def _resolve_live(self, channel_ref):
        data = self._call("playChannel", Q_PLAY_CHANNEL,
                          {"profileId": self.profile_id, "input": {"channelId": channel_ref}})
        info = ((data.get("playChannel") or {}).get("playbackInfo")) or {}
        return self._playback(info, channel_ref)

    def _resolve_archive(self, channel_ref, at_utc):
        """
        A replay, addressed by the EVENT that was on at that instant.

        IPTV Simple gives us a timestamp; this service takes an event id. The guide pass wrote the map,
        so the ordinary case is a lookup. When it misses — a guide older than the map, a profile that
        lost the file — one narrow window is asked for rather than giving up, because a viewer pressing
        Replay does not care which of our files is stale.
        """
        event_id = self._event_at(channel_ref, at_utc) or self._event_from_service(channel_ref, at_utc)
        if not event_id:
            raise ProviderError(
                "A1: arhiva se traži po emisiji, a za to vreme nijedna nije u vodiču. "
                "Osveži vodič pa pokušaj ponovo.")
        data = self._call("catchupEvent", Q_CATCHUP_EVENT, {"input": {"eventId": event_id}})
        info = ((data.get("catchupEvent") or {}).get("playbackInfo")) or {}
        return self._playback(info, channel_ref)

    def _event_at(self, channel_ref, at_utc):
        """The event covering [at_utc] on this channel, out of the map the guide pass wrote."""
        rows = (_read_json(self.cache_path(ARCHIVE_CACHE)) or {}).get(channel_ref) or []
        for row in rows:
            try:
                start, end, event_id = int(row[0]), int(row[1]), str(row[2])
            except (IndexError, TypeError, ValueError):
                continue
            if start <= at_utc < end and event_id:
                return event_id
        return ""

    def _event_from_service(self, channel_ref, at_utc):
        """
        The same question, asked of the service, over a two-hour window around the instant.

        Uses `gridGuide` — a shape that is verified — rather than `previousCurrentEvents`, which the
        capture names but whose fields were never seen. One walk over the channel list is wasteful for a
        single lookup and it is still cheaper than telling somebody their archive does not work.
        """
        cursor, pages = None, 0
        while pages < MAX_PAGES:
            pages += 1
            variables = {"channelListId": self.channel_list_id, "firstChannels": PAGE,
                         "windowStart": _iso(at_utc - 3600), "windowDuration": "PT120M"}
            if cursor:
                variables["channelAfterCursor"] = cursor
            try:
                data = self._call("gridGuide", Q_GRID_GUIDE, variables)
            except (ProviderError, net.HttpError) as err:
                diag.log("A1: the archive lookup could not ask the service (%s)" % err)
                return ""
            connection = ((data.get("channelList") or {}).get("channels")) or {}
            for edge in connection.get("edges") or []:
                node = (edge or {}).get("node") or {}
                if str(node.get("id") or "") != channel_ref:
                    continue
                for row in ((node.get("events") or {}).get("edges")) or []:
                    event = (row or {}).get("node") or {}
                    if _epoch(event.get("start")) <= at_utc < _epoch(event.get("end")):
                        return str(event.get("id") or "")
                return ""                                          # found the channel, no such event
            info = connection.get("pageInfo") or {}
            if not info.get("hasNextPage"):
                break
            cursor = info.get("endCursor") or ""
            if not cursor:
                break
        return ""

    def _playback(self, info, channel_ref):
        url = str(info.get("url") or "")
        if not url:
            raise ProviderError("A1: servis nije vratio adresu strima za taj kanal.")
        session_id = str(info.get("sessionId") or "")
        heartbeat = info.get("heartbeat") or {}
        # RECORDED BEFORE THE STREAM IS HANDED OVER, because the service's keepalive loop runs in
        # ANOTHER process and this one is about to end. Without the session id there is nothing to
        # release, and an un-released session holds a concurrency slot until it times out.
        store.write_json(self.cache_path(NOW_PLAYING), {
            "url": url, "session": session_id, "channel": channel_ref,
            "hb_url": str(heartbeat.get("url") or ""),
            "hb_interval": int(heartbeat.get("interval") or 0),
            "hb_auth": bool(heartbeat.get("includeAuthHeaders")),
            "at": time.time(),
        })
        result = {
            "url": url,
            "manifest_type": "mpd",
            "license_type": "com.widevine.alpha",
            "headers": {"SDSEVO_SESSION_ID": self.sid, "SDSEVO_DEVICE_ID": self.did,
                        "SDSEVO_USER_ID": self.uid},
        }
        # NO TIMESHIFT BUFFER FOR A REPLAY, declared rather than left to the default. `catchupEvent`
        # answers a manifest with its own `streamStart`/`streamEnd`, so the programme is a BOUNDED
        # video that the player seeks inside — Iris' model, not EON's twelve-second sliding window,
        # which is the one case that genuinely needs the buffer. `test-tune.py` keeps a table of which
        # provider is which shape, and refuses any provider that does not say.
        if info.get("streamStart") or info.get("streamEnd"):
            result["timeshift"] = False
        # THE LICENCE REQUEST'S HEADERS ARE AN ASSUMPTION, and it is written down as one. The web issues
        # it from a Web Worker, so the capture could not see them; the three session headers are sent on
        # the reasonable ground that every other endpoint here authenticates that way. If Widevine ever
        # fails on a box while the manifest loads, this is the first thing to check.
        result["license_key"] = "%s|%s|R{SSM}|" % (
            self.widevine_url(),
            "&".join("%s=%s" % (k, v) for k, v in sorted(result["headers"].items())))
        return result

    # ---- session lifecycle -------------------------------------------------

    def playing_url(self):
        return (_read_json(self.cache_path(NOW_PLAYING)) or {}).get("url") or ""

    def heartbeat(self):
        """
        Holds the playback session open. Driven by service.py while our stream is the one on screen.

        The service SAYS how long it has left, so a returned timeout that is shorter than the loop's own
        tick is worth naming — it is the only warning anybody would get before streams start dropping.
        """
        state = _read_json(self.cache_path(NOW_PLAYING)) or {}
        if not state.get("session"):
            return False
        try:
            data = self._call("keepAlive", Q_KEEP_ALIVE)
            left = int(((data.get("keepSessionAlive") or {}).get("sessionTimeout")) or 0)
            if 0 < left < 45:
                diag.log("A1: the service says this session has %ds left, which is less than the "
                         "keepalive interval — the stream may drop" % left)
        except (ProviderError, net.HttpError) as err:
            diag.log("A1: keepalive failed (%s)" % err)
        return True

    def stop_heartbeat(self):
        """
        Releases the playback session — and this one is NOT housekeeping.

        An un-released session holds one of the account's concurrent-stream slots until the service
        times it out on its own, so skipping it turns a few channel changes into "nothing will play".
        Best effort: this runs while the player is being torn down and must never surface to the viewer,
        but it must still be ATTEMPTED.
        """
        path = self.cache_path(NOW_PLAYING)
        state = _read_json(path)
        session_id = str(state.get("session") or "")
        try:
            os.remove(path)
        except OSError:
            pass
        if not session_id:
            return
        try:
            self.login()
            self._call("stopPlayback", Q_STOP_PLAYBACK, {"input": {"sessionId": session_id}})
        except (ProviderError, net.HttpError) as err:
            diag.log("A1: the playback session could not be released (%s) — it will free itself when "
                     "the service times it out" % err)

    # ---- diagnostics -------------------------------------------------------

    def diagnose(self):
        rows = []
        ok, detail = net.probe(self.session, self.auth_base() + "/GetToken")
        rows.append(("Reachable", ok, detail))
        rows.append(("Credentials", bool(self.setting("username") and self.setting("password")),
                     self.setting("username") or "not set"))
        device = str(self.setting("device_id") or "")
        rows.append(("Device identity", bool(_DEVICE_SHAPE.match(device.lower())),
                     (device[:12] + "…") if device else "will be minted on first login"))
        try:
            self.login()
            rows.append(("Login", True, "profile %s, list %s" % (self.profile_id,
                                                                 self.channel_list_id)))
        except ProviderError as err:
            rows.append(("Login", False, err.message))
            return rows
        try:
            channels = self.channels()
            rows.append(("Channel list", bool(channels), "%d channels" % len(channels)))
        except Exception as err:                                   # noqa: BLE001
            rows.append(("Channel list", False, "%s: %s" % (type(err).__name__, err)))
            return rows
        # And then actually mint one — see Provider.diagnose_playback. On this service that row proves
        # something no other row can: the concurrency slots. A login succeeds while every slot is held
        # by a session an earlier crash never released, and only the mint finds out.
        rows.extend(self.diagnose_playback(channels))
        return rows


# ---- helpers ---------------------------------------------------------------

def _q(value):
    try:
        from urllib.parse import quote
    except ImportError:                                            # pragma: no cover
        from urllib import quote
    return quote(str(value or ""), safe="")


def _iso(epoch):
    """The service takes ISO-8601 in UTC, with the Z — the shape `Instant.toString()` produces."""
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(int(epoch)))


def _epoch(text):
    """
    An ISO-8601 stamp as a unix time, or 0.

    Zero on anything unparseable rather than an exception: one malformed programme must not cost the
    whole guide, and the caller drops a programme with no time.
    """
    text = str(text or "").strip()
    if not text:
        return 0
    if text.endswith("Z"):
        text = text[:-1] + "+0000"
    elif len(text) > 6 and text[-3] == ":" and text[-6] in "+-":
        text = text[:-3] + text[-2:]
    for shape in ("%Y-%m-%dT%H:%M:%S.%f%z", "%Y-%m-%dT%H:%M:%S%z"):
        try:
            import datetime
            return int(datetime.datetime.strptime(text, shape).timestamp())
        except (ValueError, TypeError):
            continue
    return 0


def _looks_like_session_error(message):
    """Whether a GraphQL refusal reads like a dead session rather than a real 'no'."""
    lowered = str(message or "").lower()
    return any(word in lowered for word in
               ("session", "token", "unauthorized", "unauthenticated", "not logged", "expired"))


def _read_json(path):
    """One small file back as a dict, or {} — never an exception. Same shape every provider here uses;
    the WRITES all go through `store.write_json`, which is atomic."""
    try:
        with io.open(path, "r", encoding="utf-8") as handle:
            data = json.loads(handle.read())
        return data if isinstance(data, dict) else {}
    except (OSError, IOError, ValueError):
        return {}
