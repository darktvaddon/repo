# -*- coding: utf-8 -*-
"""
More than one account per provider — two EON subscriptions, a second Yettel household, both at once.

THE ONE RULE THIS FILE IS BUILT AROUND: a box with a single account must behave EXACTLY as it did
before this existed. Same channel ids, same play URLs, same channel numbers, same cache files. That is
not politeness — those ids are written into IPTV Simple's own database and into Kodi's PVR tables, so
changing them for everybody would silently reset every user's channel list, favourites and history.

So the provider's ordinary settings — `eon_username`, `eon_password`, … — ARE the first account. They
are not migrated anywhere. Extra accounts live in `accounts.json` beside the playlist, each with its own
copy of the same setting names, and each gets a suffix on everything that has to stay unique.

    first account   eon        channel "eon_665"    cache "eon_play.json"
    second account  eon#a1b2   channel "eon@a1b2_665"   cache "a1b2-eon_play.json"

The `@` is deliberate: it cannot appear in a provider key or a provider's own channel id, so splitting
one back apart is unambiguous forever.
"""

import json
import os
import uuid

from . import catcache, diag

STORE = "accounts.json"
#: Separates an account suffix from the provider's own id inside a channel id. Chosen because no
#: provider key and no provider-issued id has ever contained it — see the module docstring.
SEP = "@"


def _path(settings):
    return os.path.join(settings.profile_dir(), STORE)


def load(settings):
    """Extra accounts only — the first one is the ordinary settings and is never in this file."""
    try:
        with open(_path(settings), "r", encoding="utf-8") as handle:
            data = json.loads(handle.read())
    except (OSError, IOError, ValueError):
        return []
    return [a for a in data if isinstance(a, dict) and a.get("id") and a.get("provider")] \
        if isinstance(data, list) else []


def save(settings, accounts):
    """
    Returns whether the store was written — a caller storing a device id has to be able to tell.

    Written to a temporary file and MOVED into place, the way the playlist and settings.xml are. This is
    the one file in the profile that cannot be regenerated: every other store beside it is a cache (the
    provider play descriptors, the TMDB rows, the resume positions, the licence verdict) and losing one
    costs a rebuild, while this one holds accounts somebody typed on a phone, one field at a time, on a
    television. `load()` treats a truncated file as "no extra accounts" — quietly and by design, since the
    alternative is an addon that will not start — so an interrupted write here does not corrupt the list,
    it makes the whole list VANISH with nothing to say so. A TV box is switched off at the wall rather
    than shut down, which makes an interrupted write the ordinary case rather than the unlucky one.
    """
    path = _path(settings)
    tmp = path + ".tmp"
    try:
        with open(tmp, "w", encoding="utf-8") as handle:
            handle.write(json.dumps(accounts, ensure_ascii=False, indent=1))
        os.replace(tmp, path)
        return True
    except (OSError, IOError, ValueError) as err:
        diag.log("Accounts: could not write %s (%s)" % (STORE, err), "ERROR")
        try:
            os.remove(tmp)
        except OSError:
            pass
        return False


def add(settings, provider_key, values, name=""):
    """
    Store one more account for [provider_key] and return its id.

    [values] is keyed exactly like the settings screen — `eon_username` and so on — so a caller that can
    already write the first account can write the second with no new vocabulary.
    """
    accounts = load(settings)
    account_id = uuid.uuid4().hex[:4]
    while any(a["id"] == account_id for a in accounts):             # four hex chars, but still
        account_id = uuid.uuid4().hex[:4]
    accounts.append({"id": account_id, "provider": provider_key,
                     "name": name or ("%s %d" % (provider_key.upper(), len(accounts) + 2)),
                     "enabled": True, "values": dict(values)})
    save(settings, accounts)
    diag.log("Accounts: added a second %s account (%s)" % (provider_key, account_id))
    return account_id


def remove(settings, account_id):
    accounts = load(settings)
    kept = [a for a in accounts if a["id"] != account_id]
    if len(kept) == len(accounts):
        return False
    save(settings, kept)
    # The cached catalogue block goes with it. Left behind, this account's channels reappear in the
    # playlist the next time its provider fails — see catcache.forget_account.
    catcache.forget_account(settings, account_id)
    diag.log("Accounts: removed account %s" % account_id)
    return True


def describe(settings):
    """Every account on this box, first one included, for a screen that lists them."""
    out = []
    for provider_key, label in _first_account_labels(settings):
        out.append({"id": "", "provider": provider_key, "name": label, "first": True,
                    "enabled": settings.get_bool("%s_enabled" % provider_key)})
    for account in load(settings):
        out.append({"id": account["id"], "provider": account["provider"],
                    "name": account.get("name") or account["provider"], "first": False,
                    "enabled": bool(account.get("enabled", True))})
    return out


def _first_account_labels(settings):
    """The providers configured the ordinary way. Kept private: only [describe] needs it, and it has to
    ask the registry, which would be a circular import at module level."""
    from .provider import _REGISTRY, _ensure_registered
    _ensure_registered()
    out = []
    for cls in _REGISTRY:
        if settings.get_bool("%s_enabled" % cls.key):
            out.append((cls.key, cls.label))
    return out


class AccountView(object):
    """
    A settings object that answers one account's questions from that account's own values.

    Anything that is NOT one of this provider's settings — the refresh interval, the guide window, the
    profile directory — falls straight through to the real settings, because those are properties of the
    box, not of an account. Getting that split wrong is how a second account would quietly acquire its
    own playlist path and overwrite the first one's.
    """

    def __init__(self, settings, provider_key, account):
        self._settings = settings
        self._prefix = "%s_" % provider_key
        self._enabled_key = "%s_enabled" % provider_key
        self._account = account
        self.account_id = account["id"]
        self.account_name = account.get("name") or provider_key

    def _mine(self, name):
        return name.startswith(self._prefix)

    def get(self, name, default=""):
        if not self._mine(name):
            return self._settings.get(name, default)
        if name == self._enabled_key:
            # An extra account's on/off switch is the `enabled` field on the account itself, not a
            # setting inside its values. One source of truth: without this the provider asked for
            # `eon_enabled`, found nothing in the account, fell back to the default of false, and the
            # account was built and then immediately skipped as disabled.
            return "true" if self._account.get("enabled", True) else "false"
        value = (self._account.get("values") or {}).get(name, "")
        return value if value != "" else default

    def set(self, name, value):
        """
        Store one value and return WHETHER IT LANDED, exactly as Settings.set does.

        The return value is not decoration and this method used to have none, which mattered because
        callers check it: `service._protect_secrets` treats a falsy answer as "the password could not be
        encrypted, leave it in the clear" and logs an error for it — so every extra account's password
        was reported as unstorable at every service start while accounts.json had in fact been written
        perfectly. `Provider.remember` reads it the same way, to warn about a device id that will cost a
        slot. A method whose contract is "same as Settings.set" has to include the answer.
        """
        if not self._mine(name):
            return self._settings.set(name, value)
        if name == self._enabled_key:
            self._account["enabled"] = str(value).lower() in ("true", "1", "yes")
            accounts = load(self._settings)
            for stored in accounts:
                if stored["id"] == self.account_id:
                    stored["enabled"] = self._account["enabled"]
                    break
            return save(self._settings, accounts)
        # Written back to the store immediately, because the values that arrive this way are the ones
        # that MUST survive — a device id minted at first login, a token refreshed after a session.
        self._account.setdefault("values", {})[name] = value
        accounts = load(self._settings)
        found = False
        for stored in accounts:
            if stored["id"] == self.account_id:
                stored.setdefault("values", {})[name] = value
                found = True
                break
        if not found:
            # The account is gone from the store — deleted from the accounts screen while this instance
            # was in use. Saying so beats writing the value into an in-memory copy nothing will read.
            diag.log("Accounts: %s is no longer in %s, so %s was not stored"
                     % (self.account_id, STORE, name), "ERROR")
            return False
        return save(self._settings, accounts)

    def get_bool(self, name, default=False):
        raw = self.get(name, "true" if default else "false")
        return str(raw).lower() in ("true", "1", "yes")

    def get_int(self, name, default=0):
        try:
            return int(self.get(name, str(default)))
        except (TypeError, ValueError):
            return default

    def __getattr__(self, item):
        # profile_dir, playlist_path, epg_path, refresh_hours, epg_days_*, verbose — all of them are
        # about the box and belong to the real settings. Delegated rather than listed so a new one
        # added to Settings does not have to be remembered here too.
        return getattr(self._settings, item)
