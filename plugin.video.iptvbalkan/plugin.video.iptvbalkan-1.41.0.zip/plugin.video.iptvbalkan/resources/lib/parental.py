# -*- coding: utf-8 -*-
"""
The parental PIN: one number that keeps the Video klub, and anything else chosen, off a child's screen.

## What it protects, and what it deliberately does not

It gates the VIDEO KLUB — the on-demand catalogue, where the films are. Live television is left alone on
purpose: a channel list is what a television is for, the guide is on screen anyway, and a PIN in front of
every zap would be turned off within a day. Someone who wants channels locked has Kodi's own parental
controls per channel group, which are better at it than this could be.

## Whole club, or only some categories

Two modes, because "keep the children out of the films" and "keep them out of the adult category" are
different requests and only one of them was covered at first.

  * [MODE_ALL] — the PIN is asked at the door. Nobody browses anything without it.
  * [MODE_CATEGORIES] — the catalogue is open and only categories whose NAME matches [locked_names]
    ask. The default list catches what providers actually call these sections, so it works without
    anyone configuring anything.

MATCHED BY NAME, not by the provider's category id. Ids are rebuilt whenever a catalogue is refreshed
and differ per provider and per account, so a lock keyed on one would quietly fall off — and a lock that
silently stops locking is worse than none. A name matches on a case-insensitive substring, so "XXX" also
covers "XXX FILMOVI" and "Xxx (18+)".

## The honest limit of a per-category lock

A category lock is about the CATEGORY. Once a title has left it there is no category left to check:

  * SEARCH goes to each provider's own search endpoint, and what comes back is a title, not a section.
    A result is dropped when the TITLE itself matches a locked word, which catches "XXX …" naming and
    nothing subtler.
  * CONTINUE WATCHING remembers what was played, not where it was found, and the same rule applies.

So [MODE_CATEGORIES] keeps a child out of the section. It is not a promise that no adult title can ever
appear on the screen by another route — [MODE_ALL] is the mode that promises that, and the settings
screen says so rather than leaving it to be discovered.

## The PIN is stored HASHED, not encrypted

The provider passwords go through the vault ([[vault]]) because the addon has to be able to READ them
back — a login needs the password itself. A PIN never needs reading back; it only needs comparing. So it
is stored as a salted SHA-256, and there is nothing in the settings file to recover even with the key.

The salt is per install and random. Without one, four digits are four digits: a table of all ten thousand
hashes is built in a second, and every box that chose 1234 would show the same value in its settings.xml
— so a parent reading another parent's file would learn their PIN.

Iterated, because four digits is a tiny space and one SHA-256 is fast. The count is fixed rather than
tuned per device: the check happens once when a screen opens, and a box slow enough for 50k rounds to be
noticeable is slow enough that the screen behind it will be the delay.

## Failing closed, and what that means here

A PIN that cannot be read (an unwritable profile, a corrupted settings file) means NOT LOCKED. That is
the opposite of the licence gate's rule, and deliberately: this protects a child from stumbling into a
film, it does not protect a subscription from a thief. Locking a paying family out of their own
catalogue because a settings file went bad would be the worse failure by a distance.
"""

import hashlib
import os
import time

from . import diag

#: Settings keys. `parental_pin` never holds the PIN itself — see the module docstring.
ENABLED = "parental_enabled"
PIN_HASH = "parental_pin"
SALT = "parental_salt"
MODE = "parental_mode"
NAMES = "parental_names"

MODE_ALL = "all"
MODE_CATEGORIES = "categories"

#: What providers here actually call these sections, so the feature works before anyone edits a list.
#: Deliberately short: every extra word is another ordinary category someone loses by accident, and
#: "Drama" containing "ram" is the shape of mistake a long list makes.
DEFAULT_NAMES = "XXX, 18+, ADULT, EROT, PORN, ZA ODRASLE"

#: Rounds of SHA-256 over the salted PIN.
ROUNDS = 50000

#: How long one correct entry lasts before it is asked for again, in seconds. Kodi runs a plugin as a
#: fresh process per screen, so "remember it for this session" has to be a timestamp on disk rather than
#: a variable — there is no session to hold it in.
GRACE_SECONDS = 15 * 60
UNLOCKED_UNTIL = "parental_unlocked_until"


def _hash(pin, salt):
    data = ("%s|%s" % (salt, pin)).encode("utf-8")
    for _ in range(ROUNDS):
        data = hashlib.sha256(data).digest()
    return data.hex()


def is_set(settings):
    """Whether a PIN has been chosen at all. Not the same as [is_locked] — the feature can be switched
    off with a PIN still stored, and switching it back on must not demand it be retyped."""
    try:
        return bool((settings.get(PIN_HASH, "") or "").strip())
    except Exception:                                              # noqa: BLE001
        return False


def is_locked(settings):
    """Whether the Video klub should ask for the PIN right now."""
    try:
        if not settings.get_bool(ENABLED, False) or not is_set(settings):
            return False
        until = int(settings.get(UNLOCKED_UNTIL, "0") or 0)
    except Exception as err:                                       # noqa: BLE001
        # FAILS OPEN. See the module docstring: a broken settings file must not lock a family out of
        # films they pay for.
        diag.log("Parental: could not read the lock state (%s) — leaving it open" % err, "ERROR")
        return False
    return time.time() >= until


def set_pin(settings, pin):
    """Store [pin]. An empty value clears it and switches the lock off."""
    pin = (pin or "").strip()
    if not pin:
        settings.set(PIN_HASH, "")
        settings.set(SALT, "")
        settings.set(ENABLED, False)
        settings.set(UNLOCKED_UNTIL, "0")
        return True
    salt = os.urandom(16).hex()
    settings.set(SALT, salt)
    settings.set(PIN_HASH, _hash(pin, salt))
    settings.set(ENABLED, True)
    # A freshly chosen PIN does not leave the club open on the grace from before it existed.
    settings.set(UNLOCKED_UNTIL, "0")
    return True


def verify(settings, pin):
    """True when [pin] matches. On success the lock stays open for [GRACE_SECONDS]."""
    stored = (settings.get(PIN_HASH, "") or "").strip()
    salt = (settings.get(SALT, "") or "").strip()
    if not stored or not salt:
        return False
    # hmac.compare_digest, not `==`: string comparison stops at the first differing character, and the
    # time that takes is measurable. Against a four-digit PIN typed on a remote it is a theoretical
    # attack; using the constant-time compare costs one import and removes the question.
    import hmac
    if not hmac.compare_digest(_hash(pin, salt), stored):
        return False
    settings.set(UNLOCKED_UNTIL, str(int(time.time()) + GRACE_SECONDS))
    return True


def relock(settings):
    """Forget a successful entry immediately — the 'lock now' action."""
    settings.set(UNLOCKED_UNTIL, "0")


# ---- per-category locking ---------------------------------------------------

def mode(settings):
    """[MODE_ALL] or [MODE_CATEGORIES]. Anything unrecognised reads as ALL, which is the safe direction:
    a settings value nobody understands must not quietly turn the lock into a partial one."""
    try:
        return MODE_CATEGORIES if (settings.get(MODE, MODE_ALL) or "") == MODE_CATEGORIES else MODE_ALL
    except Exception:                                              # noqa: BLE001
        return MODE_ALL


def locked_names(settings):
    """The words a category name is matched against, upper-cased and stripped of blanks."""
    try:
        raw = settings.get(NAMES, "")
    except Exception:                                              # noqa: BLE001
        raw = ""
    if not (raw or "").strip():
        raw = DEFAULT_NAMES
    return [w.strip().upper() for w in raw.split(",") if w.strip()]


def matches(settings, text):
    """Whether [text] — a category name, or a title standing in for one — hits the locked list."""
    if not text:
        return False
    upper = str(text).upper()
    return any(word in upper for word in locked_names(settings))


def gate_for(settings, name):
    """
    Whether opening something called [name] should ask for the PIN right now.

    The single question every caller asks, so the two modes are decided in ONE place rather than in each
    screen — a screen that forgets which mode is on is a screen where the lock is not there at all.
    """
    if not is_locked(settings):
        return False
    if mode(settings) == MODE_ALL:
        return True
    return matches(settings, name)


def hide(settings, text):
    """
    Whether a row named [text] should be left off a list entirely — search results and continue-watching.

    Only in category mode: with the whole club locked, nothing is reachable to hide in the first place,
    and hiding rows there would strip a parent's own search results after they had entered the PIN.
    """
    if mode(settings) != MODE_CATEGORIES:
        return False
    return is_locked(settings) and matches(settings, text)
