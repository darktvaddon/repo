# -*- coding: utf-8 -*-
"""Importing this package is what registers the providers — see provider.register."""

from . import eon      # noqa: F401
from . import iris     # noqa: F401
from . import move     # noqa: F401
from . import yettel   # noqa: F401
from . import xtream   # noqa: F401  (also registers the plain-M3U provider)
