# -*- coding: utf-8 -*-
"""
A QR encoder and a PNG writer, in pure Python and with no dependencies.

Kodi ships neither. The alternatives were a third-party module addon (another thing that has to resolve
on every platform, for one small feature) or vendoring someone else's code; this is ~200 lines of a
fully specified algorithm, and it is verified pixel-for-pixel against the reference `qrcode` package in
`C:\\Projects\\kodi-iptvbox\\test-qr.py`. That test is what makes writing it defensible: a QR that is
subtly wrong still LOOKS like a QR, and the only symptom is a phone that quietly refuses to scan it.

Scope is deliberately narrow — byte mode, error-correction level M, versions 1 to 10. That covers a LAN
pairing URL (~60 characters) several times over. Anything longer raises rather than silently producing
a code no phone will read.
"""

import struct
import zlib

#: (total codewords, EC codewords per block, [(block count, data codewords per block), …]) for level M.
#: Level M is the middle of the four: it survives a photograph of a TV screen taken at an angle, which
#: level L does not reliably do, without the size jump of Q or H.
_VERSIONS = {
    1: (26, 10, [(1, 16)]),
    2: (44, 16, [(1, 28)]),
    3: (70, 26, [(1, 44)]),
    4: (100, 18, [(2, 32)]),
    5: (134, 24, [(2, 43)]),
    6: (172, 16, [(4, 27)]),
    7: (196, 18, [(4, 31)]),
    8: (242, 22, [(2, 38), (2, 39)]),
    9: (292, 22, [(3, 36), (2, 37)]),
    10: (346, 26, [(4, 43), (1, 44)]),
}

#: Row/column centres of the alignment patterns, per version.
_ALIGNMENT = {
    1: [], 2: [6, 18], 3: [6, 22], 4: [6, 26], 5: [6, 30],
    6: [6, 34], 7: [6, 22, 38], 8: [6, 24, 42], 9: [6, 26, 46], 10: [6, 28, 50],
}

_EC_LEVEL_BITS = 0b00      # level M's own 2-bit code in the format information


# ---- GF(256) ---------------------------------------------------------------

_EXP = [0] * 512
_LOG = [0] * 256


def _init_tables():
    x = 1
    for i in range(255):
        _EXP[i] = x
        _LOG[x] = i
        x <<= 1
        if x & 0x100:
            x ^= 0x11D                     # the QR field's primitive polynomial
    for i in range(255, 512):
        _EXP[i] = _EXP[i - 255]


_init_tables()


def _gf_mul(a, b):
    if a == 0 or b == 0:
        return 0
    return _EXP[_LOG[a] + _LOG[b]]


def _generator(degree):
    poly = [1]
    for i in range(degree):
        poly = _poly_mul(poly, [1, _EXP[i]])
    return poly


def _poly_mul(a, b):
    out = [0] * (len(a) + len(b) - 1)
    for i, av in enumerate(a):
        for j, bv in enumerate(b):
            out[i + j] ^= _gf_mul(av, bv)
    return out


def _ec_codewords(data, count):
    """Reed-Solomon remainder — the error correction block appended to each data block."""
    gen = _generator(count)
    remainder = list(data) + [0] * count
    for i in range(len(data)):
        factor = remainder[i]
        if factor == 0:
            continue
        for j, g in enumerate(gen):
            remainder[i + j] ^= _gf_mul(g, factor)
    return remainder[len(data):]


# ---- encoding --------------------------------------------------------------

def _pick_version(length):
    for version in sorted(_VERSIONS):
        _total, ec_per_block, groups = _VERSIONS[version]
        data_capacity = sum(count * size for count, size in groups)
        header_bits = 4 + (8 if version < 10 else 16)
        if length * 8 + header_bits <= data_capacity * 8:
            return version
    raise ValueError("QR: %d bytes is more than this encoder handles (max version 10, level M)" % length)


def _bitstream(payload, version):
    _total, _ec, groups = _VERSIONS[version]
    capacity = sum(count * size for count, size in groups)

    bits = []

    def push(value, width):
        for i in range(width - 1, -1, -1):
            bits.append((value >> i) & 1)

    push(0b0100, 4)                                   # byte mode
    push(len(payload), 8 if version < 10 else 16)
    for byte in payload:
        push(byte, 8)
    push(0, min(4, capacity * 8 - len(bits)))         # terminator
    while len(bits) % 8:
        bits.append(0)

    codewords = [int("".join(str(b) for b in bits[i:i + 8]), 2) for i in range(0, len(bits), 8)]
    # Pad alternately with these two fixed bytes, exactly as the specification requires — any other
    # filler produces a code that decodes to the right string on some readers and not others.
    pad = [0xEC, 0x11]
    added = 0
    while len(codewords) < capacity:
        codewords.append(pad[added % 2])
        added += 1
    return codewords


def _interleave(codewords, version):
    _total, ec_per_block, groups = _VERSIONS[version]
    blocks, ec_blocks, offset = [], [], 0
    for count, size in groups:
        for _ in range(count):
            block = codewords[offset:offset + size]
            offset += size
            blocks.append(block)
            ec_blocks.append(_ec_codewords(block, ec_per_block))

    out = []
    for i in range(max(len(b) for b in blocks)):
        for block in blocks:
            if i < len(block):
                out.append(block[i])
    for i in range(ec_per_block):
        for block in ec_blocks:
            out.append(block[i])
    return out


# ---- module placement ------------------------------------------------------

def _new_matrix(size):
    return [[None] * size for _ in range(size)]


def _place_function_patterns(matrix, version):
    size = len(matrix)

    def finder(row, col):
        for r in range(-1, 8):
            for c in range(-1, 8):
                rr, cc = row + r, col + c
                if not (0 <= rr < size and 0 <= cc < size):
                    continue
                inside = (0 <= r <= 6 and c in (0, 6)) or (0 <= c <= 6 and r in (0, 6)) \
                    or (2 <= r <= 4 and 2 <= c <= 4)
                matrix[rr][cc] = 1 if inside else 0

    finder(0, 0)
    finder(0, size - 7)
    finder(size - 7, 0)

    for i in range(8, size - 8):
        bit = 1 if i % 2 == 0 else 0
        matrix[6][i] = bit
        matrix[i][6] = bit

    centres = _ALIGNMENT[version]
    for r in centres:
        for c in centres:
            # Skipped where a finder already sits — the three corners are not alignment positions.
            if (r < 8 and c < 8) or (r < 8 and c > size - 9) or (r > size - 9 and c < 8):
                continue
            for dr in range(-2, 3):
                for dc in range(-2, 3):
                    matrix[r + dr][c + dc] = 1 if max(abs(dr), abs(dc)) != 1 else 0

    matrix[size - 8][8] = 1                            # the always-dark module

    for i in range(9):                                 # reserve the format areas
        if matrix[8][i] is None:
            matrix[8][i] = 0
        if matrix[i][8] is None:
            matrix[i][8] = 0
    for i in range(8):
        if matrix[8][size - 1 - i] is None:
            matrix[8][size - 1 - i] = 0
        if matrix[size - 1 - i][8] is None:
            matrix[size - 1 - i][8] = 0

    if version >= 7:
        bits = _version_bits(version)
        for i in range(18):
            bit = (bits >> i) & 1
            matrix[i // 3][size - 11 + i % 3] = bit
            matrix[size - 11 + i % 3][i // 3] = bit


def _reserved(matrix, version, row, col):
    """True where a function pattern lives, i.e. where data must not be written."""
    size = len(matrix)
    if row == 6 or col == 6:
        return True
    if row < 9 and col < 9:
        return True
    if row < 9 and col >= size - 8:
        return True
    if row >= size - 8 and col < 9:
        return True
    if version >= 7 and ((row < 6 and col >= size - 11) or (col < 6 and row >= size - 11)):
        return True
    for r in _ALIGNMENT[version]:
        for c in _ALIGNMENT[version]:
            if (r < 8 and c < 8) or (r < 8 and c > size - 9) or (r > size - 9 and c < 8):
                continue
            if abs(row - r) <= 2 and abs(col - c) <= 2:
                return True
    return False


def _place_data(matrix, version, codewords):
    size = len(matrix)
    bits = []
    for word in codewords:
        for i in range(7, -1, -1):
            bits.append((word >> i) & 1)

    index = 0
    col = size - 1
    upward = True
    while col > 0:
        if col == 6:                                   # the vertical timing column is skipped entirely
            col -= 1
        rows = range(size - 1, -1, -1) if upward else range(size)
        for row in rows:
            for offset in (0, 1):
                cc = col - offset
                if _reserved(matrix, version, row, cc):
                    continue
                matrix[row][cc] = bits[index] if index < len(bits) else 0
                index += 1
        upward = not upward
        col -= 2


# ---- masking ---------------------------------------------------------------

_MASKS = [
    lambda r, c: (r + c) % 2 == 0,
    lambda r, c: r % 2 == 0,
    lambda r, c: c % 3 == 0,
    lambda r, c: (r + c) % 3 == 0,
    lambda r, c: (r // 2 + c // 3) % 2 == 0,
    lambda r, c: (r * c) % 2 + (r * c) % 3 == 0,
    lambda r, c: ((r * c) % 2 + (r * c) % 3) % 2 == 0,
    lambda r, c: ((r + c) % 2 + (r * c) % 3) % 2 == 0,
]


def _penalty(matrix):
    """The specification's four penalty rules. Picking the wrong mask still scans on a good reader and
    fails on a cheap phone camera, so this is not an optimisation to skip."""
    size = len(matrix)
    score = 0

    for line in list(matrix) + [list(col) for col in zip(*matrix)]:
        run, previous = 0, None
        for value in line:
            if value == previous:
                run += 1
            else:
                if run >= 5:
                    score += 3 + (run - 5)
                run, previous = 1, value
        if run >= 5:
            score += 3 + (run - 5)

    for r in range(size - 1):
        for c in range(size - 1):
            block = {matrix[r][c], matrix[r][c + 1], matrix[r + 1][c], matrix[r + 1][c + 1]}
            if len(block) == 1:
                score += 3

    pattern_a = [1, 0, 1, 1, 1, 0, 1, 0, 0, 0, 0]
    pattern_b = [0, 0, 0, 0, 1, 0, 1, 1, 1, 0, 1]
    for line in list(matrix) + [list(col) for col in zip(*matrix)]:
        for i in range(size - 10):
            window = list(line[i:i + 11])
            if window == pattern_a or window == pattern_b:
                score += 40

    dark = sum(sum(row) for row in matrix)
    percent = dark * 100 // (size * size)
    score += 10 * (abs(percent - 50) // 5)
    return score


def _format_bits(mask):
    value = (_EC_LEVEL_BITS << 3) | mask
    bits = value << 10
    generator = 0b10100110111
    for i in range(4, -1, -1):
        if bits & (1 << (i + 10)):
            bits ^= generator << i
    return ((value << 10) | bits) ^ 0b101010000010010


def _version_bits(version):
    bits = version << 12
    generator = 0b1111100100101
    for i in range(5, -1, -1):
        if bits & (1 << (i + 12)):
            bits ^= generator << i
    return (version << 12) | bits


def _apply_format(matrix, mask):
    """
    The 15 format bits, written twice.

    Bit i counts from the LSB, and the two copies run in OPPOSITE directions: the vertical copy climbs
    column 8 from the top, the horizontal copy runs row 8 from the right-hand edge inwards. Writing the
    two the other way round — vertical along row 8, horizontal down column 8 — produces a code whose
    every other module is right, differing from a correct one in about a dozen places. It looks like a
    QR code, and no phone will read it. That was the first version of this function.
    """
    size = len(matrix)
    bits = _format_bits(mask)
    for i in range(15):
        bit = (bits >> i) & 1
        # Vertical copy, down column 8, skipping the timing row at 6.
        if i < 6:
            matrix[i][8] = bit
        elif i < 8:
            matrix[i + 1][8] = bit
        else:
            matrix[size - 15 + i][8] = bit
        # Horizontal copy, along row 8, from the right edge back towards the finder.
        if i < 8:
            matrix[8][size - 1 - i] = bit
        elif i == 8:
            matrix[8][7] = bit
        else:
            matrix[8][14 - i] = bit
    matrix[size - 8][8] = 1                            # always dark, re-asserted after the writes


def encode(text):
    """The QR modules for [text] as a list of rows of 0/1, no quiet zone."""
    payload = text.encode("utf-8")
    version = _pick_version(len(payload))
    size = version * 4 + 17

    codewords = _interleave(_bitstream(payload, version), version)

    best, best_score = None, None
    for mask in range(8):
        matrix = _new_matrix(size)
        _place_function_patterns(matrix, version)
        _place_data(matrix, version, codewords)
        for row in range(size):
            for col in range(size):
                if not _reserved(matrix, version, row, col) and _MASKS[mask](row, col):
                    matrix[row][col] ^= 1
        _apply_format(matrix, mask)
        score = _penalty(matrix)
        if best_score is None or score < best_score:
            best, best_score = matrix, score
    return best


# ---- PNG -------------------------------------------------------------------

def _chunk(tag, data):
    return (struct.pack(">I", len(data)) + tag + data
            + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF))


def _write_png(path, width, height, rows):
    header = struct.pack(">IIBBBBB", width, height, 8, 0, 0, 0, 0)   # 8-bit greyscale
    png = (b"\x89PNG\r\n\x1a\n" + _chunk(b"IHDR", header)
           + _chunk(b"IDAT", zlib.compress(bytes(rows), 9)) + _chunk(b"IEND", b""))
    with open(path, "wb") as handle:
        handle.write(png)
    return path


def write_flat_png(path, level=255, size=8):
    """
    A tiny single-colour PNG.

    Kodi's `ControlImage` can tint any texture with `colorDiffuse`, so one white square is every solid
    panel and divider the pairing screen needs. The alternative was shipping skin artwork — which means
    a texture file per colour, and a skin folder, for what is one stretched rectangle.
    """
    row = bytearray([0]) + bytearray([level]) * size
    return _write_png(path, size, size, row * size)


def write_png(path, text, module_pixels=8, quiet_zone=4):
    """
    Writes [text] as a black-on-white PNG.

    The quiet zone is not decoration: a QR with no clear margin is unreadable, and on a TV that margin
    has to be part of the IMAGE, since whatever is behind it could be any colour the skin chooses.
    """
    matrix = encode(text)
    size = len(matrix) + quiet_zone * 2
    width = size * module_pixels

    rows = bytearray()
    for row in range(size):
        line = bytearray()
        for col in range(size):
            inside = (quiet_zone <= row < size - quiet_zone and quiet_zone <= col < size - quiet_zone)
            dark = inside and matrix[row - quiet_zone][col - quiet_zone]
            line.extend(b"\x00" * module_pixels if dark else b"\xff" * module_pixels)
        for _ in range(module_pixels):                 # each module is a square, so repeat the scanline
            rows.append(0)                             # PNG filter type 0, once per scanline
            rows.extend(line)

    return _write_png(path, width, width, rows)
