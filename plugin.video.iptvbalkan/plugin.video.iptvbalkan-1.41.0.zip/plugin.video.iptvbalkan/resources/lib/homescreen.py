"""
Putting the Video klub within reach of Kodi's home screen.

The honest framing first, because it is a recurring misunderstanding: **no addon can place itself on
Kodi's home menu.** That menu belongs to the SKIN, and adding an entry to it is a skin setting
(Estuary: Settings -> Interface -> Skin -> Configure skin -> Main menu items). Writing our own addon
would not change that — it would land in exactly the same place, under Add-ons.

What an addon CAN do is create a **favourite**, which Estuary and most other skins can surface on the
home screen, and which is one click away from the remote regardless. That is what this module does.

Three rules make an auto-added favourite acceptable rather than presumptuous:

* it is added ONCE. A user who deletes it has decided; re-adding it on the next start would be the
  behaviour of adware, not of a TV addon. The "we already did this" marker is what enforces that.
* nothing that belongs to the user is touched. We add ours, and we do not manage anyone else's.
  ONE exception, added after the rename: a favourite pointing at a PREVIOUS addon id is ours and is
  dead — the addon it names is not installed any more — so `drop_stale` removes it rather than leaving
  two identical "Video klub" rows on the home screen, one of which does nothing. Removing our own
  corpse is not managing the user's favourites.
* the setting can turn it off before it ever happens, and the menu row can add it back afterwards.
"""
import io
import json
import os
import xml.etree.ElementTree as ET

import xbmc

try:
    import xbmcvfs
except ImportError:                                                # pragma: no cover - tests stub Kodi
    xbmcvfs = None

from . import diag, migrate
from . import settings as settings_module
from .i18n import T

#: Where the Video klub lives. Kodi opens a plugin path inside the Videos window.
VIDEO_CLUB_PATH = "plugin://plugin.video.iptvbalkan/?action=vod"

#: Marks that the one automatic attempt has happened, successful or not. Stored in the addon's own
#: settings rather than a file so it travels with a settings backup, and so a user who really wants the
#: attempt repeated can clear it from the settings screen.
DONE_SETTING = "home_shortcut_done"

#: Whether we may add it at all. Default true — the owner's call; see the module docstring.
ENABLED_SETTING = "home_shortcut"


def _rpc(method, params=None):
    """One JSON-RPC call. Returns the parsed `result`, or None on any failure."""
    request = {"jsonrpc": "2.0", "id": 1, "method": method, "params": params or {}}
    try:
        raw = xbmc.executeJSONRPC(json.dumps(request))
        answer = json.loads(raw)
    except Exception as err:                                        # noqa: BLE001
        diag.log("Home shortcut: %s failed (%s)" % (method, err), "ERROR")
        return None
    if "error" in answer:
        diag.log("Home shortcut: %s -> %s" % (method, answer["error"]), "ERROR")
        return None
    return answer.get("result")


def _is_ours(target, addon_id=None):
    """Whether a favourite's target is a Video klub link of ours — this id's, or a previous one's."""
    prefix = "plugin://%s/" % (addon_id or settings_module.ADDON_ID)
    return prefix in (target or "") and "action=vod" in (target or "")


def already_present():
    """
    True when a favourite already points at the Video klub.

    Matched on the PATH, not on the name: the user is free to rename a favourite, and renaming it must
    not make us add a second one. Kodi reports a window favourite's target in `windowparameter`.
    """
    result = _rpc("Favourites.GetFavourites",
                  {"properties": ["window", "windowparameter", "path"]})
    if not result:
        return False
    for fav in result.get("favourites") or []:
        target = fav.get("windowparameter") or fav.get("path") or ""
        if _is_ours(target):
            return True
    return False


def drop_stale(path=None):
    """
    Remove Video klub favourites left pointing at an id this addon no longer answers to.

    THE RENAME LEFT A DEAD BUTTON ON EVERY UPGRADED BOX. `already_present()` matches on the CURRENT
    id, quite deliberately — so after `plugin.video.iptvbox` became `plugin.video.iptvbalkan` the old
    favourite matched nothing, a second one was added beside it, and the first one stayed on the home
    screen pointing at an addon that is no longer installed. Two identical "Video klub" rows, one of
    which does nothing at all. Reported from the sofa, and reproduced on the box:

        <favourite name="Video klub">ActivateWindow(10025,"plugin://plugin.video.iptvbox/?action=vod",return)</favourite>
        <favourite name="Video klub">ActivateWindow(10025,"plugin://plugin.video.iptvbalkan/?action=vod",return)</favourite>

    Kodi has NO JSON-RPC call that removes a favourite, so this edits `favourites.xml` — the one file
    in userdata this addon touches, and it touches nothing in it except our own dead rows. A row whose
    name the user changed is still ours: the match is on the address, as everywhere else here.

    Returns how many were removed.
    """
    target = path or _favourites_path()
    if not target:
        return 0
    try:
        with io.open(target, "r", encoding="utf-8") as handle:
            original = handle.read()
    except (IOError, OSError):
        return 0                                                   # no favourites file yet: nothing to do
    try:
        root = ET.fromstring(original.encode("utf-8"))
    except ET.ParseError as err:
        # Somebody else's file, and a malformed one. Rewriting it on a guess would cost the user every
        # favourite they have, which is far worse than one dead row.
        diag.log("Home shortcut: favourites.xml could not be read (%s) — left alone" % err, "ERROR")
        return 0

    stale = [node for node in list(root)
             if any(_is_ours(node.text or "", old) for old in migrate.PREVIOUS_IDS)]
    if not stale:
        return 0
    for node in stale:
        root.remove(node)
    try:
        tmp = target + ".tmp"
        with io.open(tmp, "w", encoding="utf-8") as handle:
            handle.write(ET.tostring(root, encoding="unicode"))
        os.replace(tmp, target)
    except (IOError, OSError) as err:
        diag.log("Home shortcut: could not rewrite favourites.xml (%s)" % err, "ERROR")
        return 0
    diag.log("Home shortcut: removed %d Video klub favourite(s) left over from the previous addon id"
             % len(stale))
    return len(stale)


def _favourites_path():
    """userdata/favourites.xml, translated through Kodi so it is right on every platform."""
    if xbmcvfs is None:
        return ""
    try:
        return os.path.join(xbmcvfs.translatePath("special://profile"), "favourites.xml")
    except Exception:                                              # noqa: BLE001
        return ""


def add(force=False):
    """
    Adds the favourite. Returns True when it is present afterwards.

    [force] is the difference between the menu row and the automatic pass: the menu row is a person
    asking for it right now, so it runs even after the one automatic attempt has been made.
    """
    if already_present():
        diag.log("Home shortcut: a Video klub favourite already exists")
        return True
    ok = _rpc("Favourites.AddFavourite", {
        "title": T("Video klub"),
        "type": "window",
        "window": "videos",
        "windowparameter": VIDEO_CLUB_PATH,
    })
    # Read it straight back rather than trusting the call. This project has been bitten before by a
    # write that reported success and changed nothing (the settings-dialog race in 0.4.1), and a
    # favourite is exactly the kind of thing nobody checks until they go looking for it.
    if ok is not None and already_present():
        diag.log("Home shortcut: Video klub favourite added")
        return True
    diag.log("Home shortcut: could not add the favourite (force=%s)" % force, "ERROR")
    return False


def ensure_once(settings):
    """
    The automatic pass, run by the service after a successful start.

    Does nothing at all if the owner turned it off, and nothing on any start after the first — see the
    module docstring for why "once" rather than "keep it there".
    """
    # Both of these return BEFORE the marker is written, and that ordering is the point. The marker used
    # to be set in a `finally`, which runs on these returns too — so a box that had the feature switched
    # off got marked "already done" on its very first start, and switching the setting back on then did
    # nothing for ever after. The marker records that an ATTEMPT was made, not that the service started.
    try:
        if not settings.get_bool(ENABLED_SETTING, True):
            return
        if settings.get_bool(DONE_SETTING, False):
            return
    except Exception as err:                                        # noqa: BLE001
        diag.log("Home shortcut: could not read its own settings (%s)" % err, "ERROR")
        return

    try:
        add()
    except Exception as err:                                        # noqa: BLE001
        # Never let a convenience feature break service startup: the guide, the playlist and the
        # heartbeat all run after this.
        diag.log("Home shortcut: skipped (%s)" % err, "ERROR")
    finally:
        # Marked even when the attempt FAILED. Retrying every single start would mean an addon that keeps
        # poking at someone's favourites forever because one JSON-RPC call went wrong once.
        try:
            settings.set(DONE_SETTING, True)
        except Exception:                                           # noqa: BLE001
            pass
