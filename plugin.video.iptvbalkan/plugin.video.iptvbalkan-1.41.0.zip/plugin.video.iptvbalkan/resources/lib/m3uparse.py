# -*- coding: utf-8 -*-
"""
Reading somebody else's playlist and guide.

WHY THIS EXISTS. `M3uProvider.channels()` used to `return []` with a comment saying the playlist is
"passed through to IPTV Simple untouched" through `playlist_url()` — and nothing in the addon ever
called `playlist_url()`. So a user could switch M3U on, type an address, watch the refresh log
"M3U playlist -> 0 channels, 0 programmes, 0s", and get nothing, with no error anywhere. A settings
page with no code behind it. Reported from the sofa on 2026-08-01: "pustio sam m3u listu … iz m3u liste
nije uneo ni jedan kanal".

Passing the address through cannot work either, and that is worth writing down: IPTV Simple takes ONE
m3uPath per instance and this addon already points that at its own merged playlist. Two sources means
merging them ourselves, which is what every other provider here does.

The parser is deliberately forgiving. A playlist from a panel is not a standard: attributes appear in
any order, quoting varies, `#EXTGRP` shows up instead of `group-title`, and per-channel options arrive
as `#EXTVLCOPT` or `#KODIPROP`. Anything not understood is carried, not dropped — a stream that needs a
User-Agent and does not get one is a channel that silently refuses to play.
"""

import re

#: `#EXTINF:-1 tvg-id="x" tvg-logo="y" group-title="z",Display Name`
_ATTR = re.compile(r'([A-Za-z0-9_-]+)\s*=\s*"([^"]*)"')
_EXTINF = re.compile(r"^#EXTINF:\s*(-?\d+)\s*(.*?),\s*(.*)$")


def parse(text):
    """
    A list of channel dicts from an M3U body: name, tvg_id, logo, group, number, url, props, headers.

    Only entries that have BOTH a name and a URL are returned. A malformed block is skipped rather than
    guessed at — half a channel is worse than one channel fewer, because it lands in someone's TV list
    and fails at the moment they press it.
    """
    out = []
    pending = None
    props, options, group_line = {}, {}, ""
    for raw in (text or "").splitlines():
        line = raw.strip()
        if not line:
            continue
        if line.upper().startswith("#EXTM3U"):
            continue
        match = _EXTINF.match(line)
        if match:
            duration, attributes, name = match.groups()
            del duration
            pending = {"attrs": dict(_ATTR.findall(attributes)), "name": name.strip()}
            props, options, group_line = {}, {}, ""
            continue
        if line.upper().startswith("#EXTGRP:"):
            group_line = line.split(":", 1)[1].strip()
            continue
        if line.upper().startswith("#KODIPROP:"):
            key, _, value = line.split(":", 1)[1].partition("=")
            props[key.strip()] = value.strip()
            continue
        if line.upper().startswith("#EXTVLCOPT:"):
            key, _, value = line.split(":", 1)[1].partition("=")
            options[key.strip().lower()] = value.strip()
            continue
        if line.startswith("#"):
            continue                                               # a comment, or a directive we ignore
        if not pending:
            continue                                               # a URL with no #EXTINF above it
        attrs = pending["attrs"]
        name = pending["name"] or attrs.get("tvg-name") or ""
        if name:
            # VLC's per-channel options are the same three things Kodi needs, under other names.
            headers = {}
            if options.get("http-user-agent"):
                headers["User-Agent"] = options["http-user-agent"]
            if options.get("http-referrer"):
                headers["Referer"] = options["http-referrer"]
            number = attrs.get("tvg-chno") or attrs.get("channel-number") or "0"
            out.append({
                "name": name,
                "tvg_id": attrs.get("tvg-id") or "",
                "logo": attrs.get("tvg-logo") or "",
                "group": attrs.get("group-title") or group_line,
                "number": int(number) if str(number).isdigit() else 0,
                "url": line,
                "props": props,
                "headers": headers,
                "radio": (attrs.get("radio") or "").lower() == "true",
                "catchup_days": _int(attrs.get("catchup-days")),
                "catchup_source": attrs.get("catchup-source") or "",
                "catchup_mode": attrs.get("catchup") or "",
                "kind": kind_of(line),
            })
        pending, props, options, group_line = None, {}, {}, ""
    return out


def _int(value):
    try:
        return int(str(value or "0"))
    except (TypeError, ValueError):
        return 0


def programmes(text, wanted_ids, limit=200000):
    """
    Programmes out of an XMLTV document, for the channels we actually listed.

    Streamed with `iterparse` and cleared as it goes: these files reach tens of megabytes, and holding
    the whole tree costs more memory than the box has to spare during a refresh — the OOM lesson from
    the Android side, in a different language.

    Times are XMLTV's own (`20260801203000 +0200`) and are handed on unchanged: our writer emits the
    same format, so re-encoding them would only be an opportunity to lose the offset.
    """
    import xml.etree.ElementTree as ET
    from io import StringIO

    out = []
    wanted = set(wanted_ids or ())
    try:
        for _event, element in ET.iterparse(StringIO(text or ""), events=("end",)):
            if element.tag != "programme":
                continue
            channel = element.get("channel") or ""
            start, stop = element.get("start") or "", element.get("stop") or ""
            if channel in wanted and start and stop:
                title = (element.findtext("title") or "").strip()
                if title:
                    out.append({
                        "channel_id": channel,
                        "start": start,
                        "stop": stop,
                        "title": title,
                        "desc": (element.findtext("desc") or "").strip(),
                    })
            element.clear()
            if len(out) >= limit:
                break
    except ET.ParseError:
        # A truncated or HTML answer (a captive portal, an expired link) is not a crash: the caller
        # reports "no guide" and the channels still work, which is the half that matters.
        return out
    return out

#: A panel's playlist is not only channels. Xtream-style servers put films and episodes in the same
#: file, addressed by a path segment: `/movie/user/pass/123.mkv`, `/series/user/pass/456.mkv`, while
#: live is `/live/...` or just `/<user>/...`. Measured on the owner's own list on 2026-08-01:
#:
#:     545 live, 12 radio, 308 movie, 390 series
#:
#: Imported as channels, those 698 films become 698 rows in the television list — sorted between the
#: news channels, with no guide and nothing to play from the guide, which is exactly what was reported:
#: "filmove … nije dodao u katalog nego se vide u kanalima i nemam dugme za play programme nego samo
#: switch". A film is not a channel; it belongs in the Video klub, and that is where they go now.
_VOD_SEGMENTS = ("/movie/", "/movies/", "/series/", "/vod/")
_VOD_SUFFIXES = (".mkv", ".mp4", ".avi", ".m4v", ".mov")


def kind_of(url):
    """"live", "movie" or "series" — from the address, which is the only honest signal in an M3U."""
    lowered = (url or "").lower().split("?", 1)[0]
    if "/series/" in lowered:
        return "series"
    if any(segment in lowered for segment in _VOD_SEGMENTS):
        return "movie"
    if lowered.endswith(_VOD_SUFFIXES):
        # No telling a film from an episode here, and it does not matter: both belong in the Video klub.
        return "movie"
    return "live"
