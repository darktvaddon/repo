# -*- coding: utf-8 -*-
"""
LAN pairing: type the account on a phone, not on a TV remote.

The box opens a tiny plain-HTTP server on its own LAN address, shows a QR code holding that address
plus a one-time token, and the phone that scans it gets a small form. What comes back is written
through the SAME settings keys the settings screen writes, so there is no second, parallel "add an
account" path that can drift from the first.

Ported from the Android client's `LanPairingManager` — same port, same URL shape, same one-time-token
protocol, deliberately: a user who has already paired a phone to the app sees the identical flow here.
What is NOT copied is the EON brand list. The app numbers those by operator (SBB, Telemach, …); this
addon numbers them by country, exactly as `eon_brand` is declared in settings.xml. Copying the app's
list would have silently written the wrong brand.

Three properties that matter, each one a deliberate choice rather than an accident:

* **The socket binds to the ONE address printed in the QR, not to 0.0.0.0.** This server briefly
  accepts a plaintext password, so it must not also be listening on a VPN or a second interface.
* **The token is required on both the GET and the POST.** Without it the page is a form that writes
  provider credentials into the addon, reachable by anything on the network.
* **It stops.** Five minutes, or the first successful submission, whichever comes first — and the
  caller's `stop()` is honoured even while a client is connected, which is why accept() runs on a
  timeout instead of blocking forever (closing a socket out from under a blocked accept() is not
  reliable across platforms, and this addon runs on all of them).

There is no TLS and there cannot be: a self-signed certificate on a LAN address produces a browser
warning the user must click through, which trains exactly the wrong habit, and no phone will trust it
anyway. The exposure is one password on the local network for a few minutes, to the same LAN the
stream itself crosses unencrypted.
"""

import hmac
import os
import socket
import threading
import time

try:
    from urllib.parse import unquote_plus
except ImportError:                                                # pragma: no cover  (Python 2 tooling)
    from urllib import unquote_plus                                # noqa: F401

from resources.lib import accounts, diag, transfer

#: The Android client's port, on purpose — see the module docstring.
PORT = 8791
#: If it is busy (a second Kodi, or the app itself on the same box) the next few are tried and the QR
#: carries whichever one won. A fixed port that fails is a feature that just does not open.
PORT_ATTEMPTS = 5
SESSION_SECONDS = 5 * 60
MAX_FORM_BYTES = 24 * 1024
#: How long the phone waits while the TV writes the account. Generous, because the answer it gets is
#: the verified one — the alternative is a fast "submitted" that means nothing.
APPLY_TIMEOUT = 20.0
CLIENT_TIMEOUT = 30.0
ACCEPT_TIMEOUT = 1.0

WAITING = "waiting"
DONE = "done"
ERROR = "error"
STOPPED = "stopped"


class PairingError(Exception):
    """A submission that cannot be applied. The message is shown on the phone, so it is written for
    the person holding it, not for the log."""


# ---- what the form may write ------------------------------------------------

#: type -> (label, [(form field, setting id)], [required form fields], enable-setting)
#:
#: Only providers this addon actually implements are here. The app's form also offers Stalker; there is
#: no Stalker provider in this addon yet, and an option that silently does nothing is worse than an
#: option that is missing.
_TYPES = [
    ("m3u", "M3U playlist",
     [("url", "m3u_url"), ("epg", "m3u_epg_url")], ["url"], "m3u_enabled"),
    ("xtream", "Xtream Codes",
     [("server", "xtream_host"), ("user", "xtream_username"), ("pass", "xtream_password")],
     ["server", "user", "pass"], "xtream_enabled"),
    ("eon", "EON",
     [("eonbrand", "eon_brand"), ("eonuser", "eon_username"), ("eonpass", "eon_password"),
      ("eondevice", "eon_device_id")], ["eonuser", "eonpass"], "eon_enabled"),
    ("iris", "Iris",
     [("irisuser", "iris_username"), ("irispass", "iris_password"),
      ("irisdevice", "iris_device_id")], ["irisuser", "irispass"], "iris_enabled"),
    ("move", "Move TV",
     [("moveuser", "move_username"), ("movepass", "move_password"),
      ("movedevice", "move_device_id")], ["moveuser", "movepass"], "move_enabled"),
    # Handled before this table is walked (see apply_form) — listed here only so the phone's type
    # selector offers it in the same place as the rest.
    ("transfer", "Prenos naloga (kod)", [], ["token_blob"], ""),
]

#: Must stay in step with the `eon_brand` options in resources/settings.xml — the value written here is
#: an index into that list.
_EON_BRANDS = [(0, "EON TV (RS)"), (1, "EON TV (BA)"), (2, "EON TV (ME)"),
               (3, "EON TV (MK)"), (4, "EON TV (SI)")]


def _same(written, read_back):
    """Kodi normalises what it stores — a boolean written as "true" can come back as "1". Comparing the
    raw strings would report a successful write as a failure."""
    a, b = str(written).strip().lower(), str(read_back).strip().lower()
    truthy = ("true", "1", "yes")
    if a in truthy and b in truthy:
        return True
    return a == b


def verify(settings, written):
    """The setting ids whose value did NOT survive the write, which is the whole point of this module
    reporting anything at all — see the comment in `apply_form`."""
    return sorted(key for key, value in written.items() if not _same(value, settings.get(key, "")))


def on_disk(settings, written):
    """
    Which of [written] can be found in Kodi's own settings.xml on disk.

    Reported, never enforced. Reading a value back through the API proves it reached Kodi; it does not
    prove Kodi flushed it, and if a future failure is a flush rather than an overwrite, this line in the
    log is what will say so. It is not a failure condition because Kodi is entitled to write that file
    when it likes — treating "not there yet" as an error would reject perfectly good pairings.
    """
    path = os.path.join(settings.profile_dir(), "settings.xml")
    try:
        with open(path, "rb") as handle:
            blob = handle.read().decode("utf-8", "replace")
    except (OSError, IOError) as err:
        return "settings.xml unreadable (%s)" % err
    found = [key for key in written if ('id="%s"' % key) in blob]
    return "%d of %d on disk (%s)" % (len(found), len(written),
                                      ", ".join(sorted(set(written) - set(found))) or "all")


def apply_form(settings, form):
    """
    Write one submitted account into the addon's settings; return (display name, what was written).

    Two failures this refuses to paper over:

    * A form posted with an empty password would enable a provider that then fails at the next refresh,
      and the user would look for the fault on the TV instead of on the phone where it happened.
    * **A write that does not stick.** Kodi's addon settings dialog holds its own copy of every value
      and writes that copy back over settings.xml when it closes — so anything written while it is open
      is silently lost. The first build of this feature reported "Added" and then had nothing:
      credentials gone, refresh returning 0 channels, and no way to tell from the box which of the two
      halves had failed. Every value is now read straight back, and a write that vanished is reported
      as the failure it is.
    """
    kind = (form.get("type") or "").strip()
    if kind == "transfer":
        # An account handed over as a code rather than typed. There is no camera on this end, so it
        # is a paste field rather than a scan.
        profile = transfer.decode(form.get("token_blob") or "")
        if not profile:
            raise PairingError("That does not look like an account transfer code.")
        written = {}
        try:
            transfer.apply(settings, profile, written)
        except ValueError as err:
            raise PairingError(str(err))
        # EVERY field, not just the enable flag. Verifying only that one checked the single value whose
        # loss does not matter, and would have said "Added" for an import whose username and password
        # were both discarded by the open settings dialog.
        lost = verify(settings, written)
        if lost:
            raise PairingError("The TV accepted the account but did not save it (%s)."
                               % ", ".join(lost))
        return transfer.describe(profile), written

    for key, label, fields, required, enable in _TYPES:
        if key != kind:
            continue
        missing = [f for f in required if not (form.get(f) or "").strip()]
        if missing:
            raise PairingError("%s needs: %s" % (label, ", ".join(missing)))
        # A provider that is ALREADY configured gets a second account rather than being overwritten.
        # Overwriting is the behaviour that loses a working subscription to a typo, and "add the one at
        # my mother's too" is exactly what someone standing at the TV with a phone is trying to do.
        first_field = fields[0][1] if fields else ""
        if first_field and settings.get(first_field, "").strip() and form.get("as_new"):
            values = {}
            for field, setting_id in fields:
                value = (form.get(field) or "").strip()
                if setting_id.endswith("_brand"):
                    value = value if value.isdigit() else "0"
                values[setting_id] = value
            if key == "eon" and not values.get("eon_device_id"):
                values["eon_register_new_device"] = "true"
            account_id = accounts.add(settings, key, values,
                                      name=(form.get("name") or "").strip())
            # Verified the same way a first account is: read back from the store, not assumed.
            stored = [a for a in accounts.load(settings) if a["id"] == account_id]
            if not stored:
                raise PairingError("The TV accepted the account but did not save it.")
            return ((form.get("name") or "").strip() or "%s (2)" % label), {}

        written = {}
        for field, setting_id in fields:
            value = (form.get(field) or "").strip()
            # An empty optional field is written as empty on purpose — pairing a second account into a
            # box that already had one must not leave the previous device id behind, quietly pointing
            # the new credentials at the old device slot.
            if setting_id.endswith("_brand"):
                value = value if value.isdigit() else "0"
            settings.set(setting_id, value)
            written[setting_id] = value
        # EON refuses to log in at all without a device number, and the addon will not register one
        # unless it was asked to. Pairing with the device field left empty therefore produced a
        # perfectly configured account that could not log in — "0 channels", with the credentials
        # sitting right there looking correct. Leaving the field empty IS the request to register.
        if key == "eon" and not written.get("eon_device_id"):
            settings.set("eon_register_new_device", "true")
            written["eon_register_new_device"] = "true"
        # Only the provider that was just paired is touched. Turning the others off would make pairing
        # a phone destroy a working setup, which is not what "add an account" means anywhere.
        settings.set(enable, "true")
        written[enable] = "true"

        lost = verify(settings, written)
        if lost:
            diag.log("Pairing: %d of %d settings did not survive the write (%s)"
                     % (len(lost), len(written), ", ".join(lost)), "ERROR")
            raise PairingError(
                "The TV accepted the account but did not save it (%s). Close the addon's settings "
                "screen on the TV — while it is open it overwrites anything written behind it — and "
                "scan the code again." % ", ".join(lost))
        diag.log("Pairing: %s configured from a paired phone (%d settings, all verified)"
                 % (label, len(written)))
        return (form.get("name") or "").strip() or label, written
    raise PairingError("Unknown account type %r." % kind)


# ---- the server -------------------------------------------------------------

class PairingServer(object):
    """
    One pairing session. Construct, [start], poll [state] until it is not WAITING, then [stop].

    The socket work runs on its own thread because the caller is the Kodi UI: a plugin that blocks in
    accept() for five minutes is a frozen TV.
    """

    #: "pair" serves the account form; "log" serves the log to a phone instead. Same socket, same
    #: one-time token, same QR — because the alternative for getting a log off a TV is photographing
    #: seventeen pages of it, which is how this session's actual bug was nearly missed.
    MODES = ("pair", "log")

    def __init__(self, settings, host=None, port=PORT, mode="pair"):
        self.settings = settings
        self.mode = mode if mode in self.MODES else "pair"
        self.host = host or lan_address()
        self.port = port
        #: 128 bits from the OS random source. Not `random` — that is seeded predictably enough that a
        #: token from it is guessable by anything that knows roughly when pairing started.
        self.token = "".join("%02x" % byte for byte in bytearray(os.urandom(16)))
        self.url = ""
        self.deadline = 0.0
        self._socket = None
        self._thread = None
        self._stop = threading.Event()
        self._lock = threading.Lock()
        self._state = WAITING
        self._detail = ""
        #: What the last successful submission wrote, so the caller can check ONCE MORE after its
        #: screen has closed — see `pair_with_phone`.
        self.written = {}
        # The submitted form is handed to the caller's thread rather than applied here. Kodi's addon
        # API resolves "which addon am I" from the calling script's context, and a socket thread this
        # module started is not that context; a write from here can be accepted and go nowhere. The
        # phone still waits for the real answer, which is why this is a handshake and not a queue.
        self._pending = None
        self._pending_result = None
        self._pending_done = threading.Event()

    # ---- lifecycle ----

    def start(self):
        """Binds, and returns the URL that goes into the QR. Raises OSError/socket.error if it cannot."""
        if not self.host:
            raise PairingError("This box has no network address a phone could reach.")
        last = None
        for offset in range(PORT_ATTEMPTS):
            sock = None
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                # No SO_REUSEADDR: on this port that would let a second pairing session bind alongside
                # a first one still holding a live token, and the phone would reach whichever won the
                # race. A busy port is meant to be visible, and the loop moves to the next one.
                sock.bind((self.host, self.port + offset))
                sock.listen(4)
                sock.settimeout(ACCEPT_TIMEOUT)
                self._socket = sock
                self.port = self.port + offset
                break
            except (OSError, socket.error) as err:                 # noqa: UP024
                last = err
                try:
                    if sock is not None:
                        sock.close()
                except Exception:                                  # noqa: BLE001
                    pass
        if self._socket is None:
            raise PairingError("Ports %d-%d are all busy (%s)."
                               % (PORT, PORT + PORT_ATTEMPTS - 1, last))

        self.url = "http://%s:%d/%s?token=%s" % (self.host, self.port,
                                                 "log" if self.mode == "log" else "pair", self.token)
        self.deadline = time.time() + SESSION_SECONDS
        self._thread = threading.Thread(target=self._serve, name="iptvbox-pairing")
        self._thread.daemon = True
        self._thread.start()
        # The token is what makes the URL a credential; the log gets the address only.
        diag.log("Pairing: listening on %s:%d" % (self.host, self.port))
        return self.url

    def stop(self):
        self._stop.set()
        thread = self._thread
        if thread is not None and thread is not threading.current_thread():
            thread.join(ACCEPT_TIMEOUT * 3)
        try:
            if self._socket is not None:
                self._socket.close()
        except Exception:                                          # noqa: BLE001
            pass
        self._socket = None
        self._thread = None

    def seconds_left(self):
        return max(0, int(self.deadline - time.time()))

    def state(self):
        with self._lock:
            return self._state, self._detail

    def _set_state(self, state, detail=""):
        with self._lock:
            self._state, self._detail = state, detail

    # ---- serving ----

    def _serve(self):
        while not self._stop.is_set():
            if time.time() >= self.deadline:
                self._set_state(STOPPED, "The pairing link expired.")
                return
            try:
                client, _addr = self._socket.accept()
            except socket.timeout:
                continue
            except (OSError, socket.error):                         # noqa: UP024  (closed under us)
                return
            try:
                client.settimeout(CLIENT_TIMEOUT)
                self._handle(client)
            except Exception as err:                               # noqa: BLE001
                # One malformed request must not end a session the user is still standing in front of.
                diag.log("Pairing: request failed — %s: %s" % (type(err).__name__, err))
            finally:
                try:
                    client.close()
                except Exception:                                  # noqa: BLE001
                    pass
            if self.state()[0] == DONE:
                return

    def _handle(self, client):
        stream = client.makefile("rb")
        request = _line(stream)
        if not request:
            return
        parts = request.split(" ")
        if len(parts) < 2:
            return
        method, path = parts[0], parts[1]

        length = 0
        while True:
            header = _line(stream)
            if header is None or not header.strip():
                break
            name, _, value = header.partition(":")
            if name.strip().lower() == "content-length":
                try:
                    length = int(value.strip())
                except ValueError:
                    length = 0

        if method == "GET":
            route, _, query = path.partition("?")
            if not self._token_ok(_query(query).get("token", "")):
                _respond(client, 403, "text/plain; charset=utf-8", "Invalid or expired pairing link.")
                return
            if self.mode == "log":
                # Two logs, because they answer different questions. Ours ends where the addon's job
                # ends — "the playlist was written, IPTV Simple was pointed at it". Everything after
                # that (the PVR manager, the guide import, a stream that will not open) is only in
                # Kodi's own log, which on a TV box is otherwise unreachable.
                kodi = route.startswith("/kodi")
                text = (diag.read_kodi_log() if kodi else diag.read_log()) or "The log is empty."
                if route.endswith(".txt"):
                    # Served as a download so the phone gets a file it can forward, not a page it has
                    # to select and copy. This is the whole point: a log has to be able to LEAVE the TV.
                    _respond(client, 200, "text/plain; charset=utf-8", text,
                             extra='Content-Disposition: attachment; filename="%s"\r\n'
                                   % ("kodi.log" if kodi else diag.LOG_NAME))
                else:
                    _respond(client, 200, "text/html; charset=utf-8",
                             _log_html(self.token, text, kodi))
                return
            _respond(client, 200, "text/html; charset=utf-8", _form_html(self.token))
            return

        if self.mode == "log":
            _respond(client, 405, "text/plain; charset=utf-8", "This session only serves the log.")
            return

        if method != "POST":
            _respond(client, 405, "text/plain; charset=utf-8", "Method not allowed.")
            return

        if length <= 0 or length > MAX_FORM_BYTES:
            # Drained (up to a bound) before answering. Closing a socket with the client still pushing
            # a body sends a RST, and the phone shows a connection error instead of the reason —
            # "something went wrong on the TV" for what is really "that form was too big".
            stream.read(min(length, MAX_FORM_BYTES * 2))
            _respond(client, 400, "text/plain; charset=utf-8", "Bad request.")
            return
        # Content-Length counts BYTES; the body is read as bytes and decoded once, whole. Reading it as
        # text through a buffered reader cannot be made byte-exact, and the read then stalls until the
        # socket timeout on any client that sends plain UTF-8.
        body = stream.read(length) or b""
        form = _query(body.decode("utf-8", "replace"))
        if not self._token_ok(form.get("token", "")):
            _respond(client, 403, "text/plain; charset=utf-8", "Invalid or expired pairing link.")
            return
        ok, detail = self._apply_on_owner(form)
        if not ok:
            # The phone is told, and the session stays open so it can be corrected right there — a
            # mistyped password should not mean walking back to the TV to start again.
            _respond(client, 200, "text/html; charset=utf-8", _page(
                "Could not add the account", _escape(detail), ok=False))
            return
        _respond(client, 200, "text/html; charset=utf-8", _page(
            'Added "%s" to your TV' % _escape(detail), "You can close this page now."))
        self._set_state(DONE, detail)

    def _apply_on_owner(self, form):
        """Hand the form to whichever thread is calling [pump] and wait for its verdict."""
        with self._lock:
            self._pending_result = None
            self._pending_done.clear()
            self._pending = form
        if not self._pending_done.wait(APPLY_TIMEOUT):
            with self._lock:
                self._pending = None
            return False, ("The TV did not answer. Is the IPTV Balkan pairing screen still open on it?")
        return self._pending_result

    def pump(self):
        """
        Apply anything the phone has submitted. MUST be called from the thread that owns the Kodi
        session — the plugin's own — and often enough that the phone is not left waiting: everything
        the person holding it sees happens between this call and the next.
        """
        with self._lock:
            form, self._pending = self._pending, None
        if form is None:
            return
        try:
            name, written = apply_form(self.settings, form)
            self.written = written
            result = (True, name)
        except PairingError as err:
            result = (False, str(err))
        except Exception as err:                                   # noqa: BLE001
            # Whatever went wrong reaches the phone. An addon that fails silently here is exactly what
            # this whole round of work was spent diagnosing.
            diag.log("Pairing: applying the form failed — %s: %s" % (type(err).__name__, err), "ERROR")
            result = (False, "%s: %s" % (type(err).__name__, err))
        with self._lock:
            self._pending_result = result
        self._pending_done.set()

    def _token_ok(self, given):
        # Constant-time, because the alternative is a token that can be guessed one character at a time
        # by anything that can time an HTTP response on the same LAN.
        return hmac.compare_digest(str(given), str(self.token))


# ---- plumbing ---------------------------------------------------------------

def lan_address():
    """
    The IPv4 address a phone on the same network can actually reach, or "" if there is none.

    The UDP "connect" sends nothing — it only asks the kernel which local address would be used to
    reach the outside world, which is the one the box's own router hands out. That answer is preferred
    over the hostname lookup because on Android and on most Linux boxes the hostname resolves to
    127.0.0.1, and a QR holding 127.0.0.1 is a QR that scans perfectly and goes nowhere.
    """
    # KODI'S OWN ANSWER FIRST, because the probe below asks the wrong question on a phone.
    #
    # Read off a Samsung running Kodi 22 with mobile data on: Kodi reported 10.84.22.155 (its Wi-Fi
    # address) while this function returned 10.124.54.221 — the CARRIER's. The probe asks the kernel
    # which address would reach the internet, and with mobile data up that is the cellular interface;
    # the address is in 10.0.0.0/8 so `_is_private` accepts it, and the QR then holds an address the
    # phone's own browser cannot reach. Kodi tracks the interface it considers current and says so.
    try:
        import xbmc                                                # noqa: PLC0415  (Kodi-only)
        reported = (xbmc.getInfoLabel("Network.IPAddress") or "").strip()
    except Exception:                                              # noqa: BLE001  (tooling, tests)
        reported = ""
    if _is_private(reported):
        return reported

    candidate = ""
    probe = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        probe.connect(("8.8.8.8", 80))
        candidate = probe.getsockname()[0]
    except (OSError, socket.error):                                # noqa: UP024
        candidate = ""
    finally:
        try:
            probe.close()
        except Exception:                                          # noqa: BLE001
            pass
    if _is_private(candidate):
        return candidate

    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            address = info[4][0]
            if _is_private(address):
                return address
    except (OSError, socket.error):                                # noqa: UP024
        pass
    # A routable public address is still better than nothing (some boxes sit on a flat network), but a
    # loopback address never is.
    return candidate if candidate and not candidate.startswith("127.") else ""


def _is_private(address):
    if not address:
        return False
    if address.startswith("192.168.") or address.startswith("10."):
        return True
    if address.startswith("172."):
        try:
            second = int(address.split(".")[1])
        except (IndexError, ValueError):
            return False
        return 16 <= second <= 31
    return False


def _line(stream):
    """One CRLF-terminated header line, decoded as ASCII (which is what the HTTP spec allows there)."""
    raw = stream.readline(8192)
    if not raw:
        return None
    return raw.decode("latin-1").rstrip("\r\n")


def _query(raw):
    out = {}
    for pair in (raw or "").split("&"):
        if not pair:
            continue
        key, _, value = pair.partition("=")
        out[unquote_plus(key)] = unquote_plus(value)
    return out


def _respond(client, code, content_type, body, extra=""):
    payload = body.encode("utf-8")
    status = {200: "OK", 400: "Bad Request", 403: "Forbidden",
              405: "Method Not Allowed"}.get(code, "Error")
    head = ("HTTP/1.1 %d %s\r\n"
            "Content-Type: %s\r\n"
            "Content-Length: %d\r\n"
            # No caching anywhere: this page carries a one-time token and, on the way back, a password.
            "Cache-Control: no-store\r\n"
            "%s"
            "Connection: close\r\n\r\n" % (code, status, content_type, len(payload), extra))
    client.sendall(head.encode("latin-1"))
    client.sendall(payload)


def _escape(text):
    """Everything on these pages that came from the network goes through here — the submitted name and
    the error detail both land inside HTML, and without this the pairing page is a self-XSS."""
    return (str(text).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
            .replace('"', "&quot;").replace("'", "&#39;"))


_CSS = """
body{font-family:sans-serif;background:#0D1526;color:#E8EDF2;padding:20px;max-width:480px;margin:0 auto}
h2{color:#2FD4A6} label{display:block;margin-top:14px;font-size:14px;color:#8A97A8}
input,select,textarea{width:100%;padding:10px;margin-top:4px;border-radius:8px;border:1px solid #253349;
background:#131C2E;color:#E8EDF2;box-sizing:border-box;font-size:16px}
button{margin-top:22px;width:100%;padding:12px;border-radius:24px;border:none;background:#2FD4A6;
color:#0D1526;font-weight:bold;font-size:16px}
.hint{font-size:12px;color:#8A97A8;margin-top:6px}
.check{display:flex;align-items:center;gap:8px;color:#E8EDF2;font-size:14px}
.fields{display:none}
"""


def _page(heading, message, ok=True):
    return ("<!doctype html><html><head><meta charset=\"utf-8\">"
            "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">"
            "<title>IPTV Balkan</title><style>%s h2{color:%s}</style></head>"
            "<body><h2>%s</h2><p>%s</p></body></html>"
            % (_CSS, "#2FD4A6" if ok else "#FF6B6B", heading, message))


def _log_html(token, text, kodi=False):
    """
    A log, on the phone, with the newest lines first.

    Newest first because that is the only part anyone reads: the failure is at the END of a log and a
    page opened at the top of 200 KB is a page nobody scrolls. The download link is beside it so the
    whole thing can be forwarded rather than photographed, and the two logs link to each other because
    the answer is regularly in the other one.
    """
    lines = text.splitlines()
    tail = "\n".join(reversed(lines[-4000:]))
    safe_token = _escape(token)
    tabs = "".join(
        '<a class="tab%s" href="%s?token=%s">%s</a>'
        % (" on" if is_kodi == kodi else "", route, safe_token, label)
        for route, label, is_kodi in (("/log", "IPTV Balkan", False), ("/kodi", "Kodi", True)))
    return """<!doctype html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>%s - log</title><style>%s
pre{white-space:pre-wrap;word-break:break-word;font-size:12px;line-height:1.45;background:#131C2E;
border:1px solid #253349;border-radius:8px;padding:12px;margin-top:16px}
a.btn{display:block;text-align:center;margin-top:16px;padding:12px;border-radius:24px;
background:#2FD4A6;color:#0D1526;font-weight:bold;text-decoration:none}
.tabs{display:flex;gap:8px;margin-top:8px}
.tab{flex:1;text-align:center;padding:10px;border-radius:20px;border:1px solid #253349;
background:#131C2E;color:#8A97A8;text-decoration:none;font-size:14px}
.tab.on{background:#2FD4A6;color:#0D1526;font-weight:bold;border-color:#2FD4A6}
</style></head><body>
<h2>%s - log</h2>
<div class="tabs">%s</div>
<p class="hint">%d lines, newest first.</p>
<a class="btn" href="%s?token=%s">Save as a file</a>
<pre>%s</pre>
</body></html>""" % ("Kodi" if kodi else "IPTV Balkan", _CSS, "Kodi" if kodi else "IPTV Balkan",
                     tabs, len(lines), "/kodi.txt" if kodi else "/log.txt", safe_token,
                     _escape(tail))


def _form_html(token):
    """
    The whole phone-side interface, in one self-contained page.

    Field blocks are hidden and shown by the type selector, so the phone shows only what the chosen
    account actually needs — the same shape as the app's pairing page, which is what a user who has
    paired the app before will expect.
    """
    options = "".join('<option value="%s">%s</option>' % (key, label)
                      for key, label, _f, _r, _e in _TYPES)
    brands = "".join('<option value="%d">%s</option>' % (value, label) for value, label in _EON_BRANDS)
    blocks = """
    <div class="fields" id="f-m3u" style="display:block">
      <label>Playlist address<input name="url" placeholder="http://.../get.php?..."></label>
      <label>XMLTV address (optional)<input name="epg"></label>
    </div>
    <div class="fields" id="f-xtream">
      <label>Server<input name="server" placeholder="http://host:port"></label>
      <label>Username<input name="user" autocapitalize="none" autocorrect="off" autocomplete="off"></label>
      <label>Password<input name="pass" type="password" autocomplete="new-password"></label>
    </div>
    <div class="fields" id="f-eon">
      <label>Brand<select name="eonbrand">%s</select></label>
      <label>Username<input name="eonuser" autocapitalize="none" autocorrect="off" autocomplete="off"></label>
      <label>Password<input name="eonpass" type="password" autocomplete="new-password"></label>
      <label>Device id<input name="eondevice" placeholder="702c44df-4acc-..."
             autocomplete="off" data-form-type="other" spellcheck="false">
        <button type="button" class="paste" data-for="eondevice">Nalepi</button>
        <span class="hint">Paste it from another install to share that device slot. Left empty, the TV
        registers a NEW device and uses one of the subscription's slots — EON frees one per month.</span>
      </label>
    </div>
    <div class="fields" id="f-iris">
      <label>Username<input name="irisuser" autocapitalize="none" autocorrect="off"
             autocomplete="off"></label>
      <label>Password<input name="irispass" type="password" autocomplete="new-password"></label>
      <label>Device id (optional)<input name="irisdevice" placeholder="d64b37cf-1d25-..."
             autocomplete="off" data-form-type="other" spellcheck="false">
        <button type="button" class="paste" data-for="irisdevice">Nalepi</button>
        <span class="hint">Iris refuses an extra device at login — paste the id from a device
        where this account already works.</span></label>
    </div>
    <div class="fields" id="f-transfer">
      <label>Kod za prenos naloga
        <textarea name="token_blob" rows="4" placeholder="Nalepi kod koji si dobio"></textarea>
        <span class="hint">Prenosi se SAMO nalog, ne i lista kanala — ovaj uredjaj se
        prijavljuje sam.</span></label>
    </div>
    <div class="fields" id="f-move">
      <label>Username<input name="moveuser" autocapitalize="none" autocorrect="off" autocomplete="off"></label>
      <label>Password<input name="movepass" type="password" autocomplete="new-password"></label>
      <label>Device id (optional)<input name="movedevice" autocomplete="off"></label>
    </div>
    """ % brands
    return """<!doctype html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Add an account to IPTV Balkan</title><style>%s</style></head><body>
<h2>Add an account to your TV</h2>
<form method="post" action="/pair" autocomplete="off">
<input type="hidden" name="token" value="%s">
<label>Name (optional)<input name="name" placeholder="My account"></label>
<label class="check"><input type="checkbox" name="as_new" value="1" style="width:auto">
  Dodaj kao NOV nalog (ne prepisuj postojeci)</label>
<label>Type<select name="type" id="type">%s</select></label>
%s
<button type="submit">Add to TV</button>
</form>
<script>
function wirePaste(){
  document.querySelectorAll("button.paste").forEach(function(b){
    b.addEventListener("click", function(){
      var f = document.getElementsByName(b.dataset.for)[0];
      if(!f) return;
      if(!navigator.clipboard || !navigator.clipboard.readText){ f.focus(); return; }
      navigator.clipboard.readText().then(function(t){
        f.value = (t||"").trim(); f.focus();
      }).catch(function(){ f.focus(); });
    });
  });
}
wirePaste();
</script>
<script>
var sel=document.getElementById('type');
function show(){var v=sel.value,i,n=document.querySelectorAll('.fields');
for(i=0;i<n.length;i++){n[i].style.display='none';}
var b=document.getElementById('f-'+v); if(b){b.style.display='block';}}
sel.addEventListener('change',show); show();
</script></body></html>""" % (_CSS, _escape(token), options, blocks)
