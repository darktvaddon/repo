# -*- coding: utf-8 -*-
"""
AES-CBC encryption, in pure Python, with no dependency of any kind.

WHY THIS IS HERE AND pycryptodome IS NOT
----------------------------------------
EON signs every stream request with AES-CBC, so without this there is no playback. The obvious answer
was `script.module.pycryptodome`, declared as an addon dependency — Kodi ships no crypto of its own,
and vendoring a *binary* would put the addon back in the per-architecture trap it exists to avoid.

That was the plan, and it failed on the first real box. The addon resolved, Kodi listed
`script.module.pycryptodome v3.4.3 installed`, and the import still raised
`ModuleNotFoundError: No module named 'Crypto'` — because on that Android build the bundled module is a
STUB: an addon.xml and an icon, and no `lib` directory at all. Kodi will not offer to install the real
one over it, because as far as its database is concerned the dependency is already satisfied. The
failure surfaced as a channel that would not play, with a Python traceback nobody would ever see.

So the same conclusion as the QR encoder, reached the same way: a small, fully specified algorithm that
we carry ourselves beats a dependency that is somebody else's decision on every box. AES is 200 lines
and it is verified byte-for-byte against the reference implementation and against the published NIST
vectors in `C:\\Projects\\kodi-iptvbox\\test-aes.py`.

SCOPE
-----
Encryption only, CBC only, 128/192/256-bit keys. That is exactly what EON's stream signature needs.
Nothing here is a general-purpose crypto library and it must not be treated as one: there is no
authentication, no key derivation, and no attempt at constant-time behaviour. It encrypts a few hundred
bytes of query parameters, once per tune.
"""

#: The S-box is COMPUTED, not pasted. 256 bytes of hex typed by hand is 256 chances at a typo that no
#: reading catches — and a single wrong entry produces output that looks like ciphertext, encrypts and
#: decrypts consistently against itself, and is rejected only by the far end. The definition below is
#: the specification's own: the multiplicative inverse in GF(2**8), then a fixed affine transform.
_SBOX = [0] * 256


def _build_sbox():
    p = q = 1
    while True:
        # p walks the generator 3; q walks its inverse, so q is always p's multiplicative inverse.
        p = p ^ ((p << 1) & 0xFF) ^ (0x1B if p & 0x80 else 0)
        q ^= q << 1
        q ^= q << 2
        q ^= q << 4
        q &= 0xFF
        if q & 0x80:
            q ^= 0x09
        value = q ^ _rotl(q, 1) ^ _rotl(q, 2) ^ _rotl(q, 3) ^ _rotl(q, 4)
        _SBOX[p] = value ^ 0x63
        if p == 1:
            break
    _SBOX[0] = 0x63


def _rotl(value, count):
    return ((value << count) | (value >> (8 - count))) & 0xFF


_build_sbox()

#: Round constants. Each is the previous doubled in GF(2**8), which is why 0x80 doubles to 0x1B.
_RCON = [0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80, 0x1B, 0x36, 0x6C, 0xD8, 0xAB, 0x4D]


def _xtime(value):
    """Multiply by 2 in GF(2**8) — the one primitive MixColumns is built from."""
    value <<= 1
    if value & 0x100:
        value ^= 0x11B
    return value & 0xFF


def _expand_key(key):
    """
    Round keys for a 16, 24 or 32 byte key.

    Returns a flat byte list of (rounds + 1) * 16, so a round key is a plain slice.
    """
    nk = len(key) // 4
    if nk not in (4, 6, 8):
        raise ValueError("AES: key must be 16, 24 or 32 bytes, not %d" % len(key))
    rounds = nk + 6
    words = [list(bytearray(key[4 * i:4 * i + 4])) for i in range(nk)]
    for i in range(nk, 4 * (rounds + 1)):
        word = list(words[i - 1])
        if i % nk == 0:
            word = word[1:] + word[:1]                              # RotWord
            word = [_SBOX[b] for b in word]                          # SubWord
            word[0] ^= _RCON[i // nk - 1]
        elif nk == 8 and i % nk == 4:
            # AES-256 only: an extra SubWord in the middle of each cycle. Leaving this out produces a
            # cipher that is self-consistent and simply not AES-256.
            word = [_SBOX[b] for b in word]
        words.append([word[j] ^ words[i - nk][j] for j in range(4)])
    flat = []
    for word in words:
        flat.extend(word)
    return flat, rounds


def _encrypt_block(block, round_keys, rounds):
    """
    One 16-byte block.

    The state is held COLUMN-MAJOR, the way the specification numbers it: byte i of the block is row
    i % 4 of column i // 4. Every step below reads that way, and a row-major state is the classic way
    to get a cipher that is wrong only in ShiftRows.
    """
    state = list(bytearray(block))
    for i in range(16):
        state[i] ^= round_keys[i]

    for rnd in range(1, rounds + 1):
        for i in range(16):
            state[i] = _SBOX[state[i]]

        # ShiftRows: row r moves left by r. In column-major terms, the new (r, c) is the old (r, c + r).
        shifted = list(state)
        for r in range(1, 4):
            for c in range(4):
                shifted[4 * c + r] = state[4 * ((c + r) % 4) + r]
        state = shifted

        if rnd != rounds:                                          # the last round has no MixColumns
            for c in range(4):
                a0, a1, a2, a3 = state[4 * c:4 * c + 4]
                total = a0 ^ a1 ^ a2 ^ a3
                state[4 * c + 0] = a0 ^ total ^ _xtime(a0 ^ a1)
                state[4 * c + 1] = a1 ^ total ^ _xtime(a1 ^ a2)
                state[4 * c + 2] = a2 ^ total ^ _xtime(a2 ^ a3)
                state[4 * c + 3] = a3 ^ total ^ _xtime(a3 ^ a0)

        base = rnd * 16
        for i in range(16):
            state[i] ^= round_keys[base + i]

    return bytes(bytearray(state))


def encrypt_block(key, block):
    """A single raw block. Exposed for the test vectors; callers want [cbc_encrypt]."""
    if len(block) != 16:
        raise ValueError("AES: a block is 16 bytes, not %d" % len(block))
    round_keys, rounds = _expand_key(key)
    return _encrypt_block(block, round_keys, rounds)


def cbc_encrypt(key, iv, data):
    """
    CBC over [data], which must already be a multiple of 16 bytes.

    Padding is deliberately NOT applied here. EON's blob is padded by the caller in the exact shape the
    web client uses, and a helper that silently pads as well would produce a request the edge rejects
    for a reason nothing in the log would explain.
    """
    if len(iv) != 16:
        raise ValueError("AES: the IV is 16 bytes, not %d" % len(iv))
    if len(data) % 16:
        raise ValueError("AES: CBC input must be a multiple of 16 bytes, not %d" % len(data))
    round_keys, rounds = _expand_key(key)
    out = bytearray()
    previous = bytearray(iv)
    for offset in range(0, len(data), 16):
        chunk = bytearray(data[offset:offset + 16])
        for i in range(16):
            chunk[i] ^= previous[i]
        encrypted = _encrypt_block(bytes(chunk), round_keys, rounds)
        out.extend(encrypted)
        previous = bytearray(encrypted)
    return bytes(out)
