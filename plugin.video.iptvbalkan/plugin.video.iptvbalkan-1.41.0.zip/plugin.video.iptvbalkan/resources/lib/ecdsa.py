# -*- coding: utf-8 -*-
"""
ECDSA signature verification over NIST P-256, in pure Python.

**Why this exists, and it is not a preference.** The licence answer is signed SHA256withECDSA and was
verified with pycryptodome. On the user's own Android TV box, `script.module.pycryptodome` is a STUB —
addon.xml and an icon, no `lib` directory — so `import Crypto` raises while Kodi reports the dependency
as installed, and it refuses to install the real one over a dependency it believes is satisfied. AES was
vendored into `aes.py` for exactly that reason; this is the other half.

Left as it was, the failure mode is quiet and bad: with signing enabled server-side, `verify_signed`
would throw on every check, every answer would be judged untrustworthy, the offline grace window would
run down, and the box would **lock itself** — on a paying customer, with a valid licence, because of a
missing library. Verification only, no signing: the private half never leaves the server, so there is
nothing here that could sign anything.

Verified in `C:\\Projects\\kodi-iptvbox\\test-ecdsa.py` against signatures produced by the real server
key through the openssl CLI (which is what PHP's `openssl_sign` does), and cross-checked against
pycryptodome on random messages — including the negative cases, because a verifier that accepts
everything passes every positive test ever written.
"""

import hashlib

# NIST P-256 (secp256r1, prime256v1). These are the published domain parameters.
_P = 0xFFFFFFFF00000001000000000000000000000000FFFFFFFFFFFFFFFFFFFFFFFF
_N = 0xFFFFFFFF00000000FFFFFFFFFFFFFFFFBCE6FAADA7179E84F3B9CAC2FC632551
_A = _P - 3
_B = 0x5AC635D8AA3A93E7B3EBBD55769886BC651D06B0CC53B0F63BCE3C3E27D2604B
_GX = 0x6B17D1F2E12C4247F8BCE6E563A440F277037D812DEB33A0F4A13945D898C296
_GY = 0x4FE342E2FE1A7F9B8EE7EB4A7C0F9E162BCE33576B315ECECBB6406837BF51F5

#: The DER prefix of a P-256 SubjectPublicKeyInfo. Everything after it is the 65-byte uncompressed
#: point, so matching this both identifies the curve and locates the key without a full DER parser.
_SPKI_PREFIX = bytes.fromhex("3059301306072a8648ce3d020106082a8648ce3d030107034200")


class BadKey(ValueError):
    pass


# ---- curve arithmetic ------------------------------------------------------
#
# Jacobian coordinates: (X, Y, Z) represents the affine point (X/Z², Y/Z³). Modular inversion is by far
# the most expensive operation here, and affine addition needs one per step — roughly 500 of them for a
# verification. Jacobian needs exactly ONE, at the very end.

def _double(point):
    x, y, z = point
    if y == 0:
        return (0, 0, 0)
    s = (4 * x * y * y) % _P
    m = (3 * x * x + _A * pow(z, 4, _P)) % _P
    nx = (m * m - 2 * s) % _P
    ny = (m * (s - nx) - 8 * pow(y, 4, _P)) % _P
    nz = (2 * y * z) % _P
    return (nx, ny, nz)


def _add(p, q):
    if p[2] == 0:
        return q
    if q[2] == 0:
        return p
    x1, y1, z1 = p
    x2, y2, z2 = q
    u1 = (x1 * z2 * z2) % _P
    u2 = (x2 * z1 * z1) % _P
    s1 = (y1 * pow(z2, 3, _P)) % _P
    s2 = (y2 * pow(z1, 3, _P)) % _P
    if u1 == u2:
        # Same x: either the same point (double it) or two points that cancel to infinity.
        return _double(p) if s1 == s2 else (0, 0, 0)
    h = (u2 - u1) % _P
    r = (s2 - s1) % _P
    h2 = (h * h) % _P
    h3 = (h2 * h) % _P
    x3 = (r * r - h3 - 2 * u1 * h2) % _P
    y3 = (r * (u1 * h2 - x3) - s1 * h3) % _P
    z3 = (h * z1 * z2) % _P
    return (x3, y3, z3)


def _multiply(point, scalar):
    result = (0, 0, 0)
    addend = point
    while scalar:
        if scalar & 1:
            result = _add(result, addend)
        addend = _double(addend)
        scalar >>= 1
    return result


def _to_affine_x(point):
    """The affine x of a Jacobian point — the only coordinate a verification needs."""
    x, _y, z = point
    if z == 0:
        return None
    z_inverse = pow(z, _P - 2, _P)          # Fermat: z^(p-2) == z^-1 for prime p
    return (x * z_inverse * z_inverse) % _P


# ---- DER -------------------------------------------------------------------

def _parse_signature(der):
    """
    SEQUENCE { INTEGER r, INTEGER s } — what `openssl_sign` and Java's SHA256withECDSA both emit.

    Strict on purpose. A lenient parser that shrugs at a malformed structure is a verifier that can be
    fed a signature it never really checked.
    """
    if len(der) < 8 or der[0] != 0x30:
        raise ValueError("signature is not a DER SEQUENCE")
    length = der[1]
    body = der[2:]
    if length & 0x80:                        # long form; P-256 never needs more than one length byte
        count = length & 0x7F
        if count != 1 or len(der) < 3:
            raise ValueError("unexpected DER length encoding")
        length = der[2]
        body = der[3:]
    if length != len(body):
        raise ValueError("DER length does not match the payload")

    def take_integer(data):
        if len(data) < 2 or data[0] != 0x02:
            raise ValueError("expected a DER INTEGER")
        size = data[1]
        if size == 0 or len(data) < 2 + size:
            raise ValueError("truncated DER INTEGER")
        return int.from_bytes(data[2:2 + size], "big"), data[2 + size:]

    r, rest = take_integer(body)
    s, rest = take_integer(rest)
    if rest:
        raise ValueError("trailing bytes after the signature")
    return r, s


def public_key_point(spki_der):
    """The (x, y) of a P-256 SubjectPublicKeyInfo — the form the server publishes and the app embeds."""
    if not spki_der.startswith(_SPKI_PREFIX):
        raise BadKey("not a P-256 SubjectPublicKeyInfo")
    point = spki_der[len(_SPKI_PREFIX):]
    if len(point) != 65 or point[0] != 0x04:
        raise BadKey("public key is not a 65-byte uncompressed point")
    x = int.from_bytes(point[1:33], "big")
    y = int.from_bytes(point[33:65], "big")
    # Cheap sanity check: a point that is not on the curve can make the maths below produce a value that
    # happens to match, so it is refused rather than used.
    if (y * y - (x * x * x + _A * x + _B)) % _P != 0:
        raise BadKey("public key point is not on the curve")
    return x, y


# ---- verification ----------------------------------------------------------

def verify(spki_der, message, signature_der):
    """
    True when [signature_der] is a valid SHA256withECDSA signature over [message] for [spki_der].

    Returns False rather than raising for any malformed input: to a caller there is no useful difference
    between "this signature is wrong" and "this signature is nonsense", and both must fail closed.
    """
    try:
        qx, qy = public_key_point(spki_der)
        r, s = _parse_signature(signature_der)
    except (ValueError, BadKey):
        return False

    if not (1 <= r < _N and 1 <= s < _N):
        return False

    digest = hashlib.sha256(message).digest()
    e = int.from_bytes(digest, "big")        # P-256's order is 256 bits, so no truncation is needed

    try:
        w = pow(s, -1, _N)
    except (TypeError, ValueError):          # pow(x, -1, n) needs Python 3.8; Kodi 19+ has it
        w = _inverse(s, _N)
    u1 = (e * w) % _N
    u2 = (r * w) % _N

    point = _add(_multiply((_GX, _GY, 1), u1), _multiply((qx, qy, 1), u2))
    x = _to_affine_x(point)
    if x is None:
        return False
    return x % _N == r


def _inverse(value, modulus):
    """Extended Euclid, for a Python too old for three-argument pow with a negative exponent."""
    old_r, r = value % modulus, modulus
    old_s, s = 1, 0
    while r:
        quotient = old_r // r
        old_r, r = r, old_r - quotient * r
        old_s, s = s, old_s - quotient * s
    return old_s % modulus
