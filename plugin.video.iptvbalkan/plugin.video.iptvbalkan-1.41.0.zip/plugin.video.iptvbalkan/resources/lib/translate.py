# -*- coding: utf-8 -*-
"""
Machine translation for VOD descriptions, ported from the Android client's `GoogleTranslate.kt`.

Used for exactly one thing: TMDB has a plot in English but not in Serbian. That is most of the
catalogue — TMDB's `sr-RS` coverage is thin outside domestic films — so without this a Video klub
enriched from TMDB shows English descriptions to a Serbian user, which looks worse than showing none.

## The endpoint

`translate.googleapis.com/translate_a/single?client=gtx` — the same no-key endpoint the Android app has
used for years. Two honest caveats, because they decide how this is wired rather than whether:

  * It is **undocumented**. Google can rate-limit or drop it without notice, so nothing may depend on
    it: a failure returns None and the caller keeps the original text.
  * It answers a bare JSON array with no schema. Anything unexpected is treated as "no translation",
    never as an error worth showing anyone.

Translation happens only in the background filler (see tmdb.py), never on a browse path, and the result
is stored in the TMDB cache — so each description is translated once, ever, not once per screen.
"""

import json

from . import diag, net

ENDPOINT = "https://translate.googleapis.com/translate_a/single"

#: Longer than this and it is not a plot any more. Google's endpoint starts refusing long queries, and
#: a truncated description is better than none — TMDB overviews are rarely over 1000 characters.
MAX_CHARS = 1800


def translate(text, target="sr"):
    """
    [text] in [target], or None when there is nothing to do or it did not work.

    Returns None — not the original — when the text is ALREADY in the target language, so a caller can
    tell "no translation needed" from "here is your translation" without comparing strings.
    """
    source = (text or "").strip()
    lang = (target or "").split("-")[0].strip().lower()
    if not source or not lang:
        return None
    if len(source) > MAX_CHARS:
        source = source[:MAX_CHARS].rsplit(" ", 1)[0]

    try:
        from urllib.parse import urlencode
    except ImportError:                                            # pragma: no cover
        from urllib import urlencode

    url = "%s?%s" % (ENDPOINT, urlencode({
        "client": "gtx", "sl": "auto", "dt": "t", "tl": lang, "q": source,
    }))
    # A browser User-Agent, deliberately: this endpoint is the one the web page uses, and it answers
    # differently to something that does not look like one.
    session = net.Session({"user_agent": "Mozilla/5.0"}, timeout=15, trace=False)
    try:
        body = session.get(url, expect_json=False)
    except net.HttpError as err:
        diag.log("Translate: request failed (%s)" % err)
        return None

    try:
        root = json.loads(body)
    except (ValueError, TypeError):
        return None
    if not isinstance(root, list) or not root:
        return None

    # Index 2 is the detected source language. Already in the target means there is nothing to do, and
    # translating Serbian into Serbian returns mangled text rather than the same text.
    detected = ""
    if len(root) > 2 and isinstance(root[2], str):
        detected = root[2].split("-")[0].lower()
    if detected and detected == lang:
        return None

    chunks = root[0]
    if not isinstance(chunks, list):
        return None
    out = []
    for chunk in chunks:
        if isinstance(chunk, list) and chunk and isinstance(chunk[0], str):
            out.append(chunk[0])
    result = "".join(out).strip()
    return result or None
