# -*- coding: utf-8 -*-
"""
Continue watching — where you stopped a film, kept for every provider the same way.

Checked before building this: the Android client has no resume for ANY of its sources, EON and Iris
expose nothing resembling one, and Kaltura's `bookmark/action/*` exists but nothing uses it. So there is
no provider API to lean on that would work across all three, and a feature that only Yettel had would be
the wrong kind of half-done.

So the position lives here, on the box. That has one real advantage over a provider's own bookmark —
it works identically for EON, Iris and Yettel, including titles that came from a Video klub the provider
never tracked — and one real cost: it does not follow you to the phone. Provider-side sync can be
layered on later per provider without changing anything a caller sees.

THE PART THAT IS NOT OBVIOUS: the plugin process is GONE the moment playback starts. Whatever records
the position cannot be the code that started the playback — it has to be the resident service, which is
the same reason Iris' heartbeat lives there. `play()` leaves a marker saying what it just resolved, and
service.py watches the player and writes the position against it.
"""

import json
import os
import time

from . import store

STORE = "resume.json"
#: What the plugin leaves behind so the service knows what is on screen. Removed when playback stops.
MARKER = "resume_playing.json"

#: Under this and it is a mis-tap, not a viewing. Over the far end and the film is finished — offering
#: to resume something at 99% is offering to watch the credits.
MIN_SECONDS = 30
FINISHED_FRACTION = 0.97
#: How many titles the "continue watching" row holds. A list that grows forever is one nobody prunes.
MAX_ENTRIES = 40


def _path(settings, name):
    return os.path.join(settings.profile_dir(), name)


def _read(settings, name):
    try:
        with open(_path(settings, name), "r", encoding="utf-8") as handle:
            data = json.loads(handle.read())
        return data if isinstance(data, dict) else {}
    except (OSError, IOError, ValueError):
        return {}


def _write(settings, name, data):
    # THE WHOLE STORE IS ONE FILE, so a truncate that a power cut interrupts does not cost the position
    # being written — it costs every "continue watching" this box had. Written through a rename instead:
    # see store.write_json. This one is sampled every minute while a film plays, which is precisely the
    # hour somebody is most likely to pull the plug on the box.
    store.write_json(_path(settings, name), data)


def key_for(provider_key, account_id, item_id):
    """One title, on one account. Two accounts watching the same film keep their own places."""
    return "%s%s:%s" % (provider_key, ("@" + account_id) if account_id else "", item_id)


# ---- what the plugin leaves for the service ---------------------------------

def mark_playing(settings, provider_key, account_id, item_id, url, name="", art=""):
    _write(settings, MARKER, {"key": key_for(provider_key, account_id, item_id),
                              "provider": provider_key, "account": account_id, "id": item_id,
                              "url": url, "name": name, "art": art, "since": int(time.time())})


def playing_marker(settings):
    return _read(settings, MARKER)


def clear_marker(settings):
    try:
        os.remove(_path(settings, MARKER))
    except OSError:
        pass


# ---- the store the service writes and the Video klub reads --------------------

def record(settings, marker, position, total):
    """
    Remember where this title is, or forget it when it is effectively over.

    Both ends are trimmed on purpose. A title abandoned in the first half minute is a mis-tap and
    offering to resume it is noise; one watched to the end is finished, and resuming at 99% means
    watching the credits — Kodi's own library uses the same idea for the same reason.
    """
    if not marker or not marker.get("key") or total <= 0:
        return
    positions = _read(settings, STORE)
    if position < MIN_SECONDS or position >= total * FINISHED_FRACTION:
        if positions.pop(marker["key"], None) is not None:
            _write(settings, STORE, positions)
        return
    positions[marker["key"]] = {"provider": marker.get("provider", ""),
                            "account": marker.get("account", ""),
                            "id": marker.get("id", ""),
                            "name": marker.get("name", ""),
                            "art": marker.get("art", ""),
                            "position": int(position), "total": int(total),
                            # Sub-second on purpose: whole seconds tie whenever two titles are touched
                            # in the same second, and then "most recent first" is whatever order the
                            # dictionary happened to be in.
                            "when": time.time()}
    if len(positions) > MAX_ENTRIES:
        oldest = sorted(positions.items(), key=lambda pair: pair[1].get("when", 0))
        for key, _value in oldest[:len(positions) - MAX_ENTRIES]:
            positions.pop(key, None)
    _write(settings, STORE, positions)


def position_of(settings, provider_key, account_id, item_id):
    """(position, total) in seconds, or (0, 0) — what the play route hands Kodi to resume from."""
    entry = _read(settings, STORE).get(key_for(provider_key, account_id, item_id)) or {}
    return int(entry.get("position") or 0), int(entry.get("total") or 0)


def entries(settings):
    """Everything still worth continuing, most recent first."""
    positions = _read(settings, STORE)
    rows = []
    for key, entry in positions.items():
        if not entry.get("id"):
            continue
        row = dict(entry)
        row["key"] = key
        rows.append(row)
    return sorted(rows, key=lambda r: r.get("when", 0), reverse=True)


def forget(settings, key):
    positions = _read(settings, STORE)
    if positions.pop(key, None) is not None:
        _write(settings, STORE, positions)
        return True
    return False
