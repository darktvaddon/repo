# -*- coding: utf-8 -*-
"""
Moving an account onto this addon as a CODE rather than as typing, and back out again.

The format is deliberately the one the owner's phone client already speaks, so an account
typed once can be handed over instead of retyped. Nothing in the interface advertises another
product: the pairing page simply offers a paste field for a transfer code.

The app already carries a transfer format — a `SourceProfile` as JSON, base64url encoded, handed around
inside an `iptvbox://import?src=…` deep link (see the app's `SourceTransfer.kt` and its pairing page's
"Add to app" buttons). This file speaks exactly that format, so neither side needs changing:

  * **TV -> phone**: the addon shows a QR of that deep link. The phone's camera opens it, the app takes
    it from there. Nothing here has to know how the app stores anything.
  * **phone -> TV**: the pairing page the addon already serves gets a field to paste the same token
    into. That is the direction with no camera on the receiving end, so it has to be paste.

TWO THINGS ARE DELIBERATELY NOT TRANSFERRED, and both would be bugs if they were:

**The EON brand.** The app numbers `eonProvider` by OPERATOR (0 = SBB, 1 = Telemach…) and this addon
numbers `eon_brand` by COUNTRY. The same integer means different things on the two sides, so copying it
would silently point an imported account at the wrong CDN and produce "bad credentials" for an account
that is perfectly fine. The local setting is left alone.

**Anything that is not an account.** No channel lists, no guide, no cached tokens beyond the ones that
ARE the credential (Yettel's app-token). The receiving side logs in for itself, which keeps the payload
inside a QR code and always current.
"""

import base64
import json

from . import diag

#: The app's own deep link. Its MainActivity already handles this, which is the whole reason to use it.
IMPORT_SCHEME = "iptvbox://import?src=%s"

#: addon setting  <->  the app's SourceProfile field, per provider. `type` is the app's SourceType name.
_MAP = {
    "eon": ("Eon", [("eon_username", "eonUsername"),
                    ("eon_password", "eonPassword"),
                    ("eon_device_id", "eonDeviceNumber")]),
    "iris": ("Iris", [("iris_username", "irisUsername"),
                      ("iris_password", "irisPassword"),
                      ("iris_device_id", "irisDeviceNumber")]),
    "yettel": ("Yettel", [("yettel_udid", "yettelUdid"),
                          ("yettel_app_token_id", "yettelAppTokenId"),
                          ("yettel_app_token_secret", "yettelAppTokenSecret")]),
    "move": ("Move", [("move_username", "moveUsername"),
                      ("move_password", "movePassword"),
                      ("move_device_id", "moveUid")]),
    "xtream": ("Xtream", [("xtream_host", "xtreamServerUrl"),
                          ("xtream_username", "xtreamUsername"),
                          ("xtream_password", "xtreamPassword")]),
    "m3u": ("M3u", [("m3u_url", "playlistUrl"),
                    ("m3u_epg_url", "epgUrl")]),
}

#: app SourceType -> this addon's provider key. Built from _MAP so the two can never drift apart.
_BY_TYPE = dict((app_type, key) for key, (app_type, _fields) in _MAP.items())


def _b64url_encode(raw):
    """URL-safe, unpadded — the app strips padding too, and `=` inside a URI query is what breaks it."""
    return base64.urlsafe_b64encode(raw).decode("ascii").rstrip("=")


def _b64url_decode(text):
    text = str(text or "").strip()
    return base64.urlsafe_b64decode(text + "=" * (-len(text) % 4))


from . import vault                                                 # noqa: E402


def exportable(settings):
    """Which providers on this box have something worth sending — a key field with a value in it."""
    out = []
    for key, (_app_type, fields) in sorted(_MAP.items()):
        if any(settings.get(setting_id, "").strip() for setting_id, _field in fields):
            out.append(key)
    return out


def encode(settings, provider_key, name=""):
    """This box's account for [provider_key], as the app's own transfer token."""
    if provider_key not in _MAP:
        raise ValueError("nothing to transfer for %r" % provider_key)
    app_type, fields = _MAP[provider_key]
    profile = {
        # The app requires an id and a name; the id only has to be unique on the receiving side.
        "id": "kodi-%s" % provider_key,
        "name": name or ("%s (sa TV-a)" % app_type),
        "type": app_type,
        "enabled": True,
    }
    for setting_id, field in fields:
        # Through the vault, NOT `settings.get` on its own. Once secrets are stored encrypted, a raw
        # read hands the phone an `enc1:…` blob as the password: the app saves it happily, the login
        # there fails, and nothing anywhere says why. The phone cannot decrypt it — the key belongs to
        # THIS device — so the only honest options are the real password or a refusal.
        profile[field] = _readable(settings, setting_id)
    return _b64url_encode(json.dumps(profile, ensure_ascii=False).encode("utf-8"))


def _readable(settings, setting_id):
    value = settings.get(setting_id, "")
    if not vault.is_encrypted(value):
        return value
    try:
        return vault.read(settings, value)
    except vault.Locked:
        raise Locked(
            "Nalog je zakljucan i ne moze da se posalje. Otvori 'Licenca / broj uredjaja', sacekaj "
            "da uredjaj potvrdi licencu, pa probaj ponovo.")


class Locked(Exception):
    """The account cannot be exported because its secrets cannot be read on this device right now."""


def decode(token):
    """A token back into a profile dict, or None when it is not one of ours."""
    try:
        profile = json.loads(_b64url_decode(token).decode("utf-8"))
    except (ValueError, TypeError, UnicodeDecodeError):
        return None
    if not isinstance(profile, dict) or not profile.get("type"):
        return None
    return profile


def describe(profile):
    """
    What the user is shown before accepting an import.

    The account name can claim anything, so the part that actually lets someone spot a bad payload is
    the HOST this box would start talking to. Usernames are shown because they are what a returning user
    recognises; passwords and tokens never are.
    """
    app_type = str(profile.get("type") or "?")
    parts = [app_type]
    for field in ("xtreamServerUrl", "playlistUrl"):
        value = str(profile.get(field) or "").strip()
        if value:
            host = value.split("//", 1)[-1].split("/", 1)[0]
            parts.append(host[:60])
            break
    for field in ("eonUsername", "irisUsername", "moveUsername", "xtreamUsername"):
        value = str(profile.get(field) or "").strip()
        if value:
            parts.append(value)
            break
    if app_type == "Yettel" and profile.get("yettelAppTokenId"):
        parts.append("token uparen")
    return "  ·  ".join(parts)


def apply(settings, profile, recorded=None):
    """
    Write an imported profile into this box's settings. Returns the provider key it configured.

    Empty fields are skipped rather than written: a payload from an app version that does not carry a
    device id must not wipe the one this box already has, which would cost a device slot on the next
    login for no reason.

    [recorded] is an optional dict this fills with `setting id -> value` for everything it wrote, so the
    caller can READ IT ALL BACK. That matters here for the same reason it matters on the pairing form:
    Kodi's settings dialog holds its own copy of every value and writes it back over settings.xml when it
    closes, so a write behind it is discarded. The pairing screen used to verify only the `_enabled` flag
    on this path — the one field whose loss is harmless — and would have reported "Added" for an import
    whose username and password had both been thrown away.
    """
    key = _BY_TYPE.get(str(profile.get("type") or ""))
    if not key:
        raise ValueError("nepoznat tip naloga: %r" % profile.get("type"))
    _app_type, fields = _MAP[key]
    written = []
    for setting_id, field in fields:
        value = str(profile.get(field) or "").strip()
        if not value:
            continue
        settings.set(setting_id, value)
        written.append(setting_id)
        if recorded is not None:
            recorded[setting_id] = value
    if not written:
        raise ValueError("taj kod ne nosi nijedan podatak za %s" % key)
    settings.set("%s_enabled" % key, "true")
    if recorded is not None:
        recorded["%s_enabled" % key] = "true"
    # See the module docstring on why the EON brand is NOT copied.
    if key == "eon" and profile.get("eonProvider") is not None:
        diag.log("Transfer: EON brand left as configured — the app numbers it by operator, this addon "
                 "by country, so copying it would point the account at the wrong CDN")
    diag.log("Transfer: %s configured from a transferred profile (%d fields)" % (key, len(written)))
    return key
