# -*- coding: utf-8 -*-
"""
The screens that put a QR code on the television.

Four things reach for one screen: pairing an account from a phone, sending the log to a phone, linking
Yettel through its device-code flow. They are the same idea
four times — something on the TV that a phone has to reach — so they share one window and one loop.

Split out of default.py, which had grown to hold routing, playback, browsing, maintenance AND this. The
rule going forward: default.py stays routing plus thin handlers, and every screen with a life of its own
gets a module. Nothing here changed in the move except that pairing and Yettel now RETURN whether a
catalogue refresh is worth offering instead of running one — rebuilding the catalogue belongs with the
catalogue, not with a screen.
"""

import os
import time

import xbmc
import xbmcgui

from . import diag, net, pairing, qr, transfer
from .i18n import T
from .provider import find, ProviderError


def can_open_locally():
    """
    Whether this device can be asked to open a link in its own browser.

    Android only, and deliberately NOT narrowed to phones: Kodi exposes no infobool for a touchscreen
    (checked against the shipped settings definitions and the platform list, not assumed), so there is no
    honest way to tell a phone from a TV box here. A box with no browser simply ignores the intent, which
    is why the offer is phrased as an offer and costs nothing when it cannot be taken up.
    """
    return xbmc.getCondVisibility("System.Platform.Android")


#: The old private name, kept because three call sites and a test use it.
_can_open_locally = can_open_locally


def open_locally(url):
    """
    Hand [url] to this device's own browser.

    The reason this exists: Kodi's on-screen keyboard on Android CANNOT paste. There is no system-keyboard
    toggle on the platform at all — tvOS has `input.tvosusekodikeyboard`, Android has nothing equivalent,
    which was verified against Kodi 21.2's own settings definitions rather than assumed. So on a phone, a
    36-character device id has to be entered character by character with no clipboard. The pairing form is
    already an ordinary web page served on this device; opening it here turns that into a normal browser
    field where Android's own paste works.
    """
    if not url:
        return
    diag.log("Opening the pairing form in the local browser")
    # The quoting matters: the URL carries `?token=…`, and the builtin's arguments are comma-separated,
    # so an unquoted URL containing a comma would be split into two arguments.
    xbmc.executebuiltin('StartAndroidActivity("","android.intent.action.VIEW","","%s")' % url)


#: Everything that means "I want out of here". 10 = previous menu (the remote's Back), 92 = navigation
#: back (Android's own back button and back gesture arrive as this), 13 = stop.
_LEAVE = (10, 92, 13)


class PairWindow(xbmcgui.WindowDialog):
    """
    The QR screen.

    Built control by control rather than from a skin XML file: a WindowXMLDialog needs its own skin
    folder and a texture for every solid rectangle, and everything here is one image plus four lines of
    text. `colorDiffuse` tints one white square into the whole panel (see qr.write_flat_png).

    Shown with `show()`, not `doModal()`, on purpose — the pairing server is a background thread and
    this screen has a countdown, so the caller has to stay in control of the loop. A modal window would
    hand the loop to Kodi and only give it back when the user pressed Back, and the form the phone
    submits has to be applied on the caller's thread (see PairingServer.pump).

    IT HAS BUTTONS NOW, and that is the whole point of this revision. It was built for a remote
    control: nothing on it could take focus, and the only way out was a Back keypress that this window
    happened to recognise. On a phone that is a trap — reported exactly that way: "when the QR is up I
    cannot get out, Back throws me out of the app and tapping anywhere does nothing". A screen whose
    only exit is a hardware key is a screen with no exit on a device that has no hardware keys, so
    there is now a real, focused, finger-sized button that says so, and on Android a second one that
    opens the same address in this device's own browser.

    Back is still handled, because on a remote it is the natural thing to press.
    """

    def build(self, panel_png, qr_png, url, title, instruction, hint, open_url=None):
        width, height = self.getWidth(), self.getHeight()
        self.cancelled = False
        # What the "open here" button hands to the browser, which is not always what is PRINTED under
        # the code. The export screen shows "iptvbox://import" as a caption while the QR carries the
        # whole account token, and firing an intent for the caption would open the phone's app on an
        # empty import. Pass "" there and the button is not drawn at all.
        self.link = url if open_url is None else open_url
        self.open_button = None
        # The QR is sized from the SHORT side — the coordinate space is 16:9, and sizing a square from
        # the width makes it taller than the screen. It gives up a little height to the button row,
        # which is worth more than the pixels: a code that is 6% smaller still scans.
        qr_size = int(height * 0.46)
        left = (width - qr_size) // 2
        top = int(height * 0.15)

        self.addControl(xbmcgui.ControlImage(0, 0, width, height, panel_png, colorDiffuse="EE0D1526"))
        self._label(int(width * 0.1), int(height * 0.04), int(width * 0.8), title, "font13", "FF2FD4A6")
        self._label(int(width * 0.1), int(height * 0.10), int(width * 0.8), instruction, "font12",
                    "FFE8EDF2")
        # A white margin under the QR as well as inside it: the code is printed on white and the panel
        # behind is dark, and a phone reading a QR whose quiet zone ends in dark pixels is a phone that
        # sits there focusing.
        self.addControl(xbmcgui.ControlImage(left - 12, top - 12, qr_size + 24, qr_size + 24,
                                             panel_png, colorDiffuse="FFFFFFFF"))
        self.addControl(xbmcgui.ControlImage(left, top, qr_size, qr_size, qr_png))
        self._label(int(width * 0.05), top + qr_size + 20, int(width * 0.9), url, "font12", "FF8A97A8")
        self.countdown = self._label(int(width * 0.05), top + qr_size + 52, int(width * 0.9), "",
                                     "font12", "FF8A97A8")
        self._label(int(width * 0.05), top + qr_size + 84, int(width * 0.9), hint, "font12", "FF8A97A8")

        # The button row. Sized generously on purpose: this is the control a thumb has to find on a
        # 6-inch screen, and Kodi's default button height is drawn for a sofa and a remote.
        button_h = max(50, int(height * 0.085))
        button_y = height - button_h - int(height * 0.03)
        close = self._button(int(width * 0.60), button_y, int(width * 0.28), button_h, T("Zatvori"))
        if can_open_locally() and self.link:
            self.open_button = self._button(int(width * 0.12), button_y, int(width * 0.28), button_h,
                                            T("Otvori ovde"))
            # Said explicitly, because Kodi does NOT infer it. Two buttons added to a script window
            # have no navigation between them at all until they are linked, which was measured on the
            # box: left and right both left the focus where it was, so the second button was drawn,
            # looked pressable, and no remote in the world could reach it.
            close.controlLeft(self.open_button)
            close.controlRight(self.open_button)
            self.open_button.controlLeft(close)
            self.open_button.controlRight(close)
        # Focus goes to the way OUT, not to the way on. A remote lands on the first control and presses
        # it, and the destructive reading of that press is "leave" — which is recoverable — rather than
        # "launch a browser over the screen you are reading".
        self.setFocus(close)

    def _label(self, x, y, w, text, font, colour):
        label = xbmcgui.ControlLabel(x, y, w, 34, text, font=font, textColor=colour,
                                     alignment=0x00000002 | 0x00000004)   # centre X, centre Y
        self.addControl(label)
        return label

    def _button(self, x, y, w, h, text):
        # No textures named: Kodi resolves a button's default focused/unfocused images through the
        # active skin, which is the only way a script window can look like the skin it is drawn over.
        button = xbmcgui.ControlButton(x, y, w, h, text,
                                       textColor="FFE8EDF2", focusedColor="FF0D1526",
                                       alignment=0x00000002 | 0x00000004)
        self.addControl(button)
        return button

    def tick(self, seconds):
        # Zero means "no clock on this screen" — the export QR is static and a 0:00 counting nothing
        # reads as expired.
        self.countdown.setLabel("" if seconds <= 0 else "%d:%02d" % (seconds // 60, seconds % 60))

    def onControl(self, control):
        """A button was pressed — by a finger, a mouse or the remote's OK; Kodi does not distinguish."""
        if self.open_button is not None and control.getId() == self.open_button.getId():
            open_locally(self.link)
        else:
            self.cancelled = True

    def onAction(self, action):
        # Anything else is ignored on purpose: swallowing the rest keeps a stray remote press from
        # dismissing a session the user is halfway through typing on the phone. The buttons above are
        # what a deliberate press lands on.
        if action.getId() in _LEAVE:
            self.cancelled = True


def ask_where(settings, title):
    """
    "Are you typing this on this very device, or on another one?" — asked only where it can be true.

    A QR code exists to move a link to a SECOND screen. When Kodi is running on the phone the user is
    holding, that second screen is the same screen, and the QR turns a one-tap job into: photograph the
    television, read a token off the photograph, open the browser, type it. That is what was reported,
    word for word. So on Android the two routes are offered as a plain question, and the answer decides
    whether a QR is drawn at all.

    Returns True for "here", False for "another device", None if the question was dismissed.
    """
    if not can_open_locally():
        return False
    chosen = xbmcgui.Dialog().select(title, [T("Ovde, na ovom uređaju (otvara pregledač)"),
                                             T("Na drugom telefonu (QR kod)")])
    if chosen < 0:
        return None
    return chosen == 0


def _wait_here(server, url, title):
    """
    The same-device half: the form is opened in this device's own browser, and this is what holds the
    session open while it is being filled in.

    A progress dialog rather than the QR window, and that is the point rather than a shortcut. It is one
    of Kodi's own dialogs, so it is modal, it has a Cancel button drawn by the skin at the size the skin
    draws buttons, and Back closes it — none of which was reliably true of a hand-built modeless window
    on a touchscreen. It also leaves this thread in charge, which `PairingServer.pump` requires: the form
    is applied by whoever owns the addon's context, never by the socket thread that received it.

    The honest caveat, said here because it is the one way this route fails: while the browser is in
    front, Kodi is a background app, and Android may freeze a background app. If it does, the page
    simply stops loading — visibly, at the browser — and the QR route on a second device still works.
    """
    open_locally(url)
    progress = xbmcgui.DialogProgress()
    progress.create(title, T("Forma je otvorena u pregledacu ovog uredjaja. Popuni je i posalji, pa "
                             "se vrati u Kodi."))
    monitor = xbmc.Monitor()
    total = max(1, server.seconds_left())
    try:
        while True:
            server.pump()
            state, _detail = server.state()
            left = server.seconds_left()
            if state != pairing.WAITING or left <= 0 or progress.iscanceled():
                break
            progress.update(max(0, 100 - int(left * 100 / total)),
                            T("Preostalo: %d:%02d") % (left // 60, left % 60))
            if monitor.waitForAbort(0.25):
                break
    finally:
        progress.close()
    return True


def session(settings, server, title, instruction, hint, here=False):
    """
    Start [server], show its URL, and hold the screen until it finishes or the user leaves.

    Shared by pairing and by sending the log, because they are the same thing seen twice: something on
    the TV that a phone has to reach, over a link that must not outlive the session. [here] swaps the
    QR for the browser on this device — see ask_where.
    """
    # The settings dialog is closed before anything else, and not merely because it is in the way. Kodi
    # keeps its own copy of every value in there and writes that copy back when it closes, so an account
    # written while it is open is thrown away a few seconds later. The button inside settings already
    # asks Kodi to close (<close>true</close>); this covers every other way in, and gives the dialog a
    # moment to finish saving before we write anything.
    xbmc.executebuiltin("Dialog.Close(addonsettings, true)")
    xbmc.sleep(700)

    try:
        url = server.start()
    except pairing.PairingError as err:
        xbmcgui.Dialog().ok(title, str(err))
        return False
    except (OSError, IOError) as err:
        xbmcgui.Dialog().ok(title, T("Port ne moze da se otvori: %s") % err)
        return False

    # Nothing to draw when the browser on this very device is doing the reading: no QR, no window, no
    # countdown to photograph. See _wait_here.
    if here:
        try:
            _wait_here(server, url, title)
        finally:
            server.stop()
        return True

    profile = settings.profile_dir()
    # A NEW file name every session, and the old ones removed. Kodi caches textures by path, so reusing
    # one name would show the previous session's QR — a code that scans perfectly and carries a token
    # that has already expired.
    for stale in os.listdir(profile):
        if stale.startswith("pair-") and stale.endswith(".png"):
            try:
                os.remove(os.path.join(profile, stale))
            except OSError:
                pass
    qr_png = os.path.join(profile, "pair-%s.png" % server.token[:8])
    panel_png = os.path.join(profile, "panel.png")
    qr.write_png(qr_png, url, module_pixels=8)
    qr.write_flat_png(panel_png)

    window = PairWindow()
    window.build(panel_png, qr_png, url, title, instruction, hint)
    window.show()
    monitor = xbmc.Monitor()
    try:
        while True:
            # Anything submitted is applied HERE, on the plugin's own thread, not on the socket thread
            # that received it — see PairingServer.pump. The phone is holding its connection open
            # waiting for this, so it runs every quarter second rather than once a second.
            server.pump()
            state, _detail = server.state()
            if state != pairing.WAITING or window.cancelled or server.seconds_left() <= 0:
                break
            window.tick(server.seconds_left())
            if monitor.waitForAbort(0.25):
                break
    finally:
        window.close()
        server.stop()
        try:
            os.remove(qr_png)
        except OSError:
            pass
    return True


def show_static(settings, url, title, instruction, hint, module_pixels=8, name="link"):
    """
    A QR that just sits there until the user leaves — no server behind it, no countdown.

    Separate from [session] because the two differ in the one thing that matters: a pairing code is a
    one-time secret that must expire, and this is a link anyone may keep. A countdown on a permanent
    link reads as "hurry", and a link that outlives its window reads as broken.
    """
    profile = settings.profile_dir()
    qr_png = os.path.join(profile, "qr-%s.png" % name)
    panel_png = os.path.join(profile, "panel.png")
    try:
        qr.write_png(qr_png, url, module_pixels=module_pixels)
    except ValueError as err:
        xbmcgui.Dialog().ok(title, T("Kod ne moze da se napravi: %s") % err)
        return
    qr.write_flat_png(panel_png)

    window = PairWindow()
    window.build(panel_png, qr_png, url, title, instruction, hint)
    window.show()
    monitor = xbmc.Monitor()
    try:
        while not window.cancelled:
            window.tick(0)
            if monitor.waitForAbort(0.25):
                break
    finally:
        window.close()
        try:
            os.remove(qr_png)
        except OSError:
            pass


def send_log(settings):
    """
    Put the log on a phone.

    The alternative, and what actually happened, is photographing seventeen pages of a log off a TV
    screen. The same server and the same QR as pairing; the phone gets the newest lines first and a
    download link, so the file can be forwarded from there to anywhere.
    """
    title = T("IPTV Balkan — posalji log")
    here = ask_where(settings, title)
    if here is None:
        return
    server = pairing.PairingServer(settings, mode="log")
    session(settings, server, title,
            T("Skeniraj telefonom. Log se otvara u pregledacu, sa dugmetom da se sacuva kao "
              "fajl."),
            T("Back kad zavrsis. Link vazi 5 minuta i gasi se sa ovim ekranom."),
            here=here)


def pair_with_phone(settings, here=None):
    """
    Configure an account from a phone — either another one, or the one Kodi is running on.

    This exists because of one specific thing that is genuinely painful and completely avoidable: an
    EON or Iris account means a username, a password and sometimes a 36-character device id, typed on a
    TV remote through an on-screen keyboard — and Kodi on Android has no system keyboard at all, so
    there is no clipboard and no paste anywhere inside it.

    [here] is the answer to "which device is doing the typing": True opens the form in this device's own
    browser, False draws the QR, None asks (and is what the menu passes).
    """
    title = T("IPTV Balkan — sparivanje telefonom")
    if here is None:
        here = ask_where(settings, title)
        if here is None:
            return False
    server = pairing.PairingServer(settings)
    if not session(settings, server, title,
                   T("Skeniraj kod telefonom koji je na istoj mrezi i unesi nalog tamo."),
                   T("Back za odustajanje. Link vazi 5 minuta."), here=here):
        return False

    state, detail = server.state()
    if state != pairing.DONE:
        return False

    # Checked a second time, now that this screen is gone. The values were verified at the moment they
    # were written; this catches anything that overwrote them in between — which on this box means the
    # settings dialog. Saying "added" and being wrong is the failure this whole path exists to end.
    diag.log("Pairing: %s" % pairing.on_disk(settings, server.written))
    lost = pairing.verify(settings, server.written)
    if lost:
        diag.log("Pairing: the account was written and then overwritten (%s)" % ", ".join(lost), "ERROR")
        xbmcgui.Dialog().ok(T("IPTV Balkan — sparivanje"),
                            T("Nalog je stigao sa telefona, ali ga je nesto na TV-u prebrisalo "
                              "(%s).\n\nZatvori ekran podesavanja dodatka i pokusaj ponovo — dok je "
                              "otvoren, on prepisuje sve sto se upise iza njega.") % ", ".join(lost))
        return False

    xbmcgui.Dialog().notification("IPTV Balkan", T("Dodato: %s") % detail,
                                  xbmcgui.NOTIFICATION_INFO, 5000)
    # Whether to rebuild is the CALLER's to decide and to run: a full refresh is minutes of work on a
    # big line-up, it belongs with the catalogue rather than with a screen, and the user may be about
    # to pair a second account.
    return True


def link_yettel(settings):
    """
    The one-time Yettel pairing: a code on the TV, the login on a phone, nothing typed on a remote.

    Yettel refuses a password grant outright, so this — OAuth's device flow — is not one option among
    several, it is the only way in. It also has a property worth keeping: the password and the SMS are
    handled entirely on Yettel's own page on the user's phone, and this addon never sees either.

    The QR window is reused as-is. What it holds is the verification address; the six-character code goes
    underneath it, because that is the part the user has to type over there.
    """
    from resources.lib.providers import yettel

    session = net.Session({"user_agent": yettel.YettelProvider.default_identity["user_agent"]},
                          timeout=20, trace=settings.verbose())
    try:
        pairing_info = yettel.start_pairing(session)
    except (ProviderError, net.HttpError) as err:
        xbmcgui.Dialog().ok(T("IPTV Balkan — Yettel"), T("Povezivanje nije moglo da počne: %s") % err)
        return False

    profile = settings.profile_dir()
    qr_png = os.path.join(profile, "pair-yettel.png")
    panel_png = os.path.join(profile, "panel.png")
    qr.write_png(qr_png, pairing_info["verification_uri"], module_pixels=8)
    qr.write_flat_png(panel_png)

    window = PairWindow()
    window.build(panel_png, qr_png, pairing_info["verification_uri"],
                 T("IPTV Balkan — poveži Yettel nalog"),
                 T("Skeniraj kod telefonom, prijavi se na Yettel i unesi ovaj kod:  [B]%s[/B]")
                 % pairing_info["user_code"],
                 T("Ovo se radi jednom. Back za odustajanje."))
    window.show()

    monitor = xbmc.Monitor()
    deadline = time.time() + pairing_info["expires_in"]
    token, failure = "", ""
    try:
        while time.time() < deadline and not window.cancelled:
            window.tick(int(deadline - time.time()))
            # The interval is the SERVER's, not ours. Polling faster than it asked for is what earns a
            # `slow_down`, and then a refusal.
            if monitor.waitForAbort(pairing_info["interval"]):
                break
            try:
                token = yettel.poll_pairing(session, pairing_info["device_code"])
            except ProviderError as err:
                failure = str(err)
                break
            if token:
                break
    finally:
        window.close()
        try:
            os.remove(qr_png)
        except OSError:
            pass

    if failure:
        xbmcgui.Dialog().ok(T("IPTV Balkan — Yettel"), failure)
        return False
    if not token:
        return False

    try:
        yettel.complete_pairing(settings, session, token)
    except (ProviderError, net.HttpError) as err:
        xbmcgui.Dialog().ok(T("IPTV Balkan — Yettel"),
                            T("Prijava je prošla, ali povezivanje nije dovršeno: %s") % err)
        return False
    xbmcgui.Dialog().notification("IPTV Balkan", T("Yettel nalog je povezan"),
                                  xbmcgui.NOTIFICATION_INFO, 5000)
    return True
