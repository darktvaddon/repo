# -*- coding: utf-8 -*-
"""
The credential vault: what makes the licence functional instead of decorative.

Everything else in the licence path is an `if`. Someone who can read Python deletes it and the addon
works exactly as before, because nothing the user values ever depended on the server. This closes that:
the stored provider PASSWORDS are encrypted, and the key only ever arrives inside a licence answer that
verified. A cracked copy with every check removed still cannot log in to EON, Iris or Yettel, because it
is holding ciphertext and the key is not in it.

## What is encrypted, and what deliberately is not

Only secrets — passwords and app-token secrets. NOT usernames, hosts or device ids. Two reasons, both
practical: the settings screen shows those fields, and a user who opens it to check their username must
not be shown a blob; and a username is not what stops a login. Without the password nothing connects,
which is the whole requirement.

## The key

Derived on the SERVER from the device id, so it is the same value on every answer and there is nothing
to rotate or to lose. It is sent only while the device is in trial or licensed — an expired or blocked
device gets an answer with no key at all, and there is no branch in this file that could be flipped to
produce one, because the key is not computed here.

## Grace: 30 days offline, and what it is NOT

The key is cached with the verdict and stays usable for [GRACE_SECONDS] after the last successful check.
That window exists for one reason and it is not the attacker: an outage on my side must not stop a
paying customer from watching television. The owner set it to thirty days.

It does not delay a BLOCK. A device that reaches the server and is blocked, expired or unlicensed gets
an answer carrying no key at all, and that clears the cached one on the spot — so revoking a box bites
at its next check, within fifteen minutes. The window only ever covers "the server could not be
reached", which is why a box kept deliberately offline is the case it costs: thirty days of the last
key. That is the trade, stated rather than hidden.

## ACTIVATION: a password is never kept in the clear

Until 1.28.0 an unencrypted password simply passed through, so the vault protected a COPIED PROFILE and
nothing else — anyone who cracked the gate and typed in their own credentials was untouched by it. Now
a secret that is not encrypted is not usable either: with a key it is encrypted on the spot, and without
one the provider refuses to log in and says the device is not activated.

The thing that makes this nearly free: **a provider login needs the internet anyway.** A box that has
never once reached this licence server is a box that could not have reached EON either, so nothing that
would otherwise work is being refused. What it costs is the narrow case of our server being down while
the provider is up — and that is exactly what the thirty-day window is for.

## The honest limit

An attacker running this addon on their own box, with their own valid trial, can read the key out of
memory. That is unavoidable and it is not what this defends against. What it defends against is a
CRACKED COPY handed to someone else — and now also a cracked BUILD, which has to strip this file as
well and have every customer type their credentials in again, rather than a folder that arrives ready
to use.
"""

import base64
import hashlib
import hmac
import os
import time

from . import aes, diag

#: How long a cached key outlives the last successful licence check. The owner's number.
#:
#: READ ON ITS OWN, THIS NUMBER SAYS SOMETHING IT DOES NOT MEAN. It is not "a blocked device keeps
#: working for thirty days" — a security review reached exactly that conclusion from this line. The key
#: is not held under a licence; it is SENT with each answer, and an answer for a blocked device carries
#: none, which clears the cache on the spot (licence._verdict_fields). This window covers one case only:
#: an answer that never arrived. Held in place by test-licence.test_revocation_is_immediate, which
#: fails if a future edit "keeps the last good key" when the new answer has none.
GRACE_SECONDS = 30 * 86400

#: Marks a stored value as encrypted. Versioned so a future format change can be told apart from a
#: password that happens to start with the same letters.
PREFIX = "enc1:"

#: Settings whose value is a secret. Matched by SUFFIX so a new provider's `_password` is covered the
#: day it is added rather than the day someone remembers this list.
SECRET_SUFFIXES = ("_password", "_app_token_secret")


class Locked(Exception):
    """Raised when a secret is stored encrypted and no key is available to read it."""


# ---- AES-CTR ---------------------------------------------------------------
#
# CTR rather than CBC: it needs only the FORWARD cipher, which aes.py already has and which is already
# verified against the FIPS-197 vectors. CBC would mean writing the inverse cipher — InvSubBytes,
# InvShiftRows, InvMixColumns — for no benefit here, and an untested inverse is exactly the kind of code
# that silently corrupts one block in a thousand.

def _keystream_block(key, nonce, counter):
    block = nonce + counter.to_bytes(8, "big")
    return bytes(aes.encrypt_block(key, block))


def _xor_ctr(key, nonce, data):
    """CTR is its own inverse, so this is both directions."""
    out = bytearray(len(data))
    for offset in range(0, len(data), 16):
        stream = _keystream_block(key, nonce, offset // 16)
        chunk = data[offset:offset + 16]
        for index, byte in enumerate(chunk):
            out[offset + index] = byte ^ stream[index]
    return bytes(out)


def encrypt(key, plaintext):
    """`enc1:` + base64(nonce || ciphertext || mac). Encrypt-then-MAC, so a tampered blob is rejected
    before a single byte of it is decrypted."""
    if not key:
        raise Locked("no key")
    nonce = os.urandom(8)
    data = plaintext.encode("utf-8")
    cipher = _xor_ctr(key, nonce, data)
    mac = hmac.new(key, nonce + cipher, hashlib.sha256).digest()
    return PREFIX + base64.b64encode(nonce + cipher + mac).decode("ascii")


def decrypt(key, blob):
    if not blob.startswith(PREFIX):
        return blob
    if not key:
        raise Locked("no key")
    try:
        raw = base64.b64decode(blob[len(PREFIX):])
    except (ValueError, TypeError):
        raise Locked("stored value is not readable")
    if len(raw) < 8 + 32:
        raise Locked("stored value is too short to be valid")
    nonce, cipher, mac = raw[:8], raw[8:-32], raw[-32:]
    expected = hmac.new(key, nonce + cipher, hashlib.sha256).digest()
    # compare_digest, not ==: a plain comparison leaks where the first difference is, and there is no
    # reason to hand that away for free.
    if not hmac.compare_digest(mac, expected):
        raise Locked("stored value does not match this key")
    return _xor_ctr(key, nonce, cipher).decode("utf-8", "replace")


def is_secret(name):
    return any(name.endswith(suffix) for suffix in SECRET_SUFFIXES)


def is_encrypted(value):
    return isinstance(value, str) and value.startswith(PREFIX)


# ---- the key, and its grace -------------------------------------------------

def key_for(settings):
    """
    The vault key for this box, or None.

    Read from the licence cache rather than fetched: the licence check owns the conversation with the
    server, and a second caller asking on its own would double the traffic and could hand out a key the
    verdict had already withdrawn.
    """
    from . import licence

    state = licence.cached_state(settings)
    encoded = state.get("vault_key") or ""
    if not encoded:
        return None
    last_good = int(state.get("last_good") or 0)
    if last_good <= 0:
        return None
    age = int(time.time()) - last_good
    if age > GRACE_SECONDS:
        diag.log("Vault: the cached key is %d hours old — past the %d hour grace" %
                 (age // 3600, GRACE_SECONDS // 3600), "ERROR")
        return None
    try:
        key = base64.b64decode(encoded)
    except (ValueError, TypeError):
        return None
    return key if len(key) in (16, 24, 32) else None


def read(settings, value):
    """A stored value, decrypted when it needs to be. Plain values pass through untouched."""
    if not is_encrypted(value):
        return value
    key = key_for(settings)
    if not key:
        raise Locked(_why_locked(settings))
    return decrypt(key, value)


def _activation_applies():
    """Whether a plaintext secret is refused — true on a box, false in the off-Kodi harness.

    Its own function rather than the check written inline, so a test can say which of the two it is
    exercising without having to fake half of Kodi to do it: flipping `settings._IN_KODI` would also
    send every `get` and `set` down the xbmcaddon path that does not exist there.
    """
    from . import settings as _settings
    return bool(_settings._IN_KODI)


def secure(settings, name, value, store):
    """
    A secret on its way OUT of settings, made safe to use — or refused.

    This is activation. [value] is whatever is stored under [name]; [store] writes a replacement back
    (the provider's own writer, so an extra account lands in accounts.json rather than in the global
    settings). Three cases and each has one right answer:

      * already encrypted — decrypt it, exactly as before;
      * plaintext and a key exists — encrypt it NOW and keep going. A password typed while the box was
        between checks is not a reason to fail, and leaving it in the clear is how the old behaviour
        quietly let every cracked build off the hook;
      * plaintext and no key — refuse. The device has never been activated, or has been offline past
        the window, and letting the login through would mean the vault only ever protected people who
        did not know to type their own password in.

    Returns the usable value. Raises [Locked] when it cannot be made safe.
    """
    if is_encrypted(value):
        key = key_for(settings)
        if not key:
            raise Locked(_why_locked(settings))
        return decrypt(key, value)
    if not value or not is_secret(name):
        return value
    # OUTSIDE KODI, activation does not apply — and that is not a hole anybody can stand in.
    #
    # `selftest.py` and the test suite drive the real providers from a plain Python harness against
    # `test-accounts.json`, with no Kodi, no licence state and therefore no key. Refusing those would
    # mean the one tool that proves a provider still works could no longer log in.
    #
    # What it does NOT open: the shipped addon only ever runs inside Kodi, and getting out of that means
    # not running the addon at all — no player, no PVR, no Video klub, i.e. writing a client from
    # scratch, which is precisely the work none of this pretends to stop.
    if not _activation_applies():
        return value
    key = key_for(settings)
    if not key:
        raise Locked(_why_locked(settings))
    blob = encrypt(key, value)
    if store(name, blob):
        diag.log("Vault: %s was stored in the clear and has just been encrypted" % name)
    else:
        # Not fatal: the value is usable, it simply stays in the clear until a write succeeds. Said out
        # loud because the usual cause is Kodi's settings dialog being open over the top of it.
        diag.log("Vault: %s could not be encrypted (the write did not stick) — it stays in the clear "
                 "for now" % name, "ERROR")
    return value


def _why_locked(settings):
    """
    WHY there is no key, in words the person in front of the television can act on.

    This text ends up inside a ProviderError, i.e. on the refresh screen and in every "it stopped
    working" message. It used to read `podaci za prijavu su zakljucani (no key)` — an English internal
    reason inside a Serbian sentence, naming nothing anybody can do.

    The distinction that matters is the one the box cannot explain by itself: the licence gives seven
    days of grace when the server cannot be reached, but the credential key is cached for only
    [GRACE_SECONDS]. So a box that has been ON and OFF the internet for more than a day keeps its
    licence and loses its logins — which looks exactly like a wrong password, and sends the customer to
    retype something that was never wrong.
    """
    from . import licence                       # local, like key_for — licence imports settings, not us
    state = licence.cached_state(settings)
    last_good = int(state.get("last_good") or 0)
    if not state.get("vault_key") and last_good <= 0:
        return "uređaj još nije aktiviran"
    age = int(time.time()) - last_good if last_good > 0 else 0
    if age > GRACE_SECONDS:
        return ("uređaj nije bio na internetu već %d dana, a aktivacija važi %d dana"
                % (age // 86400, GRACE_SECONDS // 86400))
    return "licenca trenutno nije potvrđena"


def protect(settings, values):
    """
    Encrypt any plaintext secret in [values] (a name -> value mapping), returning what changed.

    Called after a successful licence check. Nothing is encrypted until a key exists, so a box that has
    never reached the server keeps working exactly as it did — and nothing is ever encrypted twice.
    """
    key = key_for(settings)
    if not key:
        return {}
    changed = {}
    for name, value in values.items():
        if not value or not is_secret(name) or is_encrypted(value):
            continue
        try:
            changed[name] = encrypt(key, value)
        except Locked:
            continue
    return changed


def persist(settings, values):
    """
    Write [values] (setting id -> already-encrypted value) into settings.xml ourselves.

    Because Kodi will not. Measured on the box: `Addon().setSetting` from the resident service updates
    Kodi's IN-MEMORY copy and nothing else — settings.xml was still showing the plaintext passwords
    three minutes and several successful writes later, its own timestamp hours old. A service addon is
    unloaded only when Kodi shuts down, and a TV box is switched off rather than shut down, so in
    practice that save never happens: the secrets stayed in the clear on disk for ever while the log
    reported them encrypted at every start.

    Safe to do precisely because the caller has already set the same value through Kodi: memory and file
    now agree, so whenever Kodi does save it writes back what is already here.

    Written atomically, behind a backup that lives only for the duration of the write. The backup is
    there because this file holds every account on the box and a half-written one is worse than a
    plaintext one — and it is DELETED the moment the new file parses, because a backup of settings.xml
    is a copy of exactly the plaintext passwords this function exists to remove.
    """
    import os
    import shutil
    import xml.etree.ElementTree as ET

    path = os.path.join(settings.profile_dir(), "settings.xml")
    if not values or not os.path.isfile(path):
        return False
    try:
        backup = path + ".vault-tmp"
        shutil.copyfile(path, backup)
        tree = ET.parse(path)
        root = tree.getroot()
        touched = 0
        for node in root.findall("setting"):
            name = node.get("id")
            if name in values:
                node.text = values[name]
                # Kodi marks untouched settings `default="true"`; leaving that on a value we just wrote
                # invites it to discard ours and fall back.
                if node.get("default"):
                    del node.attrib["default"]
                touched += 1
        if not touched:
            return False
        tmp = path + ".tmp"
        tree.write(tmp, encoding="utf-8", xml_declaration=True)
        os.replace(tmp, path)
        # Prove it before letting go of the copy: a file that replaced fine but does not parse would
        # take every account with it, and the backup is the only way back.
        ET.parse(path)
        _remove(backup)
        diag.log("Vault: %d secret(s) written to settings.xml (Kodi does not flush its own)" % touched)
        return True
    except Exception as err:                                       # noqa: BLE001
        # Put the original back if a copy of it survived, then say so. Losing every configured account
        # to a failed optimisation would be a far worse bug than the one being fixed.
        try:
            if os.path.exists(path + ".vault-tmp"):
                shutil.copyfile(path + ".vault-tmp", path)
                _remove(path + ".vault-tmp")
            # And the half-finished new file, if the write got that far: it is not plaintext, but a
            # settings.xml.tmp left lying beside the real one is the sort of thing that gets found later
            # and wondered about.
            _remove(path + ".tmp")
        except OSError:
            pass
        diag.log("Vault: could not write settings.xml (%s: %s) — the value stays as Kodi has it"
                 % (type(err).__name__, err), "ERROR")
        return False


def _remove(path):
    import os
    try:
        os.remove(path)
    except OSError:
        pass
