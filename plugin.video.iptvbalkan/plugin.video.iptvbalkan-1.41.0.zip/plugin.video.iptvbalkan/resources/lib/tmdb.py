# -*- coding: utf-8 -*-
"""
TMDB metadata for the Video klub: posters, backdrops, ratings, year, genres, cast.

The providers already give a poster and a Serbian plot for their own catalogue, so this is not about
filling a blank screen — it is about the things none of them return: a BACKDROP (which is what makes a
Kodi skin look like a film library rather than a list), a rating, a year, and a cast. That is the part
of "premium" a plugin can deliver without writing a skin.

## Three rules this file will not break

**The provider's title is never replaced.** Matching a title to TMDB is approximate, and TMDB answers
`sr-RS` in CYRILLIC ("Тома", "Ко то тамо пева") while every provider catalogue here is Latin. A wrong or
differently-scripted title is worse than no metadata at all, so only the plot, artwork, rating, year,
genres and cast are ever taken.

**Nothing blocks a screen.** A Kodi directory is built in one call and handed over — there is no
"enrich what is visible" callback the way a phone list has. Fetching for a hundred titles inline would
freeze the browse for half a minute, so the browse path reads the CACHE ONLY, and misses are queued for
the resident service to fill. First visit to a category is plain, the next one is complete.

**No key is compiled in.** One was, for a while, and a key in readable Python on a customer's
television is a key anyone can lift. Since 1.31.0 the metadata comes from our own server, which holds
one key that the panel can change in a second and which reaches every box at its next licence check —
see [proxy]. The `tmdb_api_key` setting is still there for somebody who would rather use their own, and
it wins. With neither, the Video klub shows the provider's own titles and pictures and nothing here
runs at all: TMDB is an improvement to this addon, never a dependency of it.

That is also the licensing answer. TMDB's terms (section 2.A) reserve commercial use — charging users
is named explicitly — for a separate written agreement, and this addon is sold; one arrangement for one
server is a thing that can be made, a key in every install is not.
"""

import json
import os
import re
import sqlite3
import time

from . import diag, net, translate
from .store import write_json

BASE = "https://api.themoviedb.org/3/"
IMAGE_BASE = "https://image.tmdb.org/t/p/"
POSTER_SIZE = "w500"
BACKDROP_SIZE = "w1280"

#: Bumped when the stored shape changes, so an old row is refetched instead of read wrongly.
# 3: added `imdb`. A bump is what re-fetches rows already cached — without it every title looked
#    up before this change would keep answering with no id, and the subtitle search would keep
#    falling back to title text on exactly the library that is already populated.
SCHEMA = 3
CACHE_DB = "tmdb.db"
#: Titles waiting for the background filler.
QUEUE_FILE = "tmdb_queue.json"
#: A miss is remembered too — otherwise a title TMDB simply does not have is looked up forever.
MISS_TTL = 30 * 86400
HIT_TTL = 180 * 86400

#: Junk that provider catalogues put in titles. Stripped before searching, because "Toma (2021) HD" and
#: "Toma" are not the same query to TMDB and only one of them finds the film.
_NOISE = re.compile(
    r"\b(4k|uhd|fhd|hd|sd|hevc|x264|x265|1080p?|720p?|480p?|web-?dl|bluray|brrip|dvdrip|"
    r"multi|dub(bed)?|sub(bed|s)?|lat|cyr|ex-?yu|srb?|hrv|bos|mne|mkd)\b", re.I)
_YEAR = re.compile(r"\b(19\d{2}|20\d{2})\b")
_BRACKETS = re.compile(r"[\[(][^\])]*[\])]")


def normalize(title):
    """A provider title reduced to something worth searching for."""
    text = _BRACKETS.sub(" ", title or "")
    text = _NOISE.sub(" ", text)
    text = re.sub(r"[._]+", " ", text)
    text = re.sub(r"\s*[-–]\s*(S\d+\s*E\d+|E\d+).*$", "", text, flags=re.I)
    return re.sub(r"\s{2,}", " ", text).strip(" -–:")


def year_of(title):
    found = _YEAR.findall(title or "")
    return int(found[-1]) if found else None


def queries(title):
    """
    What to ask TMDB, best guess first.

    A provider title is not a title: it is a title with whatever the panel had nowhere else to put.
    Measured on a real Xtream list of 4,001 films, the shapes and how many rows carry them:

        97 Minutes (2023) (2023)              2,268   the year, twice, in brackets
        100M CRIMINAL CONVICTION  2021 (2021)   410   the year twice, once bare
        AFTERLIFE OF THE PARTY  2021  MP4       249   a trailing column (format, genre)
        02  The Godfather Part 1 1972           240   the panel's own index in front

    Two rules do all of it, and neither is applied as a RULE — both readings are offered and the first
    that answers wins, because every rule here has a counter-example that is a real film:

      * **columns are separated by two or more spaces.** A single space is part of a title —
        `12 Angry Men`, `300`, `1917` — so only runs of two or more are treated as a separator. This
        works on the RAW title, because normalize() collapses whitespace and the evidence is gone
        after it.
      * **a year inside the text must be tried both ways.** `Balkan.Ekspres.1983.WEB-DL` normalises to
        `Balkan Ekspres 1983`, and searching for that while ALSO passing year=1983 finds nothing; but
        `Blade Runner 2049`, `1984` and `Space Odyssey 2001` are titles, not dates.

    The two are COMBINED, and that is what the first version missed: `AFTERLIFE OF THE PARTY  2021  MP4`
    needs the column gone AND the year gone in the same reading before TMDB has anything to match.
    """
    raw = title or ""
    # The same text with the panel's columns taken off — an index in front, a short token at the end.
    without_columns = re.sub(r"^\s*\d{1,4}\s{2,}", "", raw)
    without_columns = re.sub(r"\s{2,}\S{1,3}\s*$", "", without_columns)

    out = []
    for text in (without_columns, raw):
        base = normalize(text)
        if not base:
            continue
        trimmed = re.sub(r"\s{2,}", " ", _YEAR.sub("", base).strip(" -–:,."))
        readings = [base]
        if trimmed and trimmed != base and len(trimmed) >= 2:
            # Year-less first when the title ENDS with the year, because that is the release-name shape;
            # otherwise the full title is the better reading.
            last = base.split()[-1] if base.split() else ""
            readings = [trimmed, base] if _YEAR.search(last) else [base, trimmed]
        for reading in readings:
            if reading not in out:
                out.append(reading)
    return out


# ---- cache ------------------------------------------------------------------

def _db(settings):
    path = os.path.join(settings.profile_dir(), CACHE_DB)
    connection = sqlite3.connect(path, timeout=5)
    connection.execute(
        "CREATE TABLE IF NOT EXISTS meta ("
        " key TEXT PRIMARY KEY, schema INTEGER, fetched INTEGER, found INTEGER, payload TEXT)")
    # Manual corrections. Kept in their own table rather than as a flag on a cached row, because an
    # alias must SURVIVE a cache wipe and a schema bump: the whole point is that somebody typed it once
    # and should never have to type it again.
    connection.execute(
        "CREATE TABLE IF NOT EXISTS alias (key TEXT PRIMARY KEY, query TEXT, series INTEGER)")
    return connection


def alias_for(settings, title, is_series=False):
    """The corrected search text for [title], or None."""
    try:
        connection = _db(settings)
        row = connection.execute("SELECT query, series FROM alias WHERE key=?",
                                 (_cache_key(title, is_series),)).fetchone()
        connection.close()
    except sqlite3.Error:
        return None
    return (row[0], bool(row[1])) if row and row[0] else None


def set_alias(settings, title, query, is_series=False):
    """
    Remember that [title] should be searched for as [query], and drop whatever was cached for it.

    The cached row is deleted rather than overwritten so that the very next look-up goes to TMDB with
    the corrected text — otherwise the correction would sit there behind a wrong answer that is still
    within its six months.
    """
    try:
        connection = _db(settings)
        with connection:
            connection.execute("INSERT OR REPLACE INTO alias (key, query, series) VALUES (?,?,?)",
                               (_cache_key(title, is_series), query.strip(), 1 if is_series else 0))
            connection.execute("DELETE FROM meta WHERE key=?", (_cache_key(title, is_series),))
        connection.close()
        return True
    except sqlite3.Error as err:
        diag.log("TMDB: could not save the correction for %r (%s)" % (title, err), "ERROR")
        return False


def clear_alias(settings, title, is_series=False):
    try:
        connection = _db(settings)
        with connection:
            connection.execute("DELETE FROM alias WHERE key=?", (_cache_key(title, is_series),))
            connection.execute("DELETE FROM meta WHERE key=?", (_cache_key(title, is_series),))
        connection.close()
        return True
    except sqlite3.Error:
        return False


def _cache_key(title, is_series):
    return "%s|%s" % ("tv" if is_series else "movie", normalize(title).lower())


def cached(settings, title, is_series=False):
    """
    Metadata for [title], or None. Never touches the network — this is what the browse path calls.

    Returns {} for a title TMDB is known not to have, so the caller can tell "nothing here" from "not
    looked up yet" and only queue the second.
    """
    try:
        connection = _db(settings)
    except sqlite3.Error:
        return None
    try:
        row = connection.execute(
            "SELECT schema, fetched, found, payload FROM meta WHERE key=?",
            (_cache_key(title, is_series),)).fetchone()
    except sqlite3.Error:
        return None
    finally:
        connection.close()
    if not row:
        return None
    schema, fetched, found, payload = row
    if schema != SCHEMA:
        return None
    age = int(time.time()) - int(fetched or 0)
    if age > (HIT_TTL if found else MISS_TTL):
        return None
    if not found:
        return {}
    try:
        return json.loads(payload)
    except ValueError:
        return None


def cached_many(settings, wanted):
    """
    {(title, is_series): meta} for a whole screen, on ONE connection. Never touches the network.

    [cached] opens a connection, runs two CREATE TABLE IF NOT EXISTS and closes again for every single
    call, which was fine when a screen held a handful of rows. A Video klub page is 200, and measured
    that way it costs eight times what one connection costs. Same answers, same meanings — a missing
    key means "not looked up yet" and an empty dict means "TMDB has nothing".
    """
    out = {}
    if not wanted:
        return out
    try:
        connection = _db(settings)
    except sqlite3.Error:
        return out
    now = int(time.time())
    try:
        for title, is_series in wanted:
            try:
                row = connection.execute(
                    "SELECT schema, fetched, found, payload FROM meta WHERE key=?",
                    (_cache_key(title, is_series),)).fetchone()
            except sqlite3.Error:
                continue
            if not row:
                continue
            schema, fetched, found, payload = row
            if schema != SCHEMA or now - int(fetched or 0) > (HIT_TTL if found else MISS_TTL):
                continue
            if not found:
                out[(title, is_series)] = {}
                continue
            try:
                out[(title, is_series)] = json.loads(payload)
            except ValueError:
                pass
    finally:
        connection.close()
    return out


def store(settings, title, is_series, data):
    """Public so the manual-correction screen can write what it just fetched — otherwise the corrected
    result would be thrown away and refetched by the background filler."""
    _store(settings, title, is_series, data)


def _store(settings, title, is_series, data):
    try:
        connection = _db(settings)
        with connection:
            connection.execute(
                "INSERT OR REPLACE INTO meta (key, schema, fetched, found, payload) VALUES (?,?,?,?,?)",
                (_cache_key(title, is_series), SCHEMA, int(time.time()),
                 1 if data else 0, json.dumps(data or {}, ensure_ascii=False)))
        connection.close()
    except sqlite3.Error as err:
        diag.log("TMDB: could not cache %r (%s)" % (title, err))


# ---- the queue the service works through ------------------------------------

def enqueue(settings, titles):
    """Remember titles the browse path could not answer from cache."""
    if not titles:
        return
    path = os.path.join(settings.profile_dir(), QUEUE_FILE)
    try:
        with open(path, "r", encoding="utf-8") as handle:
            queue = json.loads(handle.read())
        if not isinstance(queue, list):
            queue = []
    except (OSError, IOError, ValueError):
        queue = []
    known = {(entry.get("title"), entry.get("series")) for entry in queue if isinstance(entry, dict)}
    for title, is_series in titles:
        if (title, is_series) not in known:
            queue.append({"title": title, "series": bool(is_series)})
    # Bounded. A user who opens six big categories would otherwise leave thousands of rows for a filler
    # that works through a handful per minute, and the newest request is the one they are looking at.
    queue = queue[-500:]
    write_json(path, queue)


def fill_some(settings, limit=8):
    """
    Look up a few queued titles. Called from the resident service, which is the only place in this
    addon that may spend seconds on something.

    Returns how many were resolved. Stops at the first sign the key is refused, rather than working
    through five hundred titles being told "no" each time.
    """
    key = api_key(settings)
    if not key:
        return 0
    path = os.path.join(settings.profile_dir(), QUEUE_FILE)
    try:
        with open(path, "r", encoding="utf-8") as handle:
            queue = json.loads(handle.read())
        if not isinstance(queue, list):
            return 0
    except (OSError, IOError, ValueError):
        return 0
    if not queue:
        return 0

    done = 0
    while queue and done < limit:
        entry = queue.pop(0)
        if not isinstance(entry, dict) or not entry.get("title"):
            continue
        try:
            data = lookup(settings, entry["title"], bool(entry.get("series")))
        except _Refused:
            diag.log("TMDB: the key was refused — nothing more will be requested this round", "ERROR")
            break
        except Exception as err:                                   # noqa: BLE001
            diag.log("TMDB: %r failed (%s: %s)" % (entry["title"], type(err).__name__, err))
            data = None
        _store(settings, entry["title"], bool(entry.get("series")), data)
        done += 1
    write_json(path, queue)
    return done


class _Refused(Exception):
    """The key itself was rejected — a different thing from one title not being found."""


# ---- the API ----------------------------------------------------------------

#: NO KEY IS SHIPPED ANY MORE, and this note is the whole reason why.
#:
#: One used to live here — the owner's own — so the Video klub worked out of the box. A Kodi addon is
#: readable Python on a customer's television, so that key was, in practice, published: anybody could
#: lift it, anybody's misuse could get it rate-limited or revoked, and replacing it meant shipping a
#: release that every box then had to install.
#:
#: Since 1.31.0 the metadata comes from our own server (`params.tmdb_proxy`, see [proxy]), which holds
#: ONE key that is changed in the panel in a second and reaches every box at its next check. A box that
#: has no proxy and no key of its own simply shows the provider's own titles and artwork — which is
#: what the Video klub looked like before TMDB was added at all, not an error.
#:
#: The other half of the reason is licensing: TMDB reserve COMMERCIAL use for a separate written
#: agreement (§2.A names charging users). Held on the server, that is one arrangement to make rather
#: than a key sitting in every install of a product that is sold.

#: Required by TMDB's terms whether or not money changes hands, so it is shown on the licence screen.
ATTRIBUTION = ("Podaci o filmovima i serijama: TMDB. Ovaj dodatak koristi TMDB i TMDB API, ali TMDB "
               "ga nije odobrio niti sertifikovao.")


def api_key(settings):
    """This box's OWN key, or "" — there is no fallback any more. See the note above."""
    return (settings.get("tmdb_api_key", "") or "").strip()


def proxy(settings):
    """
    Where the metadata comes from, when it is not this box asking TMDB directly.

    An address delivered inside a SIGNED licence answer (`params.tmdb_proxy`) switches every request
    below onto our own server, which holds the key and forwards the same call. Three reasons it exists,
    and the first is the one that matters:

      * the key shipped here is readable Python on a customer's box, so it is effectively published.
        Held server-side there is ONE key, it can be rotated in the panel, and a box does not have to
        update to follow it;
      * TMDB's terms reserve commercial use for a separate written agreement (§2.A names charging users)
        — whichever way that is settled, it is settled in one place rather than in every install;
      * a box that never reaches TMDB (a network that blocks it) still gets descriptions.

    Empty — which is every box until the panel says otherwise — means behave exactly as before. Only
    the JSON goes through the server: poster and fanart URLs still point at image.tmdb.org, so the
    pictures never touch it.
    """
    from . import licence
    return licence.param_url(settings, "tmdb_proxy")


def enabled(settings):
    return bool(proxy(settings) or api_key(settings))


def _get(settings, path, **params):
    params.setdefault("language", settings.get("tmdb_language", "sr-RS") or "sr-RS")
    try:
        from urllib.parse import urlencode
    except ImportError:                                            # pragma: no cover
        from urllib import urlencode
    where = proxy(settings)
    if where:
        # The same call, addressed to our server, with the PATH as a parameter and no key. The reply is
        # TMDB's own JSON passed through unchanged, which is why nothing below this function knows or
        # cares which of the two answered.
        params["path"] = path
        params["hw"] = _device(settings)
        url = "%s%s%s" % (where, "&" if "?" in where else "?", urlencode(params))
    else:
        params["api_key"] = api_key(settings)
        url = "%s%s?%s" % (BASE, path, urlencode(params))
    session = net.Session({"user_agent": "IPTVBalkan-Kodi"}, timeout=15, trace=False)
    try:
        return session.get(url)
    except net.HttpError as err:
        if err.status in (401, 403):
            raise _Refused(str(err))
        raise


def _device(settings):
    """This box's licence id, so the server can answer its own customers and nobody else. Never fatal:
    a device that cannot name itself simply gets refused, which is not worse than no metadata."""
    try:
        from . import licence
        return licence.device_id(settings)
    except Exception:                                              # noqa: BLE001
        return ""


def lookup(settings, title, is_series=False):
    """Search, then fetch details. Returns a metadata dict, or None when TMDB has no such title."""
    # A manual correction replaces the guesswork entirely — no normalisation, no year stripping, no
    # second reading. Someone looked at the wrong result and typed what it should be; second-guessing
    # that is how a correction stops being one.
    override = alias_for(settings, title, is_series)
    if override:
        # The typed text REPLACES the provider's title — but it still goes through the same two
        # readings, because a person correcting a match types "Toma 2021" as naturally as "Toma", and
        # searching for that while also passing year=2021 finds nothing. Overriding the title is the
        # point; overriding the year handling would just reintroduce a bug that is already fixed.
        source, is_series = override[0], override[1]
    else:
        source = title
    candidates = queries(source)
    year = year_of(source)
    if not candidates:
        return None
    kind = "tv" if is_series else "movie"

    results = []
    for query in candidates:
        params = {"query": query}
        if year:
            params["year" if not is_series else "first_air_date_year"] = year
        results = (_get(settings, "search/%s" % kind, **params) or {}).get("results") or []
        if results:
            break
        if year:
            # The year in a provider title is often the upload year, not the film's.
            results = (_get(settings, "search/%s" % kind, query=query) or {}).get("results") or []
            if results:
                break
    if not results:
        return None

    best = _best_match(results, query, normalize(title), year, is_series)
    detail = _get(settings, "%s/%s" % (kind, best.get("id")), append_to_response="credits,external_ids") or {}
    shaped = _shape(detail, is_series)

    # TMDB's Serbian coverage is thin outside domestic titles, so most films come back with an empty
    # overview. Rather than show a Serbian catalogue with English descriptions — or none — fetch the
    # English one and machine-translate it, exactly as the Android client does. Only here, in the
    # background filler, and the result is cached with everything else: once per title, ever.
    if not shaped.get("plot") and settings.get_bool("tmdb_translate", True):
        english = _get(settings, "%s/%s" % (kind, best.get("id")), language="en-US") or {}
        overview = (english.get("overview") or "").strip()
        if overview:
            target = (settings.get("tmdb_language", "sr-RS") or "sr-RS").split("-")[0]
            translated = translate.translate(overview, target)
            if translated:
                # The machine comes back in Cyrillic too — same reason, same treatment.
                shaped["plot"] = latin(translated)
                shaped["plot_translated"] = True
            else:
                # Better an English plot than a blank one — the user can still read what it is about.
                shaped["plot"] = overview
    return shaped


def _best_match(results, query, full_title, year, is_series):
    """
    Which search result to believe.

    Taking `results[0]` is what TMDB's own ranking suggests, and for a short title it is wrong in a way
    nobody notices: "Crveni" came back as "Crveni cvet" — a different film, with a different poster and
    plot, presented confidently. Popularity beats exactness there, so a short query lands on whatever
    bigger title contains it.

    So an exact title match wins, then a matching year, and only then the ranking. But the exact match
    is tried against the FULL title before the search query, and that order is load-bearing: the query
    may have had a trailing year stripped from it (see [queries]), and "Blade Runner 2049" searched as
    "Blade Runner" matches the 1982 film exactly. Checking the full title first puts it back on 2049 —
    a regression this very rule introduced, caught only because the case was re-tested.
    """
    date_field = "first_air_date" if is_series else "release_date"
    candidates = [t for t in ((full_title or "").strip().lower(), (query or "").strip().lower()) if t]

    def titles_of(entry):
        return [(entry.get("title") or "").strip().lower(),
                (entry.get("name") or "").strip().lower(),
                (entry.get("original_title") or "").strip().lower(),
                (entry.get("original_name") or "").strip().lower()]

    head = results[:8]
    for wanted in candidates:
        for entry in head:
            if wanted in titles_of(entry):
                return entry
    if year:
        for entry in head:
            if (entry.get(date_field) or "")[:4] == str(year):
                return entry
    return results[0]



#: Serbian Cyrillic to Latin, digraphs first so `њ` cannot become `nj` one letter at a time.
#:
#: TMDB answers `sr-RS` in CYRILLIC, and so does the machine translation behind it — while every
#: provider catalogue here, the whole interface and the channel names are LATIN. A Cyrillic plot under a
#: Latin title is not a translation problem, it is two alphabets on one screen; the audience this addon
#: is sold to reads both but writes one. The TITLE is still never taken from TMDB (see the module
#: docstring); this only touches the text we do take.
_CYR = [("Њ", "Nj"), ("њ", "nj"), ("Љ", "Lj"), ("љ", "lj"), ("Џ", "Dž"), ("џ", "dž")] + list(zip(
    "АБВГДЂЕЖЗИЈКЛМНОПРСТЋУФХЦЧШабвгдђежзијклмнопрстћуфхцчш",
    ["A", "B", "V", "G", "D", "Đ", "E", "Ž", "Z", "I", "J", "K", "L", "M", "N", "O", "P", "R", "S",
     "T", "Ć", "U", "F", "H", "C", "Č", "Š",
     "a", "b", "v", "g", "d", "đ", "e", "ž", "z", "i", "j", "k", "l", "m", "n", "o", "p", "r", "s",
     "t", "ć", "u", "f", "h", "c", "č", "š"]))


def latin(text):
    """[text] in Latin. Anything that is not Serbian Cyrillic passes through untouched."""
    if not text:
        return text
    out = text
    for cyrillic, roman in _CYR:
        if cyrillic in out:
            out = out.replace(cyrillic, roman)
    return out


def _shape(detail, is_series):
    date = detail.get("first_air_date" if is_series else "release_date") or ""
    cast = [person.get("name") for person in ((detail.get("credits") or {}).get("cast") or [])[:12]
            if person.get("name")]
    directors = [person.get("name")
                 for person in ((detail.get("credits") or {}).get("crew") or [])
                 if person.get("job") == "Director" and person.get("name")]
    return {
        "plot": latin((detail.get("overview") or "").strip()),
        "year": int(date[:4]) if date[:4].isdigit() else 0,
        "rating": float(detail.get("vote_average") or 0),
        "votes": int(detail.get("vote_count") or 0),
        "genres": [latin(g.get("name")) for g in detail.get("genres") or [] if g.get("name")],
        "cast": cast,
        "director": ", ".join(directors[:2]),
        "duration": int(detail.get("runtime") or 0) * 60,
        "poster": (IMAGE_BASE + POSTER_SIZE + detail["poster_path"]) if detail.get("poster_path") else "",
        "fanart": (IMAGE_BASE + BACKDROP_SIZE + detail["backdrop_path"]) if detail.get("backdrop_path") else "",
        # THE IMDB ID, and it is here for subtitles rather than for display.
        #
        # Kodi's subtitle search hands whatever the playing item knows to every subtitle addon the user
        # has installed. Given only a title it matches on text, and Serbian provider titles are exactly
        # the input that goes wrong — "Gospodar prstenova: Dve kule" finds nothing, and a wrong film's
        # subtitles are worse than none. Given an IMDb id the match is exact and language-independent,
        # which is the whole difference between a feature that works and one that mostly does not.
        #
        # Costs no extra request: `external_ids` rides along on the detail call that already happens.
        "imdb": ((detail.get("external_ids") or {}).get("imdb_id") or ""),
        # Kept for a future "why did it match this?" screen. The TITLE is never used for display — see
        # the module docstring on Cyrillic.
        "matched": detail.get("title") or detail.get("name") or "",
    }


def decorate(item, entry, meta):
    """
    Put [meta] onto a Kodi ListItem, leaving the provider's own values in place where it has them.

    Written as "fill the gaps", not "overwrite": the provider knows its own catalogue, and its plot is
    in the same language and script as the title the user is looking at.
    """
    info = {"title": entry.get("name") or ""}
    art = {}
    provider_art = entry.get("logo") or ""

    if meta.get("plot") and not entry.get("plot"):
        info["plot"] = meta["plot"]
    elif entry.get("plot"):
        info["plot"] = entry["plot"]
    for source, field in (("year", "year"), ("duration", "duration"), ("director", "director")):
        if meta.get(source):
            info[field] = meta[source]
    if meta.get("genres"):
        info["genre"] = " / ".join(meta["genres"])
    if meta.get("cast"):
        info["cast"] = meta["cast"]
    if meta.get("rating"):
        info["rating"] = meta["rating"]
        info["votes"] = str(meta.get("votes") or 0)

    # The provider's poster wins: it is the artwork of the copy actually on offer. TMDB's is the
    # fallback, and its BACKDROP is the thing no provider gives.
    poster = provider_art or meta.get("poster") or ""
    if poster:
        art.update({"thumb": poster, "poster": poster, "icon": poster})
    if meta.get("fanart"):
        art["fanart"] = meta["fanart"]
    return info, art
