# -*- coding: utf-8 -*-
"""
Writing a small file so that a reader never sees half of it.

WHY THIS IS ITS OWN MODULE. `open(path, "w")` EMPTIES the file before the first byte is written. For
the width of that window the file exists and is empty, and everything here is read by somebody: by the
other process (the service and the plugin both run, and both touch the profile), or by this same box
after a power cut. A TV box loses power mid-write far more often than a server does — people pull the
plug on them instead of shutting them down, which is exactly what makes this worth doing rather than
theoretical.

A rename is atomic on every filesystem Kodi runs on; a truncate is not. So: write a neighbouring temp
file, then `os.replace` it over the target. A reader either gets the whole previous file or the whole
new one, and a power cut in the middle leaves the PREVIOUS file intact.

`localserver.py` has carried this pattern inline since the token race on 2026-08-02 (see the note
there), catalog._write_files has it for the playlist and the guide, and accounts/catcache have it too.
What was missing was everything SMALL: the licence state, resume positions, the done-list, the seen-list
and the TMDB database were all written with a plain truncate. This is that pattern, once.

NOT for the provider session and VOD caches. A half-written cache there fails `json.loads` on the next
read, which is already handled as "no cache" and costs one re-fetch — it heals itself, and routing it
through here would be churn in the hottest paths for no gain.
"""

import io
import json
import os

from . import diag


def write_text(path, text):
    """
    Put [text] at [path] whole, or leave what was there. True when it landed.

    The temp file is a NEIGHBOUR of the target (same directory), not in the system temp folder: on
    Android the profile and /tmp are frequently different filesystems, and `os.replace` across
    filesystems raises rather than moving — which would turn every write here into a silent failure.
    """
    temporary = path + ".tmp"
    try:
        with io.open(temporary, "w", encoding="utf-8") as handle:
            handle.write(text)
        os.replace(temporary, path)
        return True
    except (OSError, IOError, ValueError) as err:
        diag.log("Could not write %s (%s)" % (os.path.basename(path), err), "ERROR")
        # A temp file left behind would be read by nobody, but it would sit in the profile forever.
        try:
            os.remove(temporary)
        except OSError:
            pass
        return False


def write_json(path, data):
    """[data] as JSON, written the same way. False if it could not be encoded or could not be stored."""
    try:
        text = json.dumps(data, ensure_ascii=False)
    except (TypeError, ValueError) as err:
        diag.log("Could not encode %s (%s)" % (os.path.basename(path), err), "ERROR")
        return False
    return write_text(path, text)
