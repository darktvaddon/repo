# -*- coding: utf-8 -*-
"""
Search — channels, what is on the guide, and the Video klub.

Where the answers come from was decided by measuring rather than guessing:

* **Channels and programmes come from OUR OWN files.** The playlist and the XMLTV guide are already on
  disk after every refresh, so this costs no network at all and works while a provider is down. It is
  also what the Android client does — `CatalogDao.searchChannels` / `searchProgrammes` query the local
  database, not the operator.
* **The Video klub is asked live, per provider, using that provider's own search where one exists.**
  EON answers `v1/search?q=` in 0.3 s and Yettel's Kaltura backend a KSQL `name ~ '...'` in 0.5 s.
  Iris has none that works — `/VSP/V3/SearchContent` is the only endpoint that is not a 404 and it
  replies "search content failed" to every body shape tried — so it gets its VOD tree WALKED instead,
  which takes about nine seconds. That is why [vod] takes a progress callback.

  Measured, because the difference is not small: before EON's own endpoint was found, walking its 31
  catalogues took 34 seconds for the same query it now answers in under one.

Matching is accent- and case-insensitive: someone typing "sport" on a TV remote must find "Šport", and
nobody is going to hunt for the caron key on an on-screen keyboard.
"""

import calendar
import os
import re
import time
import unicodedata
import xml.etree.ElementTree as ET

from . import diag

#: How many rows each section may contribute. A remote-control list nobody can scroll to the end of is
#: not more useful than a short one, and building it costs memory on a box that has little.
CHANNEL_LIMIT = 60
PROGRAMME_LIMIT = 120
VOD_LIMIT = 120

#: How deep a provider without its own search is walked. Two levels reaches "catalogue -> titles"
#: (EON) and "kind -> genre" (Yettel); a third would mean opening every series to read its episodes,
#: which is hundreds of requests for a screen the user is waiting on.
WALK_DEPTH = 2

_XMLTV_TIME = re.compile(r"^(\d{14})")


def fold(text):
    """Lowercase, accents removed — "Šport" and "sport" have to be the same word for a search box."""
    if not text:
        return ""
    stripped = unicodedata.normalize("NFKD", text)
    return "".join(c for c in stripped if not unicodedata.combining(c)).lower()


def matches(term, *fields):
    needle = fold(term).strip()
    if not needle:
        return False
    return any(needle in fold(field) for field in fields if field)


# ---- the playlist we wrote ---------------------------------------------------

def parse_playlist(path):
    """
    Every channel in our own M3U, with the bits needed to play it again.

    The `#KODIPROP` lines are carried along rather than dropped: for a provider whose URL is direct
    they are the ONLY place the DRM and header configuration lives, so a result played without them is
    a channel that silently refuses to start.
    """
    rows = []
    if not os.path.exists(path):
        return rows
    try:
        with open(path, "r", encoding="utf-8") as handle:
            entry, props = None, {}
            for line in handle:
                line = line.rstrip("\r\n")
                if line.startswith("#EXTINF:"):
                    attrs = dict(re.findall(r'([\w-]+)="([^"]*)"', line))
                    name = line.split(",", 1)[1] if "," in line else ""
                    entry = {"id": attrs.get("tvg-id", ""), "name": name,
                             "group": attrs.get("group-title", ""),
                             "number": attrs.get("tvg-chno", ""),
                             "logo": attrs.get("tvg-logo", ""),
                             "provider": attrs.get("provider", ""),
                             "catchup_source": attrs.get("catchup-source", ""),
                             "catchup_days": attrs.get("catchup-days", "")}
                    props = {}
                elif line.startswith("#KODIPROP:") and entry is not None:
                    key, _, value = line[len("#KODIPROP:"):].partition("=")
                    props[key] = value
                elif line and not line.startswith("#") and entry is not None:
                    entry["url"] = line
                    entry["props"] = props
                    rows.append(entry)
                    entry, props = None, {}
    except (OSError, IOError) as err:
        diag.log("Search: could not read the playlist (%s)" % err, "ERROR")
    return rows


def channels_in(rows, term, limit=CHANNEL_LIMIT):
    """
    Channels whose name or group matches, out of an already-parsed playlist.

    Takes the parsed rows rather than a path because the caller needs them anyway — the catch-up
    template for a guide result is read from the same list, and parsing the file twice for one screen
    is work nobody asked for.

    Playlist order is kept: that is the operator's own numbering, the order the user already knows
    from the TV list, and re-sorting it alphabetically would only make a familiar list unfamiliar.
    """
    out = []
    for row in rows:
        if matches(term, row.get("name"), row.get("group")):
            out.append(row)
            if len(out) >= limit:
                break
    return out


def channels(settings, term, limit=CHANNEL_LIMIT):
    """[channels_in] for a caller that has no reason to hold the parsed playlist."""
    return channels_in(parse_playlist(settings.playlist_path()), term, limit)


# ---- the guide we wrote ------------------------------------------------------

def _epoch(stamp):
    """
    '20260727203000 +0000' -> epoch seconds. The offset is always +0000 in what we write.

    `calendar.timegm`, NOT `time.mktime` minus the timezone offset. mktime reads the struct as LOCAL
    time and applies whatever DST rule is in force, so through the summer every programme came out an
    hour off — which in this file means a catch-up URL asking the operator for the wrong hour, and a
    show that starts with the last few minutes of the one before it.
    """
    found = _XMLTV_TIME.match(stamp or "")
    if not found:
        return 0
    try:
        return calendar.timegm(time.strptime(found.group(1), "%Y%m%d%H%M%S"))
    except (ValueError, OverflowError):
        return 0


def programmes(settings, term, now=None, limit=PROGRAMME_LIMIT):
    """
    Shows in the guide whose title or description matches, in time order.

    Streamed with `iterparse` and cleared as it goes, because this file is 18 MB and 37,000 programmes
    on a real line-up: reading it into a tree would allocate several times that on a box with 1 GB.

    Everything still in the guide is returned, past included. A finished programme is exactly the one
    worth finding — that is what catch-up is for — and each row says which side of now it is on so the
    caller can offer the right thing.

    **The limit counts SHOWS, not airings, and that is the whole reason the collapse happens in here.**
    A show is one row per channel however often it repeats (see [_rank]), but the cap used to be spent
    before the collapse: a daily programme airing three times a day on five channels across a five-day
    guide is seventy-five matches that become five rows, so it filled the budget of a hundred and twenty
    on its own and every other matching show — further down an 18 MB file — was never collected at all.
    The user saw five results and no sign that anything had been dropped. Collapsing as we read means a
    repeat costs nothing and the cap is a hundred and twenty distinct answers.
    """
    path = settings.epg_path()
    if not os.path.exists(path):
        return []
    now = int(now if now is not None else time.time())
    names = {}
    best = {}
    try:
        for event, node in ET.iterparse(path, events=("end",)):
            if node.tag == "channel":
                display = node.find("display-name")
                names[node.get("id") or ""] = (display.text or "") if display is not None else ""
                node.clear()
                continue
            if node.tag != "programme":
                continue
            title = (node.findtext("title") or "").strip()
            desc = (node.findtext("desc") or "").strip()
            in_title = matches(term, title)
            if in_title or matches(term, desc):
                start, stop = _epoch(node.get("start")), _epoch(node.get("stop"))
                row = {"channel_id": node.get("channel") or "", "title": title, "desc": desc,
                       "start": start, "stop": stop, "in_title": in_title,
                       "state": "past" if stop and stop < now
                                else ("now" if start <= now else "next")}
                key = (fold(title), fold(names.get(row["channel_id"], row["channel_id"])))
                if key in best:
                    # Another airing of one we already have: keep whichever is the more useful one to
                    # act on, by the same rule the sort below uses.
                    if _airing_rank(row, now) < _airing_rank(best[key], now):
                        best[key] = row
                elif len(best) < limit:
                    best[key] = row
            node.clear()
    except ET.ParseError as err:
        diag.log("Search: the guide could not be read (%s)" % err, "ERROR")
    out = list(best.values())
    for row in out:
        row["channel_name"] = names.get(row["channel_id"], row["channel_id"])
    return _rank(out, now)


def _airing_rank(row, now):
    """
    Which of a show's airings is the one to offer. Module level because two callers need the SAME rule:
    [programmes] uses it to pick a winner as it reads, and [_rank] to order what survived — and a search
    where the two disagreed would collapse to one airing and then sort as if it were another.

    Whatever is on now, else the most recent finished showing (that is the one with an archive to play),
    else the soonest to come.
    """
    if row["state"] == "now":
        return (0, 0)
    if row["state"] == "past":
        return (1, now - row["start"])                      # most recent finished first
    return (2, row["start"] - now)                          # then the soonest upcoming


def _rank(rows, now):
    """
    One row per show, title matches first, and the airing that is easiest to act on.

    Two things a guide search does that nobody wants. **It repeats itself:** a series airs six times
    across the week and a plain match lists all six, which pushes everything else off the screen —
    measured on the real box, "zvezda" returned 120 programme rows and 13 films, and the films were
    below the fold. So a show is collapsed to ONE row per channel. **And it buries the obvious answer:**
    a description mentioning the word is a much weaker hit than a title containing it, and there are far
    more of them, so title matches come first regardless of time.

    Which airing survives the collapse is chosen to be the useful one: whatever is on now, else the most
    recent finished showing (that is the one with an archive to play), else the soonest to come.
    """
    best = {}
    for row in rows:
        key = (fold(row["title"]), fold(row.get("channel_name") or row["channel_id"]))
        if key not in best or _airing_rank(row, now) < _airing_rank(best[key], now):
            best[key] = row
    return sorted(best.values(),
                  key=lambda r: (0 if r.get("in_title") else 1, _airing_rank(r, now)))


def catchup_url(playlist_rows, channel_id, start_epoch):
    """
    The play URL for a finished programme, or "" when that channel keeps no archive.

    Built from the playlist's own `catchup-source`, which is the same template IPTV Simple fills in
    from the guide — so a result played from here goes down the identical path as one played from
    Kodi's own EPG, rather than a second implementation that can drift from it.
    """
    for row in playlist_rows:
        if row.get("id") != channel_id:
            continue
        template = row.get("catchup_source") or ""
        if not template or "{utc}" not in template:
            return ""
        return template.replace("{utc}", str(int(start_epoch)))
    return ""


# ---- the providers' on-demand catalogues -------------------------------------

def vod(settings, term, providers_list, progress=None, limit=VOD_LIMIT):
    """
    Films and series matching [term], across every enabled provider.

    [progress] is called as `progress(label, percent)` and may return True to cancel — a provider
    without its own search is walked one directory at a time and that is slow enough that a user
    staring at a still screen would reasonably conclude it had hung.
    """
    out = []
    total = len(providers_list) or 1
    for index, provider in enumerate(providers_list):
        if progress and progress(provider.label, int(100.0 * index / total)):
            break
        try:
            found = provider.search(term) if getattr(provider, "supports_search", False) \
                else _walk(provider, term, limit, progress, index, total)
        except Exception as err:                                   # noqa: BLE001 - one provider only
            # One provider failing must not empty the whole result list, and the user is told which.
            diag.log("Search: %s could not be searched — %s" % (provider.label, err), "ERROR")
            continue
        for entry in found:
            entry["provider"] = provider.key
            entry["account"] = provider.account_id
            entry["provider_label"] = provider.label
            out.append(entry)
            if len(out) >= limit:
                return out
    return out


def _walk(provider, term, limit, progress=None, index=0, total=1):
    """
    Depth-limited walk of a provider's VOD tree for one without a search API.

    Series are matched by their own name and never opened. Someone searching for a show wants the show,
    and expanding every series to read its episode titles turns one screen into hundreds of requests.
    """
    if not getattr(provider, "supports_vod", False):
        return []
    found, seen = [], set()
    level = [(None, 0)]
    done = 0
    while level:
        node, depth = level.pop(0)
        if progress:
            # Within one provider's share of the bar, so a slow walk still visibly advances rather than
            # sitting on one number for the fifteen seconds EON's catalogue takes.
            share = 100.0 / (total or 1)
            step = share * done / (done + len(level) + 1)
            if progress(provider.label, int(index * share + step)):
                return found
        done += 1
        try:
            entries = provider.vod(node)
        except Exception as err:                                   # noqa: BLE001
            diag.log("Search: %s node %r failed — %s" % (provider.label, node, err), "ERROR")
            continue
        for entry in entries or []:
            name = entry.get("name") or ""
            if matches(term, name, entry.get("plot")):
                marker = (entry.get("id") or "", entry.get("node") or "", name)
                if marker not in seen:
                    seen.add(marker)
                    found.append(dict(entry))
                    if len(found) >= limit:
                        return found
            if entry.get("kind") == "dir" and depth + 1 < WALK_DEPTH \
                    and not (entry.get("node") or "").startswith("series:"):
                level.append((entry.get("node"), depth + 1))
    return found


def programme_at(settings, provider_key, channel_ref, at_utc):
    """
    What was on that channel at that instant, from the guide this addon wrote.

    Catch-up playback is handed to Kodi as a resolved URL, and Kodi then shows the plain video OSD: a
    progress bar and nothing else. The programme's own title and description are sitting in our XMLTV,
    so putting them on the ListItem is the difference between "some stream" and "Dnevnik, 19:30" on
    screen while rewinding.

    The channel is matched through the PLAYLIST rather than by rebuilding a tvg-id from the provider key
    and the channel reference. Those formats differ per provider (`eon_665`, `iris_665`, and the account
    -scoped ones Yettel and Move use), and guessing wrong here fails silently — an OSD with no title
    looks exactly like a guide that has not been built yet.
    """
    try:
        at_utc = int(at_utc)
    except (TypeError, ValueError):
        return None
    needle_provider = "provider=%s" % provider_key
    needle_id = "id=%s" % channel_ref
    tvg_id = ""
    for row in parse_playlist(settings.playlist_path()):
        url = row.get("url") or ""
        source = row.get("catchup_source") or ""
        if needle_provider in (url + source) and (
                ("&%s&" % needle_id) in (url + "&") or (url + source).endswith(needle_id)
                or ("&%s&" % needle_id) in (source + "&")):
            tvg_id = row.get("id") or ""
            break
    if not tvg_id:
        return None

    path = settings.epg_path()
    if not os.path.exists(path):
        return None
    found = None
    try:
        for _event, node in ET.iterparse(path, events=("end",)):
            if node.tag != "programme":
                continue
            if node.get("channel") == tvg_id:
                start, stop = _epoch(node.get("start")), _epoch(node.get("stop"))
                # The programme CONTAINING the instant, not one starting exactly at it: the timestamp
                # IPTV Simple substitutes and the guide's own start times need not agree to the second.
                if start and stop and start <= at_utc < stop:
                    found = {"title": (node.findtext("title") or "").strip(),
                             "desc": (node.findtext("desc") or "").strip(),
                             "start": start, "stop": stop}
                    node.clear()
                    break
            node.clear()
    except ET.ParseError as err:
        diag.log("Guide: could not be read for the catch-up OSD (%s)" % err, "ERROR")
        return None
    return found
