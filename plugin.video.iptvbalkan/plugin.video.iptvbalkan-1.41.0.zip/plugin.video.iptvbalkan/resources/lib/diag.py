# -*- coding: utf-8 -*-
"""
Diagnostics: the part that has to be right before anything else is worth writing.

Every provider in this addon talks to a service that can change its mind without notice — a blocked
User-Agent, a renamed field, a new required header, an endpoint that starts answering 403. When that
happens the user sees "channel doesn't play" and nothing else, and without a trace of what was actually
sent and received, the next step is guesswork.

So this module records, per request: the method and URL (with credentials stripped), the exact headers
sent, the status, the timing, the response size, and a bounded snippet of the body. That trace is what
turns "it stopped working" into "the edge answers 403 with 'User agent blocked' on the manifest while the
API host is fine" — which is a diagnosis, not a guess.

Two rules it never breaks:
  * Passwords, tokens and stream keys are redacted before anything reaches disk. A user emailing a log
    must not be handing over their account.
  * The trace is bounded (size and count). A log that fills a TV box's storage is its own bug.
"""

import io
import os
import re
import time

from .settings import ADDON_ID

try:                     # inside Kodi
    import xbmc
    import xbmcaddon
    import xbmcvfs
    # The id is passed EXPLICITLY, for the reason settings.ADDON_ID is written down: the no-argument
    # `Addon()` resolves the addon from the calling script's context, and this module is imported by
    # everything — including code that ends up running on threads the addon started, where that context
    # does not exist. There it does not return a bad handle, it raises, and an exception at import time in
    # the logging module takes the whole addon down with it.
    _ADDON = xbmcaddon.Addon(ADDON_ID)
    _PROFILE = xbmcvfs.translatePath(_ADDON.getAddonInfo("profile"))
except ImportError:      # unit tests / tooling outside Kodi
    xbmc = None
    xbmcvfs = None
    _ADDON = None
    # OUTSIDE the addon tree, and for exactly the reason Settings.profile_dir says so: this used to be
    # `<addon>/resources/lib/_testprofile`, so every selftest run wrote a real account's request log into
    # the folder that gets zipped and pushed to boxes. pack.py skips it, but `adb push` of the source tree
    # does not — which is why the deploy recipe has a "remember to delete _testprofile" step. Writing it
    # somewhere else removes the step and the trap with it. Same env var and same default as
    # Settings.profile_dir, so the harness and the log stay together.
    _PROFILE = os.environ.get("IPTVBOX_TEST_PROFILE") or \
        os.path.join(os.path.expanduser("~"), ".iptvbox-selftest")

#: Renamed in 1.32.0. The old name was the other product's, and this file is the one thing a customer
#: is asked to send — see the branding rule in _REDACTIONS. `migrate_log_name` moves an existing file
#: across so nobody loses the history that explains their problem.
LOG_NAME = "iptvbalkan.log"
LEGACY_LOG_NAMES = ("iptvbox.log", "iptvbox.log.1")
MAX_BYTES = 512 * 1024          # one file; a TV box has little storage and nobody reads more than this
MAX_BODY_SNIPPET = 600          # enough to see an error payload, not enough to dump a channel list

# WHAT A SECRET IS CALLED, not a list of the ones we happened to think of.
#
# The old list named `password`, `access_token`, `refresh_token` and `authorization` — and missed every
# secret the providers added after it was written: Iris `userToken` and the Widevine `customData` JWT,
# Iris's session COOKIES (it pins sessions on CSESSIONID/XSESSIONID/JSESSIONID, so a cookie header is a
# live session), Yettel `appTokenSecret` and the Kaltura `ks`. That log is not private: the last 55 kB
# of it rides along with every support report, so a name nobody added to the list is a credential the
# owner receives by e-mail.
#
# So the rule is on the SHAPE OF THE NAME. Any field, header or query parameter whose name contains one
# of these words has its VALUE replaced — the name itself stays, because "which field was sent" is what
# the log exists to answer and the value is never what anyone debugging needs.
_SECRET_WORDS = (r"password|passwd|token|secret|auth|cookie|session|credential|customdata"
                 r"|signature|stream_?key|vault|apikey|api_key|\bks\b")

_REDACTIONS = [
    # JSON:  "userToken": "…"   /   'customData' : '…'
    (re.compile(r"(?i)([\"'](?:[\w.-]*(?:%s)[\w.-]*)[\"']\s*:\s*[\"'])([^\"']+)" % _SECRET_WORDS),
     r"\1<redacted>"),
    # Bare  key=value  and  key: value  (form bodies, and our own trace lines)
    (re.compile(r"(?i)((?:[\w.-]*(?:%s)[\w.-]*)[\"']?\s*[=:]\s*[\"']?)([^\"'&,\s}\]]+)" % _SECRET_WORDS),
     r"\1<redacted>"),
    # Whole headers, value and all. `> Cookie: a=1; b=2` must lose everything after the colon — the
    # per-pair rule above would leave the second cookie standing.
    (re.compile(r"(?im)^(\s*[<>]?\s*(?:cookie|set-cookie|authorization|x-play-auth|proxy-authorization)"
                r"\s*:\s*)(.+)$"), r"\1<redacted>"),
    # Query parameters. `a` and `i` are EON's signed blob and its IV: together they ARE a playable
    # credential for this account, and single letters no name rule can catch.
    (re.compile(r"(?i)([?&](?:%s|u|a|i)=)([^&\s]+)" % _SECRET_WORDS), r"\1<redacted>"),
    # WHOSE SERVER THIS IS, and whose product this is not.
    #
    # The addon is sold under its own name and has to stand on its own; the log is the one file a
    # customer is ever asked to send, and it carried both the licence server's address and another
    # product's name in every trace line. This is a BRANDING rule, not a security one — anybody who
    # looks at their router or their DNS sees the address anyway — and it says so here so that nobody
    # later mistakes it for protection.
    #
    # The address goes first, or the name rule would rewrite the host into something that no longer
    # matches a URL.
    (re.compile(r"(?i)https?://[\w.-]*iptvbox[\w.-]*(?::\d+)?"), "https://<licence-server>"),
    (re.compile(r"(?i)iptvbox"), "IPTV Balkan"),
    # THE SIGNED BLOB, which the two rules above cannot touch and which carries everything they hide.
    #
    # `payload` is base64 of the licence answer — the same host, the same fields — and it must stay
    # byte-for-byte what the server signed or the signature no longer verifies. So it cannot be
    # rewritten; it can only be left out of the log, which costs nothing: a base64 document nobody can
    # read at a glance was never what made a log useful, and the same fields are printed beside it in
    # the clear.
    (re.compile(r'(?i)("(?:payload|sig|signature)"\s*:\s*")([^"]{16,})'), r"\1<signed>"),
]


def redact(text):
    """Strip anything that identifies or authenticates the user. Applied to EVERY written line."""
    if not text:
        return text
    out = text
    for pattern, repl in _REDACTIONS:
        out = pattern.sub(repl, out)
    return out


def migrate_log_name():
    """Move a log written under the previous name across. Called once at service start."""
    try:
        if not os.path.isdir(_PROFILE):
            return
        target = os.path.join(_PROFILE, LOG_NAME)
        for legacy in LEGACY_LOG_NAMES:
            source = os.path.join(_PROFILE, legacy)
            if not os.path.isfile(source):
                continue
            if os.path.exists(target) and legacy.endswith(".1"):
                os.remove(source)           # the rotation is not worth keeping twice
            elif os.path.exists(target):
                os.remove(source)
            else:
                os.replace(source, target)
    except OSError:
        pass


def _path():
    if not os.path.isdir(_PROFILE):
        os.makedirs(_PROFILE)
    return os.path.join(_PROFILE, LOG_NAME)


def _rotate_if_needed(path):
    """One rotation, not a series: the previous file is all the history worth keeping, and two files is
    a bound a user can actually attach to a message."""
    try:
        if os.path.exists(path) and os.path.getsize(path) > MAX_BYTES:
            old = path + ".1"
            if os.path.exists(old):
                os.remove(old)
            os.rename(path, old)
    except OSError:
        pass  # a log that cannot rotate must never break playback


#: Who this log belongs to — set once per process, written at the top of every log file.
#:
#: WHY A LOG HAS TO SIGN ITSELF. A log is the one thing that leaves a customer's box, by e-mail, over
#: Telegram, through the panel's own inbox, and until now nothing INSIDE the file said which box it came
#: from: the panel row knew, a forwarded copy did not. So a log pasted into a message was an orphan —
#: the first question back was always "which device number is this?", and the answer was another round
#: trip to somebody's television.
#:
#: It is also the honest version of a watermark for a project like this one. The addon itself is public
#: and identical for everyone, so there is nothing in the CODE to mark; what can be marked is the thing
#: that actually gets passed around.
#:
#: A plain module-level string rather than a lookup, because `licence` imports THIS module — asking it
#: for the serial from here would be a circular import. The two entry points set it after the licence
#: check they already perform.
STAMP = ""


def set_stamp(text):
    """Name the box this log belongs to. Called once, from the service and from the plugin."""
    global STAMP
    STAMP = str(text or "").strip()


def _stamp_if_new(path):
    """
    The identity line, written into a log file that does not have one yet.

    CREATED EXCLUSIVELY, and that is not pedantry: this addon logs from TWO processes at once — the
    resident service and whichever plugin call Kodi is running — and both start within the same second
    of a fresh install. Checking "is the file empty" and then appending let both of them find it empty
    and both write, which is exactly what the box printed: the same header twice, at the same second.
    Mode "x" fails for the loser instead, and the loser has nothing to add.
    """
    if not STAMP:
        return
    try:
        if os.path.exists(path):
            return
        with io.open(path, "x", encoding="utf-8") as handle:
            handle.write(u"%s  ----   %s\n" % (time.strftime("%Y-%m-%d %H:%M:%S"), STAMP))
    except (OSError, IOError, ValueError):
        # Somebody else created it in the meantime, or the profile is unwritable. Both mean "no header",
        # and neither may cost a line of log.
        pass


def log(message, level="INFO"):
    """One line to Kodi's own log and to ours. Kodi's is what a power user already knows how to find;
    ours is what survives a Kodi restart and can be exported as a single file."""
    line = "%s  %-5s  %s" % (time.strftime("%Y-%m-%d %H:%M:%S"), level, redact(str(message)))
    if xbmc is not None:
        xbmc.log("[IPTV Balkan] " + redact(str(message)),
                 xbmc.LOGERROR if level == "ERROR" else xbmc.LOGINFO)
    path = _path()
    _rotate_if_needed(path)
    # After the rotation, so a fresh file gets the identity line before anything else — a log that
    # rolled over mid-session must not lose track of whose it is.
    _stamp_if_new(path)
    try:
        with io.open(path, "a", encoding="utf-8") as handle:
            handle.write(line + u"\n")
    except (OSError, IOError):
        pass


def trace_request(method, url, headers, status=None, elapsed_ms=None, size=None, body=None, error=None):
    """
    The record that makes a provider change diagnosable.

    Headers are written in full (after redaction) on purpose: when a provider starts rejecting us, the
    difference between our request and the official client's is almost always a header — and if the log
    only says "403" nobody can tell which one.
    """
    parts = ["%s %s" % (method, url)]
    if status is not None:
        parts.append("-> %s" % status)
    if elapsed_ms is not None:
        parts.append("%dms" % elapsed_ms)
    if size is not None:
        parts.append("%dB" % size)
    if error:
        parts.append("ERROR %s: %s" % (type(error).__name__, error))
    log(" ".join(parts), level="ERROR" if (error or (status and status >= 400)) else "INFO")
    for key, value in sorted((headers or {}).items()):
        log("    > %s: %s" % (key, value))
    if body:
        log("    < %s" % _body_snippet(body))


def _body_snippet(body):
    """
    What of a response body is worth keeping.

    An HTML page from a JSON API is an error page, and the useful part of it is the sentence a human
    wrote — not the doctype, the namespace list and the Angular cloak rules. A single 404 page was
    filling 600 characters of every log line and turned a real log into seventeen pages nobody could
    read on a TV. The visible text still goes in, because "User agent blocked" arrives exactly this way.
    """
    stripped = body.strip()
    if stripped[:200].lower().lstrip().startswith(("<!doctype html", "<html")):
        text = re.sub(r"(?is)<(script|style)[^>]*>.*?</\1>", " ", stripped)
        text = re.sub(r"(?s)<[^>]+>", " ", text)
        text = re.sub(r"\s+", " ", text).strip()
        return "<html, %d bytes> %s" % (len(body), text[:150] or "(no text)")
    snippet = stripped[:MAX_BODY_SNIPPET].replace("\n", " ")
    return snippet + ("…" if len(stripped) > MAX_BODY_SNIPPET else "")


def read_log():
    """Whole current log, oldest rotation first — what the 'export' action hands the user."""
    chunks = []
    for candidate in (_path() + ".1", _path()):
        if os.path.exists(candidate):
            try:
                with io.open(candidate, "r", encoding="utf-8", errors="replace") as handle:
                    chunks.append(handle.read())
            except (OSError, IOError):
                pass
    return "".join(chunks)


def read_kodi_log(max_bytes=400 * 1024):
    """
    The tail of KODI's own log, not ours.

    Ours ends where the addon's job ends: it can say "the playlist and guide were written and IPTV
    Simple was pointed at them" and nothing at all about what happened next. Everything after that —
    the PVR manager starting, the guide being imported, a stream failing in inputstream.adaptive —
    is in Kodi's log, on a box with no keyboard, in a folder that differs per platform. Getting at it
    used to mean photographing a screen; this is what makes it one scan of a QR code.

    Tailed rather than read whole: this file runs to megabytes, and what matters is always the end.
    """
    if xbmcvfs is None:
        return ""
    try:
        path = os.path.join(xbmcvfs.translatePath("special://logpath"), "kodi.log")
        size = os.path.getsize(path)
        with io.open(path, "r", encoding="utf-8", errors="replace") as handle:
            if size > max_bytes:
                handle.seek(size - max_bytes)
                handle.readline()          # drop the half line the seek landed in the middle of
            return handle.read()
    except (OSError, IOError, ValueError, AttributeError) as err:
        return "Kodi's own log could not be read: %s" % err


#: A PVR client that fails to start, as Kodi's own log writes it. Both halves are needed: the first
#: line names the addon and is written once, the second is the retry storm that costs the seconds.
_PVR_FAILED = re.compile(
    r'ADDON_STATUS.*?(pvr\.[a-z0-9_.]+) returned bad status "([^"]+)"'
    r'|<(pvr\.[a-z0-9_.]+)>: .*?(?:failed|Lost Connection|No connection)', re.IGNORECASE)


def failing_pvr_clients(exclude=("pvr.iptvsimple",)):
    """
    Which OTHER PVR clients on this box are failing, and how long the last start waited on them.

    Worth reporting and worth being careful about, in that order. Kodi creates its PVR clients one
    after another, and a client that cannot reach its backend does not fail fast — it retries on a
    timer and only then gives up, with everything behind it in the queue waiting. Measured off the
    owner's own phone log: `pvr.argustv` was created at 03:36:06.348, pinged a server that is not
    there once a second, gave up at 03:36:10.360, and `pvr.iptvsimple` — ours — only began its own
    Create at 03:36:10.369. Four seconds of a black screen and an empty channel list, every single
    start, and nothing on screen says which addon is spending them. Ours then loaded 769 channels and
    76,873 guide entries in 131 ms, which is the number that makes the four seconds worth naming.

    REPORTED, NEVER ACTED ON. Another PVR client is somebody's own installation; disabling or
    removing it is not a thing this addon may do quietly on their behalf, and "our diagnostics said
    it was slow" is not consent. So this returns text for a screen and a log line, and the decision
    stays with the person reading it.

    Read out of Kodi's log rather than asked of the addon API, because the API answers "installed and
    enabled" for a client that is enabled and broken — which is exactly the state that costs the time.
    """
    log = read_kodi_log(200 * 1024)
    if not log or log.startswith("Kodi's own log could not be read"):
        return []
    seen = {}
    for line in log.splitlines():
        match = _PVR_FAILED.search(line)
        if not match:
            continue
        name = match.group(1) or match.group(3)
        if not name or name in exclude:
            continue
        detail = match.group(2) or ""
        entry = seen.setdefault(name, {"addon": name, "status": "", "lines": 0})
        entry["lines"] += 1
        if detail:
            entry["status"] = detail
    return [seen[name] for name in sorted(seen)]


def clear_log():
    for candidate in (_path(), _path() + ".1"):
        try:
            if os.path.exists(candidate):
                os.remove(candidate)
        except OSError:
            pass
