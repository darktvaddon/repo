# -*- coding: utf-8 -*-
"""
The device-slot screen.

Every provider here caps devices per subscription, and hitting that cap is not an edge case — it is what
happens on the second install. What it looks like from the outside is a login that fails, which reads as
a wrong password, so the first thing people do is retype credentials that were never wrong. This screen
answers the actual question: what is holding my slots, which one is this box, and can I free one from
here.

The three backends differ in a way that has to be shown rather than smoothed over:

  * **Yettel** lists, renames and frees — fully self-service.
  * **Iris** lists, and nothing more. No call in the working Android client removes a device, and
    guessing an endpoint name against someone's live subscription is not something to do on their behalf.
  * **EON** offers a client nothing at all: its portal releases one device a month.

So the screen says which of those applies, per provider, instead of presenting a delete button that
sometimes works.
"""

import xbmcgui

from . import diag
from .i18n import T
from .provider import enabled_providers, ProviderError

#: Providers that cannot free a slot still get a line saying where it IS done, because "you cannot do
#: it here" without "here is where you can" is the kind of answer that produces a support message.
RELEASE_ELSEWHERE = {
    "eon": "EON oslobadja jedan uredjaj mesecno, sa svog portala (eon.tv -> Moj nalog -> Uredjaji).",
    "iris": "Iris ne dozvoljava brisanje uredjaja iz aplikacije. Oslobadja se preko MTS korisnickog "
            "servisa ili Iris portala.",
}


def _rows(settings):
    """
    (provider, devices, error) for every enabled provider that has slots to show.

    One provider failing must not empty the screen: a Yettel outage should still let someone look at
    their Iris slots, so each is collected separately and its failure travels with it.
    """
    out = []
    for provider in enabled_providers(settings):
        if not getattr(provider, "supports_devices", False):
            continue
        try:
            out.append((provider, provider.devices(), ""))
        except ProviderError as err:
            out.append((provider, [], err.message))
        except Exception as err:                                   # noqa: BLE001 - one provider only
            diag.log("Devices: %s failed — %s: %s" % (provider.label, type(err).__name__, err),
                     "ERROR")
            out.append((provider, [], "%s: %s" % (type(err).__name__, err)))
    return out


def _describe(provider, devices, error):
    lines = ["[B]%s[/B]" % provider.label]
    if error:
        # Translated HERE, not where it was raised: a provider error is usually built across several
        # source lines, and wrapping a multi-line literal is the kind of edit that changes a sentence
        # without anyone noticing. The finished sentence is the key.
        lines.append("  [COLOR red]%s[/COLOR]" % T(error))
        return lines
    if not devices:
        lines.append("  " + T("Nijedan uredjaj nije prijavljen."))
        return lines
    for device in devices:
        mark = "  [COLOR green]%s[/COLOR]" % T("(ovaj uredjaj)") if device.get("current") else ""
        detail = device.get("detail") or ""
        lines.append("  %s%s" % (device.get("name", "?"), mark))
        if detail:
            lines.append("      %s" % detail)
    if not provider.can_free_device:
        # Through the table like everything else on this screen. These three sentences were raw ASCII
        # Serbian: an English interface showed Serbian, and a Serbian one showed it without its letters
        # — on the screen whose whole job is explaining where a device slot goes.
        lines.append("  %s" % T(RELEASE_ELSEWHERE.get(
            provider.key, "Ovaj provajder ne dozvoljava brisanje odavde.")))
    return lines


def show(settings):
    """
    List the slots, then offer to free one where the provider allows it.

    A textviewer first and a chooser second, rather than one list of everything: the list is the answer
    most of the time, and putting deletable rows straight in front of someone whose only question was
    "what is using my slots" is how the wrong one gets removed.
    """
    rows = _rows(settings)
    if not rows:
        xbmcgui.Dialog().ok(T("IPTV Balkan — uredjaji"),
                            T("Nijedan ukljucen provajder ne prijavljuje uredjaje.\n\n"
                              "Iris i Yettel prijavljuju; EON ne nudi nista klijentu."))
        return

    lines = []
    for provider, devices, error in rows:
        lines.extend(_describe(provider, devices, error))
        lines.append("")
    xbmcgui.Dialog().textviewer(T("IPTV Balkan — uredjaji na pretplati"), "\n".join(lines))

    # Only what can actually be acted on reaches the chooser.
    freeable = []
    for provider, devices, error in rows:
        if error or not provider.can_free_device:
            continue
        for device in devices:
            freeable.append((provider, device))
    if not freeable:
        return

    labels = ["%s — %s%s" % (provider.label, device.get("name", "?"),
                            "  " + T("(ovaj uredjaj)") if device.get("current") else "")
              for provider, device in freeable]
    if not xbmcgui.Dialog().yesno(T("IPTV Balkan — uredjaji"),
                                  T("Zelis li da oslobodis neki slot?")):
        return
    chosen = xbmcgui.Dialog().select(T("Koji uredjaj da uklonim?"), labels)
    if chosen < 0:
        return
    provider, device = freeable[chosen]

    # Two confirmations, and the second one is not padding: removing the slot this box is using logs it
    # out, and that is a different mistake from removing an old phone.
    warning = (T("Ukloniti \"%s\" sa %s naloga?") % (device.get("name", "?"), provider.label))
    if device.get("current"):
        warning += T("\n\n[COLOR red]To je uredjaj na kom si sada.[/COLOR] Posle ovoga se ovaj Kodi "
                     "vise nece prijaviti dok se ponovo ne registruje.")
    if not xbmcgui.Dialog().yesno("IPTV Balkan", warning, yeslabel=T("Ukloni"), nolabel=T("Odustani")):
        return

    try:
        provider.free_device(device["id"])
    except (ProviderError, Exception) as err:                      # noqa: BLE001
        message = err.message if isinstance(err, ProviderError) else "%s: %s" % (type(err).__name__, err)
        diag.log("Devices: could not free %s on %s — %s" % (device.get("id"), provider.label, message),
                 "ERROR")
        xbmcgui.Dialog().ok(T("IPTV Balkan — uredjaji"), T("Uklanjanje nije uspelo:\n\n%s") % message)
        return

    diag.log("Devices: freed %s on %s" % (device.get("name"), provider.label))
    xbmcgui.Dialog().notification("IPTV Balkan", T("Uredjaj je uklonjen"), xbmcgui.NOTIFICATION_INFO, 4000)
