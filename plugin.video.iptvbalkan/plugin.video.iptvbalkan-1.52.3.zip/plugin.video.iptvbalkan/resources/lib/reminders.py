# -*- coding: utf-8 -*-
"""
"Tell me when this starts" — the one thing a television does that this addon could not.

WHY IT IS HERE AND NOT IN KODI. Kodi has timers and reminders, and they belong to the PVR client: a
backend declares timer support and Kodi draws the whole interface for it. IPTV Simple declares none —
it serves an M3U and an XMLTV and has nothing to schedule against — so on this product the row simply
is not in the guide's context menu, and no setting turns it on. It is the gap a paying viewer notices
first, because every set-top box they have owned had it.

So it is kept here, against the guide this addon already writes, and it works the only way it can:

  * a programme is remembered by CHANNEL and START TIME, off a search result — the one screen in this
    addon that lists future programmes with the data needed to identify them again;
  * the resident service is what watches the clock. It is already awake every ten seconds for the
    resume position and the heartbeat, so this costs one comparison per tick;
  * when the moment arrives the viewer is asked, once, and can be taken straight to the channel.

WHAT IT DELIBERATELY IS NOT. It does not record: nothing here can write a stream to disk, and a
"reminder" that looks like a recording is a promise this product cannot keep. It also does not survive
the programme moving — a match is (channel, start), so a delayed broadcast fires at the time that was
announced when it was set, which is the same thing a paper note on the fridge does. Both are honest
limits and both are said on screen rather than in a comment only.

THE FILE IS THE STATE. Two processes touch it — the plugin adds, the service fires — so it is written
through `store.write_json` like every other small file here, and neither side holds it in memory
between actions. See store.py for why a plain truncate is not enough on a box people unplug.
"""

import time

from . import diag, store
from .i18n import T

STORE = "reminders.json"

#: How long before the programme the viewer is asked. Two minutes, so there is time to walk to the
#: television and still catch the start, and not so early that the answer is forgotten.
LEAD_SECONDS = 120
#: How long AFTER the start a reminder is still worth firing. A box that was asleep or off comes back
#: to reminders that are already in the past; one for something that started four minutes ago is still
#: useful, and one for last Tuesday is noise. Beyond this the entry is dropped unfired.
GRACE_SECONDS = 600
#: A reminder further out than this is not accepted. The guide this addon writes reaches at most two
#: weeks, so beyond that there is nothing to have set one against.
MAX_AHEAD_SECONDS = 14 * 86400
#: A cap, so a stored file cannot grow without bound on a box nobody prunes.
MAX_ENTRIES = 100


def _path(settings):
    import os
    return os.path.join(settings.profile_dir(), STORE)


def load(settings):
    """Every reminder, oldest start first. Malformed rows are dropped rather than raising."""
    import json
    try:
        with open(_path(settings), "r", encoding="utf-8") as handle:
            data = json.loads(handle.read())
    except (OSError, IOError, ValueError):
        return []
    if not isinstance(data, list):
        return []
    out = []
    for row in data:
        if isinstance(row, dict) and row.get("start") and row.get("title"):
            out.append(row)
    out.sort(key=lambda r: int(r.get("start") or 0))
    return out


def _save(settings, rows):
    return store.write_json(_path(settings), rows[:MAX_ENTRIES])


def key_for(channel_id, start):
    return "%s@%s" % (channel_id or "", int(start or 0))


def add(settings, channel_id, channel_name, title, start, provider=""):
    """
    Remember one programme. Returns (ok, message) — the message is for the screen either way.

    Refusals are explicit rather than silent: a reminder that was not stored and said nothing is worse
    than no feature, because the viewer walks away believing they will be told.
    """
    start = int(start or 0)
    now = int(time.time())
    if start <= now:
        return False, T("Ta emisija je vec pocela.")
    if start - now > MAX_AHEAD_SECONDS:
        return False, T("To je predaleko — vodic ne ide toliko unapred.")
    rows = load(settings)
    key = key_for(channel_id, start)
    if any(row.get("key") == key for row in rows):
        return False, T("Podsetnik za tu emisiju vec postoji.")
    rows.append({
        "key": key,
        "channel_id": channel_id or "",
        "channel": channel_name or "",
        "title": title or "",
        "start": start,
        "provider": provider or "",
    })
    rows.sort(key=lambda r: int(r.get("start") or 0))
    if not _save(settings, rows):
        return False, T("Podsetnik nije mogao da se sacuva.")
    diag.log("Reminder: %s on %s at %s" % (title, channel_name,
                                           time.strftime("%Y-%m-%d %H:%M", time.localtime(start))))
    return True, T("Javicu ti kad krene.")


def forget(settings, key):
    rows = [row for row in load(settings) if row.get("key") != key]
    _save(settings, rows)


def due(settings, now=None):
    """
    (fire, keep) — the reminders whose moment has come, and what is left after them.

    Everything decided here rather than by the caller, because "due" is three rules and the service
    loop is not the place to keep them: a reminder is due from LEAD_SECONDS before the start until
    GRACE_SECONDS after it, and past that it is stale and goes without firing. The caller writes the
    survivors back, so a fired reminder cannot fire twice even if the box is restarted between ticks.
    """
    now = int(now or time.time())
    fire, keep = [], []
    for row in load(settings):
        start = int(row.get("start") or 0)
        if now >= start + GRACE_SECONDS:
            diag.log("Reminder: '%s' passed unfired (the box was off or asleep at %s)"
                     % (row.get("title") or "?",
                        time.strftime("%H:%M", time.localtime(start))))
            continue
        if now >= start - LEAD_SECONDS:
            fire.append(row)
            continue
        keep.append(row)
    return fire, keep


def keep_only(settings, rows):
    """Write back what survived a [due] pass."""
    _save(settings, rows)


def describe(row):
    """One reminder as a line for a list — the time first, because that is what is being scanned."""
    when = time.strftime("%d.%m. %H:%M", time.localtime(int(row.get("start") or 0)))
    parts = [when, row.get("title") or "?"]
    if row.get("channel"):
        parts.append(row["channel"])
    return "  —  ".join(parts)
