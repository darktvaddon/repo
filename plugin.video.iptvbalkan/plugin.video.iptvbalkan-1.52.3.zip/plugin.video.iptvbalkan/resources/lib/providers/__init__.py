# -*- coding: utf-8 -*-
"""Importing this package is what registers the providers — see provider.register."""

# ORDER MATTERS, and only here. A provider's block of channel numbers is the lowest one nobody holds
# (catalog._block_index), so on a FRESH install the first provider in this list gets block 0 — its own
# numbering, unshifted. `a1` was added alphabetically at the top and quietly took that from EON for
# anybody installing new. Existing boxes were never affected: their blocks are already written down.
from . import eon      # noqa: F401
from . import a1       # noqa: F401
from . import iris     # noqa: F401
from . import move     # noqa: F401
from . import yettel   # noqa: F401
from . import xtream   # noqa: F401  (also registers the plain-M3U provider)
