# -*- coding: utf-8 -*-
"""
Xtream Codes and plain M3U — the two that need no signing, no device registration and no session.

They are here because most users have one, and because they are the control group: when EON stops
playing and an Xtream channel on the same box plays fine, the problem is EON, not the network. That
single comparison has settled more support questions than any log line.
"""

import io
import json
import os
import re
import time

from .. import diag, localserver, m3uparse, net
from ..i18n import T
from ..provider import Provider, ProviderError, register



#: An Xtream panel's playlist address, which is what most "M3U links" sold in this market actually are.
#: `http://host:port/get.php?username=U&password=P&type=m3u_plus`
_XTREAM_GET = re.compile(r"^(https?://[^/]+)/get\.php\?(.+)$", re.I)


def xtream_bits(url):
    """
    (base, username, password) when [url] is an Xtream panel's get.php address, else None.

    WHY THIS MATTERS, measured on the owner's own list on 2026-08-03: that file is 6,974 rows and
    carries a tvg-id on **117** of them. So a playlist alone can never have a guide for more than those
    117 channels — the ids simply are not in it. The same panel's `player_api.php` knows an
    `epg_channel_id` for exactly those 117, an ARCHIVE for many more, and serves the whole guide at
    `xmltv.php` (2.5 MB, 6,986 programmes, 0.3 s).

    None of that needs the user to configure anything: the username and password are already in the
    address they pasted. So when the address is one of these, the playlist is read as a playlist and the
    panel is asked for what the playlist cannot carry.
    """
    match = _XTREAM_GET.match((url or "").strip())
    if not match:
        return None
    try:
        from urllib.parse import parse_qs
    except ImportError:                                            # pragma: no cover
        from urlparse import parse_qs
    query = parse_qs(match.group(2))
    user = (query.get("username") or [""])[0]
    password = (query.get("password") or [""])[0]
    if not user or not password:
        return None
    return match.group(1).rstrip("/"), user, password



def _guide_from_xmltv(session, url, channels, label):
    """One XMLTV document, reduced to the channels we actually listed. Shared by the two providers that
    get their guide as a file rather than as an API."""
    if not url:
        return []
    wanted = set(ch.get("tvg_id") for ch in channels or () if ch.get("tvg_id"))
    if not wanted:
        return []
    try:
        body = session.get(url, expect_json=False)
    except (net.HttpError, ProviderError) as err:
        diag.log("%s: the guide address did not answer (%s) — channels are unaffected" % (label, err),
                 "ERROR")
        return []
    rows = m3uparse.programmes(body if isinstance(body, str) else str(body or ""), wanted)
    diag.log("%s: %d programmes read from the guide" % (label, len(rows)))
    return rows


@register
class XtreamProvider(Provider):

    key = "xtream"
    label = "Xtream"
    supports_vod = True
    default_identity = {
        # Panels commonly gate on a player-ish UA; VLC's is the one nearly all of them accept.
        "user_agent": "VLC/3.0.20 LibVLC/3.0.20",
    }

    def __init__(self, settings):
        Provider.__init__(self, settings)
        self.session = net.Session(self.identity(), trace=settings.verbose())

    def _base(self):
        host = self.setting("host").rstrip("/")
        if not host:
            raise ProviderError("Xtream: enter the server address in settings.")
        if not host.startswith("http"):
            host = "http://" + host
        return host

    def _creds(self):
        user, password = self.setting("username"), self.setting("password")
        if not user or not password:
            raise ProviderError("Xtream: enter the username and password in settings.")
        return user, password

    def login(self):
        user, password = self._creds()
        data = self.session.get("%s/player_api.php?username=%s&password=%s" % (self._base(), user, password))
        info = (data or {}).get("user_info") or {}
        if str(info.get("auth", 1)) != "1":
            raise ProviderError("Xtream: the panel rejected these credentials.")
        status = str(info.get("status", "")).lower()
        if status and status != "active":
            raise ProviderError("Xtream: this account is %s." % status)
        exp = info.get("exp_date")
        if exp:
            diag.log("Xtream: account active until %s"
                     % time.strftime("%Y-%m-%d", time.gmtime(int(exp))))


    # ---- on demand --------------------------------------------------------
    #
    # Xtream panels carry a film and series library beside the channels, and until now this addon showed
    # neither: `supports_vod` was False, so an account with four thousand titles offered a channel list
    # and nothing else. The API is the same `player_api.php` the channel list already uses.
    #
    # Playback URLs are built, not fetched — the panel does not hand out a stream URL for a title, it
    # expects the client to assemble `/movie/<user>/<pass>/<id>.<ext>` from the fields in the listing.
    # `container_extension` matters: the same id under the wrong extension is a 404, and the panel does
    # not say so, it just serves nothing.

    #: How the Video klub addresses one playable title. The extension has to survive the round trip to
    #: the play route, which is handed an id and nothing else — so it rides along inside it.
    VOD_REF = "m"
    EPISODE_REF = "e"

    def _api(self, action=None, **params):
        user, password = self._creds()
        url = "%s/player_api.php?username=%s&password=%s" % (self._base(), user, password)
        if action:
            url += "&action=" + action
        for key, value in sorted(params.items()):
            url += "&%s=%s" % (key, value)
        return self.session.get(url)

    def vod(self, node=None):
        node = node or ""
        if not node:
            rows = [{"kind": "dir", "name": T("Filmovi"), "node": "movies"},
                    {"kind": "dir", "name": T("Serije"), "node": "series"}]
            return rows
        if node == "movies":
            return self._vod_categories("get_vod_categories", "moviecat")
        if node == "series":
            return self._vod_categories("get_series_categories", "seriescat")
        if node.startswith("moviecat:"):
            return self._vod_titles(node.split(":", 1)[1])
        if node.startswith("seriescat:"):
            return self._series_list(node.split(":", 1)[1])
        if node.startswith("series:"):
            return self._series_episodes(node.split(":", 1)[1])
        return []

    def _vod_categories(self, action, prefix):
        out = []
        for row in self._api(action) or []:
            cid = str((row or {}).get("category_id") or "")
            if cid:
                out.append({"kind": "dir",
                            "name": row.get("category_name") or cid,
                            "node": "%s:%s" % (prefix, cid)})
        return out

    def _vod_titles(self, category_id):
        out = []
        for row in self._api("get_vod_streams", category_id=category_id) or []:
            sid = str((row or {}).get("stream_id") or "")
            if not sid:
                continue
            out.append({
                "kind": "item",
                # Ids are namespaced and carry the extension, because the play route receives this and
                # nothing else — see VOD_REF.
                "id": "%s:%s:%s" % (self.VOD_REF, sid, row.get("container_extension") or "mp4"),
                "provider_ref": "%s:%s:%s" % (self.VOD_REF, sid, row.get("container_extension") or "mp4"),
                "name": row.get("name") or sid,
                "logo": row.get("stream_icon") or "",
                "plot": row.get("plot") or "",
                "series": False,
            })
        return out

    def _series_list(self, category_id):
        out = []
        for row in self._api("get_series", category_id=category_id) or []:
            sid = str((row or {}).get("series_id") or "")
            if not sid:
                continue
            out.append({"kind": "dir", "name": row.get("name") or sid,
                        "node": "series:%s" % sid,
                        "logo": row.get("cover") or "",
                        "plot": row.get("plot") or "",
                        "series": True})
        return out

    def _series_episodes(self, series_id):
        data = self._api("get_series_info", series_id=series_id) or {}
        seasons = data.get("episodes") or {}
        out = []
        # Season keys come back as strings ("1", "2", "10") and sorting them as strings puts season 10
        # between 1 and 2. The guide-facing order is the one a viewer expects, so they are sorted as
        # numbers where they look like numbers.
        def season_key(value):
            try:
                return (0, int(value))
            except (TypeError, ValueError):
                return (1, str(value))
        for season in sorted(seasons.keys(), key=season_key):
            for ep in seasons.get(season) or []:
                if not isinstance(ep, dict):
                    continue
                eid = str(ep.get("id") or "")
                if not eid:
                    continue
                info = ep.get("info") or {}
                number = ep.get("episode_num")
                label = ep.get("title") or info.get("name") or eid
                out.append({
                    "kind": "item",
                    "id": "%s:%s:%s" % (self.EPISODE_REF, eid,
                                        ep.get("container_extension") or "mp4"),
                    "provider_ref": "%s:%s:%s" % (self.EPISODE_REF, eid,
                                                  ep.get("container_extension") or "mp4"),
                    "name": u"%sx%02d  %s" % (season, int(number), label)
                            if str(number).isdigit() else label,
                    "logo": info.get("movie_image") or "",
                    "plot": info.get("plot") or "",
                    "series": True,
                })
        return out

    def resolve(self, channel_ref, at_utc=None, vod=False):
        """Live keeps the direct URL the channel list already carries; on demand is assembled here."""
        if not vod:
            return channel_ref
        user, password = self._creds()
        parts = str(channel_ref).split(":")
        if len(parts) != 3 or parts[0] not in (self.VOD_REF, self.EPISODE_REF):
            raise ProviderError("Xtream: nepoznat naslov (%s)." % channel_ref)
        kind, item_id, ext = parts
        folder = "movie" if kind == self.VOD_REF else "series"
        return "%s/%s/%s/%s/%s.%s" % (self._base(), folder, user, password, item_id, ext)

    def channels(self):
        user, password = self._creds()
        base = self._base()
        api = "%s/player_api.php?username=%s&password=%s" % (base, user, password)
        groups = {}
        for cat in self.session.get(api + "&action=get_live_categories") or []:
            groups[str(cat.get("category_id"))] = cat.get("category_name") or ""
        out = []
        for ch in self.session.get(api + "&action=get_live_streams") or []:
            sid = str(ch.get("stream_id"))
            group_name = groups.get(str(ch.get("category_id")), "")
            # THE ONLY SIGNAL AN XTREAM PANEL GIVES. Xtream Codes has no audio-only field: every live
            # entry is `stream_type: "live"` whether it is a television channel or a radio station, so
            # the category name is all there is — and every panel in this market names it plainly
            # ("RADIO", "RADIO STANICE", "SRB | RADIO"). Matched on the GROUP rather than the channel
            # name, because a television channel called "Radio Television of Serbia" is exactly the
            # false positive a name match produces, and it is a common channel here.
            audio_only = "radio" in group_name.lower()
            out.append({
                "id": "xtream_%s" % sid,
                "provider": self.key,
                # Written into the playlist as `provider="…"`. Every other provider already set this;
                # without it Xtream's channels carry no owner, so the catalogue cannot tell that a failed
                # Xtream refresh would be deleting channels it should be keeping (see catalog.build).
                "provider_label": self.label,
                "provider_ref": sid,
                "name": ch.get("name") or sid,
                "tvg_id": ch.get("epg_channel_id") or ("xtream_%s" % sid),
                "number": ch.get("num") or 0,
                "logo": ch.get("stream_icon") or "",
                "group": group_name,
                "radio": self.radio_flag(audio_only),
                "catchup_days": int(ch.get("tv_archive_duration") or 0) if ch.get("tv_archive") else 0,
                # Xtream archive URLs are templated, so IPTV Simple can build them itself — no per-tune
                # resolution needed, which is why this provider needs no plugin:// indirection at all.
                "catchup_source": ("%s/timeshift/%s/%s/{duration}/{Y}-{m}-{d}:{H}-{M}/%s.m3u8"
                                   % (base, user, password, sid)) if ch.get("tv_archive") else "",
                "headers": {"User-Agent": self.identity().get("user_agent", "")},
                "url": "%s/live/%s/%s/%s.m3u8" % (base, user, password, sid),
            })
        diag.log("Xtream: %d channels" % len(out))
        return out

    def epg(self, channels, hours_back=24, hours_forward=48):
        """
        The panel's own XMLTV, fetched and merged like every other provider's guide.

        This used to return nothing and rely on `xmltv_url()` — on the theory that IPTV Simple would be
        pointed at the panel directly. It cannot be: IPTV Simple reads exactly ONE guide file and that
        file is ours (the catalogue merges every provider into it). So an Xtream account had a channel
        list and no programmes at all, which is the "nema EPG" this was reported as.
        """
        del hours_back, hours_forward
        try:
            url = self.xmltv_url()
        except ProviderError:
            return []
        return _guide_from_xmltv(self.session, url, channels, self.label)

    def xmltv_url(self):
        user, password = self._creds()
        return "%s/xmltv.php?username=%s&password=%s" % (self._base(), user, password)

    def diagnose(self):
        """
        Three steps, three `try` blocks — which is the whole point of this screen.

        They used to share ONE, and that made the screen lie by omission: an exception in the reachability
        probe skipped the login and the channel count and reported the whole thing as a single failed
        "Account" row, so a panel that was simply down read as bad credentials. The row that broke has to
        be the row that says so, and every row after it still has to be attempted — that is the difference
        between "which step broke" and "something did".
        """
        rows = []
        try:
            ok, detail = net.probe(self.session, self._base() + "/player_api.php")
            rows.append(("Server reachable", ok, detail))
        except Exception as err:                                   # noqa: BLE001
            rows.append(("Server reachable", False, "%s: %s" % (type(err).__name__, err)))
        try:
            self.login()
            rows.append(("Account", True, "active"))
        except Exception as err:                                   # noqa: BLE001
            rows.append(("Account", False, str(err)))
            return rows
        try:
            channels = self.channels()
            rows.append(("Channel list", bool(channels), "%d channels" % len(channels)))
        except Exception as err:                                   # noqa: BLE001
            rows.append(("Channel list", False, "%s: %s" % (type(err).__name__, err)))
            return rows
        # No `diagnose_playback` here on purpose: an Xtream channel URL is BUILT, not resolved — there is
        # no second call to prove, and `resolve` would only hand back the string this file just composed.
        # A green row proving nothing is worse than no row.
        return rows


def _read_rows(path):
    """The cached VOD rows, or []. Deliberately NOT move.py's `_read_json`: that one answers {} for
    anything which is not a dict, and this cache is a list — which is how the Video klub came back
    empty from a file that had been written perfectly."""
    try:
        with io.open(path, "r", encoding="utf-8") as handle:
            data = json.loads(handle.read())
        return data if isinstance(data, list) else []
    except (OSError, IOError, ValueError):
        return []


def _write_rows(path, rows):
    """
    Replace the cache in one step, never truncate it in place.

    THE READER IS IN ANOTHER PROCESS. `open(path, "w")` empties the file at once and this one holds
    thousands of titles — 2.2 MB on a real account — so there is a window, on the slowest storage in the
    house, in which the Video klub reads half a JSON document. `_read_rows` answers [] to that, `vod()`
    answers [], and `video_club()` drops the provider from the list entirely: the M3U playlist simply is
    not there. Reported exactly that way — "after a refresh the M3U has no VOD" — and a refresh is
    precisely when somebody opens the club to look at what arrived.

    Worse than a race: a box switched off at the wall mid-write (the ordinary way a TV box is switched
    off) left the file truncated for GOOD, so the titles stayed missing until the next successful
    refresh. Same failure and same fix as accounts.json.
    """
    tmp = path + ".tmp"
    try:
        with io.open(tmp, "w", encoding="utf-8") as handle:
            handle.write(json.dumps(rows, ensure_ascii=False))
        os.replace(tmp, path)
    except (OSError, IOError, ValueError) as err:
        diag.log("M3U: the Video klub cache could not be written (%s)" % err, "ERROR")
        # Leaving a half-written temp file behind would fill the profile one refresh at a time.
        try:
            os.remove(tmp)
        except OSError:
            pass


@register
class M3uProvider(Provider):
    """A user-supplied playlist. No API, so nothing to break — but it still goes through the same
    identity and tracing, because a remote M3U can be blocked by UA exactly like anything else."""

    key = "m3u"
    label = "M3U playlist"
    #: Nothing to encrypt: this provider has no account at all, only a URL. Any credential a user needs
    #: is already inside that URL, and the vault does not touch it — encrypting `m3u_url` would break the
    #: settings screen, which is exactly the trade the vault was scoped to avoid.
    secret_fields = ()
    default_identity = {"user_agent": "VLC/3.0.20 LibVLC/3.0.20"}

    def __init__(self, settings):
        Provider.__init__(self, settings)
        self.session = net.Session(self.identity(), trace=settings.verbose())

    def login(self):
        if not self.setting("url"):
            raise ProviderError("M3U: enter the playlist address in settings.")

    def channels(self):
        """
        Fetch the playlist and merge it, like every other provider here.

        It used to `return []` and hand the address to `playlist_url()` instead, on the theory that
        IPTV Simple would read it directly — and nothing ever called that method. The result was a
        settings page with no code behind it: switch M3U on, type an address, and the refresh logs
        "0 channels, 0 programmes, 0s" with no error. That cannot be made to work by passing the URL
        through either, because IPTV Simple takes ONE playlist per instance and this addon already
        points it at its own merged file.
        """
        url = self.setting("url")
        if not url:
            raise ProviderError("M3U: enter the playlist address in settings.")
        body = self.session.get(url, expect_json=False)
        rows = m3uparse.parse(body if isinstance(body, str) else str(body or ""))
        if not rows:
            # Said out loud. The old silence is what made this look like it worked.
            raise ProviderError("M3U: the address answered, but no channels could be read out of it "
                                "(%d characters). Is it really a playlist?" % len(body or ""))
        identity_agent = self.identity().get("user_agent", "")
        # Films and episodes are NOT channels. A panel playlist carries all three in one file and the
        # address says which is which (see m3uparse.kind_of); imported as channels they become hundreds
        # of rows in the television list with no guide behind them — "filmove … vide se u kanalima i
        # nemam dugme za play programme nego samo switch". They are kept for the Video klub instead.
        self._vod_rows = [row for row in rows if row["kind"] != "live"]
        rows = [row for row in rows if row["kind"] == "live"]
        if self._vod_rows:
            _write_rows(self.cache_path("m3u_vod.json"), self._vod_rows)
            diag.log("M3U: %d live channels, and %d film(s)/episode(s) put in the Video klub"
                     % (len(rows), len(self._vod_rows)))
        # Only the live rows, and only when the address is a panel — see _enrich_from_panel.
        self._enrich_from_panel(rows)
        token = localserver.token(self.settings)
        routed = 0
        out = []
        for index, row in enumerate(rows):
            reference = row["tvg_id"] or ("m3u_%d" % (index + 1))
            headers = dict(row["headers"])
            headers.setdefault("User-Agent", identity_agent)
            out.append({
                "id": self.scoped("m3u_%s" % reference),
                "provider": self.key,
                "provider_label": self.label,
                "provider_ref": reference,
                "name": row["name"],
                # The playlist's OWN tvg-id is kept, because the guide that goes with it is keyed on
                # that id and on nothing else. Only a channel with no id at all gets one from us.
                "tvg_id": row["tvg_id"] or self.scoped("m3u_%s" % reference),
                "number": row["number"],
                "logo": row["logo"],
                "group": row["group"],
                # The playlist's own `radio="true"`, put through the same rule every provider uses: the
                # source is declaring what the station IS, and `radio_in_radio_list` decides which of
                # Kodi's players opens it. Carried straight through before, so this was the one provider
                # whose stations ignored that setting and kept cutting out under Kodi's audio player.
                "radio": self.radio_flag(row["radio"]),
                "catchup_days": row["catchup_days"],
                "catchup_source": row["catchup_source"],
                "catchup_mode": row["catchup_mode"],
                "headers": headers,
                "props": row["props"],
                "url": row["url"],
            })
            # THROUGH OUR OWN REDIRECTOR, and only for a panel's HLS. Measured on this panel: its
            # segments are addressed as `…00000474.ts?channelId=1&uid=…&hlsid=…`, i.e. the URL does not
            # END in a known extension — and FFmpeg 7 (Kodi 22) refuses exactly that, which is the wall
            # EON hit in 1.23.9 and the reason "nijedan kanal se ne pusta" came back after the switch to
            # HLS. The redirector already answers it: it rewrites each segment with `&ext=.ts` on the
            # end, which this panel ignores (checked live — same bytes, same 200), and the segments stay
            # ABSOLUTE so the box forwards a few kilobytes of text and never any video.
            if row.get("panel_ref") and token:
                out[-1]["url"] = localserver.url_for(token, self.key, row["panel_ref"],
                                                     self.account_id)
                out[-1]["inputstream"] = "inputstream.ffmpegdirect"
                out[-1]["manifest_type"] = "hls"
                routed += 1
        if routed:
            # Said out loud because the alternative is unanswerable from a log: after 1.34.1 the owner's
            # phone still showed the panel's own address in Kodi's log, and the only way to tell whether
            # the rewrite had happened at all was to read the playlist file off the device. It had; Kodi
            # was still holding the list it loaded before the refresh.
            diag.log("M3U: %d channel(s) play through this box's own server, which answers the probe "
                     "Kodi makes before every tune — the panel does not" % routed)
        diag.log("M3U: %d channels read from the playlist" % len(out))
        return out

    def epg(self, channels, hours_back=24, hours_forward=48):
        """
        The XMLTV that goes with the playlist — typed in, or worked out from the playlist address.

        Most "M3U links" in this market are an Xtream panel's `get.php`, and that address already
        carries the username and password. So when nobody has filled the guide field in, the panel's own
        `xmltv.php` is derived from it rather than left empty: reported as "nema EPG", and it was simply
        a second address nobody knew they had to paste.
        """
        del hours_back, hours_forward
        url = self.setting("epg_url")
        # A PLAYLIST ADDRESS IS NOT A GUIDE ADDRESS, and the two fields sit next to each other.
        #
        # Read off the owner's own phone: `M3U: 0 programmes read from the guide`, and the line above it
        # in the trace is the guide answering `#EXTM3U`. The same get.php address had been pasted into
        # both fields — which is the obvious thing to do, since it is the only address anybody was
        # given. Parsed as XMLTV a playlist yields nothing, silently, for ever.
        if url and xtream_bits(url):
            diag.log("M3U: the guide field holds the PLAYLIST address (get.php), which is not a guide — "
                     "using the panel's own xmltv.php instead")
            url = ""
        if not url:
            url = self._panel_xmltv()
            if url:
                diag.log("M3U: the guide comes from the panel's own xmltv.php")
        return _guide_from_xmltv(self.session, url, channels, "M3U")

    def _panel(self):
        """The panel behind this playlist address, or None. See xtream_bits."""
        return xtream_bits(self.setting("url"))

    def _panel_xmltv(self):
        bits = self._panel()
        return "%s/xmltv.php?username=%s&password=%s" % bits if bits else ""

    def _enrich_from_panel(self, rows):
        """
        Fill in what the playlist file leaves out, from the panel's own API.

        Measured on a real list: 6,974 rows, a tvg-id on 117 of them, and no archive information at all
        — while `player_api.php` knows the guide id for those 117 AND that a further several hundred
        channels keep a 24-hour archive. One request (about 130 KB) buys both, and the rows are matched
        by the stream id that is already the last part of every live URL.

        Never fatal: a panel that does not answer leaves the playlist exactly as it was.
        """
        bits = self._panel()
        if not bits:
            return
        base, user, password = bits
        try:
            streams = self.session.get("%s/player_api.php?username=%s&password=%s&action=get_live_streams"
                                       % (base, user, password)) or []
        except (net.HttpError, ProviderError) as err:
            diag.log("M3U: the panel's API did not answer (%s) — the playlist is used as it is" % err)
            return
        by_id = {}
        for stream in streams:
            if isinstance(stream, dict) and stream.get("stream_id") is not None:
                by_id[str(stream["stream_id"])] = stream
        if not by_id:
            return

        # HLS RATHER THAN A RAW TS SOCKET, when the panel offers it.
        #
        # `type=m3u_plus&output=mpegts` hands out addresses like `http://host/user/pass/1` — one endless
        # MPEG-TS socket with no extension on the end. On a phone that is the worst of both worlds:
        # nothing recovers a stalled read (there is no manifest to re-fetch, so Kodi simply waits, and
        # "zakuca, moram da ugasim Kodi" is what that looks like from the sofa), and FFmpeg 7 — Kodi 22 —
        # is unhappy with extensionless segment names, which is the same wall EON hit in 1.23.9.
        #
        # The same panel serves `/live/user/pass/<id>.m3u8`: a real HLS manifest whose segments are
        # named `.ts`. Checked against the live panel before switching anything, and only used when the
        # panel itself says it is allowed — `allowed_output_formats` is in its own login answer, so this
        # is asked rather than assumed.
        hls = False
        try:
            info = (self.session.get("%s/player_api.php?username=%s&password=%s" % (base, user, password))
                    or {}).get("user_info") or {}
            hls = "m3u8" in [str(f).lower() for f in (info.get("allowed_output_formats") or [])]
        except (net.HttpError, ProviderError):
            hls = False

        filled_ids, filled_archive, switched = 0, 0, 0
        for row in rows:
            sid = str(row.get("url") or "").rstrip("/").rsplit("/", 1)[-1].split(".")[0]
            stream = by_id.get(sid)
            if not stream:
                continue
            epg_id = str(stream.get("epg_channel_id") or "").strip()
            if epg_id and not row.get("tvg_id"):
                row["tvg_id"] = epg_id
                filled_ids += 1
            if hls:
                row["url"] = "%s/live/%s/%s/%s.m3u8" % (base, user, password, sid)
                row["panel_ref"] = sid
                switched += 1
            if stream.get("tv_archive") and not row.get("catchup_days"):
                # Minutes in this panel's answer, days in ours — 1440 is one day, not four years.
                minutes = int(stream.get("tv_archive_duration") or 0)
                days = max(1, minutes // 1440) if minutes > 60 else minutes
                row["catchup_days"] = days
                row["catchup_source"] = ("%s/timeshift/%s/%s/{duration}/{Y}-{m}-{d}:{H}-{M}/%s.m3u8"
                                         % (base, user, password, sid))
                filled_archive += 1
        if filled_ids or filled_archive:
            diag.log("M3U: the panel filled in %d guide id(s) and %d archive(s) the playlist did not "
                     "carry" % (filled_ids, filled_archive))
        if switched:
            diag.log("M3U: %d channel(s) switched to the panel's HLS form — a manifest recovers from a "
                     "stall, an endless TS socket does not" % switched)

    # ---- the Video klub ---------------------------------------------------
    #
    # Built from the same playlist, cached to disk at refresh time: the plugin process that draws the
    # Video klub is not the one that fetched the list, and re-downloading several megabytes to open a
    # menu is exactly the mistake the other providers already learned not to make.

    supports_vod = True

    def vod(self, node=None):
        rows = _read_rows(self.cache_path("m3u_vod.json"))
        if not rows:
            return []
        node = node or ""
        if not node:
            groups = {}
            for row in rows:
                label = row.get("group") or T("Ostalo")
                groups[label] = groups.get(label, 0) + 1
            return [{"kind": "dir", "name": "%s (%d)" % (label, count), "node": "g:%s" % label}
                    for label, count in sorted(groups.items(), key=lambda kv: (-kv[1], kv[0]))]
        if node.startswith("g:"):
            wanted = node[2:]
            # `id`, NOT `ref`. `video_club()` builds the play URL from `entry["id"]` — every other
            # provider emits that — so a row keyed `ref` produced `…&id=&vod=1` and the film simply did
            # not start. The Video klub LISTED all 6417 titles perfectly, which is why this survived:
            # the tree was checked and playing one was not. Nothing anywhere read `ref`.
            #
            # For this provider the id IS the address: `resolve()` hands it straight back, because a
            # plain playlist has nothing to mint.
            return [{"kind": "item",
                     "name": row.get("name") or "?",
                     "logo": row.get("logo") or "",
                     "id": row.get("url") or "",
                     "series": row.get("kind") == "series"}
                    for row in rows if (row.get("group") or T("Ostalo")) == wanted]
        return []

    def resolve(self, channel_ref, at_utc=None, vod=False):
        """
        Live and on demand are both a plain URL here — the playlist already carried it.

        The exception is a panel channel going through the redirector: there the playlist carries the
        loopback address, so what comes back here is the panel's own STREAM ID and the manifest has to
        be built again. Anything that already looks like an address is handed straight back, which is
        every VOD title and every ordinary playlist row.
        """
        del at_utc, vod
        reference = str(channel_ref)
        if "://" not in reference:
            bits = self._panel()
            if bits and reference.isdigit():
                base, user, password = bits
                return "%s/live/%s/%s/%s.m3u8" % (base, user, password, reference)
        return reference

    def playlist_url(self):
        return self.setting("url")

    def xmltv_url(self):
        return self.setting("epg_url")

    def diagnose(self):
        url = self.setting("url")
        if not url:
            return [("Playlist address", False, "not set")]
        ok, detail = net.probe(self.session, url)
        return [("Playlist reachable", ok, detail)]
