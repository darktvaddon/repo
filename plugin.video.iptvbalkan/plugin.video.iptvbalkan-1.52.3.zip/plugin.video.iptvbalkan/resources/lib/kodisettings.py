# -*- coding: utf-8 -*-
"""
Two of Kodi's OWN settings that decide whether this addon looks finished, and the rule for touching them.

An addon may not simply reconfigure somebody's Kodi. The rule here is the one `service.py` already uses
for IPTV Simple's instance preferences, and it is the whole reason this file is small: **change it only
while it still holds Kodi's default**. The moment the owner has chosen a value themselves, that value is
theirs and this stops touching it — permanently, because Kodi tells us what its default was.

    epg.pastdaystodisplay   how much PAST guide Kodi keeps. Default 1 day.
    locale.language         Kodi's own interface language, which is what the SETTINGS screen follows.

The first one is not cosmetic. A box downloading four days of archive and keeping one day of guide is
a box where three of those days cannot be opened at all: the programme is in our file, IPTV Simple
hands it over, and Kodi drops it because it falls outside the window it was told to display. That is
"the archive only goes back to yesterday", reported as "Play programme does nothing".
"""

import json

from . import diag

try:
    import xbmc
    _IN_KODI = True
except ImportError:                                                # tooling / unit tests
    xbmc = None
    _IN_KODI = False

#: What Kodi calls "Serbian" is the LATIN resource, and that is the id to install and to set. The plain
#: `resource.language.sr_rs` is the Cyrillic one; on a box that has never had it, setting it does
#: nothing at all and the addon looks broken — which is exactly what the owner reported.
SERBIAN_RESOURCES = ("resource.language.sr_rs@latin", "resource.language.sr_rs")


def _rpc(method, params=None):
    """One JSON-RPC round trip into the Kodi we are running inside."""
    if not _IN_KODI:
        return {}
    request = {"jsonrpc": "2.0", "id": 1, "method": method, "params": params or {}}
    try:
        return json.loads(xbmc.executeJSONRPC(json.dumps(request))) or {}
    except Exception as err:                                       # noqa: BLE001
        diag.log("Kodi settings: %s failed — %s: %s" % (method, type(err).__name__, err), "ERROR")
        return {}


def setting(name):
    """(value, default) for one of Kodi's settings, or (None, None) if it cannot be read."""
    answer = _rpc("Settings.GetSettings", {"level": "expert"})
    for row in ((answer.get("result") or {}).get("settings") or []):
        if row.get("id") == name:
            return row.get("value"), row.get("default")
    return None, None


def set_setting(name, value):
    answer = _rpc("Settings.SetSettingValue", {"setting": name, "value": value})
    return bool(answer.get("result"))


def past_guide_days(wanted):
    """
    How many days of PAST guide it is worth downloading — never more than Kodi will keep.

    The other half of [align_guide_window]. That one raises Kodi's window to match the addon while the
    setting is still at its default; this one gives way when the owner has set it themselves, because
    Kodi's number is the one that decides what a viewer can actually open. Downloading seven days into
    a box that keeps two spends the requests, the minutes and the disk on five days that Kodi drops on
    import — invisible, unopenable, and not free:

      * a customer's Move refresh (1.40.1, 2026-08-06) asked for seven days back and was REFUSED
        outright — that provider's guide endpoint has a ceiling — while his Kodi kept two, which is
        inside it. The wasted half of the request was also the half that broke it.
      * even where it succeeds it is five passes instead of one, and the guide budget then runs out
        before the far end arrives anyway.

    Returns [wanted] unchanged when Kodi cannot be asked (tooling, unit tests) or when its window is
    at least as wide — this only ever REDUCES, and only against a number read from Kodi itself.
    """
    wanted = max(0, int(wanted))
    value, _default = setting("epg.pastdaystodisplay")
    if value is None:
        return wanted
    kept = max(0, int(value))
    return kept if kept < wanted else wanted


def guide_window_report(settings):
    """
    The archive-depth answer, as plain lines for the diagnostics screen and the panel's diagnostics
    command.

    "The archive only goes back a day" is a report whose answer has so far lived in one INFO line in
    the log (catalog.build writes it when the download is clamped) — which means reading it takes a
    visit to the box, for a question two numbers answer: what this addon is set to download, and how
    much past guide Kodi keeps. This puts both numbers, and the one that WINS, on the screen where
    support already looks. The provider may of course hold even less than the winning number — that
    ceiling is theirs, not ours, and it is not claimed here.
    """
    from .i18n import T
    wanted = settings.epg_days_back()
    lines = [T("podeseno u dodatku: %d dan(a) unazad, %d unapred")
             % (wanted, settings.epg_days_forward())]
    value, _default = setting("epg.pastdaystodisplay")
    if value is None:
        # Tooling, or a Kodi whose JSON-RPC is not answering: there is no number to compare against,
        # and inventing one would put a depth nobody measured on a diagnostics screen.
        lines.append(T("Kodi nije mogao da bude pitan koliko proslog vodica cuva — koristi se "
                       "podeseno"))
        return lines
    kept = max(0, int(value))
    effective = kept if kept < wanted else wanted
    lines.append(T("Kodi cuva: %d dan(a) proslog vodica (Podesavanja -> PVR -> Vodic)") % kept)
    lines.append(T("preuzima se: %d dan(a) unazad — starijih emisija na ovom uredjaju nema")
                 % effective)
    if kept < wanted:
        lines.append(T("da bi bilo svih %d, podigni Kodijev broj; dodatak ga prati na sledecem "
                       "osvezavanju") % wanted)
    return lines


def align_guide_window(days_back):
    """
    Keep as much past guide as this addon downloads — but only while Kodi is still on its own default.

    Returns a short description if something was changed, "" otherwise.
    """
    value, default = setting("epg.pastdaystodisplay")
    if value is None:
        return ""
    if value != default:
        # The owner has an opinion. Say it once, at INFO, because "my archive only goes back a day" is
        # otherwise a mystery with the answer sitting in Kodi's own settings.
        if value < days_back:
            diag.log("Kodi keeps %s day(s) of past guide and this addon downloads %s — the older "
                     "programmes will not appear. That setting is yours (Settings -> PVR -> Guide), "
                     "so it is left alone." % (value, days_back))
        return ""
    if value >= days_back:
        return ""
    if not set_setting("epg.pastdaystodisplay", int(days_back)):
        return ""
    diag.log("Kodi kept %s day(s) of past guide; raised to %s to match what the archive offers"
             % (value, days_back))
    return "guide window %s -> %s days" % (value, days_back)


def kodi_is_serbian():
    """True for either script. `endswith("sr_rs")` missed the Latin one — the id ends in "@latin" —
    so the offer went on being made to somebody who had already accepted it."""
    return "sr_rs" in str(setting("locale.language")[0] or "")


def offer_serbian(ask):
    """
    Kodi's SETTINGS screen is drawn by Kodi and follows KODI's language, not ours.

    The addon translates everything it draws itself; the one screen it cannot is the settings dialog,
    because that belongs to Kodi. So when somebody has chosen Serbian here and Kodi is in English, the
    honest thing is to offer the one change that finishes the job — and to ask, because switching the
    whole interface is not a decision an addon gets to make quietly.

    [ask] is a callable answering True/False, so the decision (and the dialog) stays with the caller.
    Returns True if Kodi was switched.
    """
    if kodi_is_serbian():
        return False
    if not ask():
        return False
    for resource in SERBIAN_RESOURCES:
        # InstallAddon is Kodi's own builtin for this and is a no-op when the resource is already
        # there. It is also silent when the id does not exist, which is why the result is CHECKED
        # below rather than assumed.
        xbmc.executebuiltin("InstallAddon(%s)" % resource, True)
        if not set_setting("locale.language", resource):
            continue
        # Read it back. `Settings.SetSettingValue` answers true for a value Kodi then refuses (an
        # uninstalled resource is exactly that case), and an addon that says "done" and changed
        # nothing is the failure this project has paid for more than once.
        if kodi_is_serbian():
            diag.log("Kodi's interface language switched to %s at the user's request" % resource)
            return True
    diag.log("Kodi's language could not be switched to Serbian — neither resource could be installed "
             "or set; opening Kodi's own language screen instead", "ERROR")
    return False


def open_language_screen():
    """
    The fallback, and it is a real answer rather than an apology.

    If the switch cannot be made from here — no network for the language resource, a build that refuses
    the change, anything — the one thing this addon can still do is put the user in front of the screen
    where it is one press away, instead of leaving them with a row that does nothing.
    """
    xbmc.executebuiltin("ActivateWindow(Settings)")
    xbmc.sleep(500)
    # Interface -> Regional, which is where Language lives in Kodi 19+.
    xbmc.executebuiltin("SetFocus(-1)")
    diag.log("Opened Kodi's settings so the language can be changed by hand")
