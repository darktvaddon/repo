# -*- coding: utf-8 -*-
"""
What every provider looks like from the outside, and the two things they all get for free.

**Identity is data.** Each provider declares its default network identity (User-Agent, Origin, Referer,
device descriptors), and every field can be overridden from the settings screen without touching code.
This is the whole reason this addon exists: when a provider blocklists a string, the fix has to be a
text field, not a new build.

**The device id is ours to keep.** Every one of these services counts devices per subscription, and a
client that mints a fresh id on each login burns a slot every time until the account hits its ceiling.
So the id is generated ONCE, written back to settings, and reused — and it is visible in the settings
screen so the same slot can be shared with another install instead of spending a second one.
"""

import uuid

from . import diag, licence, vault


class ProviderError(Exception):
    """A failure the user can act on. [message] is shown as-is, so it must be written for them."""

    def __init__(self, message, retryable=False):
        super(ProviderError, self).__init__(message)
        self.message = message
        self.retryable = retryable


def tuned_value(settings, name, fallback):
    """
    A server-steered constant, off the signed licence answer — see `Provider.tuned` for the whole story.

    A FUNCTION as well as a method because the values are needed where there is no provider instance:
    Yettel's pairing flow is three module-level functions that run before any account exists, and its
    `clientTag` is exactly the sort of value that starts being refused — so the one flow that cannot be
    retried on a new release was the one flow that could not be steered.
    """
    try:
        value = licence.params(settings).get(name)
    except Exception:                                              # noqa: BLE001
        # A missing or unreadable licence file must never be the reason a provider cannot log in.
        return fallback
    value = str(value or "").strip()
    return value or fallback


class Provider(object):
    """
    Subclasses implement whichever of these they support and leave the rest alone. Everything returns
    plain dicts in the shape playlist.py writes, so no provider type leaks past this boundary.
    """

    #: settings prefix, e.g. "eon" -> eon_username, eon_password, eon_device_id, eon_user_agent
    key = None
    #: shown in the settings screen and in every log line this provider writes
    label = None
    #: identity defaults; anything here can be overridden per-install from settings
    default_identity = {}
    #: Whether [resolve] understands `vod=True`. Declared rather than sniffed at call time — see the
    #: comment in default.py's play route on why catching a TypeError instead is a trap.
    supports_vod = False
    #: Whether [search] is implemented against a real backend query. False means search.py walks the
    #: VOD tree instead — slower, but it finds things.
    supports_search = False
    #: How deep that walk goes for THIS provider. None means search.WALK_DEPTH, which reaches titles on
    #: a two-level tree. A provider whose titles live one level deeper has to say so, or the walk stops
    #: on the folders above them and the search finds nothing while appearing to work.
    vod_walk_depth = None
    #: Whether [devices] can list this subscription's device slots. Separate from [can_free_device]
    #: because the two are genuinely different: Iris will TELL you what is registered but not let you
    #: remove anything, and a screen that offers a delete button which always fails is worse than one
    #: that says plainly where the release has to be done.
    supports_devices = False
    #: Whether [free_device] works. Yettel frees a slot on request; EON releases one per month from its
    #: own portal and offers nothing to a client.
    can_free_device = False
    #: The value names the credential vault should encrypt for this provider, WITHOUT the `<key>_`
    #: prefix. Declared per provider rather than probed from a fixed list: the service used to ask every
    #: provider for `app_token_secret`, which only Yettel has, so each pass asked Kodi for
    #: `eon_app_token_secret` and `iris_app_token_secret` — settings nothing declares. Kodi answers an
    #: undeclared setting with a debug line and carries on, so this never failed; it just meant the one
    #: cheap verification this project relies on ("run with debug on, grep the log for `was not found`")
    #: could never come back clean, and a real missing setting had two decoys to hide behind.
    secret_fields = ("password",)

    def __init__(self, settings):
        self.settings = settings
        #: "" for the account configured the ordinary way, a short suffix for every extra one. It ends
        #: up in channel ids, play URLs and cache file names — everywhere two accounts of the same
        #: provider would otherwise collide.
        self.account_id = getattr(settings, "account_id", "")
        if self.account_id:
            self.label = "%s (%s)" % (self.label, getattr(settings, "account_name", self.account_id))

    # ---- settings helpers -------------------------------------------------

    def scoped(self, value):
        """
        [value] with this account's suffix, or unchanged for the first account.

        Used for channel ids and for the `provider=` half of a play URL. The first account gets no
        suffix on purpose: those ids are already written into IPTV Simple's database and Kodi's PVR
        tables, and changing them would reset every existing user's channel list and favourites.
        """
        from . import accounts
        return value if not self.account_id else "%s%s%s" % (value, accounts.SEP, self.account_id)

    def _account_param(self):
        """The `&account=` a play URL needs, or "" for the first account — see [scoped]."""
        return "" if not self.account_id else "&account=%s" % self.account_id

    def cache_path(self, name):
        """A per-account file beside the playlist. Two accounts sharing one cache file would hand each
        other's stream descriptors to the player."""
        import os
        prefix = "%s-" % self.account_id if self.account_id else ""
        return os.path.join(self.settings.profile_dir(), prefix + name)

    def tuned(self, name, fallback):
        """
        A value the SERVER may have replaced, or the one this build was shipped with.

        WHY THIS EXISTS. A handful of constants decide whether a provider answers at all — EON's broker
        address, its client id and secret, the api prefix, the player names. When the provider changes
        one, every copy of the addon stops at once, and until now the only cure was a new release: build
        it, publish it, and wait up to six hours for each box to notice.

        These now ride down inside the SIGNED licence answer, so the fix is a field in the panel and the
        boxes have it at their next check. The shipped constant stays as the fallback, which is what
        makes this safe to leave switched off: a server that says nothing, an unlicensed box, a box that
        has never had a verified answer — all of them behave exactly as before.

        It is also the one protection measure that costs a cracked copy something real. A patched build
        never receives a signed answer, so it never receives a new value; it keeps whatever was in the
        public zip and stops working the first time the provider moves. Nothing here LOCKS it — it
        simply stops being maintained, which is the only leverage this project actually has.
        """
        return tuned_value(self.settings, name, fallback)

    def setting(self, name, default=""):
        """
        One setting for this provider and this account.

        The ONE read path, which is why the vault plugs in here rather than into each provider: five
        providers each remembering to decrypt is five chances to forget, and forgetting looks like a
        password that is simply wrong.

        A secret that cannot be decrypted raises rather than returning "" — an empty password produces
        "check your username and password" from the provider, which sends the user to re-type
        credentials that were never the problem. [Locked] says what actually happened.

        SINCE 1.28.0 THIS IS ALSO WHERE ACTIVATION HAPPENS, and it belongs here for the same reason the
        decryption does: this is the one place a credential is read. A plaintext password is encrypted
        on the way out when a key exists, and refused when none does — so a build with the licence check
        cut out cannot simply have its owner type their own credentials in and carry on. Before this,
        that was the whole story: the vault protected a copied profile and nobody else.

        `remember` is passed as the writer rather than `settings.set`, so an extra account's password is
        written back into accounts.json where it lives, and a failed write is logged instead of lost.
        """
        value = self.settings.get("%s_%s" % (self.key, name), default)
        if not isinstance(value, str):
            return value
        try:
            return vault.secure(self.settings, "%s_%s" % (self.key, name), value,
                                lambda _full, blob: self.remember(name, blob))
        except vault.Locked as err:
            raise ProviderError(
                # WRITTEN WITH ITS LETTERS. The ASCII spelling is a convention for strings that go
                # through the translation table, which restores the letters on the way to the
                # screen — this one never did: it is built by interpolation, so no table entry
                # can match it and it reached the television exactly as typed. Half a sentence in
                # each spelling ("Poveži uredjaj … cim potvrdi") on the one message a customer
                # sees when their logins stop working.
                "%s: podaci za prijavu su zaključani — %s. Poveži uređaj na internet; čim potvrdi "
                "licencu, prijava radi sama. Lozinku ne treba ponovo kucati." % (self.label, err))

    def remember(self, name, value):
        """
        Write one of this account's own values back, and SAY SO when it did not stick.

        Everything that goes through here is an identity the provider counts — a device id, EON's device
        number, a borrowed Yettel udid. Losing one is not a failure anybody sees: the next login simply
        mints a fresh identity and spends another of the subscription's device slots, and it keeps doing
        that until the account refuses to register anything more. Iris allows three.

        Two ways to lose one, and neither raises. The write can fail outright (a handle with no addon
        context — see settings.ADDON_ID), which the return value catches. Or Kodi's SETTINGS DIALOG can
        be open: it holds its own copy of every value and writes that copy back over settings.xml when it
        closes, so anything saved behind it is discarded a few seconds later. That one cannot be
        prevented from here — the dialog belongs to Kodi — but it can stop being invisible, which is why
        it is named in the log rather than merely suspected.
        """
        if not self.settings.set("%s_%s" % (self.key, name), value):
            diag.log("%s: %s_%s could not be saved — this account will register a NEW device on the "
                     "next login and spend another slot" % (self.label, self.key, name), "ERROR")
            return False
        try:
            import xbmc
            if xbmc.getCondVisibility("Window.IsActive(addonsettings)"):
                diag.log("%s: %s_%s was saved while the addon's settings screen is OPEN — close it "
                         "now, or Kodi will write its own copy back over this and the identity is lost"
                         % (self.label, self.key, name), "ERROR")
        except Exception:                                              # noqa: BLE001 - not in Kodi
            pass
        return True

    def identity(self):
        """Defaults, then every non-empty override from settings. Written this way round so a blank
        field means 'use the default' rather than 'send nothing' — an empty User-Agent is a fingerprint
        of its own."""
        ident = dict(self.default_identity)
        for field in ("user_agent", "origin", "referer", "accept_language"):
            override = self.setting(field)
            if override:
                ident[field] = override
        return ident

    def device_id(self):
        """
        The stable per-install id this account knows as 'this device'.

        Minted once and written straight back to settings. The write is the load-bearing part: a client
        that forgets its id registers a NEW device on every login, and the user only finds out when the
        account refuses the next one because its device slots are full. Paste the same value into a
        second install to have both share one slot.
        """
        existing = self.setting("device_id")
        if existing:
            return existing
        fresh = str(uuid.uuid4())
        self.remember("device_id", fresh)
        diag.log("%s: minted a device id for this install (%s…) — paste it into another install to "
                 "share the same device slot" % (self.label, fresh[:8]))
        return fresh

    # ---- shutdown ---------------------------------------------------------

    #: Set by catalog.build to whatever answers "has Kodi asked us to stop" — `Monitor.abortRequested`
    #: from the service, the same from the plugin process. None while nothing is watching.
    should_stop = None

    def stopping(self):
        """
        True once Kodi wants this process gone.

        Asked inside the long loops, and the reason is a freeze rather than tidiness. A full refresh is
        301 EON requests plus Iris on top — measured at 114 s and 42 s on the owner's box, a minute and
        a half to two and a half minutes during which the old loops looked at nothing but their own
        budget. Kodi does not kill a running script on shutdown: it asks, and then WAITS, and on Android
        that wait happens inside `NativeActivity.onDestroy` on the UI thread. Long enough and the system
        reports "isn't responding" over a black screen — which is exactly what a frozen box looks like
        from the sofa, and there is nothing in any log to say the addon was merely busy.

        Deliberately swallowing: a callable that raises must not be the thing that stops a refresh.
        """
        try:
            return bool(self.should_stop and self.should_stop())
        except Exception:                                          # noqa: BLE001
            return False

    # ---- the interface ----------------------------------------------------

    def enabled(self):
        return self.settings.get_bool("%s_enabled" % self.key, False)

    def login(self):
        """Establish a session. Raise [ProviderError] with something the user can act on."""
        raise NotImplementedError

    def channels(self):
        """List of channel dicts (see playlist.write_m3u for the shape)."""
        raise NotImplementedError

    def epg(self, channels, hours_back=24, hours_forward=48):
        """List of programme dicts. Providers with no guide return []."""
        return []

    def resolve(self, channel, at_utc=None):
        """
        Playable URL for [channel]. [at_utc] set means catch-up.

        Providers whose URLs are stable put them straight in the playlist and never implement this;
        providers that mint a short-lived signed URL per tune resolve through the plugin:// route.
        """
        raise NotImplementedError

    def playing_url(self):
        """
        The stream this provider last handed to the player, or "" when it has none open.

        Only providers that need a keepalive implement it, and the service uses it to tell "my stream is
        still on screen" from "something else is playing now" — see _heartbeat in service.py.
        """
        return ""

    def stop_heartbeat(self):
        """Forget whatever [playing_url] would return. Safe to call when there is nothing to forget."""

    def vod(self, node=None):
        """
        One level of the on-demand tree. Return [] when the provider has no VOD.

        [node] is None at the top and otherwise whatever a previous entry put in its own `node` — an
        opaque string this provider chose, so no two providers have to agree on a scheme. Entries are
        plain dicts, and only `kind` and `name` are required:

            {"kind": "dir",  "name": "Filmovi: Akcija", "node": "movies/Akcija",
             "logo": "", "plot": ""}
            {"kind": "item", "name": "Ime filma", "id": "12345",
             "logo": "", "plot": "", "year": 2024, "duration": 5400}

        A `dir` is asked for again with its own node; an `item` is played through the normal play route
        with `vod=<id>`, so on-demand and live share one resolver rather than growing a second one.
        """
        return []

    def search(self, term):
        """
        On-demand titles matching [term], in the same entry shape [vod] returns.

        Only implement this where the backend HAS a search, and where that search was verified to
        FILTER. Declaring `supports_search` over an endpoint that quietly ignores the term is worse
        than leaving it alone: search.py's fallback walks the tree this provider already lists, and a
        walk that finds everything slowly beats a query that confidently returns the wrong page. EON's
        `v1/vodassets` is exactly that trap — it accepts `search=`, `title=`, `query=`, `name=`, `q=`,
        `text=`, `keyword=` and `filter=`, and answers all eight with the unfiltered catalogue and a
        200. Its real search lives at a different endpoint entirely.
        """
        return []

    def devices(self):
        """
        The device slots this subscription has spent, newest information first.

        Every provider here caps devices per subscription, and hitting that cap is not a rare event —
        it is what happens on the second install, and the error it produces ("login refused") reads like
        a wrong password. This is the screen that answers "what is using my three slots".

        Entries are plain dicts; only `id` and `name` are required:

            {"id": "…", "name": "Chrome on Windows", "detail": "online, registered 12.03.2026",
             "current": True}

        `current` marks the slot THIS box occupies — it must be obvious before anyone presses delete.
        """
        return []

    def free_device(self, device_id):
        """
        Release one slot. Raise [ProviderError] with something the user can act on.

        Only called when [can_free_device] is set. Removing the slot this install is using is allowed
        (it is sometimes exactly what someone wants to do from a box they are about to give away), but
        the caller is expected to have said so first.
        """
        raise ProviderError("%s: releasing a device from here is not supported." % self.label)

    def diagnose(self):
        """
        Rows of (check, ok, detail) for the diagnostics screen.

        This is what gets read at 9am when a provider changed something overnight: it must say which
        step broke and what came back, not just that something did.
        """
        return []

    def radio_flag(self, is_audio_only):
        """
        Whether an audio-only station should be published as a RADIO channel — one rule, every provider.

        The rule is not cosmetic and it is not per provider, which is why it stopped being written out
        per provider. Kodi plays a channel marked `radio="true"` with its AUDIO player, and that player
        ends the stream the moment a station changes its sample rate mid-broadcast (measured on Radio
        Studio B: dead in thirty seconds under Radio, alive after three minutes in the TV list, same URL
        and same minute). Four stations in five never change rate, so as a bug it looks random.

        `radio_in_radio_list` is the owner's answer, and it defaults to OFF — stations play from the TV
        list, where they never cut out. EON honoured it; Move set the flag unconditionally and M3U
        carried whatever the source playlist declared, so on those two the setting quietly meant nothing
        and their stations kept dropping out for the reason this setting exists to prevent.
        """
        return bool(is_audio_only) and self.settings.get_bool("radio_in_radio_list", False)

    def diagnose_playback(self, channels):
        """
        One extra diagnostics row: does a channel from [channels] actually RESOLVE to a stream?

        WHY IT IS HERE RATHER THAN IN ONE PROVIDER. Move grew this row first, after "Move does not
        work" was reported twice against a screen whose every row was green — because every row above
        it proves the LOGIN, and the channel list and the stream come from two different calls. The
        second one carries the play token, the DRM flag and the entitlement, and it is the one a
        viewer presses. That reasoning is not Move's; it is true of every provider here, and the other
        three were still answering "your account is fine" to somebody whose television showed nothing.

        THE FIRST CHANNEL, not a random one, so two runs of this screen are comparable. Returns a list
        so a provider with no channels to try simply adds nothing.

        Deliberately tolerant of the shapes `resolve` returns: a dict with a url, or a bare string.
        """
        if not channels:
            return []
        first = channels[0]
        name = first.get("name") or "?"
        try:
            stream = self.resolve(first.get("id") or first.get("ref") or "")
            url = (stream or {}).get("url", "") if isinstance(stream, dict) else str(stream or "")
            return [("Playback", bool(url), "%s -> %s" % (name, (url or "no url")[:60]))]
        except ProviderError as err:
            # Written for the user in the first place, so it is worth showing as it is.
            return [("Playback", False, "%s: %s" % (name, err.message))]
        except Exception as err:                                   # noqa: BLE001
            return [("Playback", False, "%s: %s: %s" % (name, type(err).__name__, err))]


_REGISTRY = []


def register(cls):
    _REGISTRY.append(cls)
    return cls


def _ensure_registered():
    """
    Import the provider package, which is what puts the classes in [_REGISTRY].

    This lives here, at the point of use, rather than in each caller's import block — and that is the
    whole point. `service.py` imported it and the plugin did not, so the background refresh saw five
    providers and everything launched from the menu saw NONE: "Refresh channels and guide now" reported
    0 channels, diagnostics said "no providers are enabled yet", and playback through the plugin:// route
    could not have resolved a channel either. All of it with EON enabled, its credentials on disk, and
    the log cheerfully agreeing that nothing was enabled. An import that must not be forgotten is one
    that should not be the caller's job.
    """
    if not _REGISTRY:
        from . import providers                                    # noqa: F401  (registers them)


def provider_keys():
    """
    Every provider key this build knows, without building a single provider.

    Wanted by anything that needs to ask a question ABOUT the providers rather than of them — the
    playlist fingerprint asks whether any of them has been switched on or off, and constructing six
    provider objects (each with its own HTTP session) to read six booleans would be absurd on a path
    that runs every service tick.

    From the REGISTRY, so a provider added tomorrow is included by existing. That is not tidiness: the
    fingerprint was a hand-written list of four setting names, and every provider's enable flag was
    missing from it — which is the whole reason it did not notice a provider being turned off.
    """
    _ensure_registered()
    return sorted(cls.key for cls in _REGISTRY if cls.key)


def all_providers(settings):
    """
    One instance per ACCOUNT, not per provider.

    The provider's ordinary settings are the first account and come first — a box with one account gets
    exactly the list it always got, in the same order, which is what keeps its channel numbering stable.
    Extra accounts follow, each with a settings view of its own (see accounts.AccountView).
    """
    from . import accounts
    _ensure_registered()
    out = [cls(settings) for cls in _REGISTRY]
    by_key = dict((cls.key, cls) for cls in _REGISTRY)
    for account in accounts.load(settings):
        cls = by_key.get(account.get("provider"))
        if cls is None:
            # A provider that used to exist, or a hand-edited file. Reported rather than dropped in
            # silence — an account that vanishes without a word is a support message.
            diag.log("Accounts: %r is for unknown provider %r — ignored"
                     % (account.get("name"), account.get("provider")), "ERROR")
            continue
        if not account.get("enabled", True):
            continue
        out.append(cls(accounts.AccountView(settings, cls.key, account)))
    return out


def find(settings, key, account_id=""):
    """The one instance matching a play URL's provider and account."""
    for provider in all_providers(settings):
        if provider.key == key and provider.account_id == (account_id or ""):
            return provider
    raise ProviderError("Unknown provider '%s'." % key)


def enabled_providers(settings):
    return [p for p in all_providers(settings) if p.enabled()]
