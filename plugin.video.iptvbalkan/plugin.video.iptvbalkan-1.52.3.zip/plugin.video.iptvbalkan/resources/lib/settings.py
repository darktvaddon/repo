# -*- coding: utf-8 -*-
"""
Settings access, with one deliberate property: reads are always live.

Kodi caches an Addon() instance's settings from when it was constructed. A long-running service that
holds one instance therefore keeps serving values the user changed an hour ago — which, for the setting
this addon exists for (the User-Agent), means editing it appears to do nothing until Kodi restarts.
That is precisely the failure this whole design is meant to avoid, so every read constructs a fresh
handle.
"""

import os

try:
    import xbmcaddon
    import xbmcvfs
    _IN_KODI = True
except ImportError:                       # tooling / unit tests
    _IN_KODI = False


#: Passed explicitly to every Addon() call. The no-argument form resolves the addon from the CALLING
#: script's context, which is not something a thread we started has — and the failure is not an
#: exception every time, it can also be a handle whose writes go nowhere. The id cannot change without
#: the folder changing, so hardcoding it here is safe in a way that guessing at runtime is not.
ADDON_ID = "plugin.video.iptvbalkan"

#: Kodi 19+ is Python 3, but this addon still runs under the Python 2 interpreter on old boxes, where a
#: `unicode` value is a perfectly good setting value and `str` alone would wrongly re-encode it.
try:
    string_types = (str, unicode)             # noqa: F821  (Python 2)
except NameError:
    string_types = (str,)


def _same_setting(written, read_back):
    """
    Whether Kodi stored what we asked it to.

    Kodi NORMALISES: a boolean written as "true" can come back as "1", and comparing the raw strings
    would report a good write as a failure. Same rule pairing.py has always used — moved here so the
    write and its check share one definition rather than two that can drift.
    """
    a, b = str(written).strip().lower(), str(read_back).strip().lower()
    truthy = ("true", "1", "yes")
    if a in truthy and b in truthy:
        return True
    return a == b


class Settings(object):

    def __init__(self, overrides=None):
        #: only used outside Kodi, so the providers can be exercised from a plain Python harness
        self._overrides = dict(overrides or {})

    # ---- raw access -------------------------------------------------------

    def get(self, name, default=""):
        if not _IN_KODI:
            return self._overrides.get(name, default)
        value = xbmcaddon.Addon(ADDON_ID).getSetting(name)
        return value if value != "" else default

    def set(self, name, value):
        """Store [value]. Returns True when the write is readable back, so a caller that must be sure —
        the vault, which will otherwise leave a password in the clear — can tell."""
        if not _IN_KODI:
            self._overrides[name] = value
            return True
        # Kodi's setSetting takes a STRING and nothing else — a bool raises "argument \"value\" for
        # method \"setSetting\" must be unicode or str", which is exactly what the phone log showed at
        # every single service start. It looked harmless because the one caller swallows it, but the
        # write never happened: `home_shortcut_done` stayed unset, so the "add the Video klub favourite
        # ONCE" rule silently became "try it on every start" — the behaviour homescreen.py's own
        # docstring calls out as unacceptable. Booleans are written the way get_bool reads them back.
        if isinstance(value, bool):
            value = "true" if value else "false"
        elif not isinstance(value, string_types):
            value = str(value)
        # ONE handle for the write and the read-back, and returning whether it took.
        #
        # Every read in this class deliberately builds a fresh Addon() so a value the user just changed
        # is seen live (see the module docstring). That is right for reads and wrong for verifying a
        # write: a fresh handle loads from settings.xml, and Kodi has not necessarily flushed the file
        # yet — so "did my write land" answered NO for a write that was perfectly fine. It is why every
        # provider password on this box reported "could not be stored encrypted" at every start and
        # stayed in the clear, and why the catch-up token had to be moved to a file.
        addon = xbmcaddon.Addon(ADDON_ID)
        addon.setSetting(name, value)
        return addon.getSetting(name) == value

    def set_many(self, values):
        """
        Write several settings through ONE handle, and return the ids whose write did not take.

        THE TRAP THIS EXISTS TO CLOSE, and `set` above already documents half of it: every READ in this
        class deliberately builds a fresh `Addon()` so a value the user just changed is seen live. That
        is right for reads and wrong for checking a write — a fresh handle loads from `settings.xml`,
        and Kodi has not necessarily flushed the file yet.

        `set` was fixed for that by keeping one handle for its own write and read-back. But the pairing
        form wrote each value with `set` and then verified the lot afterwards through `get`, which is a
        fresh handle again — so a perfectly good account was reported as "the TV accepted the account
        but did not save it", naming every field at once. Reported live on 2026-08-09 while adding an
        A1 account by phone.

        THE PROTECTION IS KEPT, because the failure it catches is real: Kodi's own settings dialog
        holds a copy of every value and writes it back over settings.xml when it closes, so anything
        written behind it IS lost. That shows up here as the write not reading back on the same handle,
        which is what this returns.
        """
        if not _IN_KODI:
            self._overrides.update({k: v for k, v in values.items()})
            return []
        addon = xbmcaddon.Addon(ADDON_ID)
        lost = []
        for name, value in values.items():
            if isinstance(value, bool):
                value = "true" if value else "false"
            elif not isinstance(value, string_types):
                value = str(value)
            addon.setSetting(name, value)
            if not _same_setting(value, addon.getSetting(name)):
                lost.append(name)
        return sorted(lost)

    def get_bool(self, name, default=False):
        raw = self.get(name, "true" if default else "false")
        return str(raw).lower() in ("true", "1", "yes")

    def get_int(self, name, default=0):
        try:
            return int(self.get(name, str(default)))
        except (TypeError, ValueError):
            return default

    # ---- paths ------------------------------------------------------------

    def profile_dir(self):
        if not _IN_KODI:
            # OUTSIDE the addon tree, deliberately. This used to be `<addon>/resources/lib/_testprofile`,
            # and the selftest filled it with the live test account's playlist, guide, provider caches and
            # log — 30 MB of real account data sitting inside the folder that gets shipped. pack.py
            # excludes it, so no release ever carried it; but anything that copies the folder wholesale
            # does, and that is exactly what happened when the addon was pushed to a box by hand.
            # Keeping it beside the harness rather than inside the product removes the trap.
            path = os.environ.get("IPTVBOX_TEST_PROFILE") or \
                os.path.join(os.path.expanduser("~"), ".iptvbox-selftest")
        else:
            path = xbmcvfs.translatePath(xbmcaddon.Addon(ADDON_ID).getAddonInfo("profile"))
        if not os.path.isdir(path):
            os.makedirs(path)
        return path

    def playlist_path(self):
        return os.path.join(self.profile_dir(), "playlist.m3u")

    def epg_path(self):
        return os.path.join(self.profile_dir(), "epg.xml")

    # ---- global knobs -----------------------------------------------------

    def refresh_hours(self):
        """Catalogue rebuilds are expensive on big line-ups; daily is the sane default and the user can
        say otherwise."""
        return max(1, self.get_int("refresh_hours", 24))

    def epg_days_back(self):
        """
        Five days of guide, and the size of the resulting file is NOT the constraint it looked like.

        These were briefly cut to 0/2 on the theory that an 18 MB XMLTV was what left the TV section at
        "PVR manager 0%" on an ARM 32-bit box. Measured on that exact box, IPTV Simple imported the
        whole thing — 302 channels, 37,006 programmes — in 1,024 milliseconds. The real cause was a
        path type set to "remote" (see service.py), and the guide had nothing to do with it. Put back,
        because two days of archive is worth having and the machine plainly does not mind.
        """
        return max(0, self.get_int("epg_days_back", 2))

    def epg_days_forward(self):
        return max(1, self.get_int("epg_days_forward", 3))

    def verbose(self):
        return self.get_bool("verbose_trace", True)
