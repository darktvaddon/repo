# -*- coding: utf-8 -*-
"""
Video-klub screens, kept on disk so the second visit costs nothing.

WHY THIS EXISTS. Browsing on-demand is the one place in this addon where the SAME request is made over
and over: open a catalogue, look at it, press Back, open it again — and every one of those is a fresh
walk over the provider's pages. On EON that is four requests of fifty titles for the first screen alone
(`VOD_PAGE_BATCH`), and pressing "Next page" fetches the earlier pages again on the way. Measured on the
owner's own account when the Video klub was first written: seventeen seconds for one catalogue.

The idea is taken from a competing addon that was examined on 2026-08-09 — it keeps the whole catalogue
in a file and pages it in memory, which is exactly why its on-demand screens feel instant next to ours.
Nothing of its code is here; the idea needed no code.

WHAT IS AND IS NOT CACHED

Only the LISTING — the rows a screen draws. Never a stream, never a licence, never a play descriptor:
those expire, are per-tune, and a stale one fails at the moment somebody presses play. A listing that is
a few hours old shows a film that was added this afternoon one visit late, which is the whole cost.

THREE PROPERTIES, each one a lesson this project has already paid for elsewhere:

* **Written through a temp file and `os.replace`** — the M3U club cache was opened with `"w"` (which
  empties it at once) and filled with 2.2 MB while a reader sat in another process. A reader landing in
  that window got half a document and reported an empty catalogue. See catcache's note; same fix.
* **Per provider AND per account.** `cache_path` adds the account prefix, so two EON subscriptions do
  not serve each other's catalogue — the same rule the channel cache follows.
* **Dropped when stale rather than served for ever.** A club that never expires is a club where a
  cancelled title stays on the shelf until the addon is reinstalled.
"""

import gzip
import json
import os
import time

from . import diag

#: Bumped when the stored shape changes. An older file is ignored rather than migrated — it is a cache,
#: and the cost of throwing one away is one screen that takes as long as it used to.
FORMAT = 1

#: How old a listing may be and still be shown. Long enough that an evening of browsing costs one fetch
#: per catalogue; short enough that a title added today is not missed by more than a session.
KEEP_SECONDS = 6 * 3600

#: A ceiling on the whole file, not on one entry. EON has thirty-one catalogues and one of them holds
#: 1,300 titles; without a cap a thorough browse would write tens of megabytes onto a box that has been
#: seen to run out of memory. When it is reached the OLDEST entries go first, so the shelves somebody is
#: actually using stay warm.
MAX_ENTRIES = 60

_NAME = "vodcache-%s.json.gz"


def path(provider):
    return provider.cache_path(_NAME % provider.key)


def _read(provider):
    try:
        with gzip.open(path(provider), "rt", encoding="utf-8") as handle:
            data = json.load(handle)
    except (OSError, IOError, ValueError, EOFError):
        return {}
    if not isinstance(data, dict) or data.get("format") != FORMAT:
        return {}
    entries = data.get("entries")
    return entries if isinstance(entries, dict) else {}


def _write(provider, entries):
    target = path(provider)
    tmp = target + ".tmp"
    try:
        with gzip.open(tmp, "wt", encoding="utf-8", compresslevel=4) as handle:
            json.dump({"format": FORMAT, "entries": entries}, handle, ensure_ascii=False)
        os.replace(tmp, target)
        return True
    except Exception as err:                                        # noqa: BLE001
        # A cache that cannot be written must never cost the screen it was speeding up.
        diag.log("Video klub cache: %s could not be stored (%s) — the screen itself is unaffected"
                 % (provider.label, err))
        try:
            os.remove(tmp)
        except OSError:
            pass
        return False


def read(provider, key, max_age=KEEP_SECONDS):
    """
    Whatever was stored under [key], or None when there is nothing young enough.

    PAYLOAD-AGNOSTIC on purpose. EON stores a finished list of screen rows; A1 stores the service's own
    reply, because one A1 document answers a folder AND every genre inside it, and slicing that is the
    provider's business rather than this module's. Anything json can carry is accepted — the first
    version of this file insisted on a list and silently answered None for A1 every single time, which
    is a cache that looks like it works and never once hits.
    """
    entry = _read(provider).get(str(key))
    if not isinstance(entry, dict):
        return None
    age = time.time() - float(entry.get("at") or 0)
    if age > max_age:
        return None
    payload = entry.get("rows")
    if payload is None:
        return None
    try:
        size = len(payload)
    except TypeError:
        size = 1
    diag.log("Video klub: %s served %d item(s) from the cache (%s old) — no request made"
             % (provider.label, size, _age_text(age)))
    return payload


def write(provider, key, payload):
    """Store [payload] under [key]. Best effort: a failure here is invisible except in the log."""
    if payload is None:
        return
    entries = _read(provider)
    entries[str(key)] = {"at": int(time.time()), "rows": payload}
    if len(entries) > MAX_ENTRIES:
        # Oldest first. `sorted` on the timestamp rather than insertion order, because the file outlives
        # the process and a dict read back from JSON carries no order worth trusting.
        for stale in sorted(entries, key=lambda k: entries[k].get("at", 0))[:len(entries) - MAX_ENTRIES]:
            entries.pop(stale, None)
    _write(provider, entries)


def forget(provider):
    """Throw the whole file away — used by the panel's `clear_cache` and by a failed parse."""
    try:
        os.remove(path(provider))
        return True
    except OSError:
        return False


def _age_text(seconds):
    seconds = int(max(0, seconds))
    if seconds < 90:
        return "%ds" % seconds
    if seconds < 5400:
        return "%dmin" % (seconds // 60)
    return "%dh" % (seconds // 3600)
