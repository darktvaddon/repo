# -*- coding: utf-8 -*-
"""
Each provider's own channels and guide, kept on disk between refreshes.

WHY THIS EXISTS. `catalog.build` used to have exactly two outcomes: every enabled provider answered and
the playlist was rewritten, or one of them failed and the WHOLE refresh was thrown away — the previous
playlist left standing, guide and all. That guard is right in what it protects (a provider that fails
must not have its channels deleted by the ones that succeeded) and much too blunt in what it costs: one
bad EON night and Iris and Yettel keep yesterday's guide too, although both answered perfectly. On a box
with three subscriptions, the provider most likely to fail decides how fresh the other two are.

With a per-provider cache the writer no longer has to choose. Each provider's fetch is stored the moment
it succeeds, and a refresh where EON fails merges fresh Iris + fresh Yettel + EON's last good block —
the channels AND the guide that went with them, which is the half that made retaining "just the failed
provider's old rows" impossible before.

The second thing it buys is the cheap rebuild. Adding an account, or linking Yettel, used to mean
fetching every provider again: about six minutes on the owner's box for a change that concerns one of
them. `catalog.build(..., only=("yettel",))` fetches that one and serves the rest from cache.

THREE PROPERTIES THAT ARE NOT OPTIONAL, each of them a lesson from somewhere else in this addon:

* **Written through a temp file and `os.replace`.** The M3U Video klub cache was opened with `"w"` — which
  empties it at once — and then filled with 2.2 MB, while the reader sits in ANOTHER process; a reader
  landing in that window got half a JSON document and reported an empty catalogue. Same shape here, same
  fix, and here the window is wider still because these files are the biggest thing the addon writes.
* **Stored BEFORE the channel numbers are shifted.** `catalog._number_block` gives every provider after
  the first a 2000-wide block by its POSITION in the enabled list, and that position moves when a
  provider is added, removed or disabled. A cached block carrying yesterday's offsets would collide with
  today's live one, so what is stored is the provider's own numbering and the offset is applied again on
  the way out.
* **A stale block is dropped rather than served forever.** A subscription that has been refused for a
  fortnight is not an outage; the guide in that block ended twelve days ago, and the rows would keep a
  dead account's channels in the list indefinitely. After [KEEP_DAYS] the block is ignored, which puts
  `catalog.build` back on its old "keep the previous playlist" path — never worse than before this
  existed.
"""

import glob
import gzip
import json
import os
import time

from . import diag

#: Bumped when the stored shape changes. A block written by an older format is ignored, not migrated:
#: it is a cache, the cost of throwing one away is one refresh.
FORMAT = 1

#: How old a block may be and still be merged into a playlist. Two weeks covers any outage worth calling
#: one — beyond that the account is gone, not unreachable, and its guide is entirely in the past.
KEEP_DAYS = 14

_NAME = "catalogue-%s.json.gz"
_GLOB = "catalogue-*.json.gz"


def path(provider):
    """This provider's block. `cache_path` adds the account prefix, so two accounts of the same provider
    do not overwrite each other's channels."""
    return provider.cache_path(_NAME % provider.key)


def save(provider, channels, programmes):
    """
    Store what this provider just answered. Returns True when the file is in place.

    Called on the success path of every refresh, so it must not be able to fail the refresh: a full disk
    or a read-only profile costs the cache, never the playlist that has already been fetched.
    """
    target = path(provider)
    tmp = target + ".tmp"
    payload = {
        "format": FORMAT,
        "key": provider.key,
        "label": provider.label,
        "saved": int(time.time()),
        "channels": channels,
        "programmes": programmes,
    }
    try:
        # Streamed into the compressor rather than dumped to a string first. The guide is the largest
        # object this addon holds — 37,000 programmes on the owner's own line-up — and `json.dumps` would
        # build a second copy of all of it in memory on a box that has already been seen to run out.
        #
        # Level 4 rather than gzip's default 9, measured on a 37,000-programme guide: 8.4 MB either way,
        # 0.63 s against 0.83 s here, and this runs on a box several times slower than this PC. The last
        # levels buy nothing on text this repetitive.
        with gzip.open(tmp, "wt", encoding="utf-8", compresslevel=4) as handle:
            json.dump(payload, handle, ensure_ascii=False)
        os.replace(tmp, target)
    except Exception as err:                                       # noqa: BLE001
        diag.log("Cache: %s could not be stored (%s: %s) — the refresh itself is unaffected"
                 % (provider.label, type(err).__name__, err), "ERROR")
        try:
            os.remove(tmp)
        except OSError:
            pass
        return False
    try:
        size_mb = os.path.getsize(target) / (1024.0 * 1024.0)
    except OSError:
        size_mb = 0.0
    diag.log("Cache: %s stored — %d channels, %d programmes, %.1f MB"
             % (provider.label, len(channels), len(programmes), size_mb))
    return True


def load(provider, keep_days=KEEP_DAYS):
    """
    This provider's last good block, or None when there is none worth using.

    None covers all of: never fetched, a block from an older format, a file that will not read, and one
    older than [keep_days]. Every one of those means the same thing to the caller — there is nothing to
    merge — and the reason is logged rather than returned, because no caller can do anything different
    with it.
    """
    target = path(provider)
    if not os.path.exists(target):
        return None
    try:
        with gzip.open(target, "rt", encoding="utf-8") as handle:
            block = json.load(handle)
    except Exception as err:                                       # noqa: BLE001
        # A truncated or corrupt block is deleted rather than left to fail identically every night. It
        # is rebuilt by the next refresh that succeeds.
        diag.log("Cache: %s could not be read (%s: %s) — discarded" % (provider.label,
                                                                       type(err).__name__, err), "ERROR")
        try:
            os.remove(target)
        except OSError:
            pass
        return None
    if not isinstance(block, dict) or block.get("format") != FORMAT:
        diag.log("Cache: %s was stored in an older format — ignored" % provider.label)
        return None
    block["age"] = max(0, int(time.time()) - int(block.get("saved") or 0))
    if block["age"] > keep_days * 86400:
        diag.log("Cache: %s was stored %s and is too old to use" % (provider.label,
                                                                    age_text(block["age"])))
        return None
    block.setdefault("channels", [])
    block.setdefault("programmes", [])
    if not block["channels"]:
        return None
    return block


def forget_account(settings, account_id):
    """
    Drop every block belonging to one extra account, called when that account is deleted.

    Without this the account is gone from the settings screen and its channels come BACK the next time
    another provider fails — merged out of a cache nothing owns any more, complete with a guide, and with
    play URLs carrying an `&account=` that no longer resolves. Age alone would clear it eventually; a
    fortnight of a deleted account's channels in the list is not "eventually" enough.

    The first account has no prefix and no delete — it is the settings screen itself — so an empty id
    would match every file there is, and is refused.
    """
    if not account_id:
        return 0
    removed = 0
    for name in glob.glob(os.path.join(settings.profile_dir(), "%s-%s" % (account_id, _GLOB))):
        try:
            os.remove(name)
            removed += 1
        except OSError:
            continue
    if removed:
        diag.log("Cache: dropped %d block(s) belonging to the removed account %s" % (removed, account_id))
    return removed


def prune(settings, keep_days=KEEP_DAYS):
    """
    Delete blocks nothing can use any more.

    Only age is judged, deliberately. "No provider claims this file" would also catch the block of an
    account that was deleted — and equally the block of a provider merely switched off for a week, which
    is exactly the one worth keeping. Age settles both without having to know which it is looking at.
    """
    removed = 0
    kept, bytes_kept = 0, 0
    cutoff = time.time() - keep_days * 86400
    for name in glob.glob(os.path.join(settings.profile_dir(), _GLOB)):
        try:
            if os.path.getmtime(name) < cutoff:
                os.remove(name)
                removed += 1
            else:
                kept += 1
                bytes_kept += os.path.getsize(name)
        except OSError:
            continue
    if removed:
        diag.log("Cache: removed %d block(s) older than %d days" % (removed, keep_days))
    # What the whole thing costs, said out loud once per refresh. These are the biggest files the addon
    # writes — a guide runs to several megabytes compressed — and a box short of storage is a real
    # complaint here, so the number belongs in the log rather than in an estimate.
    diag.log("Cache: %d block(s) on disk, %.1f MB" % (kept, bytes_kept / (1024.0 * 1024.0)))
    return removed


def age_text(seconds):
    """
    How old a block is, in the interface's own language.

    It used to be Serbian unconditionally, on the reasoning that it is read beside a provider's error
    message — and the line it lands in was composed in English, so the refresh screen said
    "312 channels, 8421 programmes, iz kesa (pre 3 h)". Half a sentence in each language is not a
    compromise between two audiences, it is a screen that looks unfinished to both. Now it follows T()
    like everything else, and the line around it does too.
    """
    from .i18n import T
    seconds = max(0, int(seconds))
    if seconds < 3600:
        return T("pre %d min") % (seconds // 60)
    if seconds < 86400:
        return T("pre %d h") % (seconds // 3600)
    return T("pre %d dana") % (seconds // 86400)
