# -*- coding: utf-8 -*-
"""
Things the panel can ask a box to DO, as opposed to things it can tell a box to say.

Messages were half a channel: the panel could put text on a television and nothing more. Everything
else — "send me your log", "rebuild your channel list", "your EON session is wedged, drop it" — needed
the person in front of the television to be walked through a menu on the phone, which is the support
call this whole addon exists to avoid.

**How it travels.** No new endpoint and no polling of its own. The licence check already runs every
fifteen minutes and already comes back signed, so a `commands` array rides down inside that same answer
and the results ride back up through the support endpoint the box already posts to.

**Three rules, and each one is a refusal that matters:**

* **Signed only.** A command runs code on someone else's box. `_verdict_fields` already drops
  `messages` and `vault_key` from an unsigned answer for exactly this reason; a command is strictly
  worse than a message and is filtered by the same gate — it is only ever read out of the verified
  fields.
* **Once each.** Ids are remembered, the way support replies are. A command left standing in the panel
  must not run again at every check, or "send me your log" becomes ninety-six uploads a day.
* **Known verbs only.** Anything unrecognised is reported back as refused rather than ignored, so a
  panel that gets ahead of the addon sees "this box is too old for that" instead of silence.

Nothing here can be made to run arbitrary code: the verb decides the function, the panel only picks a
verb from a list this file defines.
"""

import io
import json
import os

from . import diag, store

#: Commands already carried out, so one instruction is obeyed once. Bounded for the same reason the
#: support one is: the list exists to stop repeats, not to be a history.
DONE_FILE = "commands_done.json"
DONE_KEEP = 200


def pending(settings, inbox):
    """The commands in [inbox] this box has not run yet, oldest first."""
    done = set(_read_done(settings))
    out = []
    for entry in inbox or []:
        if not isinstance(entry, dict):
            continue
        identifier = str(entry.get("id") or "")
        verb = str(entry.get("type") or entry.get("command") or "").strip().lower()
        if not identifier or identifier in done or not verb:
            continue
        out.append({"id": identifier, "type": verb, "args": entry.get("args") or {}})
    return out


def run_pending(settings):
    """
    Carry out whatever the panel has left for this box.

    Called from the service after each licence check. Every failure is caught per command: one bad
    instruction must not stop the next, and must not take the service's own loop down with it.
    """
    from . import licence
    inbox = licence.commands(settings)
    for entry in pending(settings, inbox):
        verb = entry["type"]
        handler = _HANDLERS.get(verb)
        if handler is None:
            _finish(settings, entry, False, "unknown command %r — this box runs an older addon" % verb)
            continue
        try:
            ok, detail = handler(settings, entry.get("args") or {})
        except Exception as err:                                   # noqa: BLE001
            ok, detail = False, "%s: %s" % (type(err).__name__, err)
        _finish(settings, entry, ok, detail)


def _finish(settings, entry, ok, detail):
    """Mark it done and tell the panel what happened, in that order.

    Marked FIRST on purpose. If the report cannot be posted — the box is on a flaky link, which is
    exactly when a log is being asked for — the command must still not run again on the next check.
    A missing result reads as "no answer yet" in the panel; ninety-six repeats of a heavy command
    reads as a broken product.
    """
    _mark_done(settings, entry["id"])
    diag.log("Command %s (%s): %s%s" % (entry["id"], entry["type"], "done" if ok else "REFUSED",
                                        "" if ok else " — " + str(detail)), "INFO" if ok else "ERROR")
    try:
        from . import support
        support.report_command(settings, entry["id"], entry["type"], ok, detail)
    except Exception as err:                                       # noqa: BLE001
        diag.log("Command %s: result could not be reported (%s)" % (entry["id"], err), "ERROR")


# ---- the verbs --------------------------------------------------------------

def _cmd_log(settings, args):
    """Send the log up, with nobody in front of the television.

    This is the one that pays for the whole file: "it does not work" turns into a log on the panel
    without asking someone to find a menu on a remote and read a number off a screen.
    """
    from . import support
    note = str(args.get("note") or "Trazeno sa panela")
    ok, detail = support.send(settings, note, include_log=True)
    return ok, detail


def _cmd_diagnostics(settings, args):
    """Send the provider health report — smaller than a log and usually the actual answer."""
    del args
    from . import support
    from .provider import all_providers
    lines = []
    for provider in all_providers(settings):
        if not provider.enabled():
            continue
        lines.append("[%s]" % provider.label)
        try:
            for check, ok, note in provider.diagnose():
                lines.append("  %-4s %s — %s" % ("OK" if ok else "FAIL", check, note))
        except Exception as err:                                   # noqa: BLE001
            lines.append("  FAIL diagnostics crashed — %s: %s" % (type(err).__name__, err))
    if not lines:
        lines.append("no providers enabled on this box")
    # The archive-depth block, same as the on-screen diagnostics: this command exists so support can be
    # done WITHOUT the customer, and "how far back does his archive go" is the question it kept
    # answering with a request for a log.
    from . import kodisettings
    lines.append("")
    lines.append("[Guide window]")
    for row in kodisettings.guide_window_report(settings):
        lines.append("  %s" % row)
    return support.send(settings, "DIJAGNOSTIKA (trazeno sa panela)\n\n" + "\n".join(lines),
                        include_log=False)


def _cmd_refresh(settings, args):
    """Rebuild the channel list and guide now."""
    del args
    from . import catalog
    result = catalog.build(settings)
    if result.ok:
        return True, "%d channels, %d programmes" % (result.channels, result.programmes)
    return False, "; ".join("%s: %s" % (label, note)
                            for label, ok, note in result.per_provider if not ok) or "nothing written"


def _cmd_clear_cache(settings, args):
    """
    Throw away the derived files a box can get stuck on, keeping accounts and settings.

    Deliberately a short, NAMED list rather than "everything in the profile": the same folder holds the
    licence state, the resume positions and the catch-up token, and a command that wipes those turns a
    support action into a fresh install.

    `playlist.m3u` and `epg.xml` are NOT on the list, and leaving them off is the point. Deleting them
    bought nothing — a rebuild writes both wholesale through `os.replace` — while costing two things.
    The box is left with NO channel list until the next scheduled refresh, which is up to a day away
    because the running service's clock is not reset by files disappearing underneath it. And it defeats
    catalog.build's own safety net, which deliberately keeps the previous playlist when a refresh fails:
    delete it first and a provider outage during the rebuild leaves the customer with nothing at all.
    Send `refresh` when a rebuild is what is wanted; that is the verb for it.
    """
    del args
    removed = []
    # A1's three are here because this verb's whole purpose is a box that is stuck, and A1 is the
    # provider that can get stuck in a way the others cannot: a playback session it never released
    # holds one of the account's very few concurrent-stream slots, and `a1_playing.json` is the record
    # of it. Its session and event-map caches go with it, since a stale session is the other half of
    # the same complaint. (The list is still a NAMED one, not "everything in the profile" — the same
    # folder holds the licence state, the resume positions and the accounts.)
    for name in ("eon_play.json", "iris_play.json", "eon-session.json", "tmdb_queue.json",
                 "a1_session.json", "a1_events.json", "a1_playing.json"):
        path = os.path.join(settings.profile_dir(), name)
        try:
            if os.path.isfile(path):
                os.remove(path)
                removed.append(name)
        except OSError as err:
            return False, "could not remove %s (%s)" % (name, err)

    # THE VIDEO-KLUB LISTINGS, by pattern rather than by name — there is one per provider and per
    # account, so a named list would be six entries that grow to twelve the day somebody adds a second
    # subscription, and the next provider would be forgotten. This is the one cache a viewer can
    # actually SEE being wrong ("that film is gone from the shelf and still shows"), so support has to
    # be able to drop it from the panel. Everything under it is derived: worst case one screen takes as
    # long as it used to.
    import glob
    for path in sorted(glob.glob(os.path.join(settings.profile_dir(), "*vodcache-*.json.gz"))):
        try:
            os.remove(path)
            removed.append(os.path.basename(path))
        except OSError as err:
            return False, "could not remove %s (%s)" % (os.path.basename(path), err)
    return True, "removed: %s" % (", ".join(removed) or "nothing was there")


def _cmd_message(settings, args):
    """
    Put text on this television.

    A message as a COMMAND rather than only as an entry in `messages`, because a command is confirmed:
    the panel learns that the box actually showed it, on which date, instead of only knowing it was
    handed over. Both paths still work — an older box reads `messages`, a newer one takes either.

    Raised on its own thread, because this runs inside the service's loop and a modal dialog there stops
    everything else in it until somebody presses OK — see support.show_async. So "shown" means it is on
    the screen, not that it has been read; waiting for the second would mean a box in an empty room with
    a dead heartbeat.
    """
    from . import support
    from .i18n import T
    text = str(args.get("text") or "").strip()
    if not text:
        return False, "empty message"
    support.show_async(T("IPTV Balkan — poruka"), [text])
    return True, "shown (not waiting for it to be dismissed)"


def _cmd_ping(settings, args):
    """Prove the channel works end to end. Costs nothing and answers "is this box listening"."""
    del settings, args
    return True, "pong"


#: The whole vocabulary. A panel can only pick from here, which is what keeps this from being a remote
#: shell: there is no verb that takes code, a path, or a command line.
_HANDLERS = {
    "log": _cmd_log,
    "message": _cmd_message,
    "diagnostics": _cmd_diagnostics,
    "refresh": _cmd_refresh,
    "clear_cache": _cmd_clear_cache,
    "ping": _cmd_ping,
}

#: Reported to the panel on every check so it can grey out what a given box cannot do yet.
SUPPORTED = sorted(_HANDLERS)


# ---- the "already ran" list -------------------------------------------------

def _read_done(settings):
    path = os.path.join(settings.profile_dir(), DONE_FILE)
    try:
        with io.open(path, "r", encoding="utf-8") as handle:
            data = json.loads(handle.read())
        return [str(x) for x in data] if isinstance(data, list) else []
    except (OSError, IOError, ValueError):
        return []


def _mark_done(settings, identifier):
    done = _read_done(settings)
    if identifier in done:
        return
    done.append(identifier)
    # An empty done-list is a list that has forgotten EVERY command it has run, not just this one — so
    # the next check re-runs whatever the panel still has queued: the log uploaded twice, the message
    # shown twice, the catalogue rebuilt twice. Cheap to make impossible.
    store.write_json(os.path.join(settings.profile_dir(), DONE_FILE), done[-DONE_KEEP:])
