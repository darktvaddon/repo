# -*- coding: utf-8 -*-
"""
Two-way support: the user writes, and the log goes with it.

The device→server half deliberately reuses the EXISTING `licence/api/support.php` that the Android app
already posts to — same fields, same inbox, same e-mail notification. Nothing new on the server for this
direction, and one inbox instead of two. The message carries the licence serial and the device hash, so
a report can be matched to the row in the Kodi device screen without asking the user for anything.

**The log travels with the message, and that is the whole point.** Every support round in this project so
far has started with "send me the log", which on a TV box means photographing a screen or walking someone
through a QR flow. A report that arrives without one is a report that costs a day.

The server→device half arrives inside the licence answer (see licence.py), which is already signed and
device-bound — so a reply cannot be forged by anything that can answer HTTP, and cannot be replayed onto
another box.
"""

import json

try:
    from urllib.parse import urlencode
except ImportError:                                                # pragma: no cover
    from urllib import urlencode

from . import diag, licence, net
from .i18n import T

#: The same script the Android app posts to — same inbox, same e-mail notification, no new server code
#: for this direction.
#:
#: NO `?app=` ON THE URL, and that is the whole history of this line. It was given one, to file Kodi
#: reports under their own product, and the live script answers **400** to it — read off a phone on
#: 2026-08-02: `POST …/support.php?app=iptvbox-kodi -> 400 34B`, so every report and every command
#: result from every Kodi box has been failing since. Asked directly, the deployed script says what it
#: means, and both halves were measured against it that day:
#:
#:     ?app=iptvbox-kodi   -> 400  {"ok":false,"error":"Unknown app"}
#:     (no query)          -> 422  {"ok":false,"error":"Poruka je obavezna."}   ← past the app gate
#:
#: It knows one app id and takes it from the FORM, exactly as the Android client sends it.
#:
#: Which product a message belongs to travels in the body instead (`product`, `client`), where an older
#: support.php ignores it and a newer one can file on it. Then the Kodi section of the panel can be
#: given these without the addon changing again — and until it is, a Kodi report is still recognisable
#: at a glance from the `device` line, which starts with KODI.
#: Where a Kodi report goes FIRST: our own receiver, which files it under this product and shows it in
#: the Kodi section of the panel — which is the whole point, and the one thing `support.php` cannot do.
#: It knows one app id, mails everything as "New support / suggestion message from IPTV Box Android",
#: and the panel page carrying that customer's serial never sees the message at all.
ENDPOINT = "https://iptvbox-player.com/licence/api/kodi-support.php"

#: And where it goes when that file is not on the server yet. A 404 here is not a failure, it is an
#: older server — and a support channel that breaks the day the addon ships, waiting for an upload, is
#: worse than one that files messages in the wrong inbox for a while. Anything other than 404 is a real
#: error and is reported as one: a 500 must not be quietly re-sent somewhere else.
FALLBACK_ENDPOINT = "https://iptvbox-player.com/licence/api/support.php"

#: Sent alongside `app` in the body: the licence half of this addon has always identified itself as
#: `iptvbox-kodi`, and both halves of one box being filed under different names is what the panel needs
#: in order to show them together.
PRODUCT = "iptvbox-kodi"

#: How much of the log to attach. The server caps at 60k and truncates from the FRONT, so trimming here
#: to the tail is what decides whether it keeps the useful end or the boring beginning.
LOG_TAIL = 55000

#: Messages already shown, so a reply is not re-opened on every check. Same idea as the Android client's
#: seen-id set.
SEEN_FILE = "support_seen.json"


def _post(session, body, headers):
    """
    Post to our own receiver, and fall back to the old one only when it is NOT THERE.

    The distinction is the whole design: 404 means "this server has not been updated yet", which is a
    condition of the server and not of the message. Every other status is the receiver answering — it
    has an opinion, and re-sending the same report to a second inbox on the strength of a 500 would
    duplicate messages on the day something goes wrong there.
    """
    try:
        return session.post(ENDPOINT, body=body, headers=headers)
    except net.HttpError as err:
        if err.status != 404:
            raise
        diag.log("Support: this server has no kodi-support.php yet — sending to the shared inbox")
        return session.post(FALLBACK_ENDPOINT, body=body, headers=headers)


def send(settings, message, include_log=True):
    """
    Post one report. Returns (ok, detail) — never raises, because a failure here has to be TOLD to the
    user rather than swallowed into a log they cannot send.
    """
    message = (message or "").strip()
    if not message:
        return False, T("Poruka je prazna.")

    verdict = licence.check(settings)
    device = licence.device_id(settings)
    body = {
        "app": "iptvbox",
        "product": PRODUCT,
        "client": "kodi",
        "version": _addon_version(),
        # Marked so a Kodi report is recognisable at a glance in an inbox shared with the phone app.
        "device": "KODI %s / serial %s" % (_platform(), verdict.serial or "?"),
        "device_hw_id": device,
        "message": message,
    }
    if include_log:
        log = diag.read_log() or ""
        body["log"] = log[-LOG_TAIL:]

    session = net.Session({"user_agent": "IPTVBalkan-Kodi/%s" % _addon_version()}, timeout=25,
                          trace=settings.verbose())
    try:
        answer = _post(session, urlencode(body).encode("utf-8"),
                       {"Content-Type": "application/x-www-form-urlencoded"})
    except net.HttpError as err:
        diag.log("Support: could not send (%s)" % err, "ERROR")
        return False, "Slanje nije uspelo: %s" % err

    if isinstance(answer, dict) and not answer.get("ok", True):
        return False, str(answer.get("error") or "Server je odbio poruku.")
    diag.log("Support: report sent (%d characters of log attached)" % len(body.get("log", "")))
    return True, T("Poruka je poslata.")



def report_command(settings, command_id, verb, ok, detail):
    """
    Tell the panel what happened to one command.

    Posted to the same endpoint the user's own reports go to, marked `kind=command` so the panel can
    file it against the command instead of showing it as somebody's support message. Never raises:
    the command has already been carried out and already been marked done, so a failure to report is
    a missing line in the panel and nothing worse.
    """
    verdict = licence.check(settings)
    body = {
        "app": "iptvbox",
        "product": PRODUCT,
        "client": "kodi",
        "kind": "command",
        "command_id": str(command_id),
        "command": str(verb),
        "ok": bool(ok),
        "version": _addon_version(),
        "device": "KODI %s / serial %s" % (_platform(), verdict.serial or "?"),
        "device_hw_id": licence.device_id(settings),
        "message": str(detail or ""),
    }
    try:
        session = net.Session({"user_agent": "IPTVBalkan-Kodi/1.0"}, timeout=15,
                              trace=settings.verbose())
        _post(session, json.dumps(body).encode("utf-8"), {"Content-Type": "application/json"})
        return True
    except Exception as err:                                       # noqa: BLE001
        diag.log("Support: command result not delivered (%s)" % err, "ERROR")
        return False

# ---- replies coming back ----------------------------------------------------

def pending(settings):
    """Messages from the server this box has not shown yet, newest last."""
    seen = set(_read_seen(settings))
    out = []
    for entry in licence.messages(settings):
        identifier = str(entry.get("id") or "")
        text = str(entry.get("text") or "").strip()
        if not text or (identifier and identifier in seen):
            continue
        out.append({"id": identifier, "text": text})
    return out


def mark_seen(settings, identifier):
    if not identifier:
        return
    seen = _read_seen(settings)
    if identifier in seen:
        return
    seen.append(identifier)
    # Bounded: the id list only exists to stop a repeat, and an unbounded one would grow forever on a
    # box that is talked to often.
    _write_seen(settings, seen[-200:])


def _read_seen(settings):
    import os
    path = os.path.join(settings.profile_dir(), SEEN_FILE)
    try:
        with open(path, "r", encoding="utf-8") as handle:
            data = json.loads(handle.read())
        return [str(x) for x in data] if isinstance(data, list) else []
    except (OSError, IOError, ValueError):
        return []


def _write_seen(settings, seen):
    import os
    path = os.path.join(settings.profile_dir(), SEEN_FILE)
    try:
        with open(path, "w", encoding="utf-8") as handle:
            handle.write(json.dumps(seen))
    except (OSError, IOError, ValueError) as err:
        diag.log("Support: could not record shown messages (%s)" % err)


def _addon_version():
    try:
        import xbmcaddon
        return xbmcaddon.Addon().getAddonInfo("version") or "?"
    except Exception:                                              # noqa: BLE001
        return "?"


def _platform():
    try:
        import xbmc
        return (xbmc.getInfoLabel("System.BuildVersion") or "").split(" ")[0] or "?"
    except Exception:                                              # noqa: BLE001
        return "?"


# ---- the screen -------------------------------------------------------------

def screen(settings):
    """
    Write a message and send it with the log.

    One keyboard, one confirmation, and the log attached by default — the user is not asked to decide
    whether it is relevant, because they cannot know and it is the only thing that makes a report
    actionable.
    """
    import xbmcgui

    keyboard = xbmcgui.Dialog().input(T("Opisi problem ili napisi poruku"),
                                      type=xbmcgui.INPUT_ALPHANUM)
    if not keyboard or not keyboard.strip():
        return

    verdict = licence.check(settings)
    if not xbmcgui.Dialog().yesno(
            T("IPTV Balkan — poruka podrsci"),
            T("Poslati poruku zajedno sa logom sa ovog uredjaja?\n\n"
              "Broj uredjaja: %s\n\nLog sadrzi adrese i greske, ali NE i lozinke — one se ne "
              "upisuju.")
            % (verdict.serial or T("jos nije dodeljen")),
            yeslabel=T("Posalji"), nolabel=T("Odustani")):
        return

    ok, detail = send(settings, keyboard)
    if ok:
        xbmcgui.Dialog().ok("IPTV Balkan",
                            T("%s\n\nOdgovor stize u ovaj isti dodatak — javice se sam kad dodje.")
                            % detail)
    else:
        xbmcgui.Dialog().ok(T("IPTV Balkan — poruka nije poslata"),
                            T("%s\n\nAko se ponavlja, posalji log preko '%s'.")
                            % (detail, T("Posalji log na telefon (QR)")))


def show_async(title, texts):
    """
    Put one or more dialogs on the television WITHOUT holding up the caller.

    Everything that shows one of these runs inside the resident SERVICE's loop, and `Dialog().ok()` is
    modal: it does not return until somebody presses OK. On a box nobody is sitting in front of — which
    is most boxes, most of the time — that stopped the loop outright: no Iris heartbeat, so the stream it
    exists to keep alive is dropped by the provider; no resume position recorded; no catalogue refresh;
    and `monitor.abortRequested()` never polled, so Kodi's own shutdown sat waiting for a service that
    was waiting for a remote control. A message from the panel is the least important thing in that loop
    and must not be able to stall the rest of it.

    Shown one after another on a SINGLE thread, not one thread each: two dialogs raised at once stack on
    top of each other and the one underneath is unreadable.
    """
    import threading
    import xbmcgui

    queued = [t for t in texts if t]
    if not queued:
        return

    def _show():
        for text in queued:
            try:
                xbmcgui.Dialog().ok(title, text)
            except Exception as err:                               # noqa: BLE001
                diag.log("Support: a message could not be shown (%s)" % err, "ERROR")
                return

    thread = threading.Thread(target=_show, name="iptvbox-message")
    thread.daemon = True
    thread.start()


def show_pending(settings):
    """
    Show whatever the server has replied, once each. Called from the service after a licence check.

    Marked seen BEFORE anything is drawn, and that order is load-bearing now that the dialog does not
    block: the service carries on ticking while the message is still on screen, so a reply still listed
    as unseen would be raised again on the next pass, and again on the one after that.
    """
    texts = []
    for entry in pending(settings):
        texts.append(entry["text"])
        mark_seen(settings, entry["id"])
    show_async(T("IPTV Balkan — poruka"), texts)
