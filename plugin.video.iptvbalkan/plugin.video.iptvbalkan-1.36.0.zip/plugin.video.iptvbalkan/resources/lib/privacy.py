# -*- coding: utf-8 -*-
"""
What leaves this box, said plainly, on the box itself.

Asked on a forum on 2026-08-01 — "ne znam sta se sve radi od konekcija prema serveru i koliko je
ugrozena privatnost" — and it is a fair question about an add-on that talks to a licence server, a
metadata service and a television provider. The answer is short and mostly reassuring, which is exactly
why it should be readable without trusting anybody: the alternative is that each person guesses.

Two rules for this file, because a privacy page that drifts is worse than none:

  * every claim here is about code in this repository, not about intentions. If a line cannot be pointed
    at a call, it does not belong here;
  * it reports THIS box. Whether TMDB is on, whether the log is being kept, which providers are
    configured — read at the moment the screen opens, so nobody has to work out which paragraph applies
    to them.

Deliberately NOT a settings screen. Everything named here can already be switched off where it is
switched on, and a second set of switches would only disagree with the first.
"""

from . import licence
from .i18n import T

try:
    import xbmc
    _IN_KODI = True
except ImportError:                                                # tooling / unit tests
    xbmc = None
    _IN_KODI = False


def _host(url):
    """The host out of a URL, for a sentence rather than for a request."""
    text = (url or "").split("//", 1)[-1]
    return text.split("/", 1)[0]


def lines(settings):
    """The screen's text, as a list of lines. Nothing here opens a socket."""
    from .provider import all_providers

    enabled = [p.label for p in all_providers(settings) if p.enabled()]
    tmdb_on = bool(settings.get("tmdb_api_key", "") or True)       # the built-in key means always on
    translate_on = settings.get_bool("tmdb_translate", True)
    log_on = settings.get_bool("verbose_trace", True)

    out = [T("Ovaj dodatak ne salje nikakvu statistiku i nema reklame. Nijedan tok se ne "
             "prosledjuje preko naseg servera — uredjaj razgovara direktno sa tvojim operaterom."), ""]

    # ---- 1. the licence -----------------------------------------------------
    #
    # NEITHER THE ADDRESS NOR THE INTERVAL IS PRINTED, and that is deliberate. What this page owes the
    # reader is what LEAVES the box and what comes back — it does not owe anyone the hostname to put in
    # a `hosts` file or the number of minutes to wait the check out. Both are discoverable by somebody
    # who reads Python or a router log, and neither is worth handing over on a television screen. The
    # third parties below (TMDB, the translator) ARE named, because there the address is the point:
    # they are not ours, and a reader deserves to know whose they are. test-privacy.py pins both halves.
    out.append("[B]%s[/B]" % T("1. Provera licence — povremeno"))
    out.append(T("Ide na nas server."))
    out.append(T("Salje: broj ovog uredjaja (izveden iz MAC adrese, pa hesovan), verziju dodatka, "
                 "otisak koda i otisak naloga — a to je hesovan spisak KOJI provajderi su podeseni, "
                 "nikad korisnicko ime i nikad lozinka."))
    out.append(T("Vraca: stanje licence, poruke iz panela i kljuc kojim se otkljucavaju sacuvane "
                 "lozinke na ovom uredjaju."))
    out.append(T("Server vidi tvoju IP adresu, kao i svaki server kome se javis; u panelu se cuva "
                 "samo njen hes, radi brojanja mreza."))
    out.append("")

    # ---- 2. support ---------------------------------------------------------
    out.append("[B]%s[/B]" % T("2. Poruka podrsci — samo kad je ti posaljes"))
    out.append(T("Uz poruku ide kraj loga sa ovog uredjaja i broj uredjaja, da bi se poruka spojila sa "
                 "pravim uredjajem. Lozinke, tokeni i kljucevi za tok se BRISU iz loga pre nego sto "
                 "se on uopste upise na disk."))
    # Two whole sentences rather than one with a word spliced in: a one-word key ("vodi") is a
    # fragment nobody can translate confidently, and it collides with every other use of the word.
    out.append(T("Log se trenutno vodi na ovom uredjaju.") if log_on else
               T("Log se trenutno ne vodi na ovom uredjaju."))
    out.append("")

    # ---- 3. TMDB and translation -------------------------------------------
    out.append("[B]%s[/B]" % T("3. Slike i opisi za Video klub (TMDB)"))
    if tmdb_on:
        out.append(T("Naziv filma ili serije koju gledas u Video klubu ide na api.themoviedb.org da "
                     "bi se nasla slika, opis i godina; same slike se preuzimaju sa image.tmdb.org. "
                     "Ne ide ni ko si, ni koji nalog imas."))
        if translate_on:
            out.append(T("Kad TMDB nema opis na srpskom, tekst opisa ide na Google prevodilac "
                         "(translate.googleapis.com). Iskljucuje se u podesavanjima."))
    else:
        out.append(T("Iskljuceno na ovom uredjaju."))
    out.append("")

    # ---- 4. the providers themselves ---------------------------------------
    out.append("[B]%s[/B]" % T("4. Tvoj TV provajder"))
    out.append(T("Ukljuceni: %s") % (", ".join(enabled) or T("nijedan")))
    out.append(T("Prijava, lista kanala, vodic i sam tok idu direktno sa ovog uredjaja na provajderov "
                 "server, tvojim nalogom. Mi to ne posredujemo i ne vidimo."))
    out.append("")

    # ---- 5. what stays here -------------------------------------------------
    out.append("[B]%s[/B]" % T("5. Sta ostaje na uredjaju"))
    out.append(T("Nalozi, lista kanala, vodic, log i istorija gledanja su fajlovi u fascikli ovog "
                 "dodatka. Lozinke se cuvaju sifrovane, kljucem koji stize uz licencu."))
    out.append(T("Sve to nestaje kad se dodatak obrise."))
    return out


def show(settings):
    """The screen. A text window, because this is something to read, not something to answer."""
    import xbmcgui
    xbmcgui.Dialog().textviewer(T("IPTV Balkan — privatnost"), "\n".join(lines(settings)))
