# -*- coding: utf-8 -*-
"""
M3U + XMLTV writers.

This is the bridge that buys a native PVR experience without a line of C++. IPTV Simple reads both
files and gives us the real channel list, the EPG grid, groups, channel numbers and catch-up — on
android-arm, arm64, x86_64 and everything else, from one platform-independent zip. A binary PVR addon
would mean a separate cross-compiled build per architecture, which is exactly the trap pvr.eon is in.

The per-channel `#KODIPROP` lines are what make DRM and per-provider headers work: inputstream.adaptive
reads the manifest type, the licence URL and the stream headers from them, so a Widevine channel needs
nothing beyond a correctly written playlist entry.
"""

import io
from xml.sax.saxutils import escape


def _attr(value):
    """
    One value, ready to sit inside the double quotes of an M3U attribute.

    Everything written here came from a provider — channel names, group names, logo URLs, category
    lists — and none of it is ours to trust. A single `"` in any of them closes the attribute early and
    IPTV Simple then reads the rest of the line as garbage: that channel disappears, and with an
    unlucky value so does the one after it. Nothing reports it; the list is simply short.

    M3U has no escaping mechanism of its own, so the quote is replaced with its typographic twin rather
    than encoded. It renders identically on screen and cannot terminate an attribute.
    """
    return unicode_type(value).replace(u'"', u"”").replace(u"\n", u" ").replace(u"\r", u"")


try:                                                       # pragma: no cover
    unicode_type = unicode                                 # noqa: F821  (Python 2 tooling)
except NameError:
    unicode_type = str


def _xml_attr(value):
    """
    Same job for XMLTV, where there IS a mechanism — and where the obvious call is the wrong one.

    `xml.sax.saxutils.escape()` handles `&`, `<` and `>` and deliberately leaves `"` alone, because it
    is written for element TEXT. Used on an attribute — which is what `<channel id="…">` and
    `<icon src="…">` are — it lets a quote through and produces XML that no parser will accept, so
    IPTV Simple drops the whole guide rather than one programme.

    `quoteattr()` is not the answer either, and the first version of this function used it: quoteattr
    CHOOSES the quote character, so a value containing `"` comes back wrapped in single quotes — and
    stripping the wrapper off to fit our own double quotes hands the raw `"` straight back. The entity
    map below is explicit about every character that can end an attribute, including the newlines an
    XML parser is free to fold into spaces.
    """
    return escape(unicode_type(value),
                  {u'"': u"&quot;", u"'": u"&apos;", u"\n": u"&#10;", u"\r": u"&#13;", u"\t": u"&#9;"})


def _prop(name, value):
    return u"#KODIPROP:%s=%s\n" % (name, value)


def header_blob(headers):
    """
    inputstream.adaptive takes stream headers as one urlencoded blob, not as separate properties.

    Public because the play route needs the SAME string: a channel tuned from Kodi's guide gets its
    headers from the playlist and one tuned through `plugin://` gets them from `default.play`, and the
    two used to build the blob differently — this one urlencoded, that one raw. inputstream.adaptive
    splits the blob on `&`, splits each pair at the first `=` and URL-DECODES the value, so a raw value
    is only harmless while it happens to contain none of `&`, `+` or `%`. Move's `X-Play-Auth` is a
    base64 token, which is exactly the value that eventually will.
    """
    try:
        from urllib.parse import quote
    except ImportError:                                   # pragma: no cover
        from urllib import quote
    return "&".join("%s=%s" % (k, quote(str(v), safe="")) for k, v in sorted((headers or {}).items()))


def write_m3u(path, channels, epg_url=None, group_by_provider=True, exact_archive_bar=False):
    """
    [channels] is a list of dicts. Only `id`, `name` and `url` are required; everything else is
    optional and simply omitted when absent:

        id, name, url, logo, group, number, tvg_id,
        manifest_type ("mpd"/"hls"), license_type, license_key, headers (dict),
        catchup_days, catchup_source, catchup_mode, catchup_play_as_live

    [exact_archive_bar] is the owner's answer to a trade-off Kodi will not let anybody have both ways —
    see the long note beside `epgplaybackaslive` below. False, the default, keeps the television
    overlay (mini guide, channel list) over an archive programme; True gives that programme its own
    honest timeline instead.
    """
    lines = [u"#EXTM3U"]
    if epg_url:
        # Quoted like every other attribute. It used to be written bare — quoteattr(...).strip('"') —
        # which is fine for a plain path and breaks the moment one has a space in it.
        lines.append(u' x-tvg-url="%s"' % _attr(epg_url))
    out = [u"".join(lines) + u"\n"]

    for ch in channels:
        attrs = [u'tvg-id="%s"' % _attr(ch.get("tvg_id") or ch["id"])]
        if ch.get("logo"):
            attrs.append(u'tvg-logo="%s"' % _attr(ch["logo"]))
        if ch.get("number"):
            attrs.append(u'tvg-chno="%s"' % _attr(ch["number"]))
        # IPTV Simple takes a SEMICOLON-separated list here, so a channel can sit in several groups at
        # once — which is what the providers actually describe (a channel is HD *and* Sport *and*
        # Local). The Android app's model allowed one group per channel and had to pick a winner; here
        # there is no reason to throw the rest away.
        #
        # The provider's own name goes FIRST, so Kodi's TV section offers "EON" and "Iris" as groups and
        # two subscriptions stop being one undivided list of 769 channels. It is an EXTRA group, not a
        # replacement: every themed group the provider describes is still there behind it. The
        # `provider=` attribute below looks like it should do this job and does not — Kodi 21 records it
        # for the channel manager, it is not a browsable grouping.
        groups = []
        if group_by_provider and ch.get("provider_label"):
            groups.append(unicode_type(ch["provider_label"]))
        if ch.get("group"):
            groups.append(unicode_type(ch["group"]))
        if groups:
            attrs.append(u'group-title="%s"' % _attr(u";".join(groups)))
        if ch.get("radio"):
            # Without this the audio stations land in Kodi's TV list. With it they get their own Radio
            # section, which is where someone looks for them.
            attrs.append(u'radio="true"')
        if ch.get("provider_label"):
            attrs.append(u'provider="%s"' % _attr(ch["provider_label"]))
        # Catch-up is a playlist attribute in IPTV Simple: given a window and a templated source it
        # renders the whole archive in the guide, with no extra code on our side.
        if ch.get("catchup_days"):
            # The MODE is per provider, not one setting for all of them, because the two archives here
            # are different shapes.
            #
            #   "default" — a timeshift stream. IPTV Simple re-requests catchup-source with a NEW {utc}
            #               on every seek. Right for EON: that source is the loopback redirector, so a
            #               seek costs one cheap HTTP fetch that ffmpegdirect makes itself.
            #
            #   "vod"     — one programme, resolved ONCE, seeked inside by the player. Right for Iris:
            #               its CUTV call returns a STATIC manifest covering the whole programme
            #               (playseek=<start>-<end>), which is already natively seekable.
            #
            # Iris on "default" is what made replay "work, then not, then drop back to the guide": its
            # source is a plugin:// URL, so every seek re-entered the addon, re-ran PlayChannel and
            # re-negotiated Widevine — playback restarted instead of moving, and a slow or failed
            # re-resolve left Kodi with nothing to play.
            attrs.append(u'catchup="%s" catchup-days="%s"'
                         % (_attr(ch.get("catchup_mode") or "default"), _attr(ch["catchup_days"])))
            if ch.get("catchup_source"):
                attrs.append(u'catchup-source="%s"' % _attr(ch["catchup_source"]))

        # The name sits after the comma, where a quote is harmless — but a newline in it would split
        # the entry in two and orphan the URL on the line below.
        out.append(u"#EXTINF:-1 %s,%s\n"
                   % (u" ".join(attrs), unicode_type(ch["name"]).replace(u"\n", u" ")))

        # WHOSE TIMELINE the archive gets, decided per channel rather than by one setting for the box.
        #
        # IPTV Simple's `catchupPlayEpgAsLive` makes a replayed programme arrive at Kodi as a LIVE
        # channel with a timeshift buffer: the PVR overlay stays, so the guide and the channel list are
        # a button away, and for EON that is right — its archive really is a sliding window and
        # ffmpegdirect re-mints the URL as you scrub, so Kodi's live model is describing the truth.
        #
        # For Iris it is a lie with a visible cost. A CUTV resolve returns a STATIC manifest of exactly
        # one programme, seekable end to end by inputstream.adaptive — but in live mode Kodi draws the
        # bar from its own live model instead of from the media, and the result is the report this
        # exists to fix: a bar sitting near-full at the wrong scale, a clock that disagrees with the
        # picture, and a nudge of the remote that jumps ten minutes or falls off the end.
        #
        # The setting is per IPTV Simple INSTANCE, which is why this looked for three releases like it
        # needed a second instance carrying the Iris channels alone. It does not. The mechanism, read
        # off the sources rather than guessed:
        #
        #   * a `#KODIPROP` becomes an ordinary channel property (PlaylistLoader keeps any key it does
        #     not recognise, lowercased);
        #   * StreamUtils::SetAllStreamProperties appends the channel's own properties BEFORE the
        #     catchup ones, so ours is the earlier entry;
        #   * Kodi's CPVRStreamProperties::EPGPlaybackAsLive() takes the FIRST match in that list.
        #
        # So a channel that says `epgplaybackaslive=false` opts itself out and is played as a bounded
        # video with the media's own timeline, while every other channel keeps the instance setting.
        #
        # WHAT IT COSTS, and why it is now the owner's choice instead of ours. A programme played that
        # way is not a channel as far as Kodi is concerned: `CPVRPlaybackState` records a playing EPG
        # TAG and never a playing channel, `IsPlayingTV()` is therefore false, and the fullscreen
        # window's keymap context falls back to the plain video one. The mini guide, the channel list
        # and channel up/down all belong to the live context, so they are simply not there. That is
        # what was reported after 1.18.9 — "I want to see the mini EPG and the channel list when I go
        # back in the archive too" — and it is not a bug in either half: Kodi will not draw a live
        # overlay over a stream it has been told not to treat as live, and it will not draw a truthful
        # bar over one it does. Only one of the two can be true at a time.
        #
        # So the default is the overlay, which is what television behaves like and what was asked for,
        # and `archive_exact_bar` is there for whoever would rather scrub accurately. Nothing else
        # changes with it: the provider still declares its own catch-up MODE, so an Iris replay is
        # still resolved once and seeked inside rather than re-resolved on every nudge.
        if exact_archive_bar and ch.get("catchup_days") and ch.get("catchup_play_as_live") is False:
            out.append(_prop("epgplaybackaslive", "false"))

        # Which inputstream opens this channel. Defaults to inputstream.adaptive, which is what every
        # manifest-based provider here wants; a channel can name another one, and EON does — it asks for
        # inputstream.ffmpegdirect so IPTV Simple will hand that addon its catch-up properties and
        # archive seeking becomes possible at all. The property namespace follows the addon's name,
        # which is why it cannot simply be hardcoded twice.
        engine = ch.get("inputstream") or ("inputstream.adaptive" if ch.get("manifest_type") else "")
        if engine:
            out.append(_prop("inputstream", engine))
            if ch.get("manifest_type"):
                out.append(_prop("%s.manifest_type" % engine, ch["manifest_type"]))
            if engine.endswith("ffmpegdirect"):
                # A live stream that is not declared as one is opened as a file, and then Kodi shows a
                # finished-length progress bar over something that never ends.
                out.append(_prop("inputstream.ffmpegdirect.is_realtime_stream", "true"))
        if ch.get("license_type"):
            out.append(_prop("inputstream.adaptive.license_type", ch["license_type"]))
        if ch.get("license_key"):
            out.append(_prop("inputstream.adaptive.license_key", ch["license_key"]))
        if ch.get("headers"):
            blob = header_blob(ch["headers"])
            # Both properties, deliberately: older inputstream.adaptive reads stream_headers, newer
            # prefers manifest_headers, and a channel that plays on one Kodi version and not another is
            # the kind of difference nobody enjoys chasing.
            out.append(_prop("inputstream.adaptive.stream_headers", blob))
            out.append(_prop("inputstream.adaptive.manifest_headers", blob))

        out.append(ch["url"] + u"\n")

    with io.open(path, "w", encoding="utf-8", newline="") as handle:
        handle.write(u"".join(out))
    return len(channels)


def write_xmltv(path, channels, programmes):
    """
    [programmes] is a list of dicts: channel_id, start/stop (both 'YYYYmmddHHMMSS +0000'), title, and
    optionally desc, category, icon.
    """
    out = [u'<?xml version="1.0" encoding="UTF-8"?>\n',
           u'<tv generator-info-name="IPTV Balkan">\n']
    for ch in channels:
        cid = ch.get("tvg_id") or ch["id"]
        out.append(u'  <channel id="%s">\n' % _xml_attr(cid))
        out.append(u'    <display-name>%s</display-name>\n' % escape(ch["name"]))
        if ch.get("logo"):
            out.append(u'    <icon src="%s" />\n' % _xml_attr(ch["logo"]))
        out.append(u'  </channel>\n')
    for p in programmes:
        out.append(u'  <programme start="%s" stop="%s" channel="%s">\n'
                   % (_xml_attr(p["start"]), _xml_attr(p["stop"]), _xml_attr(p["channel_id"])))
        out.append(u'    <title>%s</title>\n' % escape(p.get("title") or ""))
        if p.get("desc"):
            out.append(u'    <desc>%s</desc>\n' % escape(p["desc"]))
        if p.get("category"):
            out.append(u'    <category>%s</category>\n' % escape(p["category"]))
        if p.get("icon"):
            out.append(u'    <icon src="%s" />\n' % _xml_attr(p["icon"]))
        out.append(u'  </programme>\n')
    out.append(u'</tv>\n')
    with io.open(path, "w", encoding="utf-8", newline="") as handle:
        handle.write(u"".join(out))
    return len(programmes)
