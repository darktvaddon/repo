# -*- coding: utf-8 -*-
"""
Trial + licence gate.

Seven days of everything, then the addon stops until the device is unlocked from the panel. The user
sees a plain number ("Uređaj 4017"), sends it to the Telegram group after paying, and the unlock is
one click on the server.

## What this can and cannot do — read before trusting it

This is a Python addon. Kodi unzips it into `addons/plugin.video.iptvbalkan/` and the source sits there in
plain text; anyone who opens this file can delete the check. Nothing written here changes that, and it
would be dishonest to pretend otherwise. What it does do is close the cheap paths that don't need any
programming at all:

* **The trial clock is the server's, not the box's.** A local "first run" date is defeated by deleting
  the addon's data folder or setting the TV's clock back. The server records when this device was first
  seen and answers with a verdict; the box only caches it.
* **The device id is DERIVED, not stored.** Reinstalling the addon re-derives the same id from the same
  hardware, so a fresh install lands back on the same expired trial instead of starting a new one. The
  cost of that choice is that a genuine hardware/network change reads as a new device — one message,
  which is the right side to err on.
* **The answer is signed (ECDSA P-256), same key and same wire format as the Android app.** Without
  this, the whole gate is defeated by one line in a `hosts` file pointing the licence domain at a
  local server that answers "licensed". That is not a theoretical attack — it is the one that beat the
  Android kill switch before 2.1.0.

The honest ceiling: this moves an attacker from "edit one text file" to "read Python and edit one text
file". For the audience that buys a TV box with Kodi on it, that is a real difference. For someone who
programs, it is not a lock at all.

## Failure policy

Never punish a paying user for a network blip, and never let an outage lock everyone at once. So:

* A verdict only counts when it VERIFIES. An unsigned or badly-signed answer cannot grant OR revoke.
* An unreachable server keeps the last good verdict for [GRACE_DAYS]; only after that does it stop.
* A device that has never once been verified gets [FIRST_RUN_GRACE_DAYS] of benefit of the doubt, so a
  box that is offline on the day it is installed is not dead on arrival.

Trust-on-first-signature, exactly like the Android client: until this install has seen one valid
signature it accepts an unsigned answer, so the addon can ship before the server endpoint is live
without locking anybody out. After the first valid signature, unsigned means someone is downgrading us.
"""

import base64
import hashlib
import io
import json
import os
import re
import time
import uuid

from . import diag, ecdsa, net
from .i18n import T

try:
    import xbmc
    _IN_KODI = True
except ImportError:                       # tooling / unit tests
    xbmc = None
    _IN_KODI = False

#: Where the verdict comes from, unless this box has been told otherwise. Same signing key either way.
DEFAULT_ENDPOINT = "https://iptvbox-player.com/licence/api/kodi-licence.php"


def endpoint(settings):
    """
    The address this box asks, which the server itself is allowed to move.

    A domain is a business decision, and this addon is sold under a name that has nothing to do with the
    one in the address compiled into it. Changing that in a release would reach only the boxes that
    update — and the ones that never do would keep asking a host that has to stay alive for them alone,
    for ever.

    So the address is a SIGNED parameter (`params.licence_endpoint`, see _verdict_fields) and it is
    remembered. A box on this version follows the move at its next check, whatever version it is on when
    the move happens; the old host only has to outlive the boxes that predate this mechanism, which is a
    finite and shrinking set rather than an open-ended promise.

    Signed, and https-only, for the obvious reason: an unsigned answer able to set this would redirect
    every box to whoever answered — see param_url. And the compiled default is always the fallback, so a
    stored address that stops answering cannot strand anybody: a box that cannot reach its remembered
    endpoint tries the built-in one on the next check.
    """
    stored = str(settings.get("licence_endpoint", "") or "").strip()
    return stored if stored.startswith("https://") else DEFAULT_ENDPOINT


#: Kept as a module-level name because tests and tools read it. The live value is endpoint().
ENDPOINT = DEFAULT_ENDPOINT

#: SPKI DER, base64 — the PUBLIC half of the server's P-256 signing key, byte-for-byte the same string
#: the Android build carries as `licencePublicKey`. Public by nature: it can only verify, never sign.
PUBLIC_KEY = ("MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEoffopHXdfHfg9OeL9BiLBbAPEMWYVWYnRal4OBfI9zqc"
              "QT5Eku/DEraHouI8fVAs75MybrrhmsH94kPqT6lLoA==")

#: **The gate is OFF.** Nothing is ever refused. Flip to True (and rebuild) when the licence is meant
#: to bite. Which licence model that will be — a server verdict or a signed file pasted in from a
#: phone — is still open; both are keyed on the same device id, so nothing here has to be decided yet.
ENFORCE = False

#: TRUST-ON-FIRST-SIGNATURE, AND WHY IT IS TIED TO [ENFORCE] RATHER THAN LEFT ON.
#:
#: An install that has never seen a valid signature accepts an UNSIGNED answer. That exists so the
#: addon can ship before the server signs without locking anybody out — and while the endpoint does not
#: exist yet, that is every install.
#:
#: Which makes it, until the day the server goes up, a complete bypass: a `hosts` entry plus a static
#: `{"ok":true,"state":"licensed"}` is a permanent licence, and because a good answer also refreshes
#: `last_good`, the offline grace never runs out either. Exactly the attack that beat the Android kill
#: switch before 2.1.0.
#:
#: So it is not a flag anyone has to remember to remove before going live: the moment enforcement is on,
#: unsigned means untrusted, full stop. A build that refuses nothing may as well accept one.
#:
#: A CONSTANT WAS THE WRONG SHAPE FOR THIS, and it left the bypass open on every shipped box. Enforcement
#: became a panel switch (the signed `enforce` field — see [enforcing_for]), but this stayed pinned to
#: the COMPILED value, so turning enforcement on server-side left the unsigned path wide open: a `hosts`
#: entry answering `{"ok":true,"state":"licensed"}` unsigned would still be accepted, and a good answer
#: also refreshes `last_good` so the offline grace never runs out either. The gate would have been on
#: and the way around it still there.
#:
#: The constant is GONE rather than left beside the function. A module-level `ALLOW_UNSIGNED` that reads
#: as the answer, next to a function that actually is the answer, is how the wrong one gets used — which
#: is precisely how this happened.


def allow_unsigned(state):
    """
    Whether an UNSIGNED answer may still be believed, for a box whose cached [state] this is.

    Both halves have to be false for it: the compiled floor AND whatever the panel last told this box.
    An install that has never reached the server has neither, and is the case the whole
    trust-on-first-signature idea exists for.

    Reads the CACHED enforcement rather than asking, deliberately — the decision is needed while judging
    an answer, and asking the server whether to trust the server is not a question that can be answered.
    A box that has been enforcing keeps refusing unsigned answers even while offline, which is the
    direction that fails safe.
    """
    return not enforcing_for(state)

#: Whether an unenforcing build still ASKS. Separate from ENFORCE on purpose: these are two questions,
#: not one. It was originally implied by ENFORCE — an off build still contacted the server "so the
#: whole path is exercised on real hardware" — and that cost a 404 on every launch and every six hours
#: against a server that is not deployed, buried a real bug under seventeen pages of log, and told a
#: tester the licence server was unreachable on a build with no licence.
#:
#: **Now on.** The reason it was off has gone away — the endpoint is deployed and answers properly — and
#: leaving it off had a consequence nobody had connected to it: with both switches false, `check()`
#: returns before it ever opens a socket, so the addon never asked the panel anything. No state, no kill
#: switch, and no messages. A message sent from the panel was not late and not lost; it was never
#: collected. Asking costs one small GET per quarter hour and cannot refuse anything while ENFORCE is
#: False.
CHECK_WHEN_OFF = True

#: The support group, shown on the licence screen and offered there as a QR — that screen is the one
#: someone opens when something is wrong, and it already has the device number they will be asked for.
#:
#: This link is in readable source and therefore effectively public: anyone holding the addon can join.
#: That is fine for a support group and is the point; if it ever needs to be closed, revoke this invite
#: in Telegram and ship a new one rather than expecting it to stay private.
TELEGRAM_URL = "https://t.me/+d7XjefqrYkkyYjlk"
SUPPORT_TEXT = "Podrska i obavestenja — Telegram grupa:"

STATE_FILE = "licence.json"
#: How long a previously-good verdict survives an unreachable server.
GRACE_DAYS = 7
#: How long a never-yet-verified install is given before the gate closes on it.
FIRST_RUN_GRACE_DAYS = 3
#: A signed document older than this is a replay, not an answer.
MAX_SIGNED_AGE_SECONDS = 3 * 24 * 3600
#: Tolerance for a box whose clock runs fast. A wrong clock must not look like an attack.
FUTURE_SKEW_SECONDS = 24 * 3600
#: Don't ask the server on every single action — this is a licence, not a heartbeat.
#: How often this box actually ASKS the server.
#:
#: Was six hours plus up to an hour of spread, which made everything the panel can do arrive up to
#: SEVEN hours late — a message sent to a customer, and the kill switch itself. That is not control, and
#: it is what "I sent a message and never saw it" turned out to be. Fifteen minutes makes the panel feel
#: like a panel; the cost is one small GET per box per quarter hour, which is nothing for the endpoint
#: and nothing for the box.
CHECK_INTERVAL_SECONDS = 15 * 60
#: The per-device spread, shortened to match. Its two reasons still hold — a shipment switched on
#: together must not ask in the same second, and a check that lands at a predictable moment can be
#: waited out with the network pulled — but a whole hour of jitter on a fifteen minute cycle would
#: double the worst case.
CHECK_SPREAD_SECONDS = 300

TRIAL = "trial"
LICENSED = "licensed"
EXPIRED = "expired"
UNKNOWN = "unknown"
#: This build has no gate at all (ENFORCE off). A state of its own rather than UNKNOWN, because
#: UNKNOWN means "could not find out" and this means "there is nothing to find out".
OFF = "off"


class Verdict(object):
    """What the gate knows right now, and everything the licence screen needs to render."""

    def __init__(self, state=UNKNOWN, serial="", trial_ends="", licensed_until="", message="",
                 verified=False, source="cache", device=""):
        self.state = state
        self.serial = serial
        #: This box's own id, always known — unlike [serial], which only a server can hand out. Kept
        #: separate so the licence screen has something real to show before any licence model exists.
        self.device = device
        self.trial_ends = trial_ends
        self.licensed_until = licensed_until
        self.message = message
        self.verified = verified
        self.source = source
        #: Whether the gate bites for THIS box. Set from the cached state — see [enforcing_for].
        self.enforcing = ENFORCE

    @property
    def allowed(self):
        # One place, deliberately: every gate in the addon asks this, so a build with the gate off
        # cannot have a caller somewhere that still refuses.
        if not self.enforcing:
            return True
        return self.state in (TRIAL, LICENSED, UNKNOWN)

    def as_dict(self):
        return {"state": self.state, "serial": self.serial, "trial_ends": self.trial_ends,
                "licensed_until": self.licensed_until, "message": self.message}


# ---- device identity --------------------------------------------------------

#: What a hardware address looks like. Six pairs of hex, separated by colons or dashes — nothing else
#: is accepted, and that is the entire fix for the worst bug this project has had.
_MAC = re.compile(r"^[0-9a-f]{2}([:-][0-9a-f]{2}){5}$", re.I)

#: Kodi answers `Network.MacAddress` with a LOCALISED PLACEHOLDER while it is still resolving the value.
#: In English that word is "Busy"; in Serbian, "Zauzeto". The old code accepted any non-empty answer, so
#: it hashed the placeholder — and every box on the same interface language got the SAME id:
#:
#:     sha256("iptvbox:busy")    = 9c18a200…   every English box, all of them serial 4009
#:     sha256("iptvbox:zauzeto") = 00cc05e9…   every Serbian box, all of them serial 4012
#:
#: Two customers' boxes were literally one record in the panel. One trial covered everybody, one block
#: would have blocked everybody, and every box shared a vault key. Found on 2026-08-01 by installing the
#: addon fresh on a box whose Kodi had just been switched to Serbian: it took over the serial belonging
#: to a completely different person's device, in another town.
#:
#: The lesson is not "handle Busy" — it is that an identity read from someone else's API must be
#: VALIDATED, not merely checked for emptiness. Hence the shape above rather than a list of words.
_RETRIES = 5
_RETRY_PAUSE_MS = 400


def _hardware_address():
    """Kodi's MAC, or "" — asked a few times, because the first answer is often the placeholder."""
    if not _IN_KODI:
        return ""
    for attempt in range(_RETRIES):
        raw = (xbmc.getInfoLabel("Network.MacAddress") or "").strip()
        if _MAC.match(raw) and raw not in ("00:00:00:00:00:00", "ff:ff:ff:ff:ff:ff"):
            return raw
        if attempt == 0 and raw:
            diag.log("Licence: Kodi answered %r for the hardware address — waiting for the real one"
                     % raw[:24])
        xbmc.sleep(_RETRY_PAUSE_MS)
    return ""



def install_id(settings):
    """
    WHICH INSTALLATION this is, as opposed to which device.

    The device id is derived from the hardware so that a reinstall lands back on the same licence — that
    is deliberate and it stays. Its cost is that the number can be MOVED: type it into a second box, or
    copy the whole data folder, and two televisions hold one licence. Nothing the box can compute about
    itself closes that, because everything the box computes is under the copier's control.

    What does close it is the SERVER refusing to serve one number in two places at once, and to do that
    it has to be able to tell two installs apart. So each installation mints a random id once and keeps
    it. It is not an identity and it proves nothing on its own: a copied FOLDER carries it along, which
    is exactly why the server also watches the network a check comes from. Between the two, "the same
    number is being used somewhere else" becomes a question with an answer.
    """
    existing = settings.get("licence_install_id", "").strip()
    if existing:
        return existing
    fresh = uuid.uuid4().hex
    settings.set("licence_install_id", fresh)
    return fresh


def device_id(settings):
    """
    A stable id for this box, derived from hardware rather than remembered.

    Derivation, not storage, is the whole point: a stored id lives in the addon's data folder, and
    deleting that folder is the first thing anyone tries. The MAC address survives a reinstall, a
    settings reset and a Kodi upgrade.

    An override is still allowed (`licence_device_id` in settings), because a box that reports no MAC at
    all would otherwise mint a fresh random id on every launch — which reads to the server as an endless
    stream of new devices, each starting its own trial. That would be a hole, not a feature, so the
    random fallback is written back and reused.
    """
    override = settings.get("licence_device_id", "").strip()
    if override:
        return override

    # DERIVED ONCE, THEN REMEMBERED — and the order matters in both directions.
    #
    # Deriving it fresh every time looks stricter and is actually wrong: Kodi reports the MAC of the
    # interface that is currently up, so moving a box from Wi-Fi to a network cable changes it. To the
    # server that is a different device — a new serial, and a customer who has PAID goes back to locked
    # for no reason they could ever guess. The same happens with a USB dongle, or a box that brings its
    # interfaces up in a different order after a firmware update.
    #
    # Remembering it reopens exactly one hole: delete the addon's data and the id is derived again. That
    # hole is closed elsewhere and better — the trial is bound to the SUBSCRIPTION as well (see
    # account_fingerprint), so a reinstall inherits the week it already used rather than getting a new
    # one. Identity stability for the paying customer, farming protection from the account binding:
    # each problem solved where it actually can be.
    #
    # A seed remembered by a version that accepted the placeholder is NOT trustworthy, and there is no
    # way to tell a good one from a bad one by looking at it — both are 64 hex characters. So the
    # marker below records that a seed was written by the validating code; a seed without it is
    # re-derived ONCE. A box whose MAC really was read correctly derives the identical value again and
    # nothing moves; a box that was carrying "busy" gets its own identity for the first time.
    remembered = settings.get("licence_device_seed", "").strip()
    if remembered and settings.get("licence_device_seed_ok", "") == "1":
        return remembered

    raw = _hardware_address()
    if not raw:
        node = uuid.getnode()
        # uuid.getnode() sets the multicast bit when it had to invent a number, i.e. it found no real
        # hardware address. That case must be persisted or it changes every run.
        raw = "%012x" % node
        if node >> 40 & 0x01:
            fresh = hashlib.sha256(("random:" + str(uuid.uuid4())).encode("utf-8")).hexdigest()
            settings.set("licence_device_id", fresh)
            diag.log("Licence: this box reports no hardware address; a stored id was minted instead")
            return fresh
    # The hardware address ALONE. The box's friendly name used to be mixed in here, and it is something
    # the owner edits in Kodi's own settings — renaming "Kodi" to "Dnevna soba" changed the derived id,
    # which to the server is a brand new device: the trial restarts, and a device that was already paid
    # for goes back to locked. An identity has to be derived from things the user cannot casually
    # change, or it is not an identity.
    derived = hashlib.sha256(("iptvbox:%s" % raw.lower()).encode("utf-8")).hexdigest()
    if remembered and remembered != derived:
        diag.log("Licence: the stored device id was derived by a version that could not tell a "
                 "hardware address from Kodi's \"busy\" placeholder — re-derived, this box now has its "
                 "own number", "ERROR")
    settings.set("licence_device_seed", derived)
    settings.set("licence_device_seed_ok", "1")
    return derived


#: Mixed into the account fingerprint below. Not a secret — it is in this file — and it is not trying to
#: be one. It exists so the value cannot be produced by hashing a username with a generic tool and
#: matched against the server's records by someone who obtains a copy of them.
ACCOUNT_SALT = "iptvbox-kodi-account-v1"


def account_fingerprint(settings):
    """
    A hash of WHICH SUBSCRIPTIONS this box is configured with — the one thing a trial farmer cannot
    throw away.

    Everything else that identifies an installation can be reset by someone determined enough: delete
    the addon, reinstall Kodi, flash the box, spoof the MAC, run it in an emulator. Each of those hands
    out another seven free days. What does NOT get thrown away is the paid television subscription the
    whole addon exists to use — nobody farms trials by cancelling their EON account.

    So the server keys the trial on this as well as on the device: a NEW device presenting an account
    that has already had its week inherits that week rather than starting a fresh one.

    Only a HASH leaves the box, and only of the account identifiers — never a password, and never the
    username in the clear. It is per-provider and sorted, so the same set of accounts always produces
    the same value regardless of the order they were configured in.

    Empty when nothing is configured yet, which is the honest answer at that moment: a box with no
    account has nothing to bind to, and it gets its trial on device identity alone.
    """
    parts = []
    for key, fields in (("eon", ("username",)), ("iris", ("username",)), ("move", ("username",)),
                        ("yettel", ("udid",)), ("xtream", ("host", "username"))):
        values = [settings.get("%s_%s" % (key, field), "").strip().lower() for field in fields]
        if all(values):
            parts.append("%s:%s" % (key, "|".join(values)))
    if not parts:
        return ""
    raw = ACCOUNT_SALT + ";" + ";".join(sorted(parts))
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:24]


# ---- signature --------------------------------------------------------------

def verify_signed(body, expected_device, now_seconds):
    """
    Returns the signed document when it is genuinely ours, else None.

    The signature covers the EXACT bytes of the base64 `payload` blob — neither side re-serialises, so
    there is no canonicalisation for the two to disagree about, which is how signature schemes usually
    end up quietly broken. `ts` and `device` are checked too: a signature alone would let someone capture
    one genuine "licensed" reply and serve it forever, or replay a paying device's reply onto their own.
    """
    payload_b64 = body.get("payload") or ""
    sig_b64 = body.get("sig") or ""
    if not payload_b64 or not sig_b64:
        return None
    try:
        payload_bytes = base64.b64decode(payload_b64)
        sig_bytes = base64.b64decode(sig_b64)
        # Our own verifier, NOT pycryptodome. On the user's own box that module is an empty stub that
        # Kodi still reports as installed, so `import Crypto` raises — and with signing enabled that
        # would make every answer untrustworthy and eventually lock a paying customer out. See
        # ecdsa.py, and aes.py, which exists for the same reason.
        #
        # DER, because PHP's openssl_sign emits a DER-encoded ECDSA signature — the same thing the
        # Android client's SHA256withECDSA expects. A raw (r||s) signature would fail here silently.
        if not ecdsa.verify(base64.b64decode(PUBLIC_KEY), payload_bytes, sig_bytes):
            diag.log("Licence: signature does not verify", "ERROR")
            return None
        payload = json.loads(payload_bytes.decode("utf-8"))
    except Exception as err:                                   # noqa: BLE001 - any failure is "not ours"
        diag.log("Licence: signature rejected (%s: %s)" % (type(err).__name__, err), "ERROR")
        return None

    ts = int(payload.get("ts") or 0)
    if ts <= 0:
        diag.log("Licence: signed answer carries no timestamp", "ERROR")
        return None
    age = now_seconds - ts
    if age > MAX_SIGNED_AGE_SECONDS:
        diag.log("Licence: signed answer is %ds old — replay, not an answer" % age, "ERROR")
        return None
    if age < -FUTURE_SKEW_SECONDS:
        diag.log("Licence: signed answer is dated in the future", "ERROR")
        return None
    # THE `device` FIELD IS REQUIRED, not merely checked when it happens to be there.
    #
    # The old condition needed BOTH sides to be non-empty before it compared anything, so a signed
    # document carrying no `device` at all sailed through — and that is the one shape an attacker would
    # choose. What it buys: capture one genuine "licensed" reply and replay it onto every other box for
    # as long as `ts` allows (three days). Signing alone does not stop that; the binding does, and only
    # if it cannot be opted out of by omission.
    #
    # Not exploitable against the current server — checked live 2026-08-02, its payload does carry
    # `device` — which is exactly why this is the moment to close it, before the gate is switched on and
    # a replayed "licensed" is worth something.
    for_device = payload.get("device") or ""
    if expected_device and for_device != expected_device:
        diag.log("Licence: signed answer is addressed to %s, not to this device"
                 % (for_device or "nobody in particular"), "ERROR")
        return None
    return payload


# ---- state ------------------------------------------------------------------

def _state_path(settings):
    return os.path.join(settings.profile_dir(), STATE_FILE)


def _read_state(settings):
    try:
        with io.open(_state_path(settings), "r", encoding="utf-8") as handle:
            data = json.loads(handle.read())
        return data if isinstance(data, dict) else {}
    except (OSError, IOError, ValueError):
        return {}


def _write_state(settings, state):
    try:
        with io.open(_state_path(settings), "w", encoding="utf-8") as handle:
            handle.write(json.dumps(state, ensure_ascii=False))
    except (OSError, IOError, ValueError) as err:
        diag.log("Licence: could not cache the verdict (%s)" % err, "ERROR")


# ---- the check --------------------------------------------------------------

def check(settings, force=False, allow_network=True):
    """
    Ask the server, cache the answer, and return the verdict the gate should act on.

    [force] skips the poll interval — used by the "Check licence now" action, so a user who has just
    paid does not wait six hours to see it.

    [allow_network] is False on the ONE path where a person is waiting for a picture: pressing play.
    A tune that happened to land on the fifteen-minute poll used to pay for the whole HTTP round trip
    before anything provider-side even started — a third of a second on a good day, and up to the
    fifteen-second timeout when the licence server is reachable but slow, which is the worst kind of
    "sometimes a channel takes forever to start" because nothing about it points at us.

    Nothing is weakened by it: the cached verdict is what the gate reads anyway, the service refreshes
    it every thirty minutes, and the offline rules below still expire a box that has genuinely stopped
    proving anything. All it removes is the coincidence of a network call standing in front of a
    button press.
    """
    hw = device_id(settings)

    # No gate in this build, so there is no verdict to compute and nothing to ask. Returned from here
    # rather than falling through everything below for two reasons, both learned the hard way:
    #
    #   * the request went to an endpoint that is not deployed yet, on every launch and every six
    #     hours, and wrote a 404 with its whole HTML error page into the log — most of what made a
    #     17-page log that a real bug was hiding inside;
    #   * the offline rules below answer "how long has this box been unable to PROVE anything", which
    #     is a question with no meaning when nothing is being proved. Run anyway, they eventually put
    #     "the licence server is unreachable" on the screen of a build that has no licence.
    #
    # The device id is still derived and still shown, because that number is what ANY licence model —
    # server verdict or signed file — ends up keyed on, and it must not change when one is chosen.
    if not ENFORCE and not CHECK_WHEN_OFF:
        return Verdict(state=OFF, device=hw, source="off")

    state = _read_state(settings)
    now = int(time.time())

    # Spread out per device, derived from its own id so it is stable rather than random per launch.
    # Two reasons: a shipment of boxes switched on together would otherwise ask in the same second
    # every six hours, and a check that lands at a predictable moment is one that can be waited out
    # with the network pulled.
    spread = int(hw[:4], 16) % CHECK_SPREAD_SECONDS if len(hw) >= 4 else 0
    due = force or (now - int(state.get("last_check") or 0)) >= CHECK_INTERVAL_SECONDS + spread
    if due and not allow_network:
        # Not "skipped" — deferred. The service polls on its own schedule and will do this within the
        # half hour; the cached verdict below is what would have been used anyway if the server had not
        # answered. Logged at all only because a box that NEVER checks would otherwise be invisible.
        diag.log("Licence: a check was due at play time — left to the service so the tune is not held up")
        due = False
    if due:
        session = net.Session({"user_agent": "IPTVBalkan-Kodi/1.0"}, timeout=15,
                              trace=settings.verbose())
        # The build fingerprint rides along. It cannot stop anyone — a person editing the gate can edit
        # this too — but it means a MODIFIED copy announces itself, and the panel sees which serial is
        # running something other than what was shipped. Cheap, and it turns "someone probably cracked
        # it" into a row with a number on it.
        # What rides UP. Beyond identifying the box, this is what makes a panel list worth looking at:
        # which addon version, which commands it understands (so a panel can grey out what an older box
        # cannot do), and when it last managed to build a catalogue. All short — it is a query string.
        from . import commands as _commands
        url = ("%s?device_hw_id=%s&version=%s&build=%s&acct=%s&can=%s&refreshed=%s&channels=%s"
               "&inst=%s") % (
            endpoint(settings), hw, _addon_version(), build_fingerprint(), account_fingerprint(settings),
            ",".join(_commands.SUPPORTED),
            _quote(settings.get("last_refresh", "")),
            _quote(settings.get("last_channel_count", "")),
            install_id(settings))
        try:
            body = session.get(url)
        except net.HttpError as err:
            # Unreachable is NOT a verdict. Fall through to whatever the cache says.
            diag.log("Licence: server unreachable (%s) — using the cached verdict" % err)
            body = None
        if isinstance(body, dict):
            signed = verify_signed(body, hw, now)
            seen_signing = bool(state.get("signing_seen"))
            if signed is not None:
                # Once we know this server signs, an unsigned answer is a downgrade attempt, not an
                # older server. The latch is one-way on purpose.
                state["signing_seen"] = True
                state.update(_verdict_fields(signed, True))
                state["last_good"] = now
                state["last_check"] = now
                # A move is written to SETTINGS, not only to the cached verdict: the verdict can be
                # cleared, and an address that survives only as long as the cache is an address that
                # sends the box back to the old host the moment anything resets it.
                moved = str(state.pop("endpoint", "") or "")
                if moved and moved != settings.get("licence_endpoint", ""):
                    if settings.set("licence_endpoint", moved):
                        diag.log("Licence: the server moved this box to %s" % moved)
                _write_state(settings, state)
            elif allow_unsigned(state) and not seen_signing and body.get("ok"):
                # Trust-on-first-signature: this install has never seen a signature, so an unsigned
                # answer is accepted exactly as it was before signing existed. Nothing is latched.
                # `state` is this box's cached verdict, so a box the panel has put into enforcement
                # refuses this branch even though the shipped build has ENFORCE off.
                state.update(_verdict_fields(body, False))
                state["last_good"] = now
                state["last_check"] = now
                _write_state(settings, state)
            else:
                diag.log("Licence: answer was not trustworthy — the cached verdict stands", "ERROR")
                state["last_check"] = now
                _write_state(settings, state)

    return _verdict_from_state(settings, state, now)


def cached_state(settings):
    """The stored verdict, for callers that need something out of it without triggering a check —
    see vault.key_for, which must never start a second conversation with the server."""
    return _read_state(settings)


def _verdict_fields(doc, verified):
    """
    The parts of an answer worth keeping.

    [verified] is not decoration. Two of these fields are only safe from a document whose SIGNATURE
    checked out, and the trust-on-first-signature path accepts unsigned answers by design:

      * `vault_key` unlocks the stored provider passwords. An unsigned answer supplying one would
        defeat the entire reason they are encrypted — anyone able to answer HTTP could hand a cracked
        copy its key.
      * `messages` put a dialog on someone's television.

    The state itself may come from an unsigned answer, because that is what lets the addon ship before
    the server signs without locking anybody out.
    """
    fields = {
        "state": str(doc.get("state") or UNKNOWN),
        "serial": str(doc.get("serial") or ""),
        "trial_ends": str(doc.get("trial_ends_at") or ""),
        "licensed_until": str(doc.get("licensed_until") or ""),
    }
    if not verified:
        # No `message` either. It is shown to the user verbatim on the licence screen, so an unsigned
        # answer being able to set it is arbitrary text on someone's television from anyone who can
        # answer HTTP — the same class of thing as `messages`, just arriving through a different field.
        #
        # SAID OUT LOUD when something was actually dropped. Silence here is how "I sent a message from
        # the panel and it never appeared" becomes unanswerable: the message arrived, the rule refused
        # it, and nothing anywhere recorded that. The rule stays; the silence does not.
        if doc.get("message") or doc.get("messages") or doc.get("vault_key"):
            diag.log("Licence: the answer carried a message or a key but was NOT SIGNED — dropped. "
                     "Sign the endpoint's replies (tools/server/sign-response.php) for these to arrive.",
                     "ERROR")
        return fields
    fields["message"] = str(doc.get("message") or "")

    # WHETHER THE GATE BITES, decided by the panel rather than compiled in.
    #
    # `ENFORCE` is a constant, so turning enforcement on used to mean building and shipping a new
    # release to every box — and turning it back off after a mistake meant doing it again while people
    # sat locked out. A one-way door of that size does not belong in a business decision. In the signed
    # half for the obvious reason: an unsigned answer able to set it either way is the whole gate.
    #
    # Absent means "leave it as it was", not "off": a panel that stops sending the field must not
    # silently unlock every box, and a stale cached `true` is the safe direction to fail.
    if "enforce" in doc:
        fields["enforce"] = "1" if str(doc.get("enforce")).lower() in ("1", "true", "yes") else "0"

    # Absent (locked, blocked, expired) CLEARS whatever was cached — that is how a revoked device stops
    # being able to read its own credentials once the grace window runs out.
    fields["vault_key"] = str(doc.get("vault_key") or "")
    # Commands sit beside messages, inside the verified half, and for a stronger version of the same
    # reason: a message puts text on a television, a command runs one of this addon's own actions on
    # someone else's box. See resources/lib/commands.py.
    orders = doc.get("commands")
    if isinstance(orders, list):
        fields["commands"] = [
            {"id": str(c.get("id") or ""), "type": str(c.get("type") or c.get("command") or ""),
             "args": c.get("args") if isinstance(c.get("args"), dict) else {}}
            for c in orders if isinstance(c, dict) and str(c.get("id") or "")
        ]
    inbox = doc.get("messages")
    if isinstance(inbox, list):
        fields["messages"] = [
            {"id": str(m.get("id") or ""), "text": str(m.get("text") or "")}
            for m in inbox if isinstance(m, dict) and str(m.get("text") or "").strip()
        ]

    # SETTINGS THE SERVER DECIDES, and the reason they arrive here rather than in a release.
    #
    # Some choices are the operator's and change without the code changing: where the Video klub gets
    # its film descriptions from, whether a service is switched on at all, an address that has to move.
    # Shipping a new version for one of those means every box waits for Kodi's six-hour update check and
    # whoever does not update never gets the change — for an address that has moved, that is a feature
    # that quietly stops working on half the boxes.
    #
    # Verified half, without argument: a parameter changes what the addon DOES, and `tmdb_proxy` in
    # particular is an address this addon will send requests to. An unsigned answer able to set it is
    # anyone who can answer HTTP pointing our boxes wherever they like.
    #
    # PRESENT-BUT-EMPTY is how a parameter is withdrawn, and absent means "leave what you had" — same
    # rule as `enforce` above and for the same reason: a panel that stops sending the field must not
    # silently change behaviour on every box.
    knobs = doc.get("params")
    if isinstance(knobs, dict):
        # THE ADDRESS THIS BOX ASKS NEXT TIME. Stored beside the parameters rather than among them,
        # because it has to survive the set being replaced wholesale — a panel that stops sending it
        # means "no change", exactly like every other absent field here.
        moved = str(knobs.get("licence_endpoint") or "").strip()
        if moved.startswith("https://"):
            fields["endpoint"] = moved
        fields["params"] = {
            str(name)[:32]: str(value)[:300]
            for name, value in knobs.items()
            if str(name).strip() and not isinstance(value, (dict, list))
        }
    return fields


def params(settings):
    """
    The server-delivered parameters this box last received, as a plain dict of strings.

    Empty for a box that has never had a verified answer, which is exactly right: every caller has to
    carry a default that behaves the way the addon behaved before this existed.
    """
    values = _read_state(settings).get("params")
    return values if isinstance(values, dict) else {}


def param_url(settings, name):
    """
    One parameter that is meant to be an ADDRESS, or "" when it is not usable as one.

    Plain `https://` only. The value already comes out of a signed document, so this is not the thing
    standing between a box and a hostile server — it is the check that a mistake in the panel (an
    address typed without a scheme, an http:// left over from a test) fails visibly here instead of
    turning into requests nobody meant to send.
    """
    value = str(params(settings).get(name) or "").strip()
    if not value:
        return ""
    if not value.startswith("https://"):
        diag.log("Licence: parameter %s is not an https address (%s) — ignored" % (name, value[:60]),
                 "ERROR")
        return ""
    return value



def _quote(value):
    """URL-safe, and empty-safe. `last_refresh` is "2026-07-29 08:12" — a raw space in a query string is
    a request some servers answer with 400 and others silently truncate."""
    try:
        from urllib.parse import quote as _q
    except ImportError:                                            # pragma: no cover
        from urllib import quote as _q
    return _q(str(value or ""), safe="")



def enforcing_for(state):
    """
    Whether the gate bites, for a box whose cached [state] this is.

    The compiled-in [ENFORCE] is the FLOOR, not the answer: a build that ships with it on cannot be
    unlocked by a server that says otherwise, which is what keeps the switch from becoming a bypass.
    Above that floor the panel decides.
    """
    if ENFORCE:
        return True
    return str((state or {}).get("enforce") or "0") == "1"


def messages(settings):
    """Replies the server has left for this box, from the cached verdict."""
    inbox = _read_state(settings).get("messages")
    return inbox if isinstance(inbox, list) else []


def commands(settings):
    """Instructions the server has left for this box, from the cached verdict."""
    orders = _read_state(settings).get("commands")
    return orders if isinstance(orders, list) else []


def build_fingerprint():
    """
    A short hash over the addon's own Python files.

    Reported, not enforced. The honest description of what it buys: an unmodified install answers with
    one value across every box on a given version, so anything else is a copy someone has edited — and
    that shows up on the server as a fact rather than a suspicion. Someone who edits the gate can of
    course edit this function too; the point is that they now have to notice it exists.

    Sorted by path and hashing CONTENT only, so the same release always produces the same value
    regardless of where Kodi unpacked it or what the file timestamps are.
    """
    global _FINGERPRINT
    if _FINGERPRINT is not None:
        return _FINGERPRINT
    digest = hashlib.sha256()
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))   # …/resources
    root = os.path.dirname(root)                                        # the addon folder
    try:
        for dirpath, dirnames, filenames in os.walk(root):
            dirnames[:] = sorted(d for d in dirnames if d not in ("__pycache__",))
            for name in sorted(filenames):
                if not name.endswith(".py"):
                    continue
                with io.open(os.path.join(dirpath, name), "rb") as handle:
                    digest.update(os.path.relpath(os.path.join(dirpath, name), root)
                                  .replace(os.sep, "/").encode("utf-8"))
                    digest.update(handle.read())
    except (OSError, IOError):
        # A fingerprint that cannot be taken must not stop a licence check; it just reports nothing.
        _FINGERPRINT = ""
        return _FINGERPRINT
    _FINGERPRINT = digest.hexdigest()[:16]
    return _FINGERPRINT


_FINGERPRINT = None


def _verdict_from_state(settings, state, now):
    """
    Turn the cache into a decision, applying the offline rules.

    The state written by the server is authoritative while it is fresh. Once it goes stale the question
    becomes "how long has this box been unable to prove anything", and that is deliberately generous:
    a real outage on my side must not read as piracy.
    """
    stored = str(state.get("state") or UNKNOWN)
    verdict = Verdict(
        state=stored,
        serial=str(state.get("serial") or ""),
        trial_ends=str(state.get("trial_ends") or ""),
        licensed_until=str(state.get("licensed_until") or ""),
        message=str(state.get("message") or ""),
        verified=bool(state.get("signing_seen")),
    )
    # Carried from the cached state, so a box that has gone offline keeps the setting it was last told
    # rather than quietly unlocking itself.
    verdict.enforcing = enforcing_for(state)
    last_good = int(state.get("last_good") or 0)
    if last_good <= 0:
        # Never verified. Give a new install a few days rather than a locked screen on day one.
        #
        # The write below is load-bearing and was missing at first: without it the "first local run"
        # was recomputed as *now* on every launch, so the grace window never elapsed and a box that
        # simply never reached the server ran free forever. Offline is the one bypass that costs an
        # attacker nothing at all — pulling the network cable — so this clock has to persist.
        first_seen = int(state.get("first_local_run") or 0)
        if first_seen <= 0:
            first_seen = now
            state["first_local_run"] = now
            _write_state(settings, state)
        if now - first_seen > FIRST_RUN_GRACE_DAYS * 86400:
            verdict.state = EXPIRED
            verdict.message = ("Licencni server nije dostupan vec nekoliko dana, pa dodatak ne moze da "
                               "potvrdi licencu. Proveri internet vezu na uredjaju.")
        else:
            verdict.state = UNKNOWN
        return verdict

    if now - last_good > GRACE_DAYS * 86400 and stored != EXPIRED:
        verdict.state = EXPIRED
        verdict.message = ("Licenca nije mogla da se proveri %d dana. Poveži uredjaj na internet pa "
                           "probaj ponovo." % GRACE_DAYS)
    return verdict


def _addon_version():
    if not _IN_KODI:
        return "test"
    try:
        import xbmcaddon
        return xbmcaddon.Addon().getAddonInfo("version")
    except Exception:                                          # noqa: BLE001
        return ""


# ---- what the user is told --------------------------------------------------

def describe(verdict):
    """The licence screen's text. Written for the customer, not for me — it has to be forwardable into
    the support group without further explanation."""
    lines = []
    if verdict.serial:
        lines.append(T("Broj uredjaja:") + "  [B]%s[/B]" % verdict.serial)
    elif verdict.device:
        # The short id is what a customer can actually read off a TV and type into a message; the full
        # one is here because it is what the server would be asked about.
        lines.append(T("Id uredjaja:") + "  [B]%s[/B]" % verdict.device[:12])
        lines.append(T("(pun: %s)") % verdict.device)
    # The date is appended rather than built into the sentence, so the four status lines keep the exact
    # keys the translation table holds — a "%s" spliced into one of them would be a fifth string that
    # differs from its own key and quietly falls back to Serbian.
    if verdict.state == TRIAL:
        lines.append(T("Status: probni period") + (" " + T("do %s") % _day(verdict.trial_ends)
                                                   if verdict.trial_ends else ""))
        lines.append("")
        lines.append(T("Kada probni period istekne, posalji gornji broj uredjaja u Telegram grupu "
                       "ispod i dodatak se otkljucava sa moje strane. Ne treba nista da instaliras "
                       "ponovo."))
    elif verdict.state == LICENSED:
        lines.append(T("Status: [COLOR green]otkljucano[/COLOR]")
                     + (" " + T("do %s") % _day(verdict.licensed_until)
                        if verdict.licensed_until else ""))
    elif verdict.state == EXPIRED:
        lines.append(T("Status: [COLOR red]zakljucano[/COLOR]"))
        lines.append("")
        lines.append(T("Posalji broj uredjaja u Telegram grupu ispod i otkljucacu ga. Kanali i vodic "
                       "ostaju na uredjaju, samo cekaju otkljucavanje."))
    elif verdict.state == OFF:
        # The honest text for a build with no gate. "Not checked with the server yet" reads like
        # something is broken and produces a support message about a feature that is switched off.
        lines.append(T("Status: [COLOR green]otkljucano[/COLOR]") + " — "
                     + T("ova verzija nema licencu"))
        lines.append("")
        lines.append(T("Id uredjaja iznad je isti onaj koji ce se koristiti kada licenca bude "
                       "ukljucena, pa ga vredi sacuvati."))
    else:
        lines.append(T("Status: jos nije provereno kod servera"))
    if verdict.message:
        lines.append("")
        lines.append(verdict.message)
    return "\n".join(lines)


def _day(iso):
    """The date part of an ISO timestamp. Nobody needs the seconds, and a raw '+02:00' offset in a
    dialog looks like a bug to a user."""
    return (iso or "")[:10]
