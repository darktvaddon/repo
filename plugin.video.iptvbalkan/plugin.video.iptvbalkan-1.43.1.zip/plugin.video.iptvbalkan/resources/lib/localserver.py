# -*- coding: utf-8 -*-
"""
A loopback redirector that makes seeking inside an EON archive programme work.

**Why this exists.** EON serves a replay as a sliding window twelve seconds long — measured: three
segments, no `EXT-X-ENDLIST`. There is no timeline to scrub, so no player can seek it. The Android
client solves this by not seeking at all: it re-mints the stream URL at the new wall-clock instant
(`PlayerViewModel.adjustEonReplay`).

Kodi can do exactly the same, and better, because inputstream.ffmpegdirect already implements it:
given `catchup_url_format_string`, it re-requests the URL with a new `{utc}` on every seek and keeps
full PVR playback — the channel name and the guide stay on screen. IPTV Simple hands it that property
(confirmed against the installed binary, which sets all thirteen ffmpegdirect catchup properties).

The one thing in the way: **ffmpegdirect cannot call `plugin://`** — checked against its own binary,
which knows only CURL and `special://`. And an EON stream URL cannot be written into the playlist
ahead of time, because it is AES-signed per tune and expires.

So the playlist points at this server instead. It sits on loopback, signs a fresh URL at the moment
ffmpegdirect asks, and answers `302`. A plain redirect is enough rather than a proxy because EON's
TIMESHIFT edge does not gate on identity — measured against the live account: manifest, variant
playlist and segment all answer 200 with no User-Agent, Referer or Origin. (The LIVE pool does gate,
which is why the play route still sends them there.)

Two properties keep this from being a hole:

* it binds to **127.0.0.1 only**, never the LAN address the pairing server uses, so nothing off the
  device can reach it;
* every URL carries a per-install token, so another app on the same box cannot use it as a free EON
  signer by guessing the path.
"""

import io
import os
import re
import threading
import time
import uuid

try:
    from http.server import BaseHTTPRequestHandler, HTTPServer
    from socketserver import ThreadingMixIn
    from urllib.parse import urlparse, parse_qsl, urljoin
    from urllib.request import Request, urlopen
except ImportError:                                                # pragma: no cover  (Python 2)
    from BaseHTTPServer import BaseHTTPRequestHandler, HTTPServer
    from SocketServer import ThreadingMixIn
    from urlparse import urlparse, parse_qsl, urljoin
    from urllib2 import Request, urlopen

from . import diag

HOST = "127.0.0.1"
#: Fixed, because the playlist is written with this port baked into every catch-up URL and a port that
#: moved between restarts would leave yesterday's playlist pointing at nothing. Chosen next to the
#: pairing server's 8791 to keep the two obvious together.
PORT = 8792
PATH = "/catchup"
#: The per-install secret, kept as a FILE beside the playlist rather than as an addon setting.
#: `Addon().setSetting` does not reach settings.xml until Kodi decides to flush it, so a token minted by
#: the service was not on disk for the plugin process that writes the catalogue on a manual refresh —
#: and half the catch-up URLs would then be written without one. A file is written when it is written.
TOKEN_FILE = "catchup-token.txt"


def token(settings):
    """The install's token, minted on first use. Empty only if the profile is unwritable, in which case
    the caller falls back to the plugin URL and archive seeking is simply unavailable."""
    path = os.path.join(settings.profile_dir(), TOKEN_FILE)
    try:
        existing = _read_token(path)
        if existing:
            return existing
        fresh = uuid.uuid4().hex
        # WRITTEN WHOLE OR NOT AT ALL. `open(path, "w")` truncates first, so for the width of one write
        # the file exists and is EMPTY — and this addon reads it from two processes (the service mints
        # it at start, the plugin reads it while writing the catalogue on a manual refresh). A reader
        # landing in that window sees nothing, decides the token is missing, mints a second one and
        # overwrites — and from then on the playlist carries a token the running server does not hold.
        # Every EON channel then answers 403 on loopback, which is exactly what the S26 Ultra's log
        # showed on 2026-08-02: "CCurlFile::Exists … Failed: HTTP returned error 403", the redirector
        # listening the whole time. A rename is atomic; a truncate is not.
        temporary = path + ".tmp"
        with io.open(temporary, "w", encoding="utf-8") as handle:
            handle.write(fresh)
        os.replace(temporary, path)
        return fresh
    except (OSError, IOError) as err:
        diag.log("Catch-up redirector: no token (%s)" % err, "ERROR")
        return ""


#: The token as it appears in a playlist row: `http://127.0.0.1:8792/catchup?t=<hex>&provider=…`.
_IN_PLAYLIST = re.compile(re.escape("%s:%d%s?t=" % (HOST, PORT, PATH)) + r"([0-9a-f]{8,64})")


def playlist_token(settings):
    """
    The token the playlist ON DISK is carrying, or "" when it carries none.

    WHY THIS IS ASKED AT ALL. A playlist can outlive the token that was written into it, and when it
    does, every EON channel answers 403 on loopback until the next scheduled rebuild — which can be a
    day away. Read off a customer's phone on 2026-08-02, in the addon's own words once the refusal was
    finally logged:

        Catch-up redirector: refused a request —
        token mismatch (playlist 0d8fb294…, server 3713b815…, file 3713b815…)

    The server and the file AGREE; it is the playlist that is out of date. So re-reading the file at
    request time — which fixes a token minted by the other process — cannot fix this one, and the only
    honest repair is to write the playlist again. Anything that leaves a profile holding yesterday's
    playlist beside a fresh token does it: a restored profile, an add-on reinstalled over its own data,
    a token file lost while the playlist stayed.

    Scanned line by line and stopped at the first hit, because the first EON row answers the question
    and there is no reason to read a megabyte to learn it. No loopback row at all is "" — a catalogue
    of Iris and M3U channels has nothing to check, and must not be rebuilt for it.
    """
    try:
        with io.open(settings.playlist_path(), "r", encoding="utf-8", errors="replace") as handle:
            for line in handle:
                found = _IN_PLAYLIST.search(line)
                if found:
                    return found.group(1)
    except (OSError, IOError):
        pass
    return ""


#: Set by the handler the moment a request arrives carrying a token nobody here recognises. The service
#: loop watches it and rebuilds the catalogue, so a box in this state repairs itself within a minute of
#: the viewer pressing a channel rather than waiting for tomorrow's refresh.
STALE_PLAYLIST = threading.Event()


def _read_token(path):
    """The token as it is on disk right now, or "" — never raises, because both callers have a fallback."""
    try:
        if not os.path.isfile(path):
            return ""
        with io.open(path, "r", encoding="utf-8") as handle:
            return handle.read().strip()
    except (OSError, IOError):
        return ""


def url_for(token, provider_key, channel_ref, account="", catchup=False):
    """
    The URL written into the playlist — the live one, or the catch-up template.

    `{utc}` is IPTV Simple's own placeholder and is left for it to substitute; this string is never
    fetched with the braces still in it.
    """
    base = "http://%s:%d%s?t=%s&provider=%s&id=%s&account=%s" % (
        HOST, PORT, PATH, token, provider_key, channel_ref, account or "")
    return base + "&utc={utc}" if catchup else base


#: One provider instance per account, kept alive for as long as the service is.
#:
#: Building a fresh one per request is what a channel change used to cost: `find()` constructs the
#: provider, `login()` validates the cached session with a `v1/sp` call, and only then does the tune
#: begin — measured on the box at about 170ms of dead time in front of every zap, on top of the
#: `v1/time` call beside it. Neither changes between channels. Held under a lock because ffmpegdirect
#: can ask for two streams at once (the tune it is starting and the one it is tearing down).
_PROVIDERS = {}
_PROVIDERS_LOCK = threading.Lock()


def _provider_for(settings, provider_key, account):
    from .provider import find
    key = (provider_key, account)
    with _PROVIDERS_LOCK:
        provider = _PROVIDERS.get(key)
        if provider is None:
            provider = find(settings, provider_key, account)
            provider.login()
            _PROVIDERS[key] = provider
        return provider


def forget_providers():
    """Drop the cached instances — called when settings change, so a new password or a different
    account is not shadowed by a session minted under the old one."""
    with _PROVIDERS_LOCK:
        _PROVIDERS.clear()


#: A refusal is logged, but not once per seek — ffmpegdirect re-asks on every scrub, and a mismatched
#: token would otherwise write a line a second. One line per distinct reason per minute is enough to
#: diagnose it and little enough to leave on in normal use.
_REFUSALS = {}
_REFUSAL_QUIET_SECONDS = 60


def _note_refusal(reason):
    _note_once("refused a request — %s" % reason, "ERROR")


def _note_once(text, level="INFO"):
    """One line per distinct message per minute — see _REFUSALS."""
    now = time.time()
    if now - _REFUSALS.get(text, 0.0) < _REFUSAL_QUIET_SECONDS:
        return
    _REFUSALS[text] = now
    diag.log("Catch-up redirector: %s" % text, level)


#: Variant playlists this server has handed out, by a short id: {id: (url, headers, minted_at)}.
#:
#: A MAP RATHER THAN THE URL IN THE QUERY, and that is the whole security of it. Putting the address in
#: the request would make this a general-purpose fetcher that anything on the box could point anywhere —
#: with our EON headers attached. Only addresses this server itself read out of a master it just signed
#: are reachable, and only for as long as a tune plausibly lasts.
_VARIANTS = {}
_VARIANTS_LOCK = threading.Lock()
#: Long enough for a film with pauses, short enough that a day of zapping does not accumulate. ffmpeg
#: re-reads a live variant every few seconds, so an entry in use is never near this.
_VARIANT_TTL = 6 * 3600
_VARIANT_MAX = 400


def _remember_variant(url, headers):
    """A short id for one variant address, so the player can ask us for it by name."""
    key = uuid.uuid4().hex[:12]
    now = time.time()
    with _VARIANTS_LOCK:
        # Swept here rather than on a timer: this is the only place that grows the map, so it is the
        # only place that needs to shrink it, and a service thread that exists only to expire dict keys
        # is a thread that can outlive the thing it was cleaning.
        if len(_VARIANTS) > _VARIANT_MAX:
            for old in [k for k, v in _VARIANTS.items() if now - v[2] > _VARIANT_TTL]:
                _VARIANTS.pop(old, None)
        _VARIANTS[key] = (url, dict(headers or {}), now)
    return key


def _variant(key):
    with _VARIANTS_LOCK:
        found = _VARIANTS.get(key)
    if not found or time.time() - found[2] > _VARIANT_TTL:
        return None
    return found[0], found[1]


#: A line in an HLS playlist that is a URI rather than a tag or a comment.
def _rewrite(body, fetched_from, headers, is_variant):
    """
    Point the variant URIs in a master back at this server; leave everything else alone.

    Relative URIs are made absolute against the address the playlist came FROM — not against the
    loopback address the player fetched it from, which is what the player would otherwise do and is
    the reason a rewritten master must never be handed back half-done.

    A MEDIA playlist (segments) is passed through with its URIs absolutised and nothing else: the
    segments are the video, and putting those through Python would turn a text proxy into a bandwidth
    one on a box that has neither the CPU nor the reason.
    """
    try:
        text = body.decode("utf-8")
    except (UnicodeDecodeError, AttributeError):
        return body                                                # not text; hand it back untouched
    if is_variant or "#EXT-X-STREAM-INF" not in text:
        return _absolutise(text, fetched_from).encode("utf-8")

    out = []
    variants = 0
    for line in text.splitlines():
        stripped = line.strip()
        if stripped and not stripped.startswith("#"):
            absolute = urljoin(fetched_from, stripped)
            out.append("http://%s:%d%s?t=%s&v=%s"
                       % (HOST, PORT, PATH, _Handler.token, _remember_variant(absolute, headers)))
            variants += 1
        else:
            out.append(line)
    diag.log("Catch-up redirector: serving a master with %d quality levels, all through this server"
             % variants)
    return ("\n".join(out) + "\n").encode("utf-8")


def _absolutise(text, fetched_from):
    """Every URI line made absolute against where the playlist came from, and named so FFmpeg 7 will
    read it — see _with_extension."""
    out = []
    for line in text.splitlines():
        stripped = line.strip()
        if stripped and not stripped.startswith("#"):
            if "://" not in stripped:
                stripped = urljoin(fetched_from, stripped)
            out.append(_with_extension(stripped))
        else:
            out.append(line)
    return "\n".join(out) + "\n"


#: Extensions FFmpeg is willing to believe a segment has. Anything already ending in one of these is
#: left exactly as the provider wrote it.
_SEGMENT_EXTENSIONS = ("ts", "m2t", "m2ts", "mts", "mpg", "mpeg", "mpegts", "m4s", "mp4", "m4a",
                       "aac", "ac3", "eac3", "mp3", "vtt", "webvtt", "cmfv", "cmfa")


def _with_extension(url):
    """
    A segment URL FFmpeg 7 will accept, which means one that ends in something it recognises.

    **This is the whole reason EON played on Kodi 21 and not on Kodi 22**, and it took three logs to
    reach because nothing anywhere said it. FFmpeg 7.0 added `extension_picky` to the HLS demuxer,
    default ON, and there is no such check in FFmpeg 6 at all. Its own words, from hls.c:

        static int test_segment(…)
            if (!c->extension_picky) return 0;
            matchA = av_match_ext(seg->url, c->allowed_segment_extensions) + …
            if (!matchA) { av_log(s, AV_LOG_ERROR, "URL %s is not in allowed_segment_extensions"); … }

    and `av_match_ext` is simply `strrchr(filename, '.')` — the LAST DOT IN THE WHOLE STRING. EON
    addresses a segment as

        https://sbb-bg-ne-h3-2.ug-be.cdn.united.cloud/stream/fragment/ts/live/?session=…&offset=…

    so the last dot is the one in the host name and the "extension" comes out as
    `cloud/stream/fragment/ts/live/?session=…`. Nothing matches, every segment is refused, and the
    player reports it as an empty stream: four quality levels listed, no streams, instant end of file.
    That is exactly what the S26 Ultra printed on every tune, on every version, while the same code on
    Kodi 21.2 played.

    So the address is given a tail that ends in `.ts`. It is a query parameter, not a path segment: the
    path is what the CDN routes on and must not be touched. Measured against the live account before
    shipping — the edge serves `…&ext=.ts` with 200 and a valid MPEG-TS sync byte, the same bytes as
    without it. Harmless on FFmpeg 6, which never looks.
    """
    # THE CHECK HAS TO BE THE SAME ONE FFMPEG MAKES, and the first version of this was not.
    #
    # It looked at the PATH — everything before the `?` — and called a segment honestly named when the
    # path ended in `.ts`. FFmpeg does not look at the path: `av_match_ext` is `strrchr` over the whole
    # string, query included. So a panel that addresses a segment as
    #
    #     …/hls2/HLS000001_00000474.ts?channelId=1&uid=1558&…&hlsid=906018131
    #
    # was judged "already named" here and refused by FFmpeg 7 there, and every channel from such a
    # panel played on Kodi 21 and on nothing newer. Found on the owner's own Xtream list, after HLS had
    # already been switched on and the channels still would not start.
    tail = url.rsplit(".", 1)[-1].lower() if "." in url else ""
    if tail in _SEGMENT_EXTENSIONS:
        return url                                                 # ends in an extension, as it stands
    return url + ("&" if "?" in url else "?") + "ext=.ts"


class _Handler(BaseHTTPRequestHandler):

    # Set by the server before it starts serving.
    settings = None
    token = ""

    def _allowed(self, args):
        """
        Whether this request carries our token — checked against the FILE as well as the value this
        server started with.

        The in-memory value alone is what made a phone unable to play anything on 2026-08-02. The token
        lives in a file precisely because two processes mint and read it, and a server holding a copy
        from its own start has no way to notice that the catalogue was later written with a different
        one. Re-reading the file is the difference between "the archive stopped working until Kodi is
        restarted" and "it corrects itself on the next tune" — and it costs nothing a tune can measure.
        """
        supplied = args.get("t") or ""
        if not supplied:
            return False, "no token in the URL (a playlist written before the token existed)"
        if supplied and supplied == self.token:
            return True, ""
        on_disk = _read_token(os.path.join(self.settings.profile_dir(), TOKEN_FILE)) \
            if self.settings else ""
        if on_disk and supplied == on_disk:
            _Handler.token = on_disk                                # adopt it, so the next tune is free
            diag.log("Catch-up redirector: the token was re-minted elsewhere — adopted the one on disk")
            return True, ""
        # Nobody here has ever seen this token, so the PLAYLIST is the stale half. Say so, and ask for
        # a rebuild — the service loop is watching this flag. Refusing quietly is what left a phone
        # loading 302 channels and playing none of them for a whole night.
        STALE_PLAYLIST.set()
        return False, ("token mismatch (playlist %s…, server %s…, file %s…) — the playlist is out of "
                       "date and is being rebuilt"
                       % (supplied[:8], (self.token or "-")[:8], (on_disk or "-")[:8]))

    def do_GET(self):                                              # noqa: N802  (BaseHTTPRequestHandler API)
        parsed = urlparse(self.path)
        if parsed.path != PATH:
            _note_refusal("unknown path %s" % parsed.path[:60])
            self.send_error(404)
            return
        # `keep_blank_values` because ffmpegdirect 22 re-serialises the query before it opens it —
        # measured: `?account&id=1887&mimetype=application%2foctet-stream&provider=eon&t=…`, with the
        # empty `account=` reduced to a bare word, a `mimetype` of its own invention added, and the
        # whole thing sorted. An empty account is a real value here (the default account), so it has to
        # survive that round trip, and anything we do not recognise is ignored rather than refused.
        args = dict(parse_qsl(parsed.query, keep_blank_values=True))
        allowed, reason = self._allowed(args)
        if not allowed:
            # No detail in the BODY: a wrong token is either a stale playlist or something that has no
            # business here, and neither is helped by being told which. The log is another matter — this
            # used to be the one refusal that left no trace anywhere, so a box that played nothing looked
            # from every log like a box that was never asked.
            _note_refusal(reason)
            self.send_error(403)
            return
        # A variant playlist the player is coming back for — see _rewrite_master. Answered before the
        # provider is consulted, because there is nothing to sign here: the URL was minted moments ago
        # for this same tune and is only being fetched on the player's behalf.
        if args.get("v"):
            remembered = _variant(args["v"])
            if not remembered:
                _note_refusal("a variant that has expired or was never ours (%s)" % args["v"][:8])
                self.send_error(404)
                return
            # One line a minute at most, and it is the line that will settle the next report: if the
            # player is asking US for the quality levels, the master rewrite is working and anything
            # still broken is further down. Silence here means it never asked.
            _note_once("the player is fetching quality levels through this server")
            self._serve_playlist(remembered[0], remembered[1], is_variant=True)
            return

        # No `utc` means LIVE. Both go through one route on purpose: IPTV Simple reads the inputstream
        # from the channel's own #KODIPROP lines and applies it to the live tune AND the catch-up tune,
        # so the two must be the same kind of URL. A live channel left on `plugin://` while catch-up
        # moved to http is exactly the split that stopped ffmpegdirect from ever being given the catchup
        # properties — see the note in eon.py.
        try:
            at_utc = int(args.get("utc") or 0)
        except ValueError:
            at_utc = 0

        try:
            provider = _provider_for(self.settings, args.get("provider") or "",
                                     args.get("account") or "")
            resolved = provider.resolve(args.get("id") or "", at_utc=at_utc or None)
        except Exception as err:                                   # noqa: BLE001
            # Every failure here is one the user sees as "the archive will not start", so it is named in
            # the log rather than left as a bare status code on a loopback socket nobody watches.
            diag.log("Catch-up redirector: %s %s at %s failed — %s: %s"
                     % (args.get("provider"), args.get("id"), at_utc, type(err).__name__, err), "ERROR")
            self.send_error(502)
            return

        target = resolved[0] if isinstance(resolved, tuple) else (
            resolved.get("url") if isinstance(resolved, dict) else resolved)
        if not target:
            self.send_error(502)
            return
        headers = resolved[1] if isinstance(resolved, tuple) else (
            resolved.get("headers") if isinstance(resolved, dict) else {})
        self._serve_playlist(target, headers or {})

    def _serve_playlist(self, target, headers, is_variant=False):
        """
        Fetch the freshly signed playlist and hand back its BODY, rather than redirecting to it.

        A 302 was the first design and it does not survive contact with the player. Measured on the box:
        ffmpegdirect opens the URL through Kodi's cURL, the redirect arrives with no useful content type,
        and it gives up with `error probing input format` — the stream never starts. Serving the text
        directly, under the HLS media type, removes the guess: the player knows what it has before it
        reads a byte.

        Only the PLAYLISTS are proxied, never the video. Segment URLs are left pointing straight at
        EON's edge, which was measured to serve them with no headers at all — so the box forwards a few
        kilobytes of text per tune and not one frame of video.

        **Why the variant list is proxied too, since 1.23.8.** What EON answers with is a MASTER: four
        quality levels, each its own absolute URL on a DIFFERENT edge host from the master's. On Kodi
        21.2 the player fetched those itself and played. On Kodi 22 (ffmpegdirect 22.2.6, FFmpeg 7) the
        same master, byte for byte, produced this and nothing else:

            Input #0, hls, from 'http://127.0.0.1:8792/catchup?…'
              Duration: N/A, bitrate: N/A
              Program 0 … variant_bitrate : 7096000     (and three more)
            Creating Demuxer
            Process - eof reading from demuxer

        Four quality levels listed and **not one stream** — the player never got a variant open, and
        said nothing about why. ffmpeg's own `open_url` is identical between 6.0 and 7.1, so this is not
        the protocol whitelist it looks like. Rather than keep guessing at somebody else's beta, the
        variants now come back through this same loopback: one address, one protocol, no second host to
        resolve. It costs a few hundred bytes every few seconds and it takes the question off the table.
        """
        # The provider's OWN headers, not a plausible-looking substitute. An invented User-Agent came
        # back 403 from the edge on the first attempt here — EON keeps a blocklist and anything it does
        # not recognise is on the wrong side of it. The resolver already knows what to send.
        try:
            request = Request(target, headers=headers)
            body = urlopen(request, timeout=20).read()
        except Exception as err:                                   # noqa: BLE001
            # The REASON travels in the response body, and this used to throw it away. "HTTP Error 403:
            # Forbidden" names the symptom and nothing else, which is a dead end at exactly the moment
            # you need a direction — the edge's own body says which parameter it disliked. Read off the
            # exception (HTTPError is itself a readable file object), capped, and never fatal: a failure
            # to read the explanation must not replace the original error with a new one.
            detail = ""
            try:
                raw = err.read()                                   # type: ignore[attr-defined]
                if raw:
                    detail = " — odgovor: " + raw.decode("utf-8", "replace")[:400].replace("\n", " ")
            except Exception:                                      # noqa: BLE001
                pass
            diag.log("Catch-up redirector: the edge refused the minted URL — %s: %s%s"
                     % (type(err).__name__, err, detail), "ERROR")
            self.send_error(502)
            return

        body = _rewrite(body, target, headers, is_variant)
        self.send_response(200)
        self.send_header("Content-Type", "application/vnd.apple.mpegurl")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        try:
            self.wfile.write(body)
        except (OSError, IOError):
            # The player hung up mid-write; normal when a seek replaces one request with the next.
            pass

    def do_HEAD(self):                                             # noqa: N802  (BaseHTTPRequestHandler API)
        """
        Answer Kodi's existence probe without signing anything.

        `pvr.iptvsimple` calls `CCurlFile::Exists` on the stream URL before it hands it to a player, and
        `Exists` is a HEAD. `BaseHTTPRequestHandler` has no `do_HEAD`, so every probe came back **501
        Unsupported method** — read off the box at 13:47 on 2026-07-31, three times in thirty seconds,
        once per channel the owner opened.

        Answering it by running the GET path would be worse than the 501: a probe would perform a full
        provider login and mint a stream URL that nobody plays, on Kodi's GUI thread, once per probe —
        and against EON that is a signed URL and a counted request. The probe only asks whether something
        is there, so it is told exactly that: the token is checked (a wrong one must not learn that the
        path exists) and the answer is 200 with no body.
        """
        parsed = urlparse(self.path)
        if parsed.path != PATH:
            _note_refusal("unknown path %s" % parsed.path[:60])
            self.send_error(404)
            return
        args = dict(parse_qsl(parsed.query, keep_blank_values=True))
        allowed, reason = self._allowed(args)
        if not allowed:
            _note_refusal(reason)
            self.send_error(403)
            return
        self.send_response(200)
        self.send_header("Content-Type", "application/vnd.apple.mpegurl")
        self.send_header("Content-Length", "0")
        self.end_headers()

    def log_message(self, *_args):
        """Silence. The default handler writes a line per request to stderr, and ffmpegdirect asks for a
        new URL on every seek — Kodi's log does not need that."""


class _Server(ThreadingMixIn, HTTPServer):
    daemon_threads = True
    allow_reuse_address = True


#: The running server, so [stop] can close its socket. One per process by construction — the port is
#: fixed, and a second bind would fail.
_SERVER = None


def start(settings, token):
    """
    Start the redirector on a background thread. Returns True when it is listening.

    Never fatal: a box where the port is taken loses archive seeking and keeps everything else, which is
    the same trade every other optional piece in this addon makes.
    """
    global _SERVER
    _Handler.settings = settings
    _Handler.token = token
    try:
        server = _Server((HOST, PORT), _Handler)
    except (OSError, IOError) as err:
        diag.log("Catch-up redirector: port %d unavailable (%s) — archive seeking will be limited"
                 % (PORT, err), "ERROR")
        # REMEMBERED, so the diagnostics screen can say it. This has been a log line only, and the
        # symptom it produces — EON channels that play but cannot be scrubbed in the archive — is not
        # one anybody connects to a port. The likeliest cause is another Kodi PROFILE whose service
        # still holds the socket (the port is fixed, by design: it is baked into every playlist row),
        # and that is a case where the answer is "restart Kodi", which nobody guesses.
        settings.set("catchup_port_error", "%d: %s" % (PORT, err))
        return False
    settings.set("catchup_port_error", "")
    thread = threading.Thread(target=server.serve_forever, name="iptvbox-catchup")
    thread.daemon = True
    thread.start()
    _SERVER = server
    diag.log("Catch-up redirector: listening on %s:%d" % (HOST, PORT))
    return True


def stop():
    """
    Close the listening socket — and this is what stops the box freezing when Kodi is closed.

    Measured on the owner's box, three runs, with nothing playing and no refresh in progress: Kodi asked
    to quit reached `~IptvSimple Stopping update thread…` and never wrote another line. The process was
    still there minutes later, `State: S` with `wchan` = `do_freezer_trap` — Android had frozen a
    half-shut-down app that no longer had a window, so nothing could finish and nothing could be
    reported. From the sofa that is a television that stops answering the remote; the system's own
    verdict on it was the two ANR traces, "Input dispatching timed out (Application does not have a
    focused window)". With this addon DISABLED the same box exited in seven seconds.

    The cause is the order of a shutdown. Kodi stops the Python scripts FIRST (`SystemExit` into the
    interpreter), then tears down its PVR clients — and IPTV Simple asks about a channel URL on the way
    out. Every EON channel in our playlist is a `http://127.0.0.1:8792/…` address, and a listening socket
    whose owner has just been killed does not refuse a connection: the kernel accepts it into the
    backlog and it is never answered. cURL then sits and waits. Closed properly the connection is
    REFUSED at once, which is an answer, and the teardown carries on.

    Idempotent and never fatal: this runs while the process is being taken apart, and a failure to close
    a socket must not be the exception that stops a clean exit.
    """
    global _SERVER
    server, _SERVER = _SERVER, None
    if server is None:
        return False
    try:
        # shutdown() ends serve_forever's loop; server_close() is the one that actually drops the
        # listening socket, and it is the socket that matters here.
        server.shutdown()
    except Exception:                                              # noqa: BLE001
        pass
    try:
        server.server_close()
    except Exception:                                              # noqa: BLE001
        pass
    diag.log("Catch-up redirector: stopped")
    return True
