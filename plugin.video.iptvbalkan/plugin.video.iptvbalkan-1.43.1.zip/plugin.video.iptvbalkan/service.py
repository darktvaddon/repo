# -*- coding: utf-8 -*-
"""
The background half: rebuild the catalogue on a schedule and keep IPTV Simple pointed at the result.

Deliberate choices, each one a lesson from the Android client:

* **The interval is a setting that actually takes effect.** Reading it once at startup would mean a
  changed value does nothing until Kodi restarts — the same class of bug as a cached User-Agent.
* **First run is immediate, then it waits.** A fresh install with no playlist must not sit empty until
  tomorrow.
* **A failed refresh does not reset the clock to zero.** It retries on a short backoff instead of
  hammering a provider that is having an outage.
"""

import hashlib
import io
import os
import threading
import time
import uuid
import xml.etree.ElementTree as ET

try:
    from urllib.parse import quote
except ImportError:                                                # pragma: no cover  (tooling)
    from urllib import quote

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from resources.lib import (catalog, diag, homescreen, licence, localserver, providers,  # noqa: F401
                           reminders, resume)
from resources.lib.i18n import T
from resources.lib.provider import enabled_providers
from resources.lib.settings import ADDON_ID, Settings
from resources.lib import kodisettings, migrate

RETRY_MINUTES = 15
#: How often the service wakes. Was 30 s, which is fine for a refresh schedule and far too
#: coarse for a resume position — a film stopped between ticks would come back half a minute
#: out. Ten costs nothing measurable and keeps the recorded position close to the truth.
TICK_SECONDS = 10
#: How long after Kodi starts a due rebuild holds off. Kodi is importing the guide into its PVR
#: database in that window, and a box doing both at once is a box showing "PVR manager 0%".
STARTUP_QUIET_SECONDS = 90
#: A gap between ticks longer than this means the box was suspended rather than busy. Six times the
#: tick: a loaded box can miss a tick or two (a guide import, a slow disk), and calling that a wake-up
#: would spread work that did not need spreading. Nothing here depends on the number being exact.
WAKE_GAP_SECONDS = TICK_SECONDS * 6
#: How long to let a just-woken box settle before the first scheduled job runs. The network adapter is
#: typically a second or two behind the wake and DNS a moment after that, so work started immediately
#: fails on name resolution and looks like an outage in the log.
WAKE_SETTLE_SECONDS = 30
#: The official Iris web player reports every 60s. Beating a little faster costs one tiny request and
#: leaves room for a slow answer without the server deciding the stream is abandoned.
HEARTBEAT_SECONDS = 45
#: How often the TMDB filler takes a turn, and how much it does per turn — one pair for while something
#: is playing, another for while the box is idle.
#:
#: The trickle exists so artwork never competes with the player for bandwidth on a TV box. Applied to an
#: IDLE box it was simply too slow to be useful: an Xtream panel with 4,001 titles needs 500 turns at
#: eight titles each, which is close to three hours before the Video klub stops looking half-empty. A
#: lookup costs 0.15-0.5s, so the idle pass clears the same backlog in minutes and still yields the
#: moment playback starts.
TMDB_INTERVAL_SECONDS = 20
TMDB_BATCH = 8
TMDB_IDLE_INTERVAL_SECONDS = 2
TMDB_IDLE_BATCH = 40
#: How often the loop ASKS the licence layer. Well inside the vault's 24h grace, and licence.check
#: itself only reaches the network on its own (6h + per-device spread) schedule.
#: How often the service looks. Cheap when the check is not due — it reads the cache and
#: returns — so this only has to be short enough not to blunt licence.CHECK_INTERVAL_SECONDS.
LICENCE_POLL_SECONDS = 5 * 60

#: Providers that need something sent WHILE a stream plays, keyed the way `provider.key` is.
_KEEPALIVE_PROVIDERS = ("iris",)


def _refresh_keepalive(settings, current):
    """
    The keepalive list, rebuilt WITHOUT throwing away the sessions in it.

    The list was built once at startup and never revisited, and the reasoning for that (see _heartbeat)
    is sound as far as it goes: constructing these every tick would mean a fresh Iris login every 45
    seconds, each one holding a device slot. But it made the LIST as permanent as the sessions, and the
    list is a function of the settings:

      * add an Iris account after Kodi is already running — which is what everybody does on the day they
        install this — and there is no keepalive entry for it, so the stream that account resolves is
        dropped by MTS after about a minute. Nothing says why, and only restarting Kodi fixes it;
      * turn Iris off and its session went on being kept warm, holding a slot the user thought they had
        freed.

    So the list is recomputed when the settings screen closes, and only then. An account that was already
    there keeps its EXISTING instance — same object, same session, no new login — which is the property
    the original comment was protecting. New keys are constructed once; removed ones are dropped.
    """
    # Keyed on key AND account: two Iris subscriptions are two logins holding two device slots, and a
    # dict keyed on the provider key alone would collapse them — one would keep its session and the
    # other would be rebuilt (a fresh login) on every settings change.
    keep = {(p.key, p.account_id): p for p in current}
    fresh = []
    for provider in enabled_providers(settings):
        if provider.key not in _KEEPALIVE_PROVIDERS:
            continue
        fresh.append(keep.get((provider.key, provider.account_id), provider))
    return fresh


def _heartbeat(keepalive):
    """
    Keep an in-progress stream alive, if there is one.

    [keepalive] holds LONG-LIVED provider instances, built once by the caller. Rebuilding them here
    would mean a fresh login on every tick — a new Iris session every 45 seconds, each one occupying a
    device slot for a while, which is a far worse problem than the dropped stream this exists to
    prevent.

    Driven by Kodi's own "is something playing" rather than by the state file alone: that file is
    written at tune time and would otherwise keep a session warm long after the user stopped watching —
    pointless traffic, and a stream the provider still counts as open.
    """
    if not keepalive:
        return
    player = xbmc.Player()
    try:
        playing = player.isPlaying()
        # WHAT is playing, not merely whether anything is. "Something is playing" was the whole test,
        # and it is true just as much when the user has zapped to an EON channel or started a film in
        # another addon — so the Iris heartbeat carried on for that stream all day and MTS kept counting
        # it as open. On an account with one or two concurrent streams, that is the second TV in the
        # house being refused. Kodi hands back the RESOLVED url here, which is exactly what the provider
        # recorded when it resolved it.
        current = player.getPlayingFile() if playing else ""
    except Exception:                                              # noqa: BLE001
        playing, current = False, ""
    for provider in keepalive:
        try:
            mine = provider.playing_url()
            if playing and mine and current and mine == current:
                provider.heartbeat()
            elif playing and mine and not current:
                # No answer from Kodi about the file (it happens mid-transition). Keeping the stream
                # alive is the safer of the two mistakes: the cost is one extra beat, the alternative
                # is a stream dropped under someone who is watching it.
                provider.heartbeat()
            else:
                provider.stop_heartbeat()
        except Exception as err:                                   # noqa: BLE001
            # A keepalive failure must never take the service down; the worst case is one dropped
            # stream, which the user fixes by pressing play again.
            diag.log("%s: keepalive failed — %s: %s" % (provider.label, type(err).__name__, err))


def _configure_iptvsimple(settings):
    """
    Point IPTV Simple at our files, once, and only if the user has not pointed it somewhere themselves.

    Overwriting an existing configuration would be the addon quietly taking over a setup the user built
    by hand — so this only fills in blanks and says what it did.
    """
    try:
        simple = xbmcaddon.Addon("pvr.iptvsimple")
    except Exception:                                              # noqa: BLE001 - not installed
        # Installed but DISABLED reads exactly like not installed from here — Addon() raises either
        # way. Asking Kodi to enable it costs nothing when it is already enabled and fixes the case
        # that otherwise produces a working addon with an empty TV list and nothing in any log to
        # explain it. A disabled addon cannot complain; that has cost this project a day before.
        diag.log("IPTV Simple did not answer — asking Kodi to enable it")
        xbmc.executebuiltin("EnableAddon(pvr.iptvsimple)")
        xbmc.sleep(1500)
        try:
            simple = xbmcaddon.Addon("pvr.iptvsimple")
            diag.log("IPTV Simple was disabled and is now enabled")
        except Exception:                                          # noqa: BLE001
            diag.log("IPTV Simple is not installed — the playlist is still written to the profile "
                     "folder and can be pointed at manually", "ERROR")
            return False
    changed = []
    if (simple.getSetting("m3uPathType") != "0" or not simple.getSetting("m3uPath")
            or migrate.owns_path(simple.getSetting("m3uPath"))):
        simple.setSetting("m3uPathType", "0")
        simple.setSetting("m3uPath", settings.playlist_path())
        changed.append("playlist")
    if (simple.getSetting("epgPathType") != "0" or not simple.getSetting("epgPath")
            or migrate.owns_path(simple.getSetting("epgPath"))):
        simple.setSetting("epgPathType", "0")
        simple.setSetting("epgPath", settings.epg_path())
        changed.append("guide")
    if changed:
        diag.log("IPTV Simple configured: %s" % ", ".join(changed))
    moved = _report_iptvsimple_instances(settings)

    # BEFORE the reload, not after. How much past guide Kodi KEEPS decides how far back the archive can
    # be opened at all (four days downloaded, one day kept, and the other three unopenable with nothing
    # saying why) — and raising it only takes effect when the guide is imported again. Done in the
    # other order it worked, silently, at the next scheduled EPG update up to two hours later.
    widened = kodisettings.align_guide_window(settings.get_int("epg_days_back", 2))

    if changed or moved or widened:
        _reload_pvr(", ".join(changed) or moved or widened)
    # Clear our own dead shortcut BEFORE offering a new one, or a box upgraded through the rename keeps
    # two identical "Video klub" rows — the older pointing at an addon id that is no longer installed,
    # so it does nothing at all when pressed. Runs every start and costs one file read when there is
    # nothing to do.
    homescreen.drop_stale()
    # After the PVR is pointed at our files, not before: the favourite opens the Video klub, and there
    # is no point offering a shortcut on a start where the addon has not managed to configure itself.
    homescreen.ensure_once(settings)
    _note_missing_subtitle_service()
    _note_failing_pvr_clients()
    return True


def _note_missing_subtitle_service():
    """
    Say so, once per start, when nothing on this box can actually fetch a subtitle.

    The addon's own half of subtitles is making sure the playing item carries a title, a year and an
    IMDb id, so Kodi's subtitle dialog has something to search WITH (see default.py's play()). The
    fetching itself belongs to a subtitle service addon, and Kodi ships with none enabled.

    Deliberately a log line and not a dependency. Declaring one in addon.xml would pick a service for
    everybody, and the right one differs by audience — podnapisi.net has by far the best Serbian,
    Croatian and Bosnian coverage and needs no account, while opensubtitles.com is bigger and does. It
    is also the kind of `<import>` that can fail an install outright if the repository does not have it,
    which is a poor trade for a convenience.

    Never fatal, never a dialog: this runs on every start of a working addon and must not become noise
    on a screen. Someone who does not want subtitles should not be told about them twice.
    """
    try:
        installed = xbmc.getCondVisibility("System.HasAddon(service.subtitles.podnapisi)") \
            or xbmc.getCondVisibility("System.HasAddon(service.subtitles.opensubtitles_by_opensubtitles)") \
            or xbmc.getCondVisibility("System.HasAddon(service.subtitles.a4ksubtitles)")
    except Exception:                                              # noqa: BLE001
        return
    if not installed:
        diag.log("No subtitle service addon is installed — the player's subtitle search will come back "
                 "empty. Add-ons -> Install from repository -> Subtitles; podnapisi.net needs no "
                 "account and has the best ex-Yu coverage.")


def _note_failing_pvr_clients():
    """
    Name, once per start, another PVR client that is failing — because ours pays for it.

    Kodi creates its PVR clients one after another. A client whose backend is not there does not fail
    fast: it retries on a timer and only then reports "Lost Connection", and everything queued behind
    it waits. On the owner's phone that is `pvr.argustv` pinging 127.0.0.1:49943 once a second for
    four seconds before `pvr.iptvsimple` is even created — every start, with a logo on screen and an
    empty TV list, and no message anywhere naming the addon spending them.

    A log line and nothing else. Disabling somebody's other PVR client to make ours look quicker is
    not a decision this addon gets to take quietly, and this is the evidence that lets the owner take
    it. Deliberately not a notification either: it is the same on every start, and a dialog that
    appears every start is one people learn to dismiss without reading.
    """
    for entry in diag.failing_pvr_clients():
        diag.log("Another PVR client is failing at startup: %s (%s). Kodi starts PVR clients one at a "
                 "time, so it delays this one and the channel list with it. It is not part of this "
                 "addon — remove or disable it under Add-ons / My add-ons / PVR clients."
                 % (entry["addon"], entry["status"] or "errors in Kodi's log"))


#: What an instance file has to say for IPTV Simple to find our files. `0` means "a local path", as
#: opposed to a URL — without it the path is read but never used.
_INSTANCE_SETTINGS = (("m3uPathType", "0"), ("m3uPath", None),
                      ("epgPathType", "0"), ("epgPath", None))

#: Settings we turn on for a TV product, but ONLY while they still carry Kodi's `default="true"` marker.
#: Pause-and-rewind on live TV is off in IPTV Simple out of the box, and its absence is the first thing
#: anyone notices — but it is also a real preference, so the moment the owner has touched it themselves
#: (which is exactly what clears that marker) it stops being ours to set.
#:
#: `catchupEnabled` was the missing one, and it made the whole archive invisible. Read off a real box:
#: our playlist carried `catchup="default"`, `catchup-days="7"` and a working `catchup-source` on every
#: EON channel, and IPTV Simple ignored all three because this flag was still at Kodi's `false`. The
#: symptom is exactly what was reported — open a programme from yesterday and the dialog offers only
#: "Switch" (tune the channel live), with no "Play programme", because IPTV Simple never told Kodi that
#: programme was playable at all. Nothing was wrong with the catch-up code; it was never being asked.
#: What IPTV Simple must have switched on for this addon to behave.
#:
#: `catchupPlayEpgAsLive` is the one that keeps the GUIDE on screen while watching an archive programme.
#: Its own help text says it plainly: disabled, "any catchup programme from the past will be played like
#: a video (bounded by start and end times)" — which is the plain video OSD, no guide, no channel list,
#: no calendar. Enabled, "it will instead act like a live stream with timeshift, also allowing the
#: ability to skip back and forward programmes", so the PVR overlay stays and the archive is navigable
#: the way live television is.
_INSTANCE_PREFERENCES = (("timeshiftEnabled", "true"), ("catchupEnabled", "true"),
                         ("catchupPlayEpgAsLive", "true"))


def _playlist_stamp(settings):
    """(mtime, size) — the cheap question, asked every tick so the expensive one rarely is."""
    try:
        st = os.stat(settings.playlist_path())
        return (st.st_mtime, st.st_size)
    except OSError:
        return None


def _playlist_digest(settings):
    """
    A fingerprint of the playlist on disk, or "" if it cannot be read.

    Content, not size or mtime: `catalog.build` writes through `os.replace` on every run, so the
    timestamp moves whether or not anything changed, and two different playlists can be the same
    length. An unreadable file answers "" and the caller then does nothing, which is the safe
    direction — a reload that does not happen costs a stale list until the next start, while one that
    fires on every tick would tear down playback repeatedly.
    """
    try:
        with io.open(settings.playlist_path(), "rb") as handle:
            return hashlib.sha256(handle.read()).hexdigest()
    except (IOError, OSError):
        return ""


def _reload_pvr(why):
    """
    Make Kodi read the playlist and the guide again, now that they are somewhere else.

    WHY THIS IS NOT OPTIONAL, and what it cost to find out. After the add-on id changed, the migration
    repointed IPTV Simple at the new profile — correctly, and the log said so. The television still
    showed the OLD guide: Kodi kept handing out catch-up addresses for `plugin.video.iptvbox`, an
    add-on that no longer exists on the box, so "Play programme" from the guide did nothing at all.
    Nothing was broken in the playlist, in the guide, or in the archive code; Kodi was simply still
    holding what it had read before, and the channel-to-guide links in its own PVR database went with
    it.

    Kodi has one instruction for this and it is the same one a person would give by hand — turn the PVR
    manager off and on. The client re-reads its settings on the way up, re-reads both files, and the
    EPG is rebuilt against the channels it just created.

    Stop BEFORE anything else has a chance to write: a running client keeps its own copy of the
    instance settings and writes it back when it goes down, which is how the repointed paths came back
    as the old ones the first time.
    """
    diag.log("IPTV Simple: %s — restarting the PVR manager so Kodi reads them again" % why)
    xbmc.executebuiltin("StopPVRManager")
    xbmc.sleep(2000)
    xbmc.executebuiltin("StartPVRManager")


def _report_iptvsimple_instances(settings):
    """
    Put our paths where IPTV Simple actually reads them.

    Kodi 20 and later let a PVR client run as several INSTANCES, and IPTV Simple uses that. Each
    instance keeps its own settings in addon_data/pvr.iptvsimple/instance-settings-<n>.xml, and the
    addon-level values — the ones `Addon("pvr.iptvsimple").setSetting()` writes, and the only ones the
    API can reach — are then just a template for instances that do not exist yet. That is why a real
    box logged "IPTV Simple configured: playlist, guide" and then sat at "PVR manager 0%" with
    `Could not validiate M3U after startup` in Kodi's own log: the write succeeded, into a file the
    running client never opens.

    So this edits the instance file. Two rules keep that honest:

      * **Only blanks are filled.** An instance already pointing somewhere is somebody's own setup —
        possibly another playlist entirely — and this must not hijack it.
      * **The write is atomic and the original is parsed, not overwritten.** Everything else in the
        file (instance name, per-instance tweaks) is preserved; a truncated write here takes the whole
        PVR client down with it.
    """
    try:
        folder = xbmcvfs.translatePath("special://profile/addon_data/pvr.iptvsimple")
        if not os.path.isdir(folder):
            return
        instances = sorted(f for f in os.listdir(folder)
                           if f.startswith("instance-settings-") and f.endswith(".xml"))
        if not instances:
            diag.log("IPTV Simple: single-instance layout — the settings written above are the ones "
                     "it reads")
            return
        # Only ONE instance is ever pointed at our files. Two clients serving the same playlist means
        # every channel appears twice in the TV list, with two EPG imports behind them — and a box that
        # has picked up a spare empty instance (easy to do while hunting for the settings) would get
        # exactly that the moment this filled them all in.
        claimed, moved = False, []
        for name in instances:
            result = _fill_instance(os.path.join(folder, name), name, settings, claimed)
            claimed = bool(result) or claimed
            if result == "moved":
                moved.append(name)
        return ("%s repointed at this version's files" % ", ".join(moved)) if moved else ""
    except Exception as err:                                       # noqa: BLE001
        diag.log("IPTV Simple: could not inspect the instance settings — %s: %s"
                 % (type(err).__name__, err))
    return ""


def _fill_instance(path, name, settings, claimed=False):
    """True if this instance serves our playlist; the string "moved" if it had to be taken back from a
    previous version's path — the caller reloads the PVR for that, and only for that."""
    was_moved = False
    wanted = {"m3uPath": settings.playlist_path(), "epgPath": settings.epg_path()}
    try:
        tree = ET.parse(path)
        root = tree.getroot()
    except (ET.ParseError, OSError, IOError) as err:
        diag.log("IPTV Simple: %s could not be read (%s) — set the M3U path by hand: %s"
                 % (name, err, wanted["m3uPath"]), "ERROR")
        return False

    existing = {}
    for node in root.findall("setting"):
        existing[node.get("id")] = node

    current = (existing["m3uPath"].text or "").strip() if "m3uPath" in existing else ""
    ours = current == wanted["m3uPath"]
    if not ours and migrate.owns_path(current):
        # Our own playlist under the id this addon used to ship as. Left as "somebody else's" it would
        # never be repointed, and the television would keep reading a file nothing refreshes any more.
        diag.log("IPTV Simple: %s still points at the previous version's playlist — moving it to %s"
                 % (name, wanted["m3uPath"]))
        ours = True
        current = ""
        was_moved = True
    if not ours:
        if current:
            return False                                           # somebody else's playlist
        if claimed:
            diag.log("IPTV Simple: %s is a second, empty instance and was left alone — remove it in "
                     "the PVR client's settings, or it shows up as an empty TV source" % name)
            return False

    changed = []
    # An instance that ALREADY points at us still goes through the loops below rather than returning
    # here. It used to return, and the effect was that anything added to these lists afterwards only
    # ever reached boxes that had not been set up yet — live pause/rewind was switched on for new
    # installs and silently skipped on the one box it was written for.
    #
    # `was_moved` is the one case where a NON-EMPTY value is overwritten, and it has to be. The branch
    # above decided this instance is ours under the id this addon used to ship as; without the
    # overwrite it logged "moving it to …" and then changed nothing, because both rules below refuse a
    # value that is already there. That is precisely what happened on a real box after the rename: the
    # paths stayed on the old profile, Kodi went on reading the old playlist and the old guide, and
    # every catch-up address it handed out named an add-on that was no longer installed — so "Play
    # programme" in the guide did nothing at all, on a box where nothing else was wrong.
    for key, fixed in ([] if (ours and not was_moved) else _INSTANCE_SETTINGS):
        value = fixed if fixed is not None else wanted[key]
        node = existing.get(key)
        if node is None:
            node = ET.SubElement(root, "setting")
            node.set("id", key)
        elif (node.text or "").strip() and not was_moved:
            # Already set by the user, or by us on an earlier run. Left alone either way.
            continue
        elif (node.text or "").strip() == value:
            continue                                               # already right; do not report it
        node.text = value
        # Kodi marks untouched values default="true"; a value we just wrote is not one.
        node.attrib.pop("default", None)
        changed.append(key)

    for key, value in _INSTANCE_PREFERENCES:
        node = existing.get(key)
        if node is None:
            node = ET.SubElement(root, "setting")
            node.set("id", key)
        elif "default" not in node.attrib:
            continue                                               # the owner has an opinion; keep it
        elif (node.text or "").strip() == value:
            continue
        node.text = value
        node.attrib.pop("default", None)
        changed.append(key)

    if not changed:
        if ours:
            diag.log("IPTV Simple: %s already points at our playlist" % name)
        return "moved" if was_moved else True

    tmp = path + ".tmp"
    tree.write(tmp, encoding="utf-8", xml_declaration=True)
    os.replace(tmp, path)
    # No longer "restart Kodi once": the caller restarts the PVR manager, which is the same instruction
    # without asking somebody to do it. See _reload_pvr.
    diag.log("IPTV Simple: %s filled in (%s)" % (name, ", ".join(changed)))
    return "moved" if was_moved else True


class _ResumeWatcher(xbmc.Player):
    """
    Records where an on-demand title was left.

    A callback rather than only a poll, because the position that matters most is the one at the moment
    of STOPPING, and a loop that ticks every ten seconds is guaranteed to miss it — Kodi has already
    torn the player down by the next tick and `getTime()` raises. So the last known position is kept
    from the polling and committed here.
    """

    #: How often the sampled position is actually written to disk while something is playing.
    #:
    #: The reading itself is taken every tick, because the one that matters is the last one before the
    #: stop — but it is kept in memory and committed by `_commit`. Writing the store on every tick meant
    #: rewriting a JSON file on the box's flash six times a minute for the whole length of a film (720
    #: times for a two-hour one) to record a number that only gets read after playback ends. What the
    #: periodic write buys is insurance against a hard power-off, which a minute's granularity covers.
    WRITE_EVERY_SECONDS = 60

    def __init__(self, settings):
        xbmc.Player.__init__(self)
        self.settings = settings
        self._last = (0, 0)
        self._written_at = 0.0

    def sample(self):
        """
        One reading, cheap enough to do on every service tick.

        The player is asked BEFORE the marker file is read, and the order is the whole point: this runs
        every ten seconds for as long as Kodi is up — 8,640 times a day — and almost none of those ticks
        have anything playing. Reading a file first meant that many pointless opens against a TV box's
        flash to learn something an in-memory call answers for free.
        """
        try:
            if not self.isPlayingVideo():
                return
        except Exception:                                          # noqa: BLE001 - player torn down
            return
        marker = resume.playing_marker(self.settings)
        if not marker:
            return
        try:
            # The RESOLVED url, which is exactly what the plugin recorded — so a film that was left
            # playing and then zapped away from is not credited with the next thing's position.
            if marker.get("url") and self.getPlayingFile() != marker["url"]:
                return
            position, total = int(self.getTime()), int(self.getTotalTime())
        except Exception:                                          # noqa: BLE001 - player torn down
            return
        if total > 0:
            self._last = (position, total)
            if time.time() - self._written_at >= self.WRITE_EVERY_SECONDS:
                self._written_at = time.time()
                resume.record(self.settings, marker, position, total)

    def _commit(self):
        marker = resume.playing_marker(self.settings)
        position, total = self._last
        if marker and total > 0:
            resume.record(self.settings, marker, position, total)
        resume.clear_marker(self.settings)
        self._last = (0, 0)
        # So the next title's first sample is written promptly rather than inheriting this one's clock.
        self._written_at = 0.0

    def onPlayBackStopped(self):
        self._commit()

    def onPlayBackEnded(self):
        # Played to the end: record() itself decides that is "finished" and drops it from the list.
        self._commit()


def _fill_metadata(settings, limit=TMDB_BATCH):
    """Work through a few queued TMDB titles. Wrapped whole — artwork is the least important thing here
    and must never stop the refresh, the heartbeat or the resume watcher sharing this loop."""
    try:
        from resources.lib import tmdb
        if not tmdb.enabled(settings):
            return
        done = tmdb.fill_some(settings, limit)
        if done:
            diag.log("TMDB: filled %d titles" % done)
    except Exception as err:                                       # noqa: BLE001
        diag.log("TMDB: filler failed — %s: %s" % (type(err).__name__, err))


def _protect_secrets(settings):
    """
    Encrypt any provider password still sitting in the clear, once a licence key exists.

    Runs from the service and only after a check, so the order is always: get a key, then encrypt. It
    never runs on a box that has not reached the server, which is what keeps a first install working
    normally while the licence is still off.

    Each value is read straight back after writing. Kodi's settings dialog holds its own copy and writes
    it back over anything changed behind it, and a password encrypted in memory but not on disk would be
    decrypted on the next read and fail — so a write that did not stick is left as plaintext rather than
    half-applied.
    """
    from resources.lib import vault
    try:
        for provider in enabled_providers(settings):
            # `provider.settings`, NOT the global one. Each provider instance is per ACCOUNT, and an
            # extra account's values live in accounts.json behind its own view — reading the global
            # settings here encrypted the FIRST account's password once per account and left every
            # extra account's password in the clear forever, on a path that would decrypt them
            # perfectly well if only something had encrypted them.
            scope = provider.settings
            current = {}
            for field in provider.secret_fields:
                name = "%s_%s" % (provider.key, field)
                raw = scope.get(name, "")
                if raw:
                    current[name] = raw
            written = vault.protect(settings, current)
            # Only the MAIN scope's values live in settings.xml; an extra account's live in accounts.json,
            # which `scope.set` writes itself and which therefore needs no help.
            main_scope = not provider.account_id
            landed = {}
            for name, encrypted in written.items():
                # Verified through the handle that wrote it — see Settings.set. Checking with a fresh
                # one asked the file rather than Kodi, and reported failure for every write.
                if not scope.set(name, encrypted):
                    diag.log("Vault: %s could not be stored encrypted — left as it was" % name, "ERROR")
                else:
                    landed[name] = encrypted
                    diag.log("Vault: %s%s is now stored encrypted"
                             % (name, " (account %s)" % provider.account_id if provider.account_id else ""))
            # And onto the disk, because Kodi keeps it in memory only — see vault.persist.
            if main_scope and landed:
                vault.persist(settings, landed)
    except Exception as err:                                                       # noqa: BLE001
        diag.log("Vault: could not protect the stored secrets — %s: %s"
                 % (type(err).__name__, err), "ERROR")


def _run_commands(settings):
    """Carry out anything the panel has asked this box to do. Wrapped whole for the same reason the
    replies are: nothing the panel asks for may take down the refresh or the heartbeat."""
    try:
        from resources.lib import commands
        commands.run_pending(settings)
    except Exception as err:                                       # noqa: BLE001
        diag.log("Commands: pass failed — %s: %s" % (type(err).__name__, err), "ERROR")


def _show_replies(settings):
    """
    Put any reply from the panel on screen, once each.

    Wrapped whole: a support reply is the least important thing this service does, and a failure in it
    must never stop the refresh, the heartbeat or the resume watcher that run in the same loop.
    """
    try:
        from resources.lib import support
        support.show_pending(settings)
    except Exception as err:                                       # noqa: BLE001
        diag.log("Support: could not show a reply — %s: %s" % (type(err).__name__, err))


def _notify(text):
    xbmcgui.Dialog().notification("IPTV Balkan", text, xbmcgui.NOTIFICATION_INFO, 4000)


def _check_reminders(settings):
    """
    Fire whatever is due, and offer to switch to the channel.

    NOT A MODAL DIALOG ON THIS THREAD. `Dialog().yesno` blocks until somebody answers, and this loop is
    what keeps the Iris stream alive, records the resume position and polls Kodi's shutdown — a
    reminder raised in an empty room used to be exactly how this service was stopped dead (see the
    note on `support.show_async`, which exists for the same reason). So the question goes to its own
    thread and the loop carries on.

    The survivors are written back BEFORE anybody is asked. A fired reminder must not fire again if the
    box is restarted while the dialog is on screen, and "was it answered" is not something this can
    know — "was it raised" is.
    """
    try:
        fire, keep = reminders.due(settings)
    except Exception as err:                                       # noqa: BLE001
        diag.log("Reminders: could not be read — %s: %s" % (type(err).__name__, err), "ERROR")
        return
    if not fire:
        return
    reminders.keep_only(settings, keep)
    for row in fire:
        diag.log("Reminder: '%s' on %s is starting" % (row.get("title") or "?",
                                                       row.get("channel") or "?"))
        _ask_and_tune(row)


def _ask_and_tune(row):
    """One reminder, on its own thread — see _check_reminders on why it cannot be this one."""
    def ask():
        try:
            title = row.get("title") or ""
            channel = row.get("channel") or ""
            if xbmcgui.Dialog().yesno(T("Podsetnik"),
                                      T("%s\npocinje na kanalu %s.\n\nPreci na taj kanal?")
                                      % (title, channel),
                                      yeslabel=T("Predji"), nolabel=T("Ne sada")):
                # Through the plugin's own tune route rather than PlayMedia on a URL: that route
                # matches the PVR channel and hands playback to Kodi's live path, which is what gives
                # the guide overlay and the channel list — the difference between "it plays" and "it
                # is on television".
                xbmc.executebuiltin('RunPlugin(plugin://%s/?action=tune&name=%s)'
                                    % (ADDON_ID, quote(channel)))
        except Exception as err:                                   # noqa: BLE001
            diag.log("Reminder: could not be shown — %s: %s" % (type(err).__name__, err), "ERROR")

    thread = threading.Thread(target=ask, name="iptvbox-reminder")
    thread.daemon = True
    thread.start()


def _first_run_at(settings):
    """
    When the first rebuild of THIS service run may start.

    The schedule used to live only in a local variable, so every Kodi start counted as a first run and
    triggered a full rebuild — logging in to EON and pulling 302 guides, roughly a hundred seconds of
    work, every single time the box was switched on. That is worse than wasteful: it happens during the
    exact minute Kodi is starting its PVR manager and parsing a 26 MB guide, so the box spends its
    slowest moment doing the same job twice. The clock has to survive the process, and `last_refresh`
    already does — it is written after every successful build.

    Two deliberate exceptions to waiting:
      * no playlist on disk yet (fresh install, or the file was wiped) — build immediately, since the
        alternative is a TV section with no channels until tomorrow;
      * an unreadable or missing timestamp — treated as "never built", same reason.
    """
    try:
        if os.path.getsize(settings.playlist_path()) <= 0:
            return 0.0
    except OSError:
        return 0.0

    # A THIRD exception, and it is the one that cost a customer a night: the playlist carries a
    # loopback token that is not ours any more. Every EON channel in it then answers 403 at the moment
    # somebody presses it — the redirector is running and healthy and refuses each request, because
    # the URL was minted against a token this profile no longer has. Nothing else notices: the channel
    # list is complete, the guide is full, the service log is clean. It is checked HERE, before the
    # first tune of the run, because the repair is simply to write the playlist again.
    carried = localserver.playlist_token(settings)
    mine = localserver.token(settings)
    if carried and mine and carried != mine:
        diag.log("The playlist was written with an older internal key (%s… vs %s…) — every archive "
                 "and EON row in it would be refused, so it is being rebuilt now"
                 % (carried[:8], mine[:8]), "ERROR")
        return 0.0

    # A NEW VERSION REBUILDS ONCE, because the playlist is not only data — it carries our decisions.
    #
    # What goes into it (`#KODIPROP` lines, catch-up mode, groups, numbering) is written at refresh time
    # and then simply sits on disk. So a release that changes one of those changes NOTHING for anybody
    # until they happen to refresh. That is exactly how 1.19.0 landed: it stopped writing
    # `epgplaybackaslive=false` so the archive would keep its television menu, the owner installed it,
    # and every Iris channel still carried the old property — the fix was on the box and invisible, and
    # the only way to know was to be told to refresh. Nobody should have to know that.
    #
    # The build fingerprint is not used here on purpose: it changes on every edit, including ones that
    # touch nothing the playlist holds. The VERSION changes when a release is made, which is the moment
    # this matters.
    try:
        version = xbmcaddon.Addon(ADDON_ID).getAddonInfo("version")
    except Exception:                                              # noqa: BLE001
        version = ""
    if version and settings.get("playlist_built_by", "") != version:
        diag.log("Playlist was written by %s and this is %s — rebuilding once so the new settings "
                 "reach it" % (settings.get("playlist_built_by", "") or "an earlier version", version))
        settings.set("playlist_built_by", version)
        return time.time() + STARTUP_QUIET_SECONDS

    # A SETTING THAT IS BAKED INTO THE PLAYLIST, changed while the box was off. Same reasoning as the
    # version check above: `archive_exact_bar` and `group_by_provider` are not read at play time, they
    # are written into the file at refresh time — so switching one and restarting used to change
    # nothing at all until the next scheduled refresh, up to a day later. A toggle that does nothing
    # for a day reads as a broken toggle.
    built_with = settings.get("playlist_built_with", "")
    # An EMPTY marker is an install that has never recorded one (every box before this version),
    # not a change — the next rebuild for any other reason writes it, and until then there is
    # nothing to compare against. Spending a rebuild on "I do not know" would mean every existing
    # box rebuilding on the upgrade for no reason.
    if built_with and built_with != catalog.playlist_fingerprint(settings):
        diag.log("A setting the playlist carries has changed — rebuilding once so it takes effect")
        return time.time() + STARTUP_QUIET_SECONDS

    stamp = settings.get("last_refresh", "")
    try:
        last = time.mktime(time.strptime(stamp, "%Y-%m-%d %H:%M"))
    except (TypeError, ValueError):
        return 0.0

    due_at = last + settings.refresh_hours() * 3600
    # Even when a rebuild IS due, it waits out the startup rush. Nothing is lost by a minute and a half;
    # what is gained is that the PVR manager gets the box to itself while it imports the guide.
    return max(due_at, time.time() + STARTUP_QUIET_SECONDS)


def _identity(settings):
    """One line naming this box: its number, this build, and the Kodi it runs on.

    The only honest form of a watermark for an addon that is public and identical for everyone — there
    is nothing in the CODE to mark, so what gets marked is the thing that actually travels: the log a
    customer sends by e-mail, over Telegram, or through the panel's own inbox.
    """
    serial = str((licence.cached_state(settings) or {}).get("serial") or "").strip()
    try:
        version = xbmcaddon.Addon(ADDON_ID).getAddonInfo("version") or "?"
    except Exception:                                              # noqa: BLE001
        version = "?"
    return "uredjaj %s · dodatak %s · Kodi %s" % (
        serial or "bez broja", version,
        (xbmc.getInfoLabel("System.BuildVersion") or "?").split(" ")[0])


def _start_catchup_redirector(settings):
    """
    Bring up the loopback redirector that makes archive seeking work — see localserver.py for the why.

    The token is minted once and kept, because it is written into every catch-up URL in the playlist: a
    token that changed on each start would invalidate the whole catalogue until the next refresh.
    """
    localserver.start(settings, localserver.token(settings))


class _Watcher(xbmc.Monitor):
    """
    Kodi's own "the user pressed OK in the settings screen" callback.

    Two things have to happen at that moment and neither used to happen at all:

      * the loopback redirector holds a LOGGED-IN provider per account for as long as the service runs
        (that is what makes a channel change cost no login), so a changed password, a pasted device id
        or a switched-off provider went on streaming through the old session until Kodi was restarted;
      * a setting the playlist CARRIES — the archive toggle, the provider grouping, the guide window —
        does nothing until the catalogue is rebuilt, and the next scheduled rebuild can be a day away.

    The callback runs on Kodi's thread, so it only raises a flag; the loop does the work.
    """

    def __init__(self):
        xbmc.Monitor.__init__(self)
        self.settings_changed = False

    def onSettingsChanged(self):                                   # noqa: N802  (Kodi API)
        self.settings_changed = True


def main():
    monitor = _Watcher()
    settings = Settings()
    from resources.lib import i18n
    i18n.configure(settings)
    # Before the first line is written, so the history moves across instead of splitting in two.
    diag.migrate_log_name()
    # WHOSE LOG IS THIS — set before the first line, because the header can only go into a file that
    # does not exist yet and "Service started" is what creates it. The serial comes from the CACHED
    # verdict, so this costs no request and waits for nothing; a box that has never reached the server
    # writes "bez broja" and corrects itself on its next start.
    diag.set_stamp(_identity(settings))
    diag.log("Service started")

    # SAID ON EVERY START, because it is the one fault that hides behind a healthy-looking box: Kodi
    # downloaded a newer version, could not put it in place, and went on running this one. Written
    # here rather than only on the diagnostics screen so it is in any log that gets sent — a box in
    # this state reports an old version number, which reads as "the update was never published".
    blocked_updates = diag.failed_addon_update()
    if blocked_updates:
        diag.log("This box has DOWNLOADED a newer version and failed to install it %d time(s) — Kodi "
                 "could not replace the addon's own files, so it is still running this one. Reinstall "
                 "the addon from the repository; accounts and settings live elsewhere and survive."
                 % blocked_updates, "ERROR")

    # Before anything else touches the profile. This is a no-op on every ordinary start; it only does
    # something on the first start after the add-on id changed, when Kodi has handed us an empty box
    # that used to have accounts in it. See resources/lib/migrate.py.
    moved = migrate.bring_forward(settings)
    if moved:
        _notify(T("Preneto iz prethodne verzije: %s") % moved)
    # A default that changed because the code around it changed — see migrate.RAISED_DEFAULTS. Silent:
    # it is not news to anybody, and it only ever touches a value the user has not touched.
    migrate.raise_defaults(settings)

    _start_catchup_redirector(settings)
    _configure_iptvsimple(settings)

    # Said once at startup rather than at the first failed zap. A user whose week is up should learn it
    # from a notification carrying the number they need to send, not from a channel that won't open.
    verdict = licence.check(settings, force=True)
    # WHOSE LOG IS THIS. Written into the head of every log file from here on, so a copy that arrives by
    # e-mail or through the panel's inbox says which box it came from without anybody being asked. See
    # diag.STAMP; it has to happen after the check, because the serial is what the check brings back.
    try:
        _version = xbmcaddon.Addon(ADDON_ID).getAddonInfo("version") or "?"
    except Exception:                                              # noqa: BLE001
        _version = "?"
    diag.set_stamp("uredjaj %s · dodatak %s · Kodi %s"
                   % (verdict.serial or "bez broja", _version,
                      (xbmc.getInfoLabel("System.BuildVersion") or "?").split(" ")[0]))
    if not verdict.allowed:
        _notify(T("Zakljucano — posalji broj uredjaja %s") % (verdict.serial or "?"))
    elif verdict.state == licence.TRIAL and verdict.trial_ends:
        diag.log("Licence: trial runs to %s (device %s)" % (verdict.trial_ends, verdict.serial))
    # A reply from the panel rides in on the same answer. Shown here rather than from the plugin, so it
    # reaches someone who is only watching television and never opens the addon's own menu.
    _show_replies(settings)
    _run_commands(settings)
    _protect_secrets(settings)

    # Built once and kept for the service's lifetime — see _heartbeat on why rebuilding is harmful, and
    # _refresh_keepalive for the one moment it has to be revisited anyway.
    keepalive = _refresh_keepalive(settings, [])

    # Kept for the service's lifetime: a Player subclass only receives Kodi's callbacks while something
    # holds a reference to it, and the stop callback is the whole reason it exists.
    watcher = _ResumeWatcher(settings)
    try:
        _loop(monitor, settings, watcher, keepalive)
    finally:
        # In a `finally` because Kodi does not only ASK a script to stop — it waits a few seconds and
        # then raises SystemExit into the interpreter, which is what happens to a tick that is inside a
        # catalogue build. That path must still close the redirector's socket: see localserver.stop, and
        # the box that would not shut down.
        localserver.stop()
        diag.log("Service stopped")


def _loop(monitor, settings, watcher, keepalive_at_start):
    """
    The service's own loop, split out of [main] so that everything main() has to do on the way OUT can
    live in one `finally` — see the note there. Nothing else moved.
    """
    # Rebound when the settings screen closes (see _refresh_keepalive), so it is a local rather than
    # the parameter: main() keeps its own name pointing at the list it built, and nothing here pretends
    # the caller can see this one.
    keepalive = keepalive_at_start
    next_run = _first_run_at(settings)
    # A reload the rebuild could not perform because somebody was watching. Held until the player is
    # free rather than dropped: the rebuild that most needs to reach Kodi is the token repair, and that
    # one happens precisely because a channel would not play.
    pending_reload = ""
    reload_postponed_said = False
    # Seeded from what is on disk right now, so the playlist Kodi has just read at startup is not
    # mistaken for a change on the first tick.
    playlist_stamp = _playlist_stamp(settings)
    playlist_digest = _playlist_digest(settings)
    heartbeat_at = 0.0
    tmdb_at = 0.0
    licence_at = time.time() + LICENCE_POLL_SECONDS
    #: When the last tick ran, so a SUSPEND can be told from a tick. Everything in this loop is
    #: scheduled as "time.time() >= x", which is right while the clock advances a tick at a time and
    #: wrong the moment the box is suspended: a television resumed after eight hours finds the refresh,
    #: the licence poll, the TMDB filler and the heartbeat ALL overdue and runs them on one tick, on a
    #: box whose network adapter is usually a second or two behind the wake. See the stagger below.
    last_tick = time.time()
    while not monitor.abortRequested():
        # THE WAKE-UP CASE. A gap much longer than a tick is not a slow tick — it is the box coming
        # back from suspend, and Kodi offers no notification for that (there is `onScreensaver`, which
        # is a different thing and does not fire for it). What is done about it is deliberately small:
        # nothing is skipped, everything is simply pushed a short way out so the work lands after the
        # network is up rather than during it, and it lands spread out rather than all at once.
        gap = time.time() - last_tick
        if gap > WAKE_GAP_SECONDS:
            diag.log("Service: %d minutes passed between ticks — this box was asleep. Everything due "
                     "is spread over the next few minutes rather than run at once." % (gap / 60))
            now = time.time()
            licence_at = max(licence_at, now + WAKE_SETTLE_SECONDS)
            tmdb_at = max(tmdb_at, now + WAKE_SETTLE_SECONDS * 3)
            heartbeat_at = max(heartbeat_at, now + WAKE_SETTLE_SECONDS)
            # The refresh is the expensive one and goes last, and only if it was already due: a box
            # that wakes to a due rebuild should do it, just not while the adapter is still coming up.
            if next_run <= now:
                next_run = now + WAKE_SETTLE_SECONDS * 6
        last_tick = time.time()
        # WATCH THE FILE, rather than calling a reload from each place that writes it.
        #
        # Three different things rewrite the playlist and they do not share a process: this loop's own
        # scheduled rebuild, a manual "refresh" from the menu (which runs in the PLUGIN process and can
        # tell the service nothing), and the token repair. Wiring a reload into each one means the next
        # writer added forgets it — the manual refresh already had, so a rebuild started from the menu
        # never reached Kodi at all.
        #
        # Cheap question first: (mtime, size) every tick, and the file is only hashed when that moves.
        stamp = _playlist_stamp(settings)
        if stamp != playlist_stamp:
            playlist_stamp = stamp
            digest = _playlist_digest(settings)
            if digest and playlist_digest and digest != playlist_digest:
                pending_reload = pending_reload or "the playlist on disk changed"
            if digest:
                playlist_digest = digest

        # Taken the moment the player is free, because the case that matters most is a repaired playlist
        # whose channels are still being refused — the viewer is sitting in front of a list that does not
        # work and has no reason to restart Kodi.
        if pending_reload and not xbmc.Player().isPlaying():
            reload_postponed_said = False
            why, pending_reload = pending_reload, ""
            _reload_pvr(why)
        elif pending_reload and not reload_postponed_said:
            # ONCE, and it is the line that explains a whole class of confusion: the channel list Kodi is
            # serving right now is the one it loaded BEFORE the refresh, so a fix that has already been
            # written to disk cannot be seen until playback stops. Read off the owner's phone on
            # 2026-08-03: he updated, the refresh rewrote every channel, he pressed play nine seconds
            # later and Kodi handed the player the OLD address — and nothing anywhere said why.
            reload_postponed_said = True
            diag.log("The channel list has changed, but something is playing — Kodi will be asked to "
                     "re-read it as soon as the player is free. Until then it serves the previous list.")

        # The settings screen was just closed — see _Watcher.
        if getattr(monitor, "settings_changed", False):
            monitor.settings_changed = False
            # Cheap and unconditional: the next play rebuilds whatever it needs, and guessing WHICH
            # credential changed is how a stale session survives the one change that mattered.
            localserver.forget_providers()
            keepalive = _refresh_keepalive(settings, keepalive)
            built_with = settings.get("playlist_built_with", "")
            if built_with and built_with != catalog.playlist_fingerprint(settings):
                diag.log("A setting the playlist carries has changed — rebuilding it now")
                next_run = 0.0

        # The redirector was asked for a stream by a playlist row it does not recognise — see
        # localserver.STALE_PLAYLIST. That is a viewer pressing a channel and getting nothing, so the
        # rebuild is not scheduled for later: it starts on this tick. Cleared first, so a rebuild that
        # fails is retried on the next refusal rather than looping on the flag.
        if localserver.STALE_PLAYLIST.is_set():
            localserver.STALE_PLAYLIST.clear()
            diag.log("A channel was refused because the playlist is older than this profile's internal "
                     "key — rebuilding it now", "ERROR")
            _notify(T("Osvezavanje liste — kanal je bio od ranije verzije"))
            next_run = 0.0

        # Cheap, and it has to be often: this is the only thing that knows how far into a film the
        # viewer is, and the value is only useful if it is close to current when they stop.
        watcher.sample()

        # "Tell me when this starts." Kodi's own reminders belong to the PVR client and IPTV Simple has
        # none, so this loop is the only clock the feature can have — see reminders.py. One file read
        # per tick, and only when the file exists at all.
        _check_reminders(settings)

        # Iris drops a stream that stops reporting, and the plugin process that resolved the URL is long
        # gone by the time playback starts — this resident service is the only thing left that can keep
        # it alive. Cheap when nothing is playing: no state file means no work and no session.
        if time.time() >= heartbeat_at:
            heartbeat_at = time.time() + HEARTBEAT_SECONDS
            _heartbeat(keepalive)

        # A few TMDB lookups per tick. Deliberately a trickle rather than a burst: this runs on a TV box
        # that may be playing a stream, and a browse screen the user is not looking at is not worth
        # competing with the player for bandwidth. Nothing happens at all without a key.
        if time.time() >= tmdb_at:
            # `isPlayingVideo`, not `isPlaying`: music or a screensaver slideshow is not what the trickle
            # was protecting, and treating either as "busy" would keep a box that is doing nothing on the
            # slow pass forever.
            busy = xbmc.Player().isPlayingVideo()
            tmdb_at = time.time() + (TMDB_INTERVAL_SECONDS if busy else TMDB_IDLE_INTERVAL_SECONDS)
            _fill_metadata(settings, TMDB_BATCH if busy else TMDB_IDLE_BATCH)

        # The licence was checked ONCE, at startup. A box that stays on for weeks — and one with only
        # Xtream or M3U never touches the plugin play route that checks again — would run its vault
        # key past the 24 hour grace and then fail its next catalogue refresh with "credentials are
        # locked", until someone restarted Kodi. licence.check is cheap between intervals (it reads
        # the cache and returns), so this only reaches the network on its own schedule.
        if time.time() >= licence_at:
            licence_at = time.time() + LICENCE_POLL_SECONDS
            # FOUR JOBS, FOUR TRY BLOCKS. They shared one, and that made the first of them the single
            # point of failure for the other three: a licence server that answered something unexpected
            # took the secret protection, the support replies and the PANEL'S COMMANDS with it — for as
            # long as it kept answering that way. The commands are how a box is reached when its owner
            # cannot describe what is wrong, so losing them silently is the worst of the four.
            for job, run in (("licence check", lambda: licence.check(settings)),
                             ("secret protection", lambda: _protect_secrets(settings)),
                             ("support replies", lambda: _show_replies(settings)),
                             ("panel commands", lambda: _run_commands(settings))):
                try:
                    run()
                except Exception as err:                           # noqa: BLE001
                    diag.log("Service: %s failed this pass — %s: %s"
                             % (job, type(err).__name__, err), "ERROR")

        if time.time() >= next_run:
            # Kodi's own "please stop" reaches the guide loops, not just this line — see catalog.build.
            before_count = settings.get("last_channel_count", "")
            before_digest = _playlist_digest(settings)
            result = catalog.build(settings, should_stop=lambda: monitor.abortRequested())
            if monitor.abortRequested():
                break
            if result.ok:
                next_run = time.time() + settings.refresh_hours() * 3600
                _notify(T("Osvezeno: %d kanala") % result.channels)
                # KODI DOES NOT RE-READ THE PLAYLIST BY ITSELF. IPTV Simple loads it at start and then
                # keeps what it has, so a refresh that adds a provider writes 7,743 channels into a
                # file while the television goes on showing the 769 it already knew — which reads as
                # "the addon did not pick up my list". Measured on the box on 2026-08-01, adding an
                # M3U playlist.
                #
                # THE COUNT IS THE WRONG QUESTION, and asking it cost two separate bugs.
                #
                # A rebuild that leaves 769 channels as 769 can still change every one of them. Turning
                # on the exact archive bar rewrites `epgplaybackaslive` on 467 Iris rows; a token repair
                # (localserver.STALE_PLAYLIST) rewrites the address of every EON row. Both kept the
                # count identical, so neither ever reached Kodi — the setting looked dead and the token
                # repair could not repair anything until somebody restarted Kodi by hand. Measured on
                # the box 2026-08-02: with the setting on and all 467 rows carrying the property, the
                # bar still reported a 60-minute live window; after a restart, and nothing else,
                # 01:51:01 with live=false.
                #
                # So compare the FILE. Same guard as before about playback — restarting the PVR manager
                # tears down the current stream — but a reload that is owed is now REMEMBERED rather
                # than dropped, because "it lands on the next start anyway" is not good enough for a box
                # that is left on for a week with channels that refuse to play.
                after_digest = _playlist_digest(settings)
                if after_digest and after_digest != before_digest:
                    pending_reload = pending_reload or (
                        "the channel list changed (%s -> %d)" % (before_count or "?", result.channels)
                        if str(result.channels) != str(before_count)
                        else "the playlist changed (%d channels, same count)" % result.channels)
            else:
                next_run = time.time() + RETRY_MINUTES * 60
                failed = [label for label, ok, _ in result.per_provider if not ok]
                if failed:
                    _notify(T("Osvezavanje nije uspelo: %s") % ", ".join(failed))
                # A FRESH INSTALL IS NOT A FAULT. With no provider configured yet there is nothing to
                # build, and logging that at ERROR every fifteen minutes is the first thing a new user
                # sees in diagnostics — an addon that looks broken before they have typed anything. The
                # two cases are told apart by whether any provider was even tried: none means "waiting
                # for an account", and only a provider that was tried and failed is an error.
                if not result.per_provider:
                    diag.log("No provider is configured yet — nothing to build. Add an account in "
                             "Settings; checking again in %d minutes." % RETRY_MINUTES)
                else:
                    diag.log("Refresh did not produce a catalogue; retrying in %d minutes"
                             % RETRY_MINUTES, "ERROR")
        # Short sleep, not one long one: the interval has to be able to change under us, and Kodi has
        # to be able to shut the service down promptly.
        if monitor.waitForAbort(TICK_SECONDS):
            break


def run():
    """
    [main], plus the one way this process is expected to end badly.

    A function rather than a bare `try` under `if __name__ == "__main__"` so that test-service.py can
    reach it: the branch that matters here is the one that RE-RAISES, and a crash-handler nobody can
    test is a crash-handler that quietly starts swallowing everything.
    """
    try:
        main()
    except RuntimeError as err:
        # KODI IS REPLACING THIS ADD-ON WHILE THIS PROCESS IS RUNNING, which is what an update IS: the
        # old id is unregistered before the service is asked to stop, so the next `xbmcaddon.Addon()`
        # — inside settings.profile_dir, reached from anywhere — raises "Unknown addon id". Seen on the
        # ross box on 2026-08-03 the moment 1.36.2 became 1.36.3: a Python traceback in kodi.log, five
        # seconds of Kodi waiting, then "script didn't stop in 5 seconds - let's kill it".
        #
        # Nothing was broken by it (Kodi starts the new service straight after, and it was refreshing
        # the guide two minutes later) — but every user who updates would have had that traceback in
        # the log they send when something else goes wrong, and a traceback is where anyone looks first.
        #
        # Caught only for THIS message: a RuntimeError that says anything else is a real failure and is
        # re-raised, because a service that swallows its own crashes is worse than one that shows them.
        if "Unknown addon id" not in str(err):
            raise
        diag.log("Kodi is replacing this add-on — the service is stopping. It starts again by itself "
                 "once the new version is in place.")


if __name__ == "__main__":
    run()
