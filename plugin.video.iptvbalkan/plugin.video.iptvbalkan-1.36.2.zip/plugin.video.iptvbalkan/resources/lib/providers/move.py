# -*- coding: utf-8 -*-
"""
Move TV (MTS-SI) — ported from `MoveApi.kt`, which is verified against a live account (301 channels,
playback working).

This file was rewritten rather than patched. The first version was built from guesswork rather than
from the working client, and every layer of it was wrong: a different host (`api.mts-si.tv` instead of
`api2.mts-si.tv/api/v2`), GET instead of POST, a Bearer header instead of `X-Auth-Token`, and field
names — `id`, `name`, `channelNumber`, `logoUrl`, `categoryName` — that this API does not serve. It
could never have worked, and it was carried for weeks as "written but unproven", which is the polite
form of "not written".

Three things about this provider that are not guessable and are the reason to port rather than invent:

**A channel has TWO ids.** `contentId` keys the guide; `liveId` mints the stream. They are different
numbers for the same channel and swapping them fails in different ways at different times.

**The stream token is a HEADER.** `/content/live/source/get` returns a plain DASH manifest plus
`protection.headerValue`, and that value has to ride as `X-Play-Auth` on the manifest AND on every
media segment — which is what the resolved stream's headers are for.

**A 200 is not success.** Every response carries `{"success": bool}`, and a 200 with `success:false` is
a real failure with a real message in it. Reading only the status code loses the reason.

Catch-up is deliberately NOT advertised, exactly as in the Android client: the provider reports a real
archive window per channel (168h is typical) but the per-programme source call was never captured, so
claiming an archive we cannot mint would put a Replay button on every programme that then silently
plays live. The window is still read and logged, so wiring it up later needs no catalogue change.
"""

import calendar
import json
import re
import time
import uuid

from .. import diag, net
from ..provider import Provider, ProviderError, register

BASE = "https://api2.mts-si.tv/api/v2"
WEB_ORIGIN = "https://play.move.tv"
#: Relative image paths (`/images/logo/rts-1_2_dark.png`) hang off this host.
IMAGE_BASE = "https://edge-mts-si-2.mts-si.tv"

#: Fixed client identity, exactly as the real web client sends it.
PARTNER_ID = 2
DEVICE_MODEL_ID = 10
DEVICE_NAME = "Chrome 150"
APP_VERSION = "3.4.8"
#: 1 = Serbian. Move TV is a Serbian service; no other locale is worth exposing.
LANG = 1
#: `dtype` in the live-source request. 1 = DASH, which is what the web client asks for.
DTYPE_DASH = 1

#: The API wants the literal string "null" for an unauthenticated request — an ABSENT header is a
#: different thing to this server, and the login call is the one that depends on it.
UNAUTHENTICATED = "null"

#: Where a channel with no genre is filed. Deliberately NOT run through T(): this is a channel GROUP
#: name, and it goes into the playlist, IPTV Simple's database and Kodi's own PVR tables. A group whose
#: name followed the interface language would become a SECOND group the moment someone switched
#: language, splitting one row of channels into two. The Video klub's own "Ostalo" is a screen label and
#: is translated — same word, different job.
GROUP_OTHER = "Ostalo"

PLAY_AUTH_HEADER = "X-Play-Auth"
#: The token carries its own expiry: `hash-…-expires-1784821848-cusid-…`.
_PLAY_AUTH_EXPIRY = re.compile(r"expires-(\d+)")

#: Channel-list rows are the only place liveId is served, and the play route needs it at tune time.
#: Cached beside the playlist rather than refetched, the same way EON caches its play descriptors.
PLAY_CACHE = "move_play.json"


@register
class MoveProvider(Provider):

    key = "move"
    label = "Move TV"
    default_identity = {
        "user_agent": ("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
                       "(KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36"),
        "origin": WEB_ORIGIN,
        "referer": WEB_ORIGIN + "/",
        "extra_headers": {"Accept": "*/*"},
    }

    def __init__(self, settings):
        Provider.__init__(self, settings)
        self.session = net.Session(self.identity(), trace=settings.verbose())
        self.token = ""
        self.customer = 0
        self.profile = 0

    # ---- transport --------------------------------------------------------

    def _post(self, path, body, authenticated=True):
        data = self.session.post(
            BASE + path, body=json.dumps(body),
            headers={"Content-Type": "application/json",
                     "X-Auth-Token": self.token if (authenticated and self.token) else UNAUTHENTICATED})
        return self._ok(data, path)

    @staticmethod
    def _ok(data, what):
        """`success:false` inside a 200 is this API's normal way of refusing, and it says why."""
        if not isinstance(data, dict):
            raise ProviderError("Move TV %s: odgovor nije JSON." % what)
        if not data.get("success"):
            raise ProviderError("Move TV %s: %s" % (what, data.get("message") or "success=false"))
        return data

    # ---- auth -------------------------------------------------------------

    def _uid(self):
        """
        A stable per-install client id.

        Minted once and written back, because the account treats a new uid as a NEW DEVICE — a fresh one
        per launch quietly fills the account's device list, which is the same trap EON's device number
        and Yettel's udid exist to avoid.
        """
        uid = self.setting("device_id").strip()
        if not uid:
            uid = str(uuid.uuid4())
            self.remember("device_id", uid)
            diag.log("Move TV: minted a device id for this install (%s…)" % uid[:8])
        return uid

    def login(self):
        username = self.setting("username")
        password = self.setting("password")
        if not username or not password:
            raise ProviderError("Move TV: korisničko ime i lozinka nisu uneti.")
        data = self._post("/login", {
            "username": username, "password": password,
            "partnerId": PARTNER_ID, "deviceName": DEVICE_NAME,
            "deviceModelId": DEVICE_MODEL_ID, "uid": self._uid(), "appVersion": APP_VERSION,
        }, authenticated=False)

        self.token = str(data.get("auth_token") or "")
        self.customer = int(data.get("customer_id") or 0)
        # NOT the same number as customer_id, and every catalogue, guide and stream call needs it.
        self.profile = int(((data.get("profile") or {}).get("id")) or 0)
        if not self.token or not self.profile:
            raise ProviderError("Move TV: prijava je prošla ali nije vratila sesiju.")
        diag.log("Move TV: logged in (customer %s, profile %s)" % (self.customer, self.profile))

    def _ensure(self):
        if not self.token:
            self.login()

    # ---- catalogue --------------------------------------------------------

    def channels(self):
        self._ensure()
        data = self._post("/content/live/all", {
            "customerId": self.customer, "customerProfileId": self.profile,
            "lang": LANG, "appVersion": APP_VERSION,
        })
        rows = data.get("content") or []
        out, skipped, play_cache = [], 0, {}
        for item in rows:
            if not (item or {}).get("subscribed"):
                # Listing channels the account cannot play only produces rows that refuse to open. The
                # count is logged so "channels are missing" has an answer without a support round-trip.
                skipped += 1
                continue
            entry = self._channel_from(item, len(out) + 1, play_cache)
            if entry:
                out.append(entry)
        if not out:
            raise ProviderError("Move TV: nijedan kanal nije u pretplati (od %d ponuđenih)." % len(rows))
        _write_json(self._cache_path(PLAY_CACHE), play_cache)
        diag.log("Move TV: %d channels (%d not subscribed, skipped)" % (len(out), skipped))
        return out

    def _channel_from(self, item, fallback_number, play_cache):
        content_id = str(item.get("contentId") or "")
        live_id = str(item.get("liveId") or "")
        name = item.get("contentName") or ""
        if not content_id or not live_id or not name:
            return None

        catchup_hours = int((item.get("catchup") or {}).get("duration")
                            or item.get("contentLiveCatchupDuration") or 0)
        categories = item.get("categories") or []
        genre = str((categories[0] or {}).get("name") or "") if categories else ""
        radio = bool(item.get("audioOnly"))
        play_cache[content_id] = {"live_id": live_id, "catchup_hours": catchup_hours}
        return {
            "id": self.scoped("move_%s" % content_id),
            "tvg_id": self.scoped("move_%s" % content_id),
            # The GUIDE's key, not the stream's — see the module docstring on the two ids.
            "provider_ref": content_id,
            "name": name,
            "number": int(item.get("contentPosition") or fallback_number),
            "group": "Radio" if radio else (genre or GROUP_OTHER),
            "radio": radio,
            "logo": _image_url((item.get("picture") or {}).get("icon")),
            "url": ("plugin://plugin.video.iptvbalkan/?action=play&provider=move&id=%s%s"
                    % (content_id, self._account_param())),
            # See the module docstring: the window is known, the per-programme call is not.
            "catchup_days": 0,
            "provider_label": self.label,
        }

    def epg(self, channels, hours_back=24, hours_forward=48):
        """One request per channel — Move TV has no batched guide endpoint, so this is budgeted like
        EON's rather than run to completion."""
        self._ensure()
        budget_until = time.time() + self.settings.get_int("move_epg_budget_sec", 180)
        out, done, failed, first_error = [], 0, 0, ""
        # A refusal that will refuse the next channel too, stopped after three rather than three hundred.
        #
        # The customer's log is the argument: 300 channels, every one answering 401, and the addon asked
        # all 300 anyway — a minute of requests against a real subscription to produce an empty guide,
        # and 65 identical ERROR lines for whoever reads the log afterwards. The EON guide learned this
        # the same way a day earlier. A per-channel failure (one bad id, one odd programme) still just
        # counts and carries on; it is the CONSECUTIVE run that means "asking again cannot help".
        consecutive, renewed = 0, False
        for ch in channels:
            if time.time() > budget_until:
                diag.log("Move TV: guide budget spent after %d/%d channels — the rest follows next "
                         "refresh" % (done, len(channels)))
                break
            # See Provider.stopping.
            if self.stopping():
                diag.log("Move TV: Kodi is closing — the guide stops after %d/%d channels"
                         % (done, len(channels)))
                break
            try:
                out.extend(self._epg_for(ch["provider_ref"], hours_back, hours_forward))
                done += 1
                consecutive = 0
            except (ProviderError, net.HttpError) as err:
                # Counted, not swallowed: a guide that came back empty because every channel failed must
                # not look the same as a provider that simply has no programmes.
                failed += 1
                consecutive += 1
                first_error = first_error or str(err)
                # A cached session outlives its token (Move's own answer says `t: 32400`, nine hours),
                # and the guide is the first thing a scheduled refresh asks for — so the first refusal
                # buys ONE fresh login and one more try. Once only: a login per failed channel would be
                # three hundred sign-ins on an account that counts them.
                if not renewed and _is_auth_failure(err):
                    renewed = True
                    consecutive = 0
                    diag.log("Move TV: the guide was refused (%s) — logging in again and retrying once"
                             % str(err)[:90])
                    try:
                        self.token = ""
                        self.login()
                    except ProviderError as login_error:
                        diag.log("Move TV: the retry login failed too — %s" % login_error, "ERROR")
                        break
                    # THE SAME CHANNEL, not the next one. `continue` here went straight on to the
                    # following channel, so the one whose refusal paid for the fresh login was the
                    # single channel that never got to use it — it stayed without a guide until the
                    # next refresh, while the comment above promised "one more try". Asked again
                    # here, and the failure counted a moment ago is taken back, because it did not
                    # turn out to be one.
                    try:
                        programmes = self._epg_for(ch["provider_ref"], hours_back, hours_forward)
                    except (ProviderError, net.HttpError) as retry_error:
                        diag.log("Move TV: the channel failed again after the fresh login (%s)"
                                 % str(retry_error)[:90])
                        continue
                    failed -= 1
                    out.extend(programmes)
                    done += 1
                    continue
                if consecutive >= 3:
                    diag.log("Move TV: three channels in a row were refused — the guide stops here "
                             "rather than asking %d more times. Last answer: %s"
                             % (max(0, len(channels) - done - failed), str(err)[:120]), "ERROR")
                    break
        if failed:
            diag.log("Move TV: %d of %d channels had no guide (first: %s)"
                     % (failed, len(channels), first_error), "ERROR")
        diag.log("Move TV: %d programmes over %d channels" % (len(out), done))
        return out

    def _epg_for(self, content_id, hours_back, hours_forward):
        now_ms = int(time.time() * 1000)
        data = self._post("/content/epg/all", {
            "customerId": self.customer,
            # THE FIELD WHOSE ABSENCE ANSWERED 401, AND THE REASON THIS PROVIDER SHIPPED WITH NO GUIDE.
            #
            # Read off a customer's log on 2026-08-01 (serial 4012, a real Move subscription): the same
            # token, the same headers, seconds apart — `/content/live/all` answered 200 with 300
            # channels and `/content/epg/all` answered `401 Unauthorized` three hundred times. The only
            # difference between the two requests was this line.
            #
            # It was not guesswork that was missing, it was reading our own note: login() says, in the
            # comment above `self.profile`, that "every catalogue, guide and stream call needs it" — and
            # the Android client this was ported from says the same thing in its own docstring while its
            # `getEpg` quietly omits it. The port copied the code and not the sentence. Neither side had
            # ever run against a Move account, so nothing contradicted it until a customer did.
            "customerProfileId": self.profile,
            "partnerId": PARTNER_ID,
            "contentId": int(content_id), "time": now_ms,
            # The window is expressed in HOURS either side of an anchor, not as absolute bounds.
            "backwards": max(0, min(24 * 14, int(hours_back))),
            "forwards": max(0, min(24 * 14, int(hours_forward))),
            "appVersion": APP_VERSION,
        })
        out = []
        for row in data.get("content") or []:
            # MILLISECONDS here. Kaltura's are seconds — an easy mix-up between providers, and one that
            # puts the whole guide in 1970.
            start = int((row or {}).get("start") or 0)
            end = int((row or {}).get("end") or 0)
            title = (row or {}).get("title") or ""
            if start <= 0 or end <= 0 or not title:
                continue
            out.append({
                "channel_id": self.scoped("move_%s" % content_id),
                "start": _xmltv(start),
                "stop": _xmltv(end),
                "title": title,
                "desc": row.get("epgDesc") or "",
            })
        return out

    # ---- playback ---------------------------------------------------------

    def _cache_path(self, name):
        return self.cache_path(name)

    def _live_id(self, content_id):
        entry = _read_json(self._cache_path(PLAY_CACHE)).get(str(content_id)) or {}
        live_id = str(entry.get("live_id") or "")
        if live_id:
            return live_id
        # A channel added since the last refresh: fetch the list once rather than refusing to play.
        self.channels()
        entry = _read_json(self._cache_path(PLAY_CACHE)).get(str(content_id)) or {}
        return str(entry.get("live_id") or "")

    def resolve(self, channel_ref, at_utc=None):
        if at_utc:
            raise ProviderError("Move TV: premotavanje unazad još nije podržano za ovog provajdera.")
        self._ensure()
        live_id = self._live_id(channel_ref)
        if not live_id:
            raise ProviderError("Move TV: taj kanal nije u listi — osveži listu kanala pa probaj ponovo.")

        data = self._post("/content/live/source/get", {
            "customerId": self.customer, "customerProfileId": self.profile,
            "liveId": int(live_id), "dtype": DTYPE_DASH, "appVersion": APP_VERSION,
        })
        manifest = str(data.get("content_url") or "")
        play_auth = str((data.get("protection") or {}).get("headerValue") or "")
        if not manifest:
            raise ProviderError("Move TV: server nije vratio adresu strima za taj kanal.")
        if not play_auth:
            raise ProviderError("Move TV: server nije vratio %s token za taj kanal." % PLAY_AUTH_HEADER)
        if ((data.get("drm") or {}).get("enabled")):
            # Widevine is advertised account-wide but was never enabled on a sampled channel. If that
            # changes, say so here rather than handing the player an encrypted manifest with no licence
            # and letting it fail as a generic playback error.
            diag.log("Move TV: channel %s reports drm.enabled — this build only handles the %s scheme, "
                     "playback will probably fail" % (channel_ref, PLAY_AUTH_HEADER), "ERROR")

        expires = _PLAY_AUTH_EXPIRY.search(play_auth)
        if expires:
            diag.log("Move TV: play token for %s valid until %s"
                     % (channel_ref, time.strftime("%H:%M:%S", time.localtime(int(expires.group(1))))))

        headers = dict(self.session.headers_for())
        # On the manifest AND on every segment — that is the whole point of returning it here rather
        # than folding it into the URL.
        headers[PLAY_AUTH_HEADER] = play_auth
        return {"url": manifest, "manifest_type": "mpd", "headers": headers}

    # ---- diagnostics ------------------------------------------------------

    def diagnose(self):
        rows = []
        ok, detail = net.probe(self.session, BASE + "/login", method="POST")
        rows.append(("Reachable", ok, detail))
        rows.append(("Credentials", bool(self.setting("username") and self.setting("password")),
                     self.setting("username") or "not set"))
        try:
            self.login()
            rows.append(("Login", True, "customer %s, profile %s" % (self.customer, self.profile)))
        except ProviderError as err:
            rows.append(("Login", False, err.message))
            return rows
        try:
            channels = self.channels()
            rows.append(("Channel list", bool(channels), "%d channels" % len(channels)))
        except Exception as err:                                   # noqa: BLE001
            rows.append(("Channel list", False, "%s: %s" % (type(err).__name__, err)))
        return rows


def _is_auth_failure(err):
    """
    Was this refusal about the SESSION rather than about the request?

    Two shapes mean the same thing here and only one of them is an HTTP status. `net.HttpError` carries
    401/403 plainly; but this API also refuses inside a 200 body (`success:false` with an `appCode`),
    which `_ok` turns into a ProviderError with the message in it — and the message a customer's log
    showed for an expired session was exactly "Unauthorized!". Both are worth one fresh login; neither
    is worth three hundred.
    """
    if isinstance(err, net.HttpError):
        return err.is_auth
    text = str(getattr(err, "message", "") or err).lower()
    return "unauthorized" in text or "401" in text or "token" in text


def _image_url(path):
    path = str(path or "")
    if not path:
        return ""
    return path if path.startswith("http") else (IMAGE_BASE + path)


def _xmltv(value):
    """
    Accepts epoch seconds, epoch millis, or an ISO string — providers are inconsistent about this and a
    guide that silently drops half its programmes is worse than one that guesses sensibly.

    The ISO branch used to slice the string at 19 characters and stamp the result `+0000`, which threw
    the offset away and declared a local time to be UTC: every programme sat an hour or two from where
    it belonged, and a guide wrong by a whole hour looks like a broken provider rather than a formatting
    bug. The offset is now read and applied.
    """
    try:
        number = float(value)
        if number > 1e11:
            number /= 1000.0
        return time.strftime("%Y%m%d%H%M%S +0000", time.gmtime(number))
    except (TypeError, ValueError):
        pass

    text = str(value).strip()
    match = re.match(r"^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2}):(\d{2})"
                     r"(?:\.\d+)?\s*(Z|[+-]\d{2}:?\d{2})?$", text)
    if not match:
        # Unparseable is not a reason to lose the whole guide — the caller drops one programme.
        diag.log("Move TV: unrecognised timestamp %r in the guide" % text[:40])
        return ""
    year, month, day, hour, minute, second = (int(g) for g in match.groups()[:6])
    offset = match.group(7)
    stamp = calendar.timegm((year, month, day, hour, minute, second, 0, 0, 0))
    if offset and offset not in ("Z", "z"):
        sign = 1 if offset[0] == "+" else -1
        offset = offset[1:].replace(":", "")
        stamp -= sign * (int(offset[:2]) * 3600 + int(offset[2:]) * 60)
    return time.strftime("%Y%m%d%H%M%S +0000", time.gmtime(stamp))


def _read_json(path):
    try:
        with open(path, "r", encoding="utf-8") as handle:
            data = json.loads(handle.read())
        return data if isinstance(data, dict) else {}
    except (OSError, IOError, ValueError):
        return {}


def _write_json(path, data):
    try:
        with open(path, "w", encoding="utf-8") as handle:
            handle.write(json.dumps(data, ensure_ascii=False))
    except (OSError, IOError, ValueError) as err:
        diag.log("Move TV: could not write the play cache (%s)" % err, "ERROR")
