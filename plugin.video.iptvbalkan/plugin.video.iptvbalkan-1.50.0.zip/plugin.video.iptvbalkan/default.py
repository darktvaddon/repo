# -*- coding: utf-8 -*-
"""
The plugin:// half: per-tune URL resolution, and the diagnostics screen.

Channels whose URL is stable (Xtream, M3U) go straight into the playlist and never come through here.
Channels whose URL is minted and signed per tune (EON, Move) point at `?action=play`, so the token is
created at the moment of playback and never written to a file that outlives it.
"""

import json
import sys
import time

try:
    from urllib.parse import parse_qsl, quote
except ImportError:                                                # pragma: no cover
    from urlparse import parse_qsl
    from urllib import quote

import xbmc
import xbmcgui
import xbmcplugin

from resources.lib import (accounts, catalog, devicescreen, diag, kodisettings, licence, net,
                           parental, playlist, privacy, qrscreen, reminders, resume, search,
                           support, tmdb, transfer)
from resources.lib import i18n
from resources.lib.i18n import T
from resources.lib.provider import all_providers, find, ProviderError
from resources.lib.settings import ADDON_ID, Settings

HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1

#: Where this addon is unpacked, asked of Kodi rather than assumed: `special://home/addons/<id>` is the
#: usual place and not the only one, and an icon path that is wrong shows nothing at all with no error.
try:
    import xbmcaddon
    ADDON_PATH = xbmcaddon.Addon(ADDON_ID).getAddonInfo("path")
except Exception:                                                  # noqa: BLE001  (tooling, tests)
    ADDON_PATH = ""


def _provider(settings, key, account=""):
    """One provider instance. `account` picks between two subscriptions of the same provider."""
    return find(settings, key, account)


def search_screen(settings, term=""):
    """
    One search box over three different things, in the order a person is most likely to want them.

    Channels and the guide are answered from the files we already wrote, so they are instant and work
    with every provider offline. The Video klub is the slow half — one provider answers a query, the
    rest have to be walked — so it runs last, behind a progress bar that can be cancelled without
    losing the results already on screen.
    """
    if not term:
        term = xbmcgui.Dialog().input(T("Pretraga: kanal, emisija ili film"))
        if not term:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
            return

    rows = search.parse_playlist(settings.playlist_path())
    found_channels = search.channels_in(rows, term)
    shows = search.programmes(settings, term)

    progress = xbmcgui.DialogProgress()
    progress.create(T("IPTV Balkan — pretraga"), T("Video klub"))

    def tick(label, percent):
        progress.update(percent, "%s: %s" % (T("Video klub"), label))
        return progress.iscanceled()

    try:
        films = search.vod(settings, term,
                           [p for p in all_providers(settings) if p.enabled() and p.supports_vod],
                           progress=tick)
    finally:
        progress.close()

    if not (found_channels or shows or films):
        xbmcgui.Dialog().ok(T("IPTV Balkan — pretraga"), T("Nema rezultata za \"%s\".") % term)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    for row in found_channels:
        # WHOSE channel this is, in the row — the same shape the film rows already use. Read off the
        # box: a search for "Balkan" answered with three rows called "Balkan Trip" and two spellings of
        # "Newsmax Balkans", because two subscriptions carry the same stations and nothing on screen
        # said which was which. Not cosmetic either: `tune` matched on the NAME alone, so picking any
        # of those three was picking whichever one Kodi happened to list first.
        label = "[%s]  %s" % (T("TV"), row.get("name", ""))
        if row.get("provider"):
            label = "%s   (%s)" % (label, row["provider"])
        item = xbmcgui.ListItem(label=label)
        if row.get("logo"):
            item.setArt({"thumb": row["logo"], "icon": row["logo"]})
        # The title MUST be the composed label, not the bare name. Found on the real box: with a
        # different title in the info tag, Kodi's list view shows THAT and the prefix built here is
        # invisible — the screen came back as a wall of bare programme names with no marker, no time
        # and no channel, and nothing in any log said the labels had been overridden.
        item.setInfo("video", {"title": label, "plot": row.get("group") or ""})
        item.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(
            HANDLE, "%s?action=tune&name=%s&url=%s&provider=%s"
            % (sys.argv[0], quote(row.get("name", "")), quote(row.get("url", "")),
               quote(row.get("provider", ""))), item, False)

    for show in shows:
        # Looked up once: the same row supplies the catch-up template AND the properties that go with it.
        channel_row = next((r for r in rows if r.get("id") == show["channel_id"]), None)
        when = time.strftime("%d.%m. %H:%M", time.localtime(show["start"])) if show["start"] else ""
        marker = {"past": T("ARHIVA"), "now": T("SADA")}.get(show["state"], T("USKORO"))
        label = "[%s]  %s  %s — %s" % (marker, when, show["title"], show["channel_name"])
        item = xbmcgui.ListItem(label=label)
        item.setInfo("video", {"title": label, "plot": show.get("desc") or ""})
        # Only a finished programme on a channel that keeps an archive can actually be played. The rest
        # are still worth listing — "when is this on" is half the reason to search a guide — so they are
        # shown as plain rows that open the description instead of failing to start.
        # "Tell me when it starts", on the rows where that is the only useful thing left to do. A
        # programme that has not started cannot be played and cannot be archived — it was a dead row
        # that opened its own description, which is the whole answer this addon had to "when is this
        # on". See reminders.py for why this cannot be Kodi's own timer.
        if show["state"] == "next" and show.get("start"):
            item.addContextMenuItems([(
                T("Podseti me kad krene"),
                "RunPlugin(%s?action=remind&channel=%s&name=%s&title=%s&start=%d)"
                % (sys.argv[0], quote(str(show["channel_id"])), quote(show["channel_name"]),
                   quote(show["title"]), int(show["start"])))])
        url = search.catchup_url(rows, show["channel_id"], show["start"]) if show["state"] == "past" \
            else ""
        if url:
            item.setProperty("IsPlayable", "true")
            # The channel's own `#KODIPROP` lines travel WITH the URL, which is the half that was
            # missing. `parse_playlist` has always carried them for exactly this reason, and nothing
            # ever applied them: an archive result from here was handed to Kodi as a bare address with
            # no inputstream named, no stream headers and — on a DRM provider like Iris — no licence
            # key, which inputstream.adaptive reports as "Failed to parse the manifest file", a message
            # that sends you looking at the manifest instead of at the missing key. Setting them is what
            # makes this the same tune IPTV Simple performs from Kodi's own guide: it does precisely
            # this, the URL from `catchup-source` plus the channel's properties.
            #
            # One thing still differs and cannot be had from here: IPTV Simple also hands ffmpegdirect a
            # `catchup_url_format_string`, which is what lets a seek re-request the stream at a new
            # instant. So a programme played from a search result plays and pauses but does not scrub;
            # opened from the guide, it does both.
            for prop, value in ((channel_row or {}).get("props") or {}).items():
                item.setProperty(prop, value)
            xbmcplugin.addDirectoryItem(HANDLE, url, item, False)
        else:
            xbmcplugin.addDirectoryItem(
                HANDLE, "%s?action=showinfo&name=%s&desc=%s"
                % (sys.argv[0], quote(label), quote((show.get("desc") or "")[:900])), item, False)

    for film in films:
        # A locked category is a category, and a search result has left it — all that is left to judge
        # by is the title. See parental's docstring: this catches "XXX …" naming and nothing subtler,
        # and the settings screen says so rather than implying a guarantee.
        if parental.hide(settings, film.get("name", "")):
            continue
        label = "[%s]  %s   (%s)" % (T("VOD"), film.get("name", ""),
                                     film.get("provider_label", ""))
        item = xbmcgui.ListItem(label=label)
        if film.get("logo"):
            item.setArt({"thumb": film["logo"], "poster": film["logo"], "icon": film["logo"]})
        item.setInfo("video", {"title": label, "plot": film.get("plot") or ""})
        if film.get("kind") == "dir":
            xbmcplugin.addDirectoryItem(
                HANDLE, "%s?action=vod&provider=%s&account=%s&node=%s&cat=%s"
                % (sys.argv[0], film.get("provider", ""), film.get("account", ""),
                   quote(film.get("node") or ""), quote(film.get("name") or "")), item, True)
        else:
            item.setProperty("IsPlayable", "true")
            xbmcplugin.addDirectoryItem(
                HANDLE, "%s?action=play&provider=%s&account=%s&id=%s&vod=1&name=%s&art=%s"
                % (sys.argv[0], film.get("provider", ""), film.get("account", ""),
                   quote(str(film.get("id") or "")), quote(film.get("name") or ""),
                   quote(film.get("logo") or "")), item, False)

    diag.log("Search %r: %d channels, %d programmes, %d VOD"
             % (term, len(found_channels), len(shows), len(films)))
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(HANDLE)


def tune(settings, name, url, provider=""):
    """
    Play a channel found by search, through the PVR when it is available.

    Handing Kodi the playlist URL directly would work, and would also mean no guide overlay, no
    channel up/down and no timeshift — the whole live-TV experience the PVR gives for free. So the
    PVR's own channel list is asked for a channel of that name first, and the raw URL is only the
    fallback for a box where the PVR client is not set up yet.
    """
    del settings
    # The PROVIDER's own group first, then the two everything-pools.
    #
    # Two subscriptions carry many of the same stations — a search for "Balkan" on this account
    # answers with three "Balkan Trip" rows — and matching on the name alone tuned whichever one Kodi
    # listed first, which is not necessarily the one that was picked. Our own playlist puts every
    # channel in a group named after its provider (that is what `group_by_provider` is for), so the
    # right list to search is that group.
    #
    # And BOTH pools in the fallback: `alltv` was the only one asked, so every audio station — 65 of
    # them on EON alone — missed the PVR entirely and fell through to the raw stream below: no guide
    # overlay, no channel list, and none of the channel's own properties. It looked like it worked,
    # which is why it lasted; and playing the radio out of search is exactly what someone is told to do
    # when a station will not start from the list.
    try:
        groups = []
        if provider:
            for kind in ("tv", "radio"):
                answer = json.loads(xbmc.executeJSONRPC(
                    '{"jsonrpc":"2.0","id":1,"method":"PVR.GetChannelGroups",'
                    '"params":{"channeltype":"%s"}}' % kind)) or {}
                for group in (answer.get("result") or {}).get("channelgroups") or []:
                    # Kodi appends its own suffix to a radio group of the same name ("EON (Radio)"),
                    # so this is a prefix rather than an equality.
                    if (group.get("label") or "").startswith(provider):
                        groups.append(group["channelgroupid"])
        groups.extend(["alltv", "allradio"])
        for group in groups:
            query = ('{"jsonrpc":"2.0","id":1,"method":"PVR.GetChannels",'
                     '"params":{"channelgroupid":%s,"properties":["channelnumber"]}}'
                     % (('"%s"' % group) if isinstance(group, str) else group))
            answer = json.loads(xbmc.executeJSONRPC(query)) or {}
            for channel in (answer.get("result") or {}).get("channels") or []:
                if (channel.get("label") or "") == name:
                    xbmc.executeJSONRPC('{"jsonrpc":"2.0","id":1,"method":"Player.Open",'
                                        '"params":{"item":{"channelid":%d}}}'
                                        % int(channel["channelid"]))
                    return
    except (ValueError, KeyError, TypeError) as err:
        diag.log("Search: PVR lookup for %r failed (%s) — playing the stream directly" % (name, err))
    xbmc.executebuiltin("PlayMedia(%s)" % url)


def _parental_mode_screen(settings):
    """
    Whole club, or only the marked categories.

    The difference is stated rather than implied. "Only some categories" sounds like the safer, tidier
    choice and it is the weaker one: a search result and a continue-watching row have left their
    category behind, so all that can be checked there is the title. Someone choosing it should know
    that before a child finds out for them.
    """
    dialog = xbmcgui.Dialog()
    now = parental.mode(settings)
    choice = dialog.select(
        T("Sta se zakljucava"),
        ["%s%s" % (T("Ceo Video klub"), "  ✓" if now == parental.MODE_ALL else ""),
         "%s%s" % (T("Samo izabrane kategorije"), "  ✓" if now == parental.MODE_CATEGORIES else "")])
    if choice == 0:
        settings.set(parental.MODE, parental.MODE_ALL)
        dialog.ok(T("Sta se zakljucava"),
                  T("PIN se trazi na ulazu u Video klub. Nista se ne otvara bez njega."))
    elif choice == 1:
        settings.set(parental.MODE, parental.MODE_CATEGORIES)
        dialog.ok(T("Sta se zakljucava"),
                  T("Katalog je otvoren, PIN traze samo kategorije sa spiska (%s).\n\n"
                    "Vazno: rezultat pretrage i 'Nastavi gledanje' vise nisu u kategoriji, pa se tamo "
                    "moze proveriti samo naslov. Ako hoces cvrstu branu, izaberi ceo Video klub.")
                  % ", ".join(parental.locked_names(settings)))


def _parental_names_screen(settings):
    """The list of category names that ask for the PIN."""
    dialog = xbmcgui.Dialog()
    current = ", ".join(parental.locked_names(settings))
    typed = dialog.input(T("Kategorije koje traze PIN (odvoji zarezom)"), defaultt=current)
    if typed is None or typed.strip() == current:
        return
    if not typed.strip():
        # Empty means "back to the defaults", not "lock nothing" — an empty list with category mode on
        # is a lock that silently protects nothing, which is the worst of the three possible states.
        settings.set(parental.NAMES, "")
        dialog.ok(T("Kategorije koje traze PIN (odvoji zarezom)"),
                  T("Spisak je vracen na podrazumevani: %s") % parental.DEFAULT_NAMES)
        return
    settings.set(parental.NAMES, typed.strip())
    dialog.ok(T("Kategorije koje traze PIN (odvoji zarezom)"),
              T("PIN sada traze kategorije cije ime sadrzi: %s")
              % ", ".join(parental.locked_names(settings)))


def parental_screen(settings):
    """
    Set, change or remove the PIN.

    Changing or removing it asks for the CURRENT one first. Without that the lock is decoration: a child
    who reaches this screen simply clears it. It is skipped only when none is set yet, which is the one
    case where there is nothing to prove.
    """
    dialog = xbmcgui.Dialog()
    if parental.is_set(settings):
        current = dialog.input(T("Trenutni PIN"), type=xbmcgui.INPUT_NUMERIC,
                               option=xbmcgui.ALPHANUM_HIDE_INPUT)
        if not current or not parental.verify(settings, current):
            dialog.notification("IPTV Balkan", T("Pogresan PIN"), xbmcgui.NOTIFICATION_WARNING, 2500)
            return
        current_mode = T("ceo Video klub") if parental.mode(settings) == parental.MODE_ALL \
            else T("samo izabrane kategorije")
        choice = dialog.select(T("Roditeljski PIN za Video klub"),
                               [T("Promeni PIN"),
                                "%s: %s" % (T("Sta se zakljucava"), current_mode),
                                T("Izmeni spisak kategorija"),
                                T("Ukloni PIN"),
                                T("Zakljucaj odmah")])
        if choice == 1:
            _parental_mode_screen(settings)
            return
        if choice == 2:
            _parental_names_screen(settings)
            return
        if choice == 3:
            parental.set_pin(settings, "")
            dialog.notification("IPTV Balkan", T("PIN je uklonjen"), xbmcgui.NOTIFICATION_INFO, 2500)
            return
        if choice == 4:
            parental.relock(settings)
            dialog.notification("IPTV Balkan", T("Zakljucano"), xbmcgui.NOTIFICATION_INFO, 2000)
            return
        if choice != 0:
            return

    first = dialog.input(T("Novi PIN (4 do 8 cifara)"), type=xbmcgui.INPUT_NUMERIC,
                         option=xbmcgui.ALPHANUM_HIDE_INPUT)
    if not first:
        return
    if not (4 <= len(first) <= 8):
        dialog.ok(T("Roditeljski PIN za Video klub"), T("PIN mora imati izmedju 4 i 8 cifara."))
        return
    again = dialog.input(T("Ponovi PIN"), type=xbmcgui.INPUT_NUMERIC,
                         option=xbmcgui.ALPHANUM_HIDE_INPUT)
    # Asked twice because it is hidden while typing and a remote's number pad is easy to mistype — and a
    # PIN nobody knows locks the catalogue for the parent as much as for the child.
    if again != first:
        dialog.ok(T("Roditeljski PIN za Video klub"), T("Dva unosa se ne poklapaju."))
        return
    parental.set_pin(settings, first)
    dialog.ok(T("Roditeljski PIN za Video klub"),
              T("Video klub sada trazi PIN. Jednom unet, vazi 15 minuta."))


def _ask_parental_pin(settings):
    """
    Ask for the PIN. True when it was right, False on a wrong one or on cancel.

    ONE attempt per screen, not a retry loop. A loop is what turns a four-digit PIN into something a
    child brute-forces while nobody is watching — and a parent who mistypes simply opens the Video klub
    again, which costs one button. There is no lockout counter either: that would be a way to lock the
    family's own catalogue by mashing a remote.
    """
    pin = xbmcgui.Dialog().input(T("Roditeljski PIN"), type=xbmcgui.INPUT_NUMERIC,
                                 option=xbmcgui.ALPHANUM_HIDE_INPUT)
    if not pin:
        return False
    if parental.verify(settings, pin):
        return True
    xbmcgui.Dialog().notification("IPTV Balkan", T("Pogresan PIN"), xbmcgui.NOTIFICATION_WARNING, 2500)
    return False


def video_club(settings, key="", node="", account="", cat=""):
    """
    The on-demand tree, as a normal Kodi directory.

    VOD cannot ride the PVR the way live TV does — IPTV Simple presents channels and a guide, and has
    nowhere to put a film. So this is the one part of the addon that IS a browsable plugin, and it stays
    deliberately thin: every provider answers one level at a time (see Provider.vod) and this only turns
    those answers into list items.
    """
    # The parental gate.
    #
    # WHERE it is asked depends on the mode, and parental.gate_for() decides that in one place so no
    # screen can forget which mode is on:
    #
    #   whole club   — `name` is empty at the top level and gate_for() answers yes, so nobody browses
    #                  anything without the PIN. A sub-category cannot be opened around it either: this
    #                  runs on every level, and the answer stays yes until one is entered.
    #   categories   — only a category whose NAME matches asks. The name travels in the URL because the
    #                  provider is not asked again on the way in; the row that was clicked already knew
    #                  what it was called.
    #
    # A parent who has answered is not asked again while walking around inside. Kodi runs a plugin as a
    # fresh process per screen, so "already answered" is a timestamp on disk rather than a variable.
    if parental.gate_for(settings, cat) and not _ask_parental_pin(settings):
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    if node == "resume":
        return _continue_watching(settings)
    if not key:
        offering = []
        for provider in all_providers(settings):
            if not provider.enabled():
                continue
            try:
                if provider.vod():
                    offering.append(provider)
            except ProviderError as err:
                diag.log("VOD: %s could not be opened — %s" % (provider.label, err.message), "ERROR")
        if not offering:
            xbmcgui.Dialog().ok(T("IPTV Balkan — Video klub"),
                                T("Nijedan ukljucen provajder nema video klub, ili prijava nije "
                                  "prosla. Pogledaj '%s'.") % T("Pokreni dijagnostiku"))
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
            return
        # One provider is the common case, and making the user click through a menu of one is noise.
        # "Continue watching" sits above the providers, because it is what someone opening this screen
        # in the evening is usually reaching for.
        if resume.entries(settings) or len(offering) > 1:
            if resume.entries(settings):
                item = xbmcgui.ListItem(label=T("Nastavi gledanje"))
                xbmcplugin.addDirectoryItem(
                    HANDLE, "%s?action=vod&node=resume" % sys.argv[0], item, True)
            item = xbmcgui.ListItem(label=T("Pretraga"))
            xbmcplugin.addDirectoryItem(HANDLE, "%s?action=search" % sys.argv[0], item, True)
            for provider in offering:
                row = xbmcgui.ListItem(label=provider.label)
                xbmcplugin.addDirectoryItem(
                    HANDLE, "%s?action=vod&provider=%s&account=%s"
                    % (sys.argv[0], provider.key, provider.account_id), row, True)
            xbmcplugin.endOfDirectory(HANDLE)
            return
        # EXACTLY ONE, by elimination: zero returned above, and anything above one was drawn and returned
        # by the branch just above. This was written as `if len(offering) == 1: … else: <draw the same
        # menu again>`, and that else could never run — harmless, but it read as though two providers
        # could still arrive here, which is the opposite of true.
        #
        # The ACCOUNT travels with the key. Every other place that hands a provider on carries both (the
        # two loops around this one do), and this shortcut carried only the key — so when the single
        # VOD-capable provider was an EXTRA account, _provider(settings, key, "") built the FIRST account
        # instead: another subscription's credentials, another catalogue, or a ProviderError. Only
        # reachable with exactly one VOD provider and it being a second account, which is why it went
        # unnoticed.
        key, account = offering[0].key, offering[0].account_id

    # A background indicator rather than a modal bar: this is usually instant (EON pages four at a
    # time, Yettel reads its cached catalogue off disk) and putting a dialog in front of an instant
    # screen is worse than no dialog at all. But the FIRST Yettel screen of the day really does walk
    # the whole catalogue — measured at thirteen seconds — and thirteen seconds of a bare spinner is
    # indistinguishable from a box that has hung.
    busy = xbmcgui.DialogProgressBG()
    busy.create("IPTV Balkan", T("Video klub"))
    try:
        # `find` raises ProviderError too, and it is INSIDE the try for the same reason it is in play():
        # a Video klub address can outlive the account it names. The home-screen favourite this addon
        # creates is a stored `plugin://…?action=vod` URL, and an extra account can be deleted after it
        # was saved — so this is reached with a provider nobody can build. Left outside, that raised
        # straight out of main() and Kodi answered a Python traceback and "Script failed" instead of the
        # one sentence naming the provider.
        provider = _provider(settings, key, account)
        entries = provider.vod(node or None)
    except ProviderError as err:
        busy.close()
        xbmcgui.Dialog().ok(T("IPTV Balkan — Video klub"), T(err.message))
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    except net.HttpError as err:
        # THE SAME GUARD play() HAS CARRIED SINCE 2026-08-02, and this screen did not. A provider turns
        # refusals into ProviderError, but a connection that dies mid-request raises the network error
        # itself — and here that walked out as "Script failed" over the Video klub. Seen on the owner's
        # box at 06:53:23 on 2026-08-04: Move's sign-in got RemoteDisconnected and the whole screen
        # came back as a traceback.
        busy.close()
        diag.log("Video klub: the provider could not be reached — %s" % err, "ERROR")
        xbmcgui.Dialog().ok(T("IPTV Balkan — Video klub"),
                            T("Nema veze sa provajderom. Proveri internet."))
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    finally:
        # A background dialog that outlives its screen sits on the skin forever, so it is closed on
        # every path out of here, including the ones that raise.
        try:
            busy.close()
        except Exception:                                          # noqa: BLE001
            pass

    # TMDB, cache-only. The directory is built in ONE call and handed to Kodi, so anything that reaches
    # the network here is time the user spends staring at a spinner — a hundred titles would be half a
    # minute. Misses are queued and the resident service fills them, so the next visit is complete.
    want_meta = tmdb.enabled(settings)
    if not want_meta:
        # SAID OUT LOUD, because its silence was indistinguishable from "nobody opened this screen".
        # The owner reported no descriptions on his phone and the log carried not one TMDB line — which
        # could equally have meant metadata was switched off or that the Video klub had never been
        # opened in that window. One line settles it.
        diag.log("TMDB: no key and no server for this box — the Video klub will show the provider's own "
                 "titles and pictures only")
    missing = []
    # One connection for the whole screen instead of one per title — see tmdb.cached_many.
    known = tmdb.cached_many(
        settings,
        [(e.get("name") or "", bool(e.get("series"))) for e in entries if e.get("kind") != "dir"]
    ) if want_meta else {}

    for entry in entries:
        item = xbmcgui.ListItem(label=entry.get("name") or "")
        art = entry.get("logo") or ""
        info = {"title": entry.get("name") or ""}
        artwork = {"thumb": art, "poster": art, "icon": art} if art else {}
        if entry.get("plot"):
            info["plot"] = entry["plot"]

        if want_meta and entry.get("kind") != "dir":
            # `meta_key`, NOT `key`. This used to be called `key` and quietly overwrote the PROVIDER key
            # that both URLs below are built from — the whole Video klub broke on it: the first title on
            # a screen replaced "eon" with a ('Title', False) tuple, and every row built after it pointed
            # at `provider=('Guardians of the formula', False)`. Opening a series answered "Unknown
            # provider", playing a title did the same, and none of it could be reproduced against the
            # provider itself because the provider was never reached.
            meta_key = (entry.get("name") or "", bool(entry.get("series")))
            if meta_key not in known:
                missing.append(meta_key)
            elif known[meta_key]:
                info, artwork = tmdb.decorate(item, entry, known[meta_key])

        if artwork:
            item.setArt(artwork)
        if len(info) > 1 or info.get("plot"):
            # setInfo is deprecated in Kodi 20+ but still the only call that works on 19 as well, and a
            # TV box in the field is as likely to be one as the other.
            item.setInfo("video", info)
        if entry.get("kind") == "dir":
            # The NAME rides along with the node. The next screen asks parental.gate_for() whether to
            # demand the PIN, and the provider is not queried again on the way in — so without this the
            # only thing known about a category being opened is an opaque id, and a per-category lock
            # would have nothing to match on.
            url = "%s?action=vod&provider=%s&account=%s&node=%s&cat=%s" % (
                sys.argv[0], key, account, quote(entry.get("node") or ""),
                quote(entry.get("name") or ""))
            xbmcplugin.addDirectoryItem(HANDLE, url, item, True)
        else:
            item.setProperty("IsPlayable", "true")
            if want_meta:
                # The escape hatch for a wrong match. TMDB ranks by popularity, so a short or local
                # title lands on whatever bigger film contains it ("Crveni" -> "Crveni cvet") and no
                # rule fixes that — the person looking at it knows what it should be, so let them say.
                item.addContextMenuItems([(
                    T("Ispravi podatke (TMDB)"),
                    "RunPlugin(%s?action=fixmeta&name=%s&series=%s)"
                    % (sys.argv[0], quote(entry.get("name") or ""),
                       "1" if entry.get("series") else ""))])
            # Title and poster ride along to the play route ONLY so "continue watching" can show them
            # later. Nothing else needs them — but that list is built from what was recorded at tune
            # time, and the play route is handed an id and nothing else, so without this the row would
            # read as a bare provider id with no artwork.
            url = "%s?action=play&provider=%s&account=%s&id=%s&vod=1&name=%s&art=%s" % (
                sys.argv[0], key, account, quote(str(entry.get("id") or "")),
                quote(entry.get("name") or ""), quote(art))
            xbmcplugin.addDirectoryItem(HANDLE, url, item, False)
    if missing:
        tmdb.enqueue(settings, missing)
        diag.log("TMDB: %d of %d titles on this screen have no data yet — queued; the service fills "
                 "them and the next visit is complete" % (len(missing), len(entries)))
    elif want_meta and entries:
        diag.log("TMDB: every title on this screen already has its data")
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(HANDLE)


def _continue_watching(settings):
    """Titles with a position, newest first. Playing one resumes; the context menu forgets it."""
    # Continue-watching remembers WHAT was played, never where it was found — so in category mode the
    # only thing left to judge a row by is its title, the same rule and the same limit as search. The
    # filter runs before the "nothing started yet" check on purpose: a list whose every row is hidden
    # must read as empty rather than as a screen with a heading and nothing under it.
    rows = [r for r in resume.entries(settings)
            if not parental.hide(settings, r.get("name") or "")]
    if not rows:
        xbmcgui.Dialog().ok(T("IPTV Balkan — Video klub"), T("Nema zapocetih naslova."))
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    for row in rows:
        left = max(0, int(row.get("total", 0)) - int(row.get("position", 0)))
        label = "%s   (%s)" % (row.get("name") or row.get("id"),
                               T("jos %d min") % (left // 60))
        item = xbmcgui.ListItem(label=label)
        if row.get("art"):
            item.setArt({"thumb": row["art"], "poster": row["art"]})
        item.setProperty("IsPlayable", "true")
        item.addContextMenuItems([(T("Zaboravi ovaj naslov"),
                                   "RunPlugin(%s?action=forget&key=%s)"
                                   % (sys.argv[0], quote(row["key"])))])
        xbmcplugin.addDirectoryItem(
            HANDLE, "%s?action=play&provider=%s&account=%s&id=%s&vod=1&name=%s&art=%s"
            % (sys.argv[0], row.get("provider", ""), row.get("account", ""),
               quote(str(row.get("id") or "")), quote(row.get("name") or ""),
               quote(row.get("art") or "")), item, False)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(HANDLE)


#: Container -> MIME, so Kodi never has to ask the server what a file is. See the note in [play].
_FILE_MIME = {
    "mp4": "video/mp4", "m4v": "video/mp4", "mov": "video/quicktime",
    "mkv": "video/x-matroska", "webm": "video/webm", "avi": "video/x-msvideo",
    "wmv": "video/x-ms-wmv", "flv": "video/x-flv", "ts": "video/mp2t",
    "mpg": "video/mpeg", "mpeg": "video/mpeg",
}


def _isa_major():
    """inputstream.adaptive's major version, or 0 when it cannot be asked."""
    try:
        version = xbmcaddon.Addon("inputstream.adaptive").getAddonInfo("version") or ""
        return int(version.split(".", 1)[0])
    except Exception:                                              # noqa: BLE001
        return 0


def play(settings, key, channel_ref, at_utc=None, vod=False, account="", name="", art=""):
    # What we were ASKED for, before anything interprets it. The log could say what the provider
    # answered and never what the question was, so an archive complaint ("it played, but not the right
    # length") had no way to distinguish our resolution from the instant IPTV Simple substituted — and
    # IPTV Simple does not necessarily substitute the programme's start: `catchupWatchEpgBeginBufferMins`
    # (default 5) deliberately asks for a few minutes earlier. That matters here because EON addresses
    # an INSTANT, which merely starts early, while Iris addresses a PROGRAMME ID looked up FROM that
    # instant — where a few minutes early is a different programme.
    # EVERY press, not only the archive ones. This was inside `if at_utc`, so a film or an episode left
    # no line at all — and when Move's Video klub could not play (see supports_vod there), the log showed
    # a channel-list fetch appearing out of nowhere and nothing saying what had been asked for. The one
    # line that would have named the culprit was the one not being written.
    if at_utc:
        diag.log("Play: %s %s at utc=%s (%s)%s"
                 % (key, channel_ref, at_utc,
                    time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(int(at_utc)))
                    if str(at_utc).isdigit() else "unparsable",
                    " vod" if vod else ""))
    else:
        diag.log("Play: %s %s%s" % (key, channel_ref, " (Video klub)" if vod else ""))
    # Checked before the provider is even constructed: a locked device must not log in to EON, spend a
    # device slot or touch the provider at all. The dialog carries the device number, because that is
    # the one thing the user has to send to get unlocked — telling them "expired" without it would
    # generate a support message whose first reply is always "which number?".
    # From the CACHE, never the network — see licence.check's [allow_network]. The gate is unchanged;
    # what is removed is an HTTP round trip standing between the button and the picture on whichever
    # tune happens to land on the poll interval.
    verdict = licence.check(settings, allow_network=False)
    if not verdict.allowed:
        xbmcgui.Dialog().ok(T("IPTV Balkan — licenca"), licence.describe(verdict))
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return

    try:
        # Inside the try, because `find` raises ProviderError too — for a provider that is not configured
        # on this box any more. That is not a hypothetical: deleting an extra account leaves its channels
        # in the playlist until the next refresh, deliberately (see accounts / catalog), so pressing play
        # on one of them in between arrives here with a provider nobody can build. Raised from outside the
        # handler it left `main()` altogether, and Kodi answers that with a Python traceback and "Script
        # failed" over the top of the channel list, instead of the one sentence saying which provider.
        provider = _provider(settings, key, account)
        # The flag only reaches providers that declare on-demand support, so a live-only provider keeps
        # the two-argument signature it has always had. Declared rather than discovered: catching a
        # TypeError to find out would also swallow a genuine TypeError raised INSIDE resolve, and then
        # quietly retry it as a live channel.
        if vod and provider.supports_vod:
            resolved = provider.resolve(channel_ref, at_utc, vod=True)
        else:
            resolved = provider.resolve(channel_ref, at_utc)
    except ProviderError as err:
        # The reason reaches the user, not just the log. "Can't play" with no explanation is what makes
        # a provider problem look like an addon problem.
        # Provider errors are translated where they are SHOWN — see the note in devicescreen._describe.
        #
        # AND THE LOG GETS THE FACTS THE MESSAGE CANNOT CARRY. An archive failure is the one report that
        # keeps arriving without enough in it to act on: "some programmes from the calendar do not play"
        # was reported for two providers on 2026-08-04 and the log held nothing but successful replays,
        # because a refusal wrote one translated sentence and nothing about WHICH programme. The moment
        # this line exists, the next report identifies itself — provider, channel, and the instant that
        # was asked for, in local time so it can be found in the guide.
        _failed_at = ""
        if at_utc:
            try:
                _failed_at = " at %s (utc=%s)" % (
                    time.strftime("%Y-%m-%d %H:%M", time.localtime(int(at_utc))), at_utc)
            except (TypeError, ValueError):
                _failed_at = " at utc=%s" % at_utc
        diag.log("Play REFUSED: %s %s%s — %s"
                 % (key, channel_ref, _failed_at, err.message), "ERROR")
        xbmcgui.Dialog().notification("IPTV Balkan", T(err.message), xbmcgui.NOTIFICATION_ERROR, 6000)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    except net.HttpError as err:
        # A PROVIDER THAT RAISES THE RAW NETWORK ERROR USED TO REACH KODI AS "Script failed".
        #
        # Providers turn refusals into ProviderError, but not every path does — an unreachable host, a
        # DNS failure, a timeout on the one call that had no wrapper. Found on 2026-08-02 the moment
        # the menu test was cut off from the network: two play routes came back as a traceback instead
        # of a message. On a television that is a red "Script failed" over the channel list, which
        # tells the user nothing and tells us nothing either.
        diag.log("Play: the provider could not be reached — %s" % err, "ERROR")
        xbmcgui.Dialog().notification(
            "IPTV Balkan", T("Nema veze sa provajderom. Proveri internet."),
            xbmcgui.NOTIFICATION_ERROR, 6000)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return

    # Three shapes, because providers differ in how much the player needs to be told. A bare URL is the
    # simple case; a (url, headers) pair covers a provider whose CDN gates on identity; a dict covers
    # DRM, where the licence server and its per-tune token have to travel with the stream (Iris).
    audio_only = False
    if isinstance(resolved, dict):
        url = resolved.get("url", "")
        headers = resolved.get("headers") or {}
        manifest = resolved.get("manifest_type") or ("mpd" if ".mpd" in url else "hls")
        licence_type = resolved.get("license_type") or ""
        licence_key = resolved.get("license_key") or ""
        # A RADIO station. See the note further down: this is the one stream that must not be handed to
        # inputstream.adaptive.
        audio_only = bool(resolved.get("audio_only"))
    elif isinstance(resolved, tuple):
        url, headers = resolved
        manifest, licence_type, licence_key = ("mpd" if ".mpd" in url else "hls"), "", ""
    else:
        url, headers = resolved, provider.session.headers_for()
        manifest, licence_type, licence_key = ("mpd" if ".mpd" in url else "hls"), "", ""

    # Is this an ADAPTIVE stream at all, or an ordinary file?
    #
    # Everything here used to be handed to inputstream.adaptive, because every provider that existed
    # served a manifest. Xtream's Video klub does not: a film is a plain `…/movie/user/pass/6590.mp4`.
    # inputstream.adaptive accepts it, tries to parse an MP4 as a manifest, and never reports anything —
    # the spinner simply turns forever, which is exactly what an Xtream film did.
    #
    # A file with a progressive extension goes to Kodi's own player. Anything else keeps the previous
    # behaviour, which matters: EON's URL is `/stream?i=…` with no extension at all, so "no extension"
    # has to keep meaning "adaptive" rather than falling through to the file player.
    progressive = url.split("?")[0].lower().rsplit(".", 1)
    is_file = len(progressive) == 2 and progressive[1] in (
        "mp4", "mkv", "avi", "ts", "mov", "flv", "m4v", "wmv", "mpg", "mpeg", "webm")

    # Catch-up gets a TIMESHIFT BUFFER instead of the adaptive inputstream, and that is the whole reason
    # rewinding inside an archive programme did not work.
    #
    # EON serves a replay as a sliding window twelve seconds long — measured: three segments, no
    # EXT-X-ENDLIST. inputstream.adaptive plays exactly what the manifest offers, so there was no
    # timeline to scrub and no amount of player configuration created one. The Android client solves
    # this by RECORDING the stream to local files as it plays and seeking inside its own recording
    # (TimeshiftRecorder), not by asking EON for a longer window.
    #
    # inputstream.ffmpegdirect does the same thing inside Kodi: `stream_mode=timeshift` buffers the
    # incoming stream to disk and hands Kodi a growing, seekable timeline. It stays ordinary PVR
    # playback, so the channel name and the guide stay on the OSD — which the alternative (the service
    # re-minting a URL and restarting playback as a plain video) would have thrown away.
    #
    # Only for catch-up, and only without DRM: a licence needs inputstream.adaptive, and live tuning
    # already works and has nothing to gain.
    # ...and ONLY for an archive that really is a window. This is not a property of catch-up, it is a
    # property of the PROVIDER, and getting it wrong is a hard failure rather than a degraded one:
    # Move hands back a STATIC manifest covering the whole programme (index-<start>-<duration>.mpd),
    # already seekable end to end by inputstream.adaptive. Handed to ffmpegdirect in timeshift mode it
    # is opened through FFmpeg's AVFormat, which cannot make a growing buffer out of a finished file —
    # "CVideoPlayer::OpenInputStream - error opening" and nothing plays at all.
    #
    # Iris was never caught by this only because it is DRM-protected and `not licence_key` excluded it;
    # that was luck, not a rule. Providers now say so explicitly, and the default keeps EON's behaviour.
    timeshift = bool(at_utc) and not vod and not licence_key
    if isinstance(resolved, dict) and resolved.get("timeshift") is False:
        timeshift = False
    if timeshift and headers:
        # ffmpegdirect has no headers property — Kodi's own convention is to append them to the URL.
        url = url + "|" + "&".join("%s=%s" % (k, quote(v, safe="")) for k, v in sorted(headers.items()))

    item = xbmcgui.ListItem(path=url)
    if at_utc and not vod:
        # Put the programme on the OSD. Kodi shows the plain video overlay for a resolved catch-up
        # stream — a bar and a clock, with no title anywhere — and the guide entry the user picked is
        # already in our own XMLTV. Best effort by design: no guide yet, or a channel whose archive
        # reaches past what we store, simply plays without a caption rather than refusing.
        programme = search.programme_at(settings, key, channel_ref, at_utc)
        if programme and programme.get("title"):
            item.setLabel(programme["title"])
            info = {"title": programme["title"]}
            if programme.get("desc"):
                info["plot"] = programme["desc"]
            if programme.get("stop") and programme.get("start"):
                info["duration"] = max(0, int(programme["stop"]) - int(programme["start"]))
            item.setInfo("video", info)

    if vod:
        # WHAT IS PLAYING, told to Kodi — which is what makes subtitle search work at all.
        #
        # A resolved plugin stream arrives at the player as a URL and nothing else. Kodi's subtitle
        # dialog hands the playing item to every subtitle addon the user has installed, so with no
        # title, no year and no id there is nothing to search on, and the button that looks like it
        # should work returns an empty list every time. That is the whole reason this addon "had no
        # subtitles": not a missing feature, a missing three lines.
        #
        # The IMDb id is the one that matters. Serbian catalogue titles are exactly the input that text
        # matching gets wrong — and the subtitles of the WRONG film are worse than none. With an id the
        # match is exact and script-independent. It comes from the TMDB cache, so it is present for any
        # title the library has already enriched and simply absent for one it has not; absent means the
        # search falls back to the title, which is what it did before.
        info = {"mediatype": "movie", "title": name or ""}
        meta = tmdb.cached(settings, name) if name else None
        if meta:
            if meta.get("year"):
                info["year"] = int(meta["year"])
            if meta.get("plot"):
                info["plot"] = meta["plot"]
            if meta.get("duration"):
                info["duration"] = int(meta["duration"])
            if meta.get("imdb"):
                # Both spellings. `imdbnumber` is what Kodi's older info API and most subtitle addons
                # read; setUniqueIDs is the modern one. Neither alone covers everything installed out
                # there, and setting both costs nothing.
                info["imdbnumber"] = meta["imdb"]
                try:
                    item.setUniqueIDs({"imdb": meta["imdb"]}, "imdb")
                except (AttributeError, TypeError):
                    # Older Kodi without setUniqueIDs — imdbnumber above still carries it.
                    pass
        item.setInfo("video", info)

        # Two halves of "continue watching", and they have to be here because this process ends the
        # moment playback starts: the marker tells the resident service WHAT is on screen so it can
        # record the position, and ResumeTime/TotalTime tell Kodi where to start.
        resume.mark_playing(settings, key, account, str(channel_ref), url,
                            name=name, art=art)
        position, total = resume.position_of(settings, key, account, str(channel_ref))
        if position and total:
            item.setProperty("ResumeTime", str(position))
            item.setProperty("TotalTime", str(total))
    if is_file:
        # An ordinary file: no inputstream, no manifest type. Kodi picks the demuxer from the container,
        # seeks natively, and the headers ride on the URL the way every other Kodi file source carries
        # them.
        #
        # The MIME type is declared and content lookup is switched OFF, and that pair is not cosmetic.
        # Without it Kodi asks the server what the file is with a HEAD request before playing — and this
        # panel NEVER ANSWERS one. Measured against it: HEAD hangs until the 25-second timeout while GET
        # answers in 0.2s. Kodi does it twice, so every film sat there for the better part of a minute
        # before a picture appeared, with `CCurlFile::Stat ... failed` the only trace.
        item.setMimeType(_FILE_MIME.get(progressive[1], "video/mp4"))
        item.setContentLookup(False)
        if headers:
            item.setPath(url + "|" + "&".join(
                "%s=%s" % (k, quote(v, safe="")) for k, v in sorted(headers.items())))
        xbmcplugin.setResolvedUrl(HANDLE, True, item)
        return

    # AUDIO ONLY: ffmpegdirect, as a live stream.
    #
    # Three players have had this stream and only the third keeps it. inputstream.adaptive refused it.
    # Kodi's own PAPlayer plays it — and ENDS it, silently, when the station changes its sample rate in
    # the middle: measured on Radio Studio B, where kodi.log reads `CDVDDemuxFFmpeg::Read() stream
    # change`, a sink re-opened at 48000 where it had been 44100, and `PAPlayer::ProcessStream - Stream
    # Finished` a minute later. The edge was blameless throughout — the same station's playlist was
    # rolling forward normally (media sequence 0, 3, 6, 9 … over ninety seconds) while Kodi gave up.
    # Stations that never change rate (Bum Bum Radio, Radio JAT) survived the identical path, which is
    # why this looked intermittent and station-specific rather than like a player problem.
    #
    # ffmpegdirect is the engine television already uses here, it handles a discontinuity without
    # ending the file, and `is_realtime_stream` tells it this is live rather than a recording. Naming an
    # inputstream is safe HERE — the trap this project knows is naming one on a `plugin://` PLAYLIST
    # entry, where Kodi hands the plugin address itself to the engine; this is the resolved http URL.
    #
    # No catch-up properties come with it, and that matters: ffmpegdirect on an audio stream that
    # claims an archive is what used to take Kodi down with it (see eon.py, where radio stopped
    # claiming one).
    if audio_only:
        item.setMimeType("application/vnd.apple.mpegurl")
        item.setContentLookup(False)
        # ffmpegdirect was tried here and MEASURED: Kodi sends a radio channel to its own audio
        # decoder whatever the item says, the engine's properties never reached it ("OpenStream() -
        # Num Props: 2", no headers among them), and the edge refused the open — both stations died in
        # ten seconds where four of five had survived ninety. The headers go on the URL, which is the
        # only channel this path has for them.
        if headers:
            item.setPath(url + "|" + "&".join(
                "%s=%s" % (k, quote(v, safe="")) for k, v in sorted(headers.items())))
        xbmcplugin.setResolvedUrl(HANDLE, True, item)
        return

    item.setMimeType("application/dash+xml" if manifest == "mpd" else "application/vnd.apple.mpegurl")
    item.setContentLookup(False)
    if timeshift:
        # Property names taken from the installed binary's own string table, not from memory — this
        # addon has been bitten before by a plausible-looking property Kodi silently ignores.
        item.setProperty("inputstream", "inputstream.ffmpegdirect")
        item.setProperty("inputstream.ffmpegdirect.stream_mode", "timeshift")
        item.setProperty("inputstream.ffmpegdirect.is_realtime_stream", "true")
        item.setProperty("inputstream.ffmpegdirect.manifest_type", manifest)
        item.setProperty("inputstream.ffmpegdirect.open_mode", "ffmpeg")
        xbmcplugin.setResolvedUrl(HANDLE, True, item)
        return
    item.setProperty("inputstream", "inputstream.adaptive")
    # `manifest_type` was DEPRECATED in inputstream.adaptive 21 and REMOVED in 22, where the manifest is
    # recognised from the MIME type set above instead. Older engines still need it and plenty of boxes
    # run them, so it is sent only where it means something.
    #
    # The line below it is the other half, and the reason both exist: a phone on Kodi 22.0-BETA1 with
    # ISA 22.3.19 listed its channels and played nothing, and not one of the three logs sent so far
    # covered the moment of a tune. A tune now leaves a line naming the engine, its version and what it
    # was handed — so the next report answers the question instead of raising it.
    if _isa_major() < 21:
        item.setProperty("inputstream.adaptive.manifest_type", manifest)
    diag.log("Play: %s -> inputstream.adaptive %s, %s%s%s"
             % (key, _isa_major() or "?", manifest,
                ", DRM" if licence_key else "", ", headers" if headers else ""))
    if licence_type:
        item.setProperty("inputstream.adaptive.license_type", licence_type)
    if licence_key:
        item.setProperty("inputstream.adaptive.license_key", licence_key)
    if headers:
        # The playlist writer's own blob, not a second spelling of it. This used to join the values
        # RAW while `playlist.header_blob` urlencoded them, so the same channel carried different
        # headers depending on whether it was tuned from Kodi's guide or through `plugin://` — and
        # inputstream.adaptive URL-decodes what it is given, which makes the raw form correct only
        # for values that happen to contain no `&`, `+` or `%`. See header_blob's own note.
        blob = playlist.header_blob(headers)
        # Both properties for the same reason the playlist writes both: which one is honoured depends
        # on the inputstream.adaptive version installed.
        item.setProperty("inputstream.adaptive.stream_headers", blob)
        item.setProperty("inputstream.adaptive.manifest_headers", blob)

    # WHICH RENDITION THE PLAYER MAY CLIMB TO, said out loud instead of left to whatever ISA was last
    # configured with.
    #
    # Reported from a real television: most of one provider's 4K channels play at 480p, and the same
    # thing happens in an unrelated addon against the same provider — so it is the manifest and the
    # player meeting each other, not our code. What this addon was contributing is silence: it set no
    # selection property at all, so ISA used whatever its own settings said, and ISA's default for a
    # SECURE (DRM) decoder is deliberately conservative because it cannot know what the device will
    # actually decrypt at.
    #
    # `adaptive` is ISA's own name for "start where you like and climb with the bandwidth", which is
    # the behaviour a viewer expects and the one that reaches 4K when the line and the decoder allow
    # it. It is not a promise of 4K: a manifest that puts its 4K rendition in a separate AdaptationSet
    # (usual when 4K is HEVC and the rest is H.264) is one no adaptive switch ever crosses, and that
    # has to be measured against the real manifest before anything else is done about it. Which is why
    # the line below exists.
    item.setProperty("inputstream.adaptive.stream_selection_type", "adaptive")
    if settings.verbose():
        # THE MEASUREMENT THAT WAS MISSING. With the trace on, fetch the manifest once and write down
        # every video rendition it advertises — width, height, bitrate, codec, and which AdaptationSet
        # each sits in. A "4K plays at 480p" report is unanswerable without it and trivial with it, and
        # nobody should have to be at the owner's house to collect it.
        diag.log_manifest_renditions(url, headers)
    xbmcplugin.setResolvedUrl(HANDLE, True, item)


def diagnostics(settings):
    """
    One screen that answers "what exactly is broken" for every enabled provider.

    Each provider reports its own chain — reachable, credentials, host, login, channel list — so the
    answer is a step, not a shrug. This is the screen to open before writing a support message.
    """
    lines = []
    for provider in all_providers(settings):
        if not provider.enabled():
            continue
        lines.append("[B]%s[/B]" % provider.label)
        try:
            for check, ok, detail in provider.diagnose():
                lines.append("  %s %s — %s" % ("[COLOR green]OK[/COLOR]" if ok else "[COLOR red]FAIL[/COLOR]",
                                               check, detail))
        except Exception as err:                                   # noqa: BLE001
            lines.append("  [COLOR red]FAIL[/COLOR] diagnostics crashed — %s: %s"
                         % (type(err).__name__, err))
        lines.append("")
    if not lines:
        lines = [T("Nijedan provajder jos nije ukljucen. Ukljuci ga u podesavanjima dodatka.")]

    # Not our addon, and said plainly for that reason. Kodi starts its PVR clients one after another,
    # so one that cannot reach its backend holds up every client behind it — including ours — and
    # nothing on screen ever names it. This is the screen where "why is the channel list slow to
    # appear" is asked, so this is where the answer belongs; what to do about it is the owner's.
    broken = diag.failing_pvr_clients()
    if broken:
        lines.append("[B]%s[/B]" % T("Drugi PVR dodaci"))
        for entry in broken:
            lines.append("  [COLOR red]FAIL[/COLOR] %s — %s%s"
                         % (entry["addon"], entry["status"] or T("greske u Kodijevom logu"),
                            T(" (%d linija)") % entry["lines"]))
        lines.append("  " + T("Taj dodatak nije nas i nista ovde ga nije diralo. Kodi pravi PVR "
                              "klijente jedan po jedan, pa onaj koji ne moze da dodje do svog servera "
                              "kasni svakom sledecem — TV lista se pojavi kasno, a vodic izgleda "
                              "zaglavljeno."))
        lines.append("  " + T("Podesavanja / Dodaci / Moji dodaci / PVR klijenti da ga iskljucis ili "
                              "uklonis."))
        lines.append("")

    # WHAT THE LAST REFRESH COST, per provider, in seconds.
    #
    # Every "it is slow" report in this project so far has been answered the same way: somebody goes to
    # the box, adds timing, and measures. The measurement is free — the refresh already knows how long
    # each provider took — so it is kept, and this is where the person with the problem can read it out
    # without anybody having to visit their television.
    timings = settings.get("last_refresh_timings", "")
    if timings:
        lines.append("[B]%s[/B]" % T("Poslednje osvezavanje"))
        lines.append("  %s" % settings.get("last_refresh", "?"))
        for part in timings.split(" · "):
            lines.append("  %s" % part)
        lines.append("")

    # AN UPDATE THAT WAS DOWNLOADED AND COULD NOT BE INSTALLED. Top of the screen, above everything
    # else, because while it is true every other row describes a version that was superseded — and the
    # first question about any of them has already been answered.
    blocked = diag.failed_addon_update()
    if blocked:
        lines.insert(0, "")
        lines.insert(0, T("Kodi ne moze da zameni fajlove dodatka, pa nova verzija ostaje "
                          "nepostavljena. Deinstaliraj dodatak i instaliraj ga ponovo iz "
                          "repozitorijuma — nalozi i podesavanja se cuvaju odvojeno i ostaju."))
        lines.insert(0, "[B][COLOR red]%s[/COLOR][/B]"
                     % (T("Azuriranje je preuzeto ali NIJE postavljeno (%d puta)") % blocked))

    # HOW DEEP THE ARCHIVE REALLY GOES. The number people ask about, previously answered only by an
    # INFO line in the log — see kodisettings.guide_window_report.
    lines.append("[B]%s[/B]" % T("Dubina arhive (prozor vodica)"))
    for row in kodisettings.guide_window_report(settings):
        lines.append("  %s" % row)
    lines.append("")

    # THE PORT, but only when it actually failed. Written by localserver.start, and it is the answer to
    # "EON se pusta ali ne mogu da premotam arhivu" — which nobody has ever guessed is a port.
    port_error = settings.get("catchup_port_error", "")
    if port_error:
        lines.append("[B]%s[/B]" % T("Premotavanje arhive"))
        lines.append("  [COLOR red]FAIL[/COLOR] %s" % port_error)
        lines.append("  " + T("Unutrasnji server nije mogao da zauzme svoj port, pa se arhiva pusta "
                              "ali se ne premotava. Najcesce ga jos drzi Kodi iz drugog profila — "
                              "ugasi i upali Kodi."))
        lines.append("")

    lines.append("Log: %s" % settings.profile_dir())
    xbmcgui.Dialog().textviewer(T("IPTV Balkan — dijagnostika"), "\n".join(lines))


def reminder_screen(settings):
    """
    What this box will tell you about, and a way to drop one.

    A textviewer would be simpler and is the wrong shape: the reason to open this screen is usually to
    cancel something, and a list you cannot act on sends the user to find the file.
    """
    rows = reminders.load(settings)
    if not rows:
        xbmcgui.Dialog().ok(T("Podsetnici"),
                            T("Nema nijednog podsetnika.\n\nPostavlja se iz pretrage: nadji emisiju "
                              "koja tek dolazi, drzi OK na njoj i izaberi „Podseti me kad krene”."))
        return
    labels = [reminders.describe(row) for row in rows]
    chosen = xbmcgui.Dialog().select(T("Podsetnici — izaberi da obrises"), labels)
    if chosen < 0:
        return
    if xbmcgui.Dialog().yesno(T("Podsetnici"), T("Obrisati podsetnik?\n\n%s") % labels[chosen]):
        reminders.forget(settings, rows[chosen].get("key") or "")
        xbmcgui.Dialog().notification("IPTV Balkan", T("Podsetnik je obrisan"),
                                      xbmcgui.NOTIFICATION_INFO, 3000)


def refresh_now(settings, only=None):
    # The same shutdown check the service passes. A manual refresh runs in THIS process, which Kodi
    # waits for just as patiently — and this is the one someone starts and then walks away from.
    #
    # [only] is passed by the flows that changed ONE provider: the rest are served from their cached
    # block, so linking Yettel on a box that also has EON and Iris takes half a minute instead of six
    # of them. A refresh chosen from the menu never passes it — there "refresh" means all of it.
    monitor = xbmc.Monitor()
    result = catalog.build(settings, should_stop=lambda: monitor.abortRequested(), only=only)
    summary = ["%s %s — %s" % ("OK  " if ok else "FAIL", label, detail)
               for label, ok, detail in result.per_provider]
    summary.append("")
    summary.append(T("%d kanala, %d emisija") % (result.channels, result.programmes))
    if not result.written:
        summary.append(T("Nista nije upisano — ostaje prethodna lista kanala."))
    xbmcgui.Dialog().textviewer(T("IPTV Balkan — osvezavanje"), "\n".join(summary))


def send_log(settings):
    qrscreen.send_log(settings)


def confirmed(args, title, question):
    """
    Guard for the pairing buttons that live in the settings screen.

    A button in Kodi's settings list is fired by a TAP on a touchscreen, and a finger dragging that list
    to scroll it lands on whatever row it started on. On a phone this means simply scrolling past the
    Yettel row opens the pairing screen — reported from a phone, where it is not merely confusing: the
    settings dialog closes under the user, and the Yettel flow has already asked Yettel for a device code
    by the time the screen appears, burning a one-time code nobody wanted.

    Only the settings buttons pass `confirm=1`. The same actions chosen deliberately from the addon's own
    menu stay one press, because there a press IS the answer to this question.
    """
    if not args.get("confirm"):
        return True
    return bool(xbmcgui.Dialog().yesno("IPTV Balkan — %s" % title, question))


def pair_with_phone(settings, here=None):
    # The answer is the provider key when the screen knows it, and plain True when it does not (an
    # older path, or a form type with no provider of its own). Only the provider that was just paired
    # is fetched; the rest come off their cached blocks, which is what makes this half a minute
    # instead of six on a box with three subscriptions. Yettel's flow has done it this way since
    # 1.26.0 — pairing simply never had the key to hand.
    paired = qrscreen.pair_with_phone(settings, here=here)
    if paired and xbmcgui.Dialog().yesno(
            "IPTV Balkan", T("Nalog je sacuvan. Osveziti listu kanala i vodic sada?")):
        refresh_now(settings, only=(paired,) if isinstance(paired, str) else None)


def link_yettel(settings):
    if qrscreen.link_yettel(settings) and xbmcgui.Dialog().yesno(
            "IPTV Balkan", T("Yettel je povezan i ukljucen. Osveziti listu kanala sada?")):
        refresh_now(settings, only=("yettel",))


def switch_kodi_to_serbian():
    """
    Offer to put KODI into Serbian too, and say plainly why that is a separate question.

    The addon's own screens follow its own setting. Kodi's settings dialog does not and cannot: it is
    drawn by Kodi, in Kodi's language, from the same .po this addon ships — so the labels ARE
    translated, they are just chosen by the wrong switch. One row does it, and it asks first, because
    changing the whole interface is the owner's call and not an addon's.
    """
    from resources.lib import kodisettings

    def ask():
        return xbmcgui.Dialog().yesno(
            "IPTV Balkan",
            T("Ekran podesavanja crta Kodi i on prati KODIJEV jezik, a ne jezik dodatka. Prebaciti "
              "ceo Kodi na srpski? Ako srpski nije instaliran, Kodi ce ga prvo preuzeti."))

    if kodisettings.offer_serbian(ask):
        xbmcgui.Dialog().ok("IPTV Balkan", T("Kodi je prebacen na srpski."))
        return
    if kodisettings.kodi_is_serbian():
        return                                                     # already Serbian, or the user said no
    # It could not be done from here. Rather than a row that does nothing, say so in one sentence and
    # open Kodi's own settings — the language is a few presses away and now they are in front of it.
    xbmcgui.Dialog().ok(
        "IPTV Balkan",
        T("Nije uspelo automatsko prebacivanje. Otvaram Kodijeva podesavanja — jezik je pod "
          "Interface / Regional / Language."))
    kodisettings.open_language_screen()


def manage_accounts(settings):
    """
    Every account on this box, and what can be done with one.

    The first account of each provider is the settings screen's own — it can be switched off there, so
    the only thing offered here is a reminder of where it lives. Extra accounts are this screen's to
    rename, disable and delete, because nothing in Kodi's settings format can list a variable number of
    anything.
    """
    while True:
        listed = accounts.describe(settings)
        if not listed:
            xbmcgui.Dialog().ok(T("IPTV Balkan — nalozi"),
                                T("Nema nijednog ukljucenog naloga. Ukljuci provajdera u "
                                  "podesavanjima ili ga unesi telefonom."))
            return
        rows = []
        for entry in listed:
            mark = "" if entry["enabled"] else "  [%s]" % T("iskljucen")
            where = T("podesavanja") if entry["first"] else T("dodatni")
            rows.append("%s  (%s)%s" % (entry["name"], where, mark))
        chosen = xbmcgui.Dialog().select(T("Nalozi na ovom uredjaju"), rows)
        if chosen < 0:
            return
        entry = listed[chosen]
        if entry["first"]:
            xbmcgui.Dialog().ok(
                T("IPTV Balkan — nalozi"),
                T("„%s“ je prvi nalog i zivi u podesavanjima dodatka — tamo se menja i "
                  "iskljucuje.\n\nDodatni nalozi se dodaju preko „Unesi nalog…“ u istom meniju, sa "
                  "cekiranim „Dodaj kao NOV nalog“.") % entry["name"])
            continue
        action = xbmcgui.Dialog().select(
            entry["name"], [T("Iskljuci") if entry["enabled"] else T("Ukljuci"),
                            T("Obrisi"), T("Nazad")])
        if action == 0:
            stored = accounts.load(settings)
            for account in stored:
                if account["id"] == entry["id"]:
                    account["enabled"] = not entry["enabled"]
            accounts.save(settings, stored)
        elif action == 1:
            if xbmcgui.Dialog().yesno("IPTV Balkan",
                                      T("Obrisati nalog „%s“?\n\nKanali nestaju iz liste posle "
                                        "sledećeg osvežavanja.") % entry["name"]):
                accounts.remove(settings, entry["id"])


def toggle_kodi_debug():
    """
    Kodi's own debug logging, from here instead of four screens deep in Settings.

    IPTV Simple writes what it is doing — how many channels it parsed, where it is in the guide — at
    DEBUG level. With debug off, a client that is quietly busy and a client that is wedged look
    exactly the same in the log: `PVR Manager: Starting` and then silence. That is the position this
    box has been in all afternoon.
    """
    xbmc.executebuiltin("ToggleDebug")
    xbmcgui.Dialog().ok(T("IPTV Balkan — Kodi debug log"),
                        T("Kodijev debug log je prebacen (ukljucen ako je bio iskljucen).\n\n"
                          "Sada: restartuj Kodi, sacekaj dva minuta na TV sekciji, pa posalji "
                          "Kodijev log sa 'Posalji log na telefon' — tab Kodi.\n\n"
                          "Kad zavrsimo, pritisni ovo jos jednom da ga ugasis: debug log je velik "
                          "i usporava uredjaj."))


def fix_metadata(settings, name, is_series):
    """
    Correct one title's TMDB match by hand.

    Runs in the foreground and looks the correction up immediately: the point of typing it is to see
    whether it worked, and being told "it is queued" and asked to come back later is how a person gives
    up on a feature. One title is one or two requests — the reason the browse path may not do this is
    that it would be a hundred.
    """
    current = tmdb.alias_for(settings, name, is_series)
    typed = xbmcgui.Dialog().input(
        T("Tacan naziv za pretragu (TMDB)"), defaultt=(current[0] if current else name),
        type=xbmcgui.INPUT_ALPHANUM)
    if typed is None:
        return
    typed = typed.strip()

    if not typed:
        # An emptied field means "forget my correction", which is the only way back to the automatic
        # guess once one has been saved.
        tmdb.clear_alias(settings, name, is_series)
        xbmcgui.Dialog().notification("IPTV Balkan", T("Ispravka je uklonjena"),
                                      xbmcgui.NOTIFICATION_INFO, 4000)
        xbmc.executebuiltin("Container.Refresh")
        return

    if not tmdb.set_alias(settings, name, typed, is_series):
        xbmcgui.Dialog().ok("IPTV Balkan", T("Ispravka nije mogla da se sacuva."))
        return
    try:
        meta = tmdb.lookup(settings, name, is_series)
    except Exception as err:                                       # noqa: BLE001
        diag.log("TMDB: correction lookup failed — %s: %s" % (type(err).__name__, err), "ERROR")
        meta = None
    tmdb.store(settings, name, is_series, meta)

    if meta:
        xbmcgui.Dialog().notification("IPTV Balkan", T("Pronadjeno: %s") % (meta.get("matched") or typed),
                                      xbmcgui.NOTIFICATION_INFO, 5000)
    else:
        xbmcgui.Dialog().ok("IPTV Balkan", T("Ni pod tim nazivom nema nista na TMDB-u.\n\nProbaj "
                                          "original (engleski) naziv, ili dodaj godinu."))
    xbmc.executebuiltin("Container.Refresh")


def show_licence(settings):
    """
    The screen a customer is pointed at. Rechecks on open (force=True) so someone who has just been
    unlocked sees it immediately instead of waiting out the poll interval.

    The support group is offered from HERE because this is the screen someone opens when something is
    wrong — and it is the only screen whose number they already have in front of them, which is the
    first thing they will be asked for.
    """
    verdict = licence.check(settings, force=True)
    # Anything the panel has left for this box, shown right here. The forced check above has just
    # downloaded it; without this it would sit in the cache until the service's next pass, so the one
    # screen a customer is told to open would still not deliver the message waiting for them.
    support.show_pending(settings)
    text = licence.describe(verdict)
    text += "\n\n" + T(licence.SUPPORT_TEXT) + "\n" + licence.TELEGRAM_URL
    text += "\n\n" + tmdb.ATTRIBUTION
    xbmcgui.Dialog().textviewer(T("IPTV Balkan — licenca"), text)

    # A separate question rather than a button, because a textviewer has no buttons — and typing that
    # invite link on a remote is exactly the sort of thing this addon exists to avoid.
    if xbmcgui.Dialog().yesno(T("IPTV Balkan — podrska"),
                              T("Prikazati QR kod za Telegram grupu?\n\nSkeniraj ga telefonom da se "
                                "pridruzis grupi za podrsku i obavestenja."),
                              yeslabel=T("Prikazi QR"), nolabel=T("Ne treba")):
        qrscreen.show_static(
            settings, licence.TELEGRAM_URL,
            T("IPTV Balkan — Telegram grupa"),
            T("Skeniraj kod telefonom da se pridruzis grupi za podrsku."),
            T("Broj uredjaja: %s   ·   Back za izlaz") % (verdict.serial or T("jos nije dodeljen")),
            name="telegram")


def show_log(settings):
    text = diag.read_log() or T("Log je prazan.")
    # Tail, not head: what just failed is at the end, and a viewer opened on week-old lines is useless.
    xbmcgui.Dialog().textviewer(T("IPTV Balkan — log"), text[-60000:])


def _kodi_language_row_applies():
    """Serbian chosen here, something else drawn by Kodi."""
    from resources.lib import kodisettings
    return i18n.language() == i18n.SERBIAN and not kodisettings.kodi_is_serbian()


def _yettel_is_relevant(settings):
    """
    Whether a row about Yettel belongs on a menu this person is reading.

    Asked because it was asked of me: "why is Yettel in there?" — on a box configured with EON and
    Iris, and no Yettel anything. A provider-specific row for a provider you do not have is not a
    feature you have not discovered yet, it is a row you have to read past every time.

    The test is deliberately generous — enabled, or holding a token from a pairing that has happened —
    because the failure to avoid is hiding the row from somebody who IS a Yettel customer. And it
    hides only a SHORTCUT: Yettel is switched on and linked from the addon's settings, which is where
    every other provider is set up and where the same "link account" button also lives. The accounts
    menu carries a row that opens exactly that screen, so the path from a fresh install to a linked
    Yettel account never runs through here.
    """
    return bool(settings.get_bool("yettel_enabled", False)
                or settings.get("yettel_app_token_id", "")
                or settings.get("yettel_udid", ""))


def _menu_rows(settings, group):
    """
    The addon's own menu. Not the channel list — that is the PVR's job; these are the tools.

    It was a flat list of seventeen rows, in the order features had been written, and it read like it:
    "Video klub" three rows above "Roditeljski PIN za Video klub", the log split across four rows
    scattered between them, and pairing an account listed twice under two names in two places. On a
    phone that is a screen you scroll and re-read.

    So: three things a person opens the addon TO DO at the top — find something, browse the on-demand
    catalogue, force a refresh — and everything else behind three named groups, each of which answers
    one question. Accounts and devices are one group because they are one subject: the earlier menu
    had "Unesi nalog telefonom", "Nalozi na ovom uredjaju", "Povezi Yettel nalog", "Uredjaji na
    pretplati" and "Posalji nalog u aplikaciju" as five peers among twelve unrelated rows, and the
    question "is my account on this box" had no single place to go and ask.

    A submenu is a real directory, so Back returns from it — which on a touchscreen is the system's own
    gesture and costs nothing to learn.
    """
    if group == "accounts":
        rows = []
        # First, because on the device that is running Kodi it is the whole job in one tap, and it is
        # what was asked for: "when I am on the same phone I want to enter the account here rather
        # than photograph a QR". Offered only where it can work — see qrscreen.can_open_locally.
        if qrscreen.can_open_locally():
            rows.append((T("Unesi nalog ovde (otvara pregledac)"), "action=pair&here=1"))
        rows.append((T("Unesi nalog sa drugog telefona (QR)"), "action=pair&here=0"))
        rows.append((T("Nalozi na ovom uredjaju"), "action=accounts"))
        if _yettel_is_relevant(settings):
            rows.append((T("Povezi Yettel nalog (jednokratni kod)"), "action=yettelpair"))
        rows.append((T("Uredjaji na pretplati (slotovi)"), "action=devices"))
        # The other direction, and only when there is something to send. It is the expensive one to do
        # by hand — an account already typed correctly here, retyped into the app including a
        # 36-character device id — and its code has been in the tree, tested, with no way to reach it
        # since this menu was regrouped.
        if transfer.exportable(settings):
            rows.append((T("Posalji nalog u aplikaciju (QR)"), "action=exportaccount"))
        # Last, and always present: this is the screen where a provider is switched on in the first
        # place, which is the path a row hidden above must never be the only way to.
        rows.append((T("Podesavanja dodatka (provajderi, nalozi)"), "action=settings"))
        return rows

    if group == "setup":
        rows = [(T("Podesavanja dodatka (provajderi, nalozi)"), "action=settings"),
                (T("Roditeljski PIN za Video klub"), "action=parental"),
                (T("Dodaj Video klub na pocetni ekran"), "action=homeshortcut")]
        # Only when it can actually do something: this addon is showing Serbian and KODI is not. The
        # settings dialog is the one screen the addon cannot translate — Kodi draws it, in Kodi's
        # language — so the row exists to finish that job rather than to explain it in a help text.
        if _kodi_language_row_applies():
            rows.append((T("Prebaci i Kodi na srpski"), "action=kodilanguage"))
        return rows

    if group == "help":
        return [(T("Licenca / broj uredjaja"), "action=licence"),
                (T("Posalji poruku podrsci (sa logom)"), "action=support"),
                # Above diagnostics on purpose: it is the row somebody looks for BEFORE deciding to
                # trust the addon, not after something has gone wrong.
                (T("Privatnost — sta odlazi sa ovog uredjaja"), "action=privacy"),
                (T("Pokreni dijagnostiku"), "action=diagnostics"),
                (T("Pogledaj log"), "action=log"),
                (T("Posalji log na telefon (QR)"), "action=sendlog"),
                (T("Kodi debug log: ukljuci/iskljuci"), "action=kodidebug"),
                (T("Obrisi log"), "action=clearlog")]

    # The root. The Video klub had no row here at all for several releases — the whole on-demand half
    # of the addon, three providers deep, was reachable only by opening a series out of a search
    # result — which is why check-addon.py fails when a declared entry point has no row.
    # NOTHING IS CONFIGURED YET — and this is the screen every customer sees first.
    #
    # Watched on a wiped profile on 2026-08-04, which is as close to a new box as this gets. The menu
    # was the same six rows it always is: "Pretraga" at the top, "Video klub" under it, and both of
    # them lead straight to a dialog saying no provider answered, because there is no account yet. The
    # one row that helps was fourth. Somebody who has just paid for this spends their first minute
    # pressing the two things that cannot work.
    #
    # So on a box with no provider switched on, the menu says what to do and offers only what can be
    # done. It reverts to the full list the moment an account exists — this is not a mode, it is the
    # empty case of one.
    if not [p for p in all_providers(settings) if p.enabled()]:
        return [(T("Unesi nalog — pocni odavde"), "action=menu&group=accounts"),
                (T("Podesavanja"), "action=menu&group=setup"),
                (T("Pomoc, licenca i dijagnostika"), "action=menu&group=help")]

    rows = [(T("Pretraga (kanali, EPG, Video klub)"), "action=search"),
            (T("Video klub"), "action=vod")]
    # STRAIGHT ON THE ROOT, and only when there is something in it. It lived one level down, inside the
    # Video klub, so picking up last night's film was Video klub -> Nastavi gledanje -> the title: three
    # presses for the single most repeated action there is on a television. It is not moved out of the
    # Video klub — it is in both places, which costs a row on a screen only while it is useful.
    if resume.entries(settings):
        rows.append((T("Nastavi gledanje"), "action=vod&node=resume"))
    # Same rule: on the root only while there is something in it, so an unused feature never costs a
    # row on the screen everybody sees.
    if reminders.load(settings):
        rows.append((T("Podsetnici"), "action=reminders"))
    return rows + [
            (T("Osvezi kanale i vodic sada"), "action=refresh"),
            (T("Nalozi i uredjaji"), "action=menu&group=accounts"),
            (T("Podesavanja"), "action=menu&group=setup"),
            (T("Pomoc, licenca i dijagnostika"), "action=menu&group=help")]


#: action -> the icon beside it. Rendered from Material Symbols, the set the Android app draws its own
#: destinations with (`Icons.Filled.*` in AppDestinations.kt), so the two halves of the product look
#: like the same product. Regenerate with tools/makeicons.py; the files live in resources/media.
#:
#: Keyed on the ACTION rather than the label, because the label is translated and a Serbian sentence is
#: not a lookup key anybody should have to keep in step with English.
_ICONS = {
    "search": "search", "vod": "vod", "refresh": "refresh", "menu&group=accounts": "accounts",
    "menu&group=setup": "settings", "menu&group=help": "help",
    "pair&here=1": "browser", "pair&here=0": "qr", "pair": "qr",
    "accounts": "account", "devices": "devices", "yettelpair": "link",
    "exportaccount": "qr", "vod&node=resume": "vod",
    "settings": "settings", "parental": "lock", "homeshortcut": "home",
    "licence": "licence", "support": "support", "privacy": "privacy",
    "diagnostics": "diagnostics", "log": "log", "sendlog": "qr",
    "kodidebug": "debug", "clearlog": "delete", "kodilanguage": "language",
}


def _icon_for(query):
    """The art for a row, matched on the longest action key that fits its query."""
    action = query.split("action=", 1)[-1]
    for key in sorted(_ICONS, key=len, reverse=True):
        if action.startswith(key):
            return "%s/resources/media/%s.png" % (ADDON_PATH, _ICONS[key])
    return ""


def _root_menu(settings, group="", update=False):
    """
    Draw the menu, or the submenu named by [group].

    [update] is what keeps Back working like Back. Reported from a forum thread on 2026-08-01: "pamti se
    ceo history, treba 10 back da se izadje", and "vracanje u trenutni folder vraca uvek u pocetni,
    svaka akcija". Both are this function, and they are two separate mistakes:

      * every row that opens a DIALOG (licence, diagnostics, devices, the log…) was drawn with only its
        action in the address, so the redraw afterwards asked for group="" — the ROOT menu. Whichever
        submenu you were in, you came back to the top. The group now travels with the row.
      * that redraw ended the directory the ordinary way, and Kodi's own documentation for the flag is
        exact: updateListing=False means "add this folder to the history". So every dialog left a level
        behind it, and ten actions meant ten presses of Back to leave. The redraw after an action is an
        UPDATE of the listing that is already open, not a new place.
    """
    for label, query in _menu_rows(settings, group):
        item = xbmcgui.ListItem(label=label)
        item.setProperty("IsPlayable", "false")
        art = _icon_for(query)
        if art:
            # Both keys: Kodi's list views draw `icon`, and the poster/thumb views draw `thumb`. Setting
            # one leaves the other view with the default folder picture, which is what "the menus do not
            # look finished" was about.
            item.setArt({"icon": art, "thumb": art})
        # The row has to know which submenu it was drawn in, so the redraw after its dialog can come
        # back HERE. Rows that open a submenu carry their own group and are left alone.
        if group and "group=" not in query:
            query = "%s&group=%s" % (query, group)
        # Listed as folders even though most of them open no folder: a non-folder entry makes Kodi try
        # to PLAY it, and those open a dialog instead — which Kodi then reports as a failed playback
        # over the top of the screen the user is reading.
        xbmcplugin.addDirectoryItem(HANDLE, "%s?%s" % (sys.argv[0], query), item, True)
    xbmcplugin.endOfDirectory(HANDLE, updateListing=update)


def main():
    settings = Settings()
    # Before anything can print. The plugin is a fresh process per action, so this runs on every menu
    # click — which is also what makes the setting take effect immediately instead of after a restart.
    i18n.configure(settings)
    args = dict(parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    action = args.get("action", "root")

    if action == "play":
        play(settings, args.get("provider", ""), args.get("id", ""), args.get("utc"),
             vod=bool(args.get("vod")), account=args.get("account", ""),
             name=args.get("name", ""), art=args.get("art", ""))
    elif action == "search":
        search_screen(settings, args.get("term", ""))
    elif action == "tune":
        tune(settings, args.get("name", ""), args.get("url", ""), args.get("provider", ""))
    elif action == "showinfo":
        xbmcgui.Dialog().ok(args.get("name", "IPTV Balkan"), args.get("desc", "") or T("Nema opisa."))
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
    elif action == "fixmeta":
        fix_metadata(settings, args.get("name", ""), bool(args.get("series")))
    elif action == "vod":
        video_club(settings, args.get("provider", ""), args.get("node", ""),
                   args.get("account", ""), args.get("cat", ""))
    elif action == "menu":
        _root_menu(settings, args.get("group", ""))
    # `kodilanguage` was missing here while the branch that handles it existed further down and the menu
    # row pointed at it — so the row drew, clicked, and reached nothing. An outer allowlist and an inner
    # branch list are two places to remember one action; check-addon.py verifies a declared entry point
    # HAS a menu row, and this is the mirror of that, which nothing checked.
    elif action in ("pair", "sendlog", "diagnostics", "refresh", "licence", "log", "clearlog",
                    "kodidebug", "kodilanguage", "yettelpair", "accounts", "devices", "support",
                    "privacy", "forget", "parental", "settings", "homeshortcut", "exportaccount",
                    "reminders", "remind"):
        if action == "homeshortcut":
            # force=True: this row IS someone asking for it now, so it must work even after the one
            # automatic attempt has been made — and after they deleted it and changed their mind.
            from resources.lib import homescreen
            ok = homescreen.add(force=True)
            xbmcgui.Dialog().ok(
                T("Video klub"),
                T("Dodato u Favorite. Da bi stajalo na pocetnom ekranu: Podesavanja -> Interfejs -> "
                  "Skin -> Podesi skin -> Stavke glavnog menija.") if ok else
                T("Nije uspelo. Video klub mozes dodati i rucno: desni klik na njega -> Dodaj u "
                  "favorite."),
            )
        elif action == "settings":
            # Kodi's own settings dialog for this addon. A row rather than a note telling people to
            # long-press: on a touchscreen the context menu is a gesture nobody has been taught, and
            # this is the screen where a provider is switched on in the first place.
            xbmc.executebuiltin("Addon.OpenSettings(%s)" % ADDON_ID)
        elif action == "pair":
            if confirmed(args, T("Sparivanje telefonom"), T("Otvoriti ekran za unos naloga?")):
                # No `here` in the query means "ask" — which is what the settings button and any old
                # bookmark send. The menu rows answer it, because there the user has just chosen.
                pair_with_phone(settings, {"1": True, "0": False}.get(args.get("here")))
        elif action == "devices":
            devicescreen.show(settings)
        elif action == "privacy":
            privacy.show(settings)
        elif action == "support":
            support.screen(settings)
        elif action == "sendlog":
            send_log(settings)
        elif action == "kodidebug":
            toggle_kodi_debug()
        elif action == "yettelpair":
            if confirmed(args, "Yettel", T("Poceti povezivanje Yettel naloga?")):
                link_yettel(settings)
        elif action == "accounts":
            manage_accounts(settings)
        elif action == "exportaccount":
            qrscreen.export_account(settings)
        elif action == "reminders":
            reminder_screen(settings)
        elif action == "remind":
            ok, message = reminders.add(settings, args.get("channel", ""), args.get("name", ""),
                                        args.get("title", ""), args.get("start", "0"))
            # [message] arrives translated — reminders.add composes it, and it is the one place that
            # knows which of the four refusals happened.
            xbmcgui.Dialog().notification(
                T("Podsetnici"), message,
                xbmcgui.NOTIFICATION_INFO if ok else xbmcgui.NOTIFICATION_WARNING, 4000)
        elif action == "forget":
            resume.forget(settings, args.get("key", ""))
            xbmc.executebuiltin("Container.Refresh")
        elif action == "diagnostics":
            diagnostics(settings)
        elif action == "refresh":
            refresh_now(settings)
        elif action == "licence":
            show_licence(settings)
        elif action == "parental":
            parental_screen(settings)
        elif action == "kodilanguage":
            switch_kodi_to_serbian()
        elif action == "log":
            show_log(settings)
        else:
            diag.clear_log()
            xbmcgui.Dialog().notification("IPTV Balkan", T("Log je obrisan"),
                                          xbmcgui.NOTIFICATION_INFO, 3000)
        # Every one of these opens a dialog and then has nothing to show. The menu is rendered AGAIN
        # rather than reporting failure: `succeeded=False` does leave the user where they were, but
        # Kodi writes "GetDirectory ... failed" into its log for it, and a log full of errors from
        # normal use is a log nobody can read a real error out of — which is exactly what cost this
        # afternoon. Listing the same menu costs nothing and Kodi is satisfied. Skipped when there is
        # no handle, i.e. when the settings button invoked us through RunPlugin.
        if HANDLE >= 0:
            _root_menu(settings, args.get("group", ""), update=True)
    else:
        _root_menu(settings)


def _crashed(error):
    """
    The last line of defence: an unhandled exception, made readable and reportable.

    Kodi's own answer to one is a notification saying "Script failed", which tells the person nothing,
    tells us nothing, and is the single most common thing a support message contains. So: the traceback
    goes to our log where it can be read, and the screen gets the name of the error, the device number
    the reply will be matched against, and one button that sends both.

    Written to be unable to fail twice. Everything it touches is in a try of its own, because a crash
    handler that crashes replaces a bad message with no message.
    """
    import traceback
    detail = "%s: %s" % (type(error).__name__, error)
    try:
        diag.log("UNHANDLED: %s\n%s" % (detail, traceback.format_exc()), "ERROR")
    except Exception:                                              # noqa: BLE001
        pass

    serial = ""
    try:
        settings = Settings()
        i18n.configure(settings)
        serial = licence.check(settings).serial or ""
    except Exception:                                              # noqa: BLE001
        settings = None

    try:
        text = T("Nesto je puklo u dodatku i radnja nije zavrsena.\n\n%s") % detail
        if serial:
            text += "\n\n" + T("Broj uredjaja: %s") % serial
        if settings is not None and xbmcgui.Dialog().yesno(
                T("IPTV Balkan — greska"), text + "\n\n" + T("Poslati log podrsci?"),
                nolabel=T("Ne treba"), yeslabel=T("Posalji")):
            support.send(settings, "SAM SE JAVIO: %s" % detail, include_log=True)
            xbmcgui.Dialog().notification("IPTV Balkan", T("Poruka je poslata."),
                                          xbmcgui.NOTIFICATION_INFO, 4000)
        elif settings is None:
            xbmcgui.Dialog().ok(T("IPTV Balkan — greska"), text)
    except Exception:                                              # noqa: BLE001
        pass

    # Kodi still has to be told the directory is finished, or the spinner stays on the screen for ever.
    try:
        if HANDLE >= 0:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
    except Exception:                                              # noqa: BLE001
        pass


if __name__ == "__main__":
    try:
        main()
    except Exception as err:                                       # noqa: BLE001
        _crashed(err)
