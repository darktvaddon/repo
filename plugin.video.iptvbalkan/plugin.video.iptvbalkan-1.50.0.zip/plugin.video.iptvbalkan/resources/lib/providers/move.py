# -*- coding: utf-8 -*-
"""
Move TV (MTS-SI) — ported from `MoveApi.kt`, which is verified against a live account (301 channels,
playback working).

This file was rewritten rather than patched. The first version was built from guesswork rather than
from the working client, and every layer of it was wrong: a different host (`api.mts-si.tv` instead of
`api2.mts-si.tv/api/v2`), GET instead of POST, a Bearer header instead of `X-Auth-Token`, and field
names — `id`, `name`, `channelNumber`, `logoUrl`, `categoryName` — that this API does not serve. It
could never have worked, and it was carried for weeks as "written but unproven", which is the polite
form of "not written".

Three things about this provider that are not guessable and are the reason to port rather than invent:

**A channel has TWO ids.** `contentId` keys the guide; `liveId` mints the stream. They are different
numbers for the same channel and swapping them fails in different ways at different times.

**The stream token is a HEADER.** `/content/live/source/get` returns a plain DASH manifest plus
`protection.headerValue`, and that value has to ride as `X-Play-Auth` on the manifest AND on every
media segment — which is what the resolved stream's headers are for.

**A 200 is not success.** Every response carries `{"success": bool}`, and a 200 with `success:false` is
a real failure with a real message in it. Reading only the status code loses the reason.

**Catch-up works as of 2026-08-03.** It was withheld for a long time and the reason is worth keeping:
the provider reports a real archive window per channel (168h is typical) but the per-programme source
call had never been captured, so advertising an archive that could not be minted would have put a
Replay button on every programme that then silently played live. The call was finally caught from a
live session at play.move.tv — `/content/epg/source/get`, taking `epgId` + `contentId` — and the
window that was being read and discarded all along now becomes `catchup_days`.

A replay resolves to `index-<start>-<duration>.mpd`: ONE STATIC manifest holding exactly that
programme. Hence `catchup_mode: "vod"` and `catchup_play_as_live: False` — the addon is entered once
per replay and the player seeks inside the media, so Kodi must draw the bar from the manifest rather
than from its live model. That costs the PVR overlay, the same trade Iris makes; EON escapes it only
because its archive is HLS with a sliding window that ffmpegdirect can run as a timeshift. It is not
about DRM — Move's catch-up has none.
"""

import calendar
import hashlib
import json
import os
import re
import time
import uuid

from .. import diag, net, store
from ..i18n import T
from ..provider import Provider, ProviderError, register

BASE = "https://api2.mts-si.tv/api/v2"
WEB_ORIGIN = "https://play.move.tv"
#: Relative image paths (`/images/logo/rts-1_2_dark.png`) hang off this host.
IMAGE_BASE = "https://edge-mts-si-2.mts-si.tv"

#: Fixed client identity, exactly as the real web client sends it.
PARTNER_ID = 2
DEVICE_MODEL_ID = 10
DEVICE_NAME = "Chrome 150"
APP_VERSION = "3.4.8"
#: 1 = Serbian. Move TV is a Serbian service; no other locale is worth exposing.
LANG = 1
#: `dtype` in the live-source request. 1 = DASH, which is what the web client asks for.
DTYPE_DASH = 1

#: contentTypeId / contentSubTypeId — the same two values under two names (from vod/filters).
TYPE_FILM = 2
TYPE_SERIES = 5
#: Pages pulled per SCREEN of a catalogue — a batch, not a ceiling. Move pages the Video klub and there
#: are 36 catalogues; walking every one of them to its end would take longer than the whole rest of a
#: refresh. Whatever follows is OFFERED as a "Next page" row rather than dropped, which is what this
#: number used to mean and what made a big catalogue look like a small one.
VOD_MAX_PAGES = 3

#: The API wants the literal string "null" for an unauthenticated request — an ABSENT header is a
#: different thing to this server, and the login call is the one that depends on it.
UNAUTHENTICATED = "null"

#: Where a channel with no genre is filed. Deliberately NOT run through T(): this is a channel GROUP
#: name, and it goes into the playlist, IPTV Simple's database and Kodi's own PVR tables. A group whose
#: name followed the interface language would become a SECOND group the moment someone switched
#: language, splitting one row of channels into two. The Video klub's own "Ostalo" is a screen label and
#: is translated — same word, different job.
GROUP_OTHER = "Ostalo"

#: What a Move client id looks like — a uuid, optionally with the server-appended ".<partnerId>".
_UID_SHAPE = re.compile(r"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}(\.\d+)?$")

PLAY_AUTH_HEADER = "X-Play-Auth"
#: The token carries its own expiry: `hash-…-expires-1784821848-cusid-…`.
_PLAY_AUTH_EXPIRY = re.compile(r"expires-(\d+)")

#: Channel-list rows are the only place liveId is served, and the play route needs it at tune time.
#: Cached beside the playlist rather than refetched, the same way EON caches its play descriptors.
PLAY_CACHE = "move_play.json"
#: The logged-in session, kept between PROCESSES. The plugin runs for exactly one action — one tune,
#: one Video klub screen — so a token held only in memory is a token thrown away at the moment it
#: becomes useful, and every screen paid for another sign-in. See _load_session.
SESSION_CACHE = "move_session.json"
#: Move's own answer carries the lifetime it means: `"t": 32400`, nine hours. Six is used instead —
#: comfortably inside it, and it means a session that goes stale early costs one re-login rather than
#: a screen of refusals. Same number Iris uses, for the same reason.
SESSION_MAX_AGE = 6 * 3600


@register
class MoveProvider(Provider):

    key = "move"
    label = "Move TV"
    #: THE VIDEO KLUB WAS BUILT AND THEN COULD NOT BE PLAYED, because this line was missing.
    #:
    #: default.py gates the on-demand call on it — `if vod and provider.supports_vod` — so without it
    #: every press on a film or an episode fell through to the LIVE branch: resolve() looked the title
    #: up as a channel, missed, re-fetched all 302 channels to be sure, missed again, and the viewer got
    #: "taj kanal nije u listi" on a film. The catalogue screens all worked, which is what made it look
    #: like a playback problem rather than a missing flag. Seen on the owner's box on 2026-08-04 at
    #: 07:48:57 and 07:49:08 — twice, ten seconds apart, and both times the log shows /content/live/all
    #: for something that was never a channel. test-tune.py now refuses a provider that offers a Video
    #: klub without declaring it.
    supports_vod = True
    default_identity = {
        "user_agent": ("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
                       "(KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36"),
        "origin": WEB_ORIGIN,
        "referer": WEB_ORIGIN + "/",
        "extra_headers": {"Accept": "*/*"},
    }

    def __init__(self, settings):
        Provider.__init__(self, settings)
        self.session = net.Session(self.identity(), trace=settings.verbose())
        self.token = ""
        self.customer = 0
        self.profile = 0
        #: True when this session came off the disk rather than from a fresh sign-in. A refusal on a
        #: restored session is worth one silent re-login; the same refusal on a fresh one is real.
        self.session_restored = False
        #: True while the login chain runs, so the retry in _post cannot fire from inside it.
        self._logging_in = False
        #: The guide window this server was measured to accept, in hours — see _epg_span. Held for the
        #: life of the process, which is the life of one refresh.
        self._epg_span_h = 0

    # ---- server-steerable constants ----------------------------------------
    #
    # The values that decide whether this backend answers at all. Shipped as the constants at the top of
    # this file and used exactly as before until the panel carries a replacement — see `Provider.tuned`.
    # `appVersion` rides on TEN calls here (login, channels, guide, both play routes, the whole Video
    # klub): it is the single most likely value to be rejected one morning, and steering it turns that
    # morning into a field in the panel instead of a rebuild, a publish and a six-hour wait.

    def host(self):
        return self.tuned("move_base", BASE).rstrip("/")

    def app_version(self):
        return self.tuned("move_app_version", APP_VERSION)

    # ---- transport --------------------------------------------------------

    def _post(self, path, body, authenticated=True, _retried=False):
        """
        Every call to Move goes through here, and so does the one recovery it needs.

        A session is now read off disk (see _load_session), which is what makes this necessary: before
        that, every process signed in first and a token could not be stale. A restored one can be — the
        account was used elsewhere, the server dropped it, six hours passed on their clock and not on
        ours — and the refusal arrives at whatever the viewer just pressed.
        `
        So: one silent re-login and one repeat, HERE rather than in the callers. Iris shipped this retry
        inside resolve() alone and the guide kept failing; Yettel shipped _ensure in some entry points
        and not others. One funnel, one place to be wrong.

        Guarded three ways so it cannot become a login loop: only for a session that was RESTORED (a
        refusal on a freshly-minted token is real and must be shown), only once per call, and never
        while the login chain itself is running.
        """
        def _refused(err):
            if not authenticated or _retried or self._logging_in or not self.session_restored:
                return False
            return _is_auth_failure(err)

        try:
            data = self.session.post(
                self.host() + path, body=json.dumps(body),
                headers={"Content-Type": "application/json",
                         "X-Auth-Token": self.token if (authenticated and self.token) else UNAUTHENTICATED})
        except net.HttpError as err:
            if not _refused(err):
                raise
            diag.log("Move TV: the stored session was refused (%s) — signing in again" % err)
            self.forget_session()
            self.login()
            return self._post(path, body, authenticated, _retried=True)

        try:
            return self._ok(data, path)
        except ProviderError as err:
            # This API also refuses inside a 200 body — see _ok and _is_auth_failure.
            if not _refused(err):
                raise
            diag.log("Move TV: the stored session was refused (%s) — signing in again" % err.message)
            self.forget_session()
            self.login()
            return self._post(path, body, authenticated, _retried=True)

    @staticmethod
    def _ok(data, what):
        """`success:false` inside a 200 is this API's normal way of refusing, and it says why."""
        if not isinstance(data, dict):
            raise ProviderError("Move TV %s: odgovor nije JSON." % what)
        if not data.get("success"):
            raise ProviderError("Move TV %s: %s" % (what, data.get("message") or "success=false"))
        return data

    # ---- auth -------------------------------------------------------------

    def _uid(self):
        """
        A stable per-install client id.

        Minted once and written back, because the account treats a new uid as a NEW DEVICE — a fresh one
        per launch quietly fills the account's device list, which is the same trap EON's device number
        and Yettel's udid exist to avoid.
        """
        uid = self.setting("device_id").strip()
        if not uid:
            uid = str(uuid.uuid4())
            self.remember("device_id", uid)
            diag.log("Move TV: minted a device id for this install (%s…)" % uid[:8])
            return uid
        # A Move uid is a UUID, optionally with a ".<partnerId>" suffix the server appends on
        # registration (e.g. "65ed1b51-…-50cc208fd1b3.2"). It is NOT the numeric device id shown
        # beside it — and that is the mistake this catches, because it does not fail: the server
        # happily accepts any string and registers it as a BRAND NEW DEVICE, silently taking a slot.
        # Seen exactly once, with "6612929" typed in where the uuid belonged.
        if not _UID_SHAPE.match(uid):
            diag.log("Move TV: device id %r does not look like a uuid — if you meant to reuse an "
                     "existing device, this is the wrong value and the account will register a NEW "
                     "one instead of sharing that slot" % uid, "ERROR")
        return uid

    def login(self):
        username = self.setting("username")
        password = self.setting("password")
        if not username or not password:
            raise ProviderError("Move TV: korisničko ime i lozinka nisu uneti.")
        self._logging_in = True
        try:
            self._login_chain(username, password)
        except net.HttpError as err:
            # THE REFUSAL THIS API MAKES THAT IS NOT A 200. `_ok` decodes `success:false` inside a 200,
            # and that covers almost everything — but a refused SIGN-IN comes back as an HTTP error with
            # the same body, and nothing here read it. So the one answer a customer can act on arrived
            # as `HttpError: HTTP 406`, which is exactly what a diagnostics screen showed on 2026-08-01
            # with nobody able to say what it meant. Measured on a real account on 2026-08-09:
            #
            #     HTTP 406  {"success":false,"message":"No slots available","appCode":"403007"}
            #
            # The body says it plainly. Reading it costs nothing and turns a dead end into an errand.
            raise _sign_in_refusal(err)
        finally:
            self._logging_in = False

    def _login_chain(self, username, password):
        # A DROPPED CONNECTION HERE USED TO REACH KODI AS A TRACEBACK. `_post` re-raises net.HttpError
        # for anything that is not a session refusal, and nothing above this converted it — so
        # "RemoteDisconnected: Remote end closed connection without response" during sign-in became
        # "Script failed" over the Video klub (owner's box, 06:53:23 on 2026-08-04). The one thing a
        # user can do about it is check their connection, so that is what it now says.
        data = self._post("/login", {
            "username": username, "password": password,
            "partnerId": PARTNER_ID, "deviceName": DEVICE_NAME,
            "deviceModelId": DEVICE_MODEL_ID, "uid": self._uid(), "appVersion": self.app_version(),
        }, authenticated=False)

        self.token = str(data.get("auth_token") or "")
        self.customer = int(data.get("customer_id") or 0)
        # NOT the same number as customer_id, and every catalogue, guide and stream call needs it.
        self.profile = int(((data.get("profile") or {}).get("id")) or 0)
        if not self.token or not self.profile:
            raise ProviderError("Move TV: prijava je prošla ali nije vratila sesiju.")
        # A token this process minted itself. The retry in _post is only for a RESTORED one:
        # if the server refuses a token it handed over seconds ago, that is an answer, not a
        # stale session, and repeating the sign-in would only ask the account twice.
        self.session_restored = False
        diag.log("Move TV: logged in (customer %s, profile %s)" % (self.customer, self.profile))
        self._store_session()

    # ---- the session, kept between processes -------------------------------
    #
    # WHY THIS EXISTS, measured rather than assumed. The owner's log from 2026-08-04 shows four sign-ins
    # inside three minutes — 06:49:14, 06:51:03, 06:52:40, 06:52:45 — one for every screen he opened,
    # because `self.token` lived only in this process and the plugin process dies with the action. Iris
    # and Yettel have kept their sessions on disk for exactly this reason and say "reusing the stored
    # session" in that same log; Move was the one provider still paying the round trip every time. One
    # of those four cost 1418 ms, and that is time in front of a viewer waiting for a picture.
    #
    # It also stops filling the account's device list, which is the trap `_uid` was written to avoid:
    # every sign-in registers a device, and the numeric device id in the answer is the slot it took.

    def _session_path(self):
        # _cache_path, not cache_path: move.py routes every cache file through that one seam (see
        # its definition below), which is also what the tests point somewhere private.
        return self._cache_path(SESSION_CACHE)

    def _account_fingerprint(self):
        """Username only — the password is not needed to tell one subscription from another, and this
        value is written to disk."""
        return hashlib.sha256((self.setting("username") or "").encode("utf-8")).hexdigest()[:16]

    def _load_session(self):
        """Restore a stored session, or answer False. Makes NO network call: whether the session still
        works is what the very next call proves, and probing it would spend the round trip this is here
        to save."""
        data = _read_json(self._session_path())
        if not isinstance(data, dict) or time.time() >= (data.get("expires_at") or 0):
            return False
        # Bound to the account it was minted for: changing the username in settings must not keep
        # playing the previous subscription.
        if data.get("account") != self._account_fingerprint():
            return False
        if not data.get("token") or not data.get("profile") or not data.get("customer"):
            return False
        self.token = str(data["token"])
        self.customer = int(data["customer"])
        self.profile = int(data["profile"])
        self.session_restored = True
        diag.log("Move TV: reusing the stored session (customer %s, profile %s)"
                 % (self.customer, self.profile))
        return True

    def _store_session(self):
        _write_json(self._session_path(), {
            "account": self._account_fingerprint(),
            "expires_at": time.time() + SESSION_MAX_AGE,
            "customer": self.customer,
            "profile": self.profile,
            "token": self.token,
        })

    def forget_session(self):
        """Throw the stored session away. Called when the server refuses one — a stored token that is no
        longer accepted is worse than none, because it is tried first on every process that follows."""
        self.token, self.customer, self.profile = "", 0, 0
        self.session_restored = False
        try:
            os.remove(self._session_path())
        except OSError:
            pass

    def _ensure(self):
        if self.token:
            return
        if self._load_session():
            return
        self.login()

    # ---- catalogue --------------------------------------------------------

    def channels(self):
        self._ensure()
        data = self._post("/content/live/all", {
            "customerId": self.customer, "customerProfileId": self.profile,
            "lang": LANG, "appVersion": self.app_version(),
        })
        rows = data.get("content") or []
        out, skipped, play_cache = [], 0, {}
        for item in rows:
            if not (item or {}).get("subscribed"):
                # Listing channels the account cannot play only produces rows that refuse to open. The
                # count is logged so "channels are missing" has an answer without a support round-trip.
                skipped += 1
                continue
            entry = self._channel_from(item, len(out) + 1, play_cache)
            if entry:
                out.append(entry)
        if not out:
            raise ProviderError("Move TV: nijedan kanal nije u pretplati (od %d ponuđenih)." % len(rows))
        _write_json(self._cache_path(PLAY_CACHE), play_cache)
        diag.log("Move TV: %d channels (%d not subscribed, skipped)" % (len(out), skipped))
        return out

    def _channel_from(self, item, fallback_number, play_cache):
        content_id = str(item.get("contentId") or "")
        live_id = str(item.get("liveId") or "")
        name = item.get("contentName") or ""
        if not content_id or not live_id or not name:
            return None

        catchup_hours = int((item.get("catchup") or {}).get("duration")
                            or item.get("contentLiveCatchupDuration") or 0)
        categories = item.get("categories") or []
        genre = str((categories[0] or {}).get("name") or "") if categories else ""
        # The GROUP still says Radio for an audio-only station whatever the setting says — that is a
        # label on a television and costs nothing. Only the `radio` FLAG, which decides which of Kodi's
        # two players opens the stream, follows the owner's setting. See Provider.radio_flag.
        audio_only = bool(item.get("audioOnly"))
        radio = self.radio_flag(audio_only)
        play_cache[content_id] = {"live_id": live_id, "catchup_hours": catchup_hours}
        return {
            "id": self.scoped("move_%s" % content_id),
            "tvg_id": self.scoped("move_%s" % content_id),
            # The GUIDE's key, not the stream's — see the module docstring on the two ids.
            "provider_ref": content_id,
            "name": name,
            "number": int(item.get("contentPosition") or fallback_number),
            "group": "Radio" if audio_only else (genre or GROUP_OTHER),
            "radio": radio,
            "logo": _image_url((item.get("picture") or {}).get("icon")),
            "url": ("plugin://plugin.video.iptvbalkan/?action=play&provider=move&id=%s%s"
                    % (content_id, self._account_param())),
            # The provider's OWN window, per channel — 168h is typical, but a channel that reports none
            # gets no Replay button rather than one that fails when pressed.
            #
            # This was hardcoded 0 until 2026-08-03. The window was never the blocker; the per-programme
            # source call was, and it had never appeared in any capture. It was finally caught live at
            # play.move.tv (`/content/epg/source/get`) and `resolve()` mints from it now.
            "catchup_days": max(1, catchup_hours // 24) if catchup_hours else 0,
            # VOD mode, and NOT played as live — the same pair Iris uses, for the same reason. A Move
            # replay resolves to `index-<start>-<duration>.mpd`, a STATIC manifest holding exactly one
            # programme, so the addon is entered once per replay and the player seeks inside the media.
            # Kodi must therefore draw the bar from the manifest, not from its live model.
            #
            # NOTE, because the opposite was briefly believed: this has nothing to do with DRM. EON keeps
            # the PVR overlay because its archive is HLS with a sliding window, which ffmpegdirect can
            # run as a timeshift; Move's static DASH goes to inputstream.adaptive exactly like Iris and
            # inherits the same either/or. See section 10 of IRIS-EON-INTEGRATION.md.
            "catchup_mode": "vod",
            "catchup_play_as_live": False,
            "catchup_source": ("plugin://plugin.video.iptvbalkan/?action=play&provider=move&id=%s%s&utc={utc}"
                               % (content_id, self._account_param())),
            "provider_label": self.label,
        }

    def epg(self, channels, hours_back=24, hours_forward=48):
        """
        One request per channel — and unlike EON's, this one really cannot be batched.

        TESTED ON THE LIVE ACCOUNT, 2026-08-04, because the same assumption about EON turned out to be
        wrong and was worth 444 s -> 75 s there. `/content/epg/all` was asked for five channels at once
        in all three shapes the API could plausibly take:

            contentId as a JSON list   -> 404
            contentId as "a,b,c"       -> 404
            contentIds as a JSON list  -> 404

        A 404 from a path that answers fine for one id is the endpoint saying "no such content", not
        "malformed request" — it takes exactly one contentId. So this stays one request per channel and
        is budgeted like EON's used to be, rather than run to completion.
        """
        self._ensure()
        budget_until = time.time() + self.settings.get_int("move_epg_budget_sec", 180)
        if not channels:
            return []
        # THE WINDOW THE SERVER WILL ACTUALLY ACCEPT, measured before 301 channels are asked with one
        # it will not. A customer's box (1.40.1, 2026-08-06) asked for the configured week — 168 hours
        # back, 72 forward — and every single channel came back
        # `400 … backwards/forwards is out of limit`: 301 channels, 0 programmes, on every refresh,
        # while live playback worked perfectly. Nothing in the capture says where the ceiling is, so it
        # is found by stepping down from what the settings want, once per refresh, and the span is then
        # covered in slices.
        span = self._epg_span(channels[0]["provider_ref"], hours_back, hours_forward)
        if not span:
            diag.log("Move TV: the guide endpoint refused every window size — no programmes this "
                     "refresh", "ERROR")
            return []
        windows = _epg_windows(hours_back, hours_forward, span)
        if len(windows) > 1:
            diag.log("Move TV: the guide server accepts %dh at a time, so %dh back / %dh forward "
                     "takes %d passes — nearest first, so a budget that runs out costs the far end"
                     % (span, hours_back, hours_forward, len(windows)))
        out, done, failed, first_error = [], 0, 0, ""
        #: (channel, start) of everything already collected. Consecutive windows overlap by an hour at
        #: the seam on purpose (see _epg_windows), and a programme delivered twice would otherwise be
        #: written to the XMLTV twice and shown twice.
        seen = set()
        # A refusal that will refuse the next channel too, stopped after three rather than three hundred.
        #
        # The customer's log is the argument: 300 channels, every one answering 401, and the addon asked
        # all 300 anyway — a minute of requests against a real subscription to produce an empty guide,
        # and 65 identical ERROR lines for whoever reads the log afterwards. The EON guide learned this
        # the same way a day earlier. A per-channel failure (one bad id, one odd programme) still just
        # counts and carries on; it is the CONSECUTIVE run that means "asking again cannot help".
        consecutive, renewed = 0, False
        # WINDOWS OUTSIDE, CHANNELS INSIDE, and that nesting is the whole design. The other way round —
        # every window of channel 1, then every window of channel 2 — spends the budget on giving the
        # first fifty channels a full week while the other 250 get nothing at all. This way the first
        # pass gives EVERY channel what is on now, and each further pass widens the whole guide.
        stopped = False
        for pass_no, (offset, back, fwd) in enumerate(windows):
            if stopped:
                break
            first_pass = pass_no == 0
            for ch in channels:
                if time.time() > budget_until:
                    diag.log("Move TV: guide budget spent after %d/%d channels on pass %d/%d — the "
                             "rest follows next refresh"
                             % (done, len(channels), pass_no + 1, len(windows)))
                    stopped = True
                    break
                # See Provider.stopping.
                if self.stopping():
                    diag.log("Move TV: Kodi is closing — the guide stops after %d/%d channels"
                             % (done, len(channels)))
                    stopped = True
                    break
                try:
                    _merge(out, seen, self._epg_for(ch["provider_ref"], back, fwd, offset))
                    if first_pass:
                        done += 1
                    consecutive = 0
                except (ProviderError, net.HttpError) as err:
                    # Counted, not swallowed: a guide that came back empty because every channel failed
                    # must not look the same as a provider that simply has no programmes. Only the first
                    # pass counts towards "had no guide" — a channel that answered for tonight and then
                    # refused for next Tuesday is not a channel without a guide.
                    if first_pass:
                        failed += 1
                    consecutive += 1
                    first_error = first_error or str(err)
                    # A cached session outlives its token (Move's own answer says `t: 32400`, nine
                    # hours), and the guide is the first thing a scheduled refresh asks for — so the
                    # first refusal buys ONE fresh login and one more try. Once only: a login per failed
                    # channel would be three hundred sign-ins on an account that counts them.
                    if not renewed and _is_auth_failure(err):
                        renewed = True
                        consecutive = 0
                        diag.log("Move TV: the guide was refused (%s) — logging in again and retrying "
                                 "once" % str(err)[:90])
                        try:
                            self.token = ""
                            self.login()
                        except ProviderError as login_error:
                            diag.log("Move TV: the retry login failed too — %s" % login_error, "ERROR")
                            stopped = True
                            break
                        # THE SAME CHANNEL, not the next one. `continue` here went straight on to the
                        # following channel, so the one whose refusal paid for the fresh login was the
                        # single channel that never got to use it — it stayed without a guide until the
                        # next refresh, while the comment above promised "one more try". Asked again
                        # here, and the failure counted a moment ago is taken back, because it did not
                        # turn out to be one.
                        try:
                            programmes = self._epg_for(ch["provider_ref"], back, fwd, offset)
                        except (ProviderError, net.HttpError) as retry_error:
                            diag.log("Move TV: the channel failed again after the fresh login (%s)"
                                     % str(retry_error)[:90])
                            continue
                        if first_pass:
                            failed -= 1
                            done += 1
                        _merge(out, seen, programmes)
                        continue
                    if consecutive >= 3:
                        diag.log("Move TV: three channels in a row were refused — the guide stops here "
                                 "rather than asking %d more times. Last answer: %s"
                                 % (max(0, len(channels) - done - failed), str(err)[:120]), "ERROR")
                        stopped = True
                        break
        if failed:
            diag.log("Move TV: %d of %d channels had no guide (first: %s)"
                     % (failed, len(channels), first_error), "ERROR")
        diag.log("Move TV: %d programmes over %d channels" % (len(out), done))
        return out

    def _epg_span(self, content_id, hours_back, hours_forward):
        """
        The widest `backwards`/`forwards` this account's server accepts, in hours — measured, once.

        Stepped DOWN from what the guide settings actually want, so a box configured for one day never
        pays for probing a week. Each step is a real request whose answer is thrown away; that is at
        most a handful of calls against the 301 this method saves from being wasted, and the result is
        remembered for the rest of the process (a refresh is one process).

        Returns 0 when every step was refused — the caller then writes no guide rather than hammering
        the endpoint, because something else is wrong and asking 300 times will not find out what.
        """
        if self._epg_span_h:
            return self._epg_span_h
        hours_back, hours_forward = max(0, int(hours_back)), max(0, int(hours_forward))
        want = max(1, max(hours_back, hours_forward))
        # THE FIRST ATTEMPT IS EXACTLY WHAT WAS ASKED FOR, and that ordering is what keeps this free
        # for everybody it does not concern. The owner's own box asks 48 back / 72 forward and the
        # server has always accepted it — 36,542 programmes over 302 channels. Probing that account
        # with a square 48/48 window would "succeed", conclude the ceiling is 48, and then fetch the
        # forward half in a SECOND pass over 302 channels: 94 seconds turned into three minutes to
        # solve a problem that box does not have. Ask for the real window first; step down only when
        # the server says no.
        attempts = [(hours_back, hours_forward)]
        attempts += [(min(hours_back, s), min(hours_forward, s)) for s in EPG_WINDOW_STEPS if s < want]
        for back, fwd in attempts:
            try:
                self._epg_for(content_id, back, fwd)
            except (ProviderError, net.HttpError) as err:
                if _is_window_refusal(err):
                    diag.log("Move TV: the guide server refused %dh back / %dh forward — asking for "
                             "less" % (back, fwd))
                    continue
                # Anything else — an expired session, a socket that went away — is NOT this method's
                # business. Hand back the widest window and let the guide loop meet the same failure
                # with the login retry and the stop-after-three it already has. Probing must never be
                # the thing that turns a recoverable refusal into an empty guide.
                return want
            # What was accepted, not what was hoped for. `_epg_windows` uses this as the ceiling for
            # EACH side, so an accepted 96/72 yields one window of exactly 96/72 and no second pass.
            self._epg_span_h = max(1, max(back, fwd))
            return self._epg_span_h
        return 0

    def _epg_for(self, content_id, hours_back, hours_forward, anchor_offset_h=0):
        # [anchor_offset_h] moves the anchor off "now" so a span wider than one accepted window can be
        # covered in slices — see _epg_windows.
        now_ms = int((time.time() + int(anchor_offset_h) * 3600) * 1000)
        data = self._post("/content/epg/all", {
            "customerId": self.customer,
            # THE FIELD WHOSE ABSENCE ANSWERED 401, AND THE REASON THIS PROVIDER SHIPPED WITH NO GUIDE.
            #
            # Read off a customer's log on 2026-08-01 (serial 4012, a real Move subscription): the same
            # token, the same headers, seconds apart — `/content/live/all` answered 200 with 300
            # channels and `/content/epg/all` answered `401 Unauthorized` three hundred times. The only
            # difference between the two requests was this line.
            #
            # It was not guesswork that was missing, it was reading our own note: login() says, in the
            # comment above `self.profile`, that "every catalogue, guide and stream call needs it" — and
            # the Android client this was ported from says the same thing in its own docstring while its
            # `getEpg` quietly omits it. The port copied the code and not the sentence. Neither side had
            # ever run against a Move account, so nothing contradicted it until a customer did.
            "customerProfileId": self.profile,
            "partnerId": PARTNER_ID,
            "contentId": int(content_id), "time": now_ms,
            # The window is expressed in HOURS either side of an anchor, not as absolute bounds.
            "backwards": max(0, min(24 * 14, int(hours_back))),
            "forwards": max(0, min(24 * 14, int(hours_forward))),
            "appVersion": self.app_version(),
        })
        out = []
        for row in data.get("content") or []:
            # MILLISECONDS here. Kaltura's are seconds — an easy mix-up between providers, and one that
            # puts the whole guide in 1970.
            start = int((row or {}).get("start") or 0)
            end = int((row or {}).get("end") or 0)
            title = (row or {}).get("title") or ""
            if start <= 0 or end <= 0 or not title:
                continue
            out.append({
                "channel_id": self.scoped("move_%s" % content_id),
                "start": _xmltv(start),
                "stop": _xmltv(end),
                "title": title,
                "desc": row.get("epgDesc") or "",
            })
        return out

    # ---- playback ---------------------------------------------------------

    def _cache_path(self, name):
        return self.cache_path(name)

    def _live_id(self, content_id):
        entry = _read_json(self._cache_path(PLAY_CACHE)).get(str(content_id)) or {}
        live_id = str(entry.get("live_id") or "")
        if live_id:
            return live_id
        # A channel added since the last refresh: fetch the list once rather than refusing to play.
        self.channels()
        entry = _read_json(self._cache_path(PLAY_CACHE)).get(str(content_id)) or {}
        return str(entry.get("live_id") or "")

    @staticmethod
    def _stamp(ms):
        """A guide timestamp as a human reads it. The API works in milliseconds; the log should not."""
        return time.strftime("%Y-%m-%d %H:%M", time.localtime(int(ms) // 1000)) if ms else "?"

    def _epg_id_at(self, content_id, at_utc):
        """The provider's `epgId` for whatever aired on [content_id] at [at_utc] (seconds).

        Asked fresh rather than cached with the guide. The guide on disk can be days old and the id has
        to be right for the ONE programme being replayed; one extra POST at the start of a replay is
        cheaper than a wrong id, and far cheaper than a stale cache that fails only for old programmes.
        """
        at_s = int(at_utc)
        at_ms = at_s * 1000
        now_ms = int(time.time() * 1000)
        hours_back = max(1, int((now_ms - at_ms) / 3600000.0) + 1)

        # HOW FAR BACK TO ASK, and why it is no longer computed to fit.
        #
        # `backwards` was set to exactly the number of hours between now and the requested instant, on
        # the reading that the API takes hours either side of an anchor. Read off the owner's own box on
        # 2026-08-05, that reading does not survive contact with the service:
        #
        #     19:49  replay 218087 at 18:00  ->  epgId 2161010038      (backwards=2)   worked
        #     19:50  REFUSED  218087 at 16:00                          (backwards=4)   nothing found
        #     19:46  replay 218084 at 15:30  ->  epgId 2160501965      (backwards=5)   worked
        #     19:47  REFUSED  218097 at 14:00                          (backwards=6)   nothing found
        #
        # The SAME channel answers for 18:00 and refuses 16:00, so this is not the archive window
        # running out — it is our request not reaching back to the programme. Whatever `backwards`
        # counts (hours on some channels, entries on others — the service never says), computing it to
        # fit exactly is what leaves the answer one programme short.
        #
        # So: ask generously, and if the rows that come back still start LATER than the instant asked
        # for, ask once more with a week. That is self-correcting whichever unit it is, and it costs a
        # second request only in the case that was failing outright before.
        first = min(24 * 14, max(6, hours_back * 2 + 2))
        for reach in (first, 24 * 8) if first < 24 * 8 else (first,):
            rows = (self._post("/content/epg/all", {
                "customerId": self.customer, "customerProfileId": self.profile,
                "partnerId": PARTNER_ID, "contentId": int(content_id), "time": now_ms,
                "backwards": reach, "forwards": 1, "appVersion": self.app_version(),
            }) or {}).get("content") or []
            starts = [int((row or {}).get("start") or 0) for row in rows if (row or {}).get("start")]
            # COMPARED IN SECONDS, deliberately. IPTV Simple substitutes {utc} with whole seconds while
            # this guide is in milliseconds, so a programme whose start carries a millisecond remainder
            # (…7350) sits just ABOVE the truncated instant and `start <= at_ms` misses it by a fraction
            # of a second — refusing a replay of exactly the programme the user picked from the guide.
            for row in rows:
                start = int((row or {}).get("start") or 0)
                end = int((row or {}).get("end") or 0)
                epg_id = (row or {}).get("epgId")
                # A boundary instant belongs to the programme STARTING there — what IPTV Simple sends
                # when the user picks a programme rather than scrubbing to an arbitrary point.
                if epg_id and (start // 1000) <= at_s < (end // 1000):
                    return str(epg_id)
            reached = min(starts) if starts else 0
            if reached and reached <= at_ms:
                # The answer DID span the instant and still holds no programme for it. Asking for more
                # of the same would only repeat it — this is a real gap in the provider's guide.
                diag.log("Move TV: %d rows back to %s cover %s and none of them is that programme"
                         % (len(rows), self._stamp(reached), self._stamp(at_ms)))
                return None
            diag.log("Move TV: asked %s back and the guide starts at %s, short of %s — asking again"
                     % (reach, self._stamp(reached) if reached else "?", self._stamp(at_ms)))
        return None

    def resolve(self, channel_ref, at_utc=None, vod=False):
        self._ensure()
        if vod:
            return self._resolve_vod(channel_ref)
        live_id = self._live_id(channel_ref)
        if not live_id:
            raise ProviderError("Move TV: taj kanal nije u listi — osveži listu kanala pa probaj ponovo.")

        if at_utc:
            # REPLAY. Note the id: the per-programme call wants the channel's `contentId` (which is what
            # `channel_ref` is), NOT the `liveId` the live call above wants. This API uses two different
            # ids for the same channel depending on the call — the trap it sets most reliably.
            epg_id = self._epg_id_at(channel_ref, at_utc)
            if not epg_id:
                raise ProviderError("Move TV: za taj termin nema emisije u programu — arhiva ga ne pokriva.")
            data = self._post("/content/epg/source/get", {
                "customerId": self.customer, "customerProfileId": self.profile,
                "epgId": int(epg_id), "contentId": int(channel_ref),
                "dtype": DTYPE_DASH, "appVersion": self.app_version(),
            })
            diag.log("Move TV: replay %s at %s -> epgId %s"
                     % (channel_ref, time.strftime("%Y-%m-%d %H:%M", time.localtime(int(at_utc))), epg_id))
        else:
            data = self._post("/content/live/source/get", {
                "customerId": self.customer, "customerProfileId": self.profile,
                "liveId": int(live_id), "dtype": DTYPE_DASH, "appVersion": self.app_version(),
            })
        manifest = str(data.get("content_url") or "")
        play_auth = str((data.get("protection") or {}).get("headerValue") or "")
        if not manifest:
            raise ProviderError("Move TV: server nije vratio adresu strima za taj kanal.")
        if not play_auth:
            raise ProviderError("Move TV: server nije vratio %s token za taj kanal." % PLAY_AUTH_HEADER)
        if ((data.get("drm") or {}).get("enabled")):
            # Widevine is advertised account-wide but was never enabled on any channel sampled so far.
            # THE STREAM IS STILL HANDED OVER, deliberately: this flag has never been seen true, so
            # refusing on it would be refusing on a guess, and if the X-Play-Auth scheme happens to
            # carry the channel anyway the viewer gets a picture instead of a message. What the line
            # below buys is a NAME for the failure when it does come — without it, an encrypted
            # manifest with no licence is indistinguishable from any other playback error in the log.
            # (The comment here used to claim this branch refused. It never did.)
            diag.log("Move TV: channel %s reports drm.enabled — this build only handles the %s scheme, "
                     "playback will probably fail" % (channel_ref, PLAY_AUTH_HEADER), "ERROR")

        expires = _PLAY_AUTH_EXPIRY.search(play_auth)
        if expires:
            # Date included on purpose: these tokens last about 24 hours, so a time-only stamp
            # showed the SAME clock time it was minted at and looked expired on arrival.
            diag.log("Move TV: play token for %s valid until %s"
                     % (channel_ref,
                        time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(int(expires.group(1))))))

        headers = dict(self.session.headers_for())
        # On the manifest AND on every segment — that is the whole point of returning it here rather
        # than folding it into the URL.
        headers[PLAY_AUTH_HEADER] = play_auth
        return {
            "url": manifest, "manifest_type": "mpd", "headers": headers,
            # NOT a sliding window. A Move replay is a static manifest of the whole programme, so it
            # goes to inputstream.adaptive and is seeked inside; ffmpegdirect's timeshift mode cannot
            # open it at all. See the note in default.py.
            "timeshift": False,
        }

    # ---- Video klub -------------------------------------------------------

    def vod(self, node=None):
        """
        The Video klub, as a three-level tree: catalogues -> titles -> (for a series) episodes.

        Node scheme, chosen so nothing has to be looked up again on the way back down:

            None                    the 36 catalogues from /content/vod/filters
            cat:<catalogId>         one catalogue, from its first page
            cat:<catalogId>@<page>  the same catalogue, continued
            ser:<contentId>         one series' episodes

        Item ids follow the same idea. A film is its own `contentId` and needs the detail call to
        learn its `vodId`; an EPISODE is `vid:<vodId>` because it already knows one — see the note in
        _resolve_vod on why episodes cannot be keyed by contentId.
        """
        self._ensure()
        if not node:
            return self._vod_catalogs()
        if node.startswith("cat:"):
            addressed, _, page = node[4:].partition("@")
            return self._vod_titles(addressed, int(page) if page.isdigit() else 1)
        if node.startswith("ser:"):
            return self._vod_episodes(node[4:])
        return []

    def _vod_catalogs(self):
        data = self._post("/content/vod/filters", {
            "customerProfileId": self.profile, "lang": LANG, "appVersion": self.app_version(),
        })
        content = data.get("content") or {}
        out = []
        for cat in content.get("catalogs") or []:
            cid = (cat or {}).get("catalogId")
            name = (cat or {}).get("name")
            if cid and name:
                out.append({"kind": "dir", "name": name, "node": "cat:%s" % cid})
        diag.log("Move TV: Video klub — %d catalogues" % len(out))
        return out

    def _vod_titles(self, catalog_id, page=1):
        """
        One batch of a catalogue, and a row that fetches the next one.

        THE BUG THIS REPLACES, reported off a real screen: the club "loads about six pages and then
        goes back to the beginning". It was not going back — it had ENDED. This walked at most
        `VOD_MAX_PAGES` pages and then stopped with nothing on screen saying so, and Kodi does what it
        always does at the end of a list: the cursor wraps to the top. A catalogue of a couple of
        thousand titles showed the newest few hundred and swallowed the rest in silence.

        The cap itself is worth keeping — thirty-six catalogues walked to their ends would take longer
        than the whole rest of a refresh — so it becomes a BATCH rather than a limit, the same shape
        EON's has, with a "Next page" row carrying the page to resume at. The service already answers
        `nextPage`; it was being read and thrown away.
        """
        out, current, fetched = [], max(1, int(page)), 0
        while current and fetched < VOD_MAX_PAGES:
            data = self._post("/content/vod/get/all", {
                "customerProfileId": self.profile, "lang": LANG, "page": current,
                "sort": "newest", "catalogId": int(catalog_id), "appVersion": self.app_version(),
            })
            for item in data.get("content") or []:
                entry = self._vod_entry(item)
                if entry:
                    out.append(entry)
            # THE SERVICE'S OWN END MARKER, and unlike EON's this one can be believed: `nextPage` is 0
            # or absent on the last page. It stays the loop's condition, so a batch stops at the end of
            # the CATALOGUE rather than at the end of the budget.
            following = data.get("nextPage") or 0
            fetched += 1
            current = int(following) if str(following).isdigit() else 0

        if current:
            # There is more and the service said so, so the row is offered without a probe. EON needs
            # one because its own end markers lie (see its note); this backend's do not.
            out.append({"kind": "dir", "name": T("Sledeca strana") + "  ▸",
                        "node": "cat:%s@%d" % (catalog_id, current)})
        return out

    def _vod_entry(self, item):
        item = item or {}
        if not item.get("subscribed", True):
            return None
        content_id = str(item.get("contentId") or "")
        title = item.get("title") or ""
        if not content_id or not title:
            return None
        picture = item.get("picture") or {}
        # A series is a DIRECTORY: it is opened, never played. contentSubTypeId 5 = Serija.
        if int(item.get("contentSubTypeId") or TYPE_FILM) == TYPE_SERIES:
            return {"kind": "dir", "name": title, "node": "ser:%s" % content_id,
                    "logo": _image_url(picture.get("poster"))}
        return {"kind": "item", "name": title, "id": content_id,
                "logo": _image_url(picture.get("poster")),
                "year": int(item.get("vodYear") or 0) or None}

    def _vod_episodes(self, content_id):
        """
        Episodes of a series — from the SAME /content/vod/get the detail call makes.

        There is no per-series endpoint and no component walk; a captured series page issued neither
        /content/page/get nor /content/component/get. The response carries the series' own fields at
        the top level and EVERY EPISODE in `content`.
        """
        data = self._post("/content/vod/get", {
            "customerProfileId": self.profile, "lang": LANG,
            "contentId": int(content_id), "appVersion": self.app_version(),
        })
        out = []
        for ep in data.get("content") or []:
            ep = ep or {}
            vod_id = str(ep.get("vodId") or "")
            if not vod_id:
                continue
            season = int(ep.get("season") or 0)
            episode = int(ep.get("episode") or 0)
            # Every episode repeats the SERIES title, so a bare title is unusable as a row label —
            # the S/E prefix is what makes the list readable at all.
            label = ep.get("title") or content_id
            if season or episode:
                label = "S%02dE%02d  %s" % (season, episode, label)
            out.append({
                "kind": "item", "name": label,
                # vid: because contentId is the SERIES for every one of these — see _resolve_vod.
                "id": "vid:%s" % vod_id,
                "logo": _image_url((ep.get("picture") or {}).get("poster")),
                "plot": ep.get("description") or "",
                "duration": int(ep.get("duration") or 0) or None,
                "year": int(ep.get("year") or 0) or None,
            })
        diag.log("Move TV: series %s -> %d episode(s)" % (content_id, len(out)))
        return out

    def _resolve_vod(self, ref):
        """
        Plays one Video klub title.

        TWO IDS AGAIN, and this time the trap is worse than for channels: every episode of a series
        carries the SERIES' contentId, so contentId identifies a series and never an episode. `vodId`
        is the only thing that tells two episodes apart, which is why episode refs arrive here already
        carrying one ("vid:<vodId>") and skip the detail call.

        WHAT PROTECTS THE STREAM — both at once, and each fails looking like the other:
          * Widevine via EZDRM (`drm.server_url`, keyed on `drm.user_id`) — without it, encrypted
            media and no licence.
          * The X-Play-Auth token on manifest AND segments — without it the CDN 403s the media first,
            so it fails BEFORE DRM matters and reads as a dead link.
        Live and catch-up have neither; this is the only Move surface that carries both.
        """
        if ref.startswith("vid:"):
            vod_id, type_id = ref[4:], TYPE_SERIES
        else:
            detail = self._post("/content/vod/get", {
                "customerProfileId": self.profile, "lang": LANG,
                "contentId": int(ref), "appVersion": self.app_version(),
            })
            # `content` COMES BACK IN TWO SHAPES, and this only ever saw one of them.
            #
            # For some titles it is a list with a single entry; for others it is the entry itself. The
            # code indexed it with [0] either way, and a dict indexed with 0 does not fail gracefully —
            # it raises KeyError: 0, which reached the television as "Script failed" with no clue which
            # film had done it. Caught on the owner's box at 10:27:33 on 2026-08-04, pressing play on
            # "Meso" (contentId 593617): the answer in the log is
            #   {"success":true,"content":{"contentId":593617,"contentName":"Meso",…}}
            # — an object, not a list. Both shapes are read here now; anything else is treated as an
            # empty answer and produces the message below rather than a crash.
            content = detail.get("content")
            if isinstance(content, dict):
                first = content
            elif isinstance(content, list) and content:
                first = content[0] if isinstance(content[0], dict) else {}
            else:
                first = {}
            vod_id = str(first.get("vodId") or "")
            type_id = int(detail.get("contentSubTypeId") or first.get("contentTypeId") or TYPE_FILM)
            if not vod_id:
                raise ProviderError("Move TV: taj naslov nema stream (vodId nije vracen).")

        data = self._post("/content/vod/source/get", {
            "customerId": self.customer, "customerProfileId": self.profile,
            "vodId": int(vod_id), "contentTypeId": type_id,
            "dtype": DTYPE_DASH, "appVersion": self.app_version(),
        })
        manifest = str(data.get("content_url") or "")
        play_auth = str((data.get("protection") or {}).get("headerValue") or "")
        if not manifest:
            raise ProviderError("Move TV: server nije vratio adresu strima za taj naslov.")
        if not play_auth:
            raise ProviderError("Move TV: server nije vratio %s token za taj naslov." % PLAY_AUTH_HEADER)

        headers = dict(self.session.headers_for())
        headers[PLAY_AUTH_HEADER] = play_auth
        resolved = {"url": manifest, "manifest_type": "mpd", "headers": headers}

        drm = data.get("drm") or {}
        if drm.get("enabled"):
            licence = str(drm.get("server_url") or "")
            user_id = str(drm.get("user_id") or "")
            if licence:
                resolved["license_type"] = "com.widevine.alpha"
                # inputstream.adaptive's key is `url|request headers|request body|response`. EZDRM keys
                # the licence on user_id, so it rides in the request headers half.
                resolved["license_key"] = "%s|%s|R{SSM}|" % (
                    licence,
                    "&".join(["Content-Type=application/octet-stream"] +
                             (["x-ezdrm-userid=%s" % user_id] if user_id else [])),
                )
                diag.log("Move TV: VOD %s is Widevine (EZDRM)%s"
                         % (vod_id, "" if user_id else " — WITHOUT a user_id, the licence may be refused"))
        return resolved

    # ---- diagnostics ------------------------------------------------------

    def diagnose(self):
        rows = []
        ok, detail = net.probe(self.session, self.host() + "/login", method="POST")
        rows.append(("Reachable", ok, detail))
        rows.append(("Credentials", bool(self.setting("username") and self.setting("password")),
                     self.setting("username") or "not set"))
        try:
            self.login()
            rows.append(("Login", True, "customer %s, profile %s" % (self.customer, self.profile)))
        except ProviderError as err:
            rows.append(("Login", False, err.message))
            return rows
        try:
            channels = self.channels()
            rows.append(("Channel list", bool(channels), "%d channels" % len(channels)))
        except Exception as err:                                   # noqa: BLE001
            rows.append(("Channel list", False, "%s: %s" % (type(err).__name__, err)))
            return rows

        # AND THEN ACTUALLY RESOLVE ONE, because "Move does not work" has been reported twice
        # against a screen that only ever proved the login. Every other row above can be green
        # while playback is impossible: the channel list comes from one call and the stream from
        # another, and the second is the one that carries the play token and the DRM flag.
        #
        # This row started here and now lives in Provider.diagnose_playback, because the reasoning
        # was never Move-specific — EON, Iris and Yettel were making the same promise on the same
        # screen with the same amount of evidence.
        rows.extend(self.diagnose_playback(channels))
        return rows


#: Guide window sizes to try, widest first — see MoveProvider._epg_span. Only the ones no larger than
#: what the guide settings actually ask for are tried.
EPG_WINDOW_STEPS = (168, 96, 48, 24, 12, 6, 3)


def _merge(out, seen, rows):
    """Adds [rows] to [out], skipping any (channel, start) already there. See the seam overlap in
    _epg_windows — the same programme legitimately arrives in two consecutive windows."""
    for row in rows:
        key = (row["channel_id"], row["start"])
        if key in seen:
            continue
        seen.add(key)
        out.append(row)


def _is_window_refusal(err):
    """
    Was this refusal about the SIZE OF THE GUIDE WINDOW rather than about anything we can fix by
    asking again?

    `/content/epg/all` answers `400 {"success":false,"message":"time/backwards/forwards not provided
    or backwards/forwards is out of limit.","appCode":"400001"}` — the same message for a missing
    field and for an oversized window, which is why the text is matched rather than the code.
    """
    body = ""
    if isinstance(err, net.HttpError):
        if err.status != 400:
            return False
        body = err.body or ""
    text = (body + " " + str(getattr(err, "message", "") or err)).lower()
    return "backwards" in text and "forwards" in text


def _epg_windows(hours_back, hours_forward, span):
    """
    The requested guide span, cut into windows the server will accept — NEAREST TO NOW FIRST.

    Returns `(anchor_offset_h, backwards, forwards)` triples, where the anchor is that many hours from
    now. One call covers `[anchor - backwards, anchor + forwards]`, so with a ceiling of `span` per
    field the first call alone covers up to 2 × span hours around now.

    The order is the point, not a detail. The guide runs against a time budget (`move_epg_budget_sec`)
    and on a slow box it WILL be cut short; whatever has been fetched by then should be tonight's
    programmes, not last Tuesday's. Slabs also overlap by an hour at each seam — a window of exactly 0
    risks the same "not provided" validator that produced this whole mess, and a duplicate programme
    costs nothing because the caller drops repeats by (channel, start).
    """
    span = max(1, int(span))
    hours_back = max(0, int(hours_back))
    hours_forward = max(0, int(hours_forward))
    near_back, near_fwd = min(hours_back, span), min(hours_forward, span)
    out = [(0, near_back, near_fwd)]
    done_back, done_fwd = near_back, near_fwd
    while done_back < hours_back or done_fwd < hours_forward:
        if done_fwd < hours_forward:
            step = min(span, hours_forward - done_fwd)
            out.append((done_fwd, 1, step))
            done_fwd += step
        if done_back < hours_back:
            step = min(span, hours_back - done_back)
            out.append((-done_back, step, 1))
            done_back += step
    return out


#: What the sign-in refuses with, and what the viewer can do about each. The CODE is matched first
#: because it is stable; the message is English and the operator may translate it at any time.
_SIGN_IN_REASONS = {
    "403007": ("Move TV: nalog nema slobodnog mesta za još jedan uređaj. Odjavi neki uređaj u Move "
               "aplikaciji ili na njihovom sajtu, pa probaj ponovo."),
}


def _sign_in_refusal(err):
    """
    A refused sign-in, as a sentence rather than a status code.

    Move answers a refused login with an HTTP error whose BODY is the same `{"success": false,
    "message": …, "appCode": …}` shape every 200 uses — so the reason is always there and was never
    read. `No slots available` (403007) is the one that matters most: nothing about the account or the
    password is wrong, and no amount of retrying will help, but one action in the operator's own app
    fixes it immediately.

    Anything unrecognised keeps the service's own message, which is still worth more than the number.
    """
    body = getattr(err, "body", "") or ""
    code, message = "", ""
    try:
        parsed = json.loads(body)
        if isinstance(parsed, dict):
            code = str(parsed.get("appCode") or "")
            message = str(parsed.get("message") or "")
    except (ValueError, TypeError):
        pass
    if code in _SIGN_IN_REASONS:
        return ProviderError(_SIGN_IN_REASONS[code])
    if message:
        return ProviderError("Move TV: prijava odbijena — %s." % message)
    if getattr(err, "status", 0) in (401, 403):
        return ProviderError("Move TV: prijava odbijena — proveri korisničko ime i lozinku.")
    return ProviderError("Move TV: prijava nije uspela (HTTP %s)." % getattr(err, "status", "?"))


def _is_auth_failure(err):
    """
    Was this refusal about the SESSION rather than about the request?

    Two shapes mean the same thing here and only one of them is an HTTP status. `net.HttpError` carries
    401/403 plainly; but this API also refuses inside a 200 body (`success:false` with an `appCode`),
    which `_ok` turns into a ProviderError with the message in it — and the message a customer's log
    showed for an expired session was exactly "Unauthorized!". Both are worth one fresh login; neither
    is worth three hundred.
    """
    if isinstance(err, net.HttpError):
        return err.is_auth
    text = str(getattr(err, "message", "") or err).lower()
    return "unauthorized" in text or "401" in text or "token" in text


def _image_url(path):
    path = str(path or "")
    if not path:
        return ""
    return path if path.startswith("http") else (IMAGE_BASE + path)


def _xmltv(value):
    """
    Accepts epoch seconds, epoch millis, or an ISO string — providers are inconsistent about this and a
    guide that silently drops half its programmes is worse than one that guesses sensibly.

    The ISO branch used to slice the string at 19 characters and stamp the result `+0000`, which threw
    the offset away and declared a local time to be UTC: every programme sat an hour or two from where
    it belonged, and a guide wrong by a whole hour looks like a broken provider rather than a formatting
    bug. The offset is now read and applied.
    """
    try:
        number = float(value)
        if number > 1e11:
            number /= 1000.0
        return time.strftime("%Y%m%d%H%M%S +0000", time.gmtime(number))
    except (TypeError, ValueError):
        pass

    text = str(value).strip()
    match = re.match(r"^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2}):(\d{2})"
                     r"(?:\.\d+)?\s*(Z|[+-]\d{2}:?\d{2})?$", text)
    if not match:
        # Unparseable is not a reason to lose the whole guide — the caller drops one programme.
        diag.log("Move TV: unrecognised timestamp %r in the guide" % text[:40])
        return ""
    year, month, day, hour, minute, second = (int(g) for g in match.groups()[:6])
    offset = match.group(7)
    stamp = calendar.timegm((year, month, day, hour, minute, second, 0, 0, 0))
    if offset and offset not in ("Z", "z"):
        sign = 1 if offset[0] == "+" else -1
        offset = offset[1:].replace(":", "")
        stamp -= sign * (int(offset[:2]) * 3600 + int(offset[2:]) * 60)
    return time.strftime("%Y%m%d%H%M%S +0000", time.gmtime(stamp))


def _read_json(path):
    try:
        with open(path, "r", encoding="utf-8") as handle:
            data = json.loads(handle.read())
        return data if isinstance(data, dict) else {}
    except (OSError, IOError, ValueError):
        return {}


def _write_json(path, data):
    """Through store.write_json like every other small file — the rule is newer than this function was."""
    store.write_json(path, data)
