# -*- coding: utf-8 -*-
"""
The HTTP layer, and the whole point of this addon existing.

Every provider identity — User-Agent, Origin, Referer, and the device descriptors sent in the login body
— is data here, never a constant baked into a binary. That is the lesson of the pvr.eon outage: its UA
was a compiled-in string, EON added that exact string to an edge blocklist, and from that moment nobody
could fix their own installation without a new build from an author who had gone quiet.

Here the same event is a settings change: type a new User-Agent, press play. And because a provider's
next move will not be the User-Agent (they have already used that one), everything else a filter can key
on is exposed the same way.
"""

import gzip
import io
import json
import time

try:
    from http.cookiejar import CookieJar, LWPCookieJar
    from urllib.request import (Request, urlopen, build_opener, HTTPCookieProcessor,
                                HTTPError, URLError)
except ImportError:                                    # pragma: no cover - py2 tooling only
    from cookielib import CookieJar, LWPCookieJar
    from urllib2 import (Request, urlopen, build_opener, HTTPCookieProcessor,
                         HTTPError, URLError)

from . import diag


class HttpError(Exception):
    """Carries the status and body, because 'it failed' is never enough to act on."""

    def __init__(self, status, url, body="", cause=None):
        super(HttpError, self).__init__("HTTP %s for %s" % (status, url))
        self.status = status
        self.url = url
        self.body = body or ""
        self.cause = cause

    @property
    def is_auth(self):
        return self.status in (401, 403)

    @property
    def is_offline(self):
        """No HTTP happened at all — DNS, routing or the socket. Status 0 is this module's marker for it.

        Worth naming, because it is the one failure where retrying the NEXT thing is pointless: a box
        whose Wi-Fi has gone to sleep answers every request in the same millisecond with
        `[Errno 7] No address associated with hostname`, and a loop that treats that as "this channel
        failed, try the next" writes three hundred identical lines into the log at full speed. That
        log is what rides along with a support report."""
        return self.status == 0

    @property
    def looks_like_ua_block(self):
        """EON's edge answers a blocked agent with a recognisable body. Naming it lets the UI say
        'your User-Agent is being refused' instead of a bare 403 the user cannot act on."""
        marker = self.body.lower()
        return self.status == 403 and ("user agent" in marker or "403.3700" in marker)


class NotJsonError(HttpError):
    """
    The service answered, successfully, with something that is not JSON.

    A subclass rather than a new exception type, so every `except HttpError` already written keeps
    catching it — the handling is the same (this provider failed, the others carry on) and only the
    message differs. It is worth its own name because the cause is almost never the provider: it is a
    captive portal, an ISP error page, or a DNS answer pointing somewhere else.
    """

    def __init__(self, status, url, body=""):
        HttpError.__init__(self, status, url, body)
        first = " ".join((body or "").split())[:120]
        self.args = ("HTTP %s for %s answered with something that is not JSON%s"
                     % (status, url, (" — " + first) if first else ""),)


class Session(object):
    """
    One provider's connection. [identity] is a plain dict so a provider can hand over whatever that
    service happens to care about, and the settings screen can override any of it.
    """

    def __init__(self, identity, timeout=20, trace=True, cookies=False, cookie_file=None):
        self.identity = dict(identity or {})
        self.timeout = timeout
        self.trace = trace
        self._jar = None
        # Off by default because every provider written so far is cookie-free, and a session that
        # silently accumulates cookies is a source of confusing cross-request state.
        #
        # Iris needs it and cannot work without it: its backend sits behind a load balancer that pins a
        # session with CSESSIONID/XSESSIONID/JSESSIONID, so the SwitchProfile call at the end of the
        # login chain lands on a node that never saw TSSSOAuth and fails with "125023001: user session
        # not found or timeout" — every time, not intermittently. The failure names a session timeout,
        # which sends you looking at tokens rather than at cookies.
        #
        # [cookie_file] keeps that jar between PROCESSES, which is what makes a cached login worth
        # having: the plugin runs for exactly one channel change, so a session held only in memory is a
        # session thrown away at the moment it becomes useful. `ignore_discard` is the whole point —
        # these are session cookies, and the default behaviour of both load and save is to drop exactly
        # those.
        if cookies:
            if cookie_file:
                self._jar = LWPCookieJar(cookie_file)
                try:
                    self._jar.load(ignore_discard=True, ignore_expires=True)
                except (IOError, OSError, ValueError):
                    pass                      # no jar yet, or one written by another version
            else:
                self._jar = CookieJar()
            self._opener = build_opener(HTTPCookieProcessor(self._jar))
        else:
            self._opener = None

    def save_cookies(self):
        """Write the jar out, if this session was given a file to keep it in. Never fatal: losing the
        jar costs one extra login, and failing a tune over it would cost the picture."""
        if isinstance(self._jar, LWPCookieJar):
            try:
                self._jar.save(ignore_discard=True, ignore_expires=True)
                return True
            except (IOError, OSError, ValueError):
                pass
        return False

    def _open(self, request):
        if self._opener is not None:
            return self._opener.open(request, timeout=self.timeout)
        return urlopen(request, timeout=self.timeout)

    # ---- identity ---------------------------------------------------------

    def headers_for(self, extra=None):
        headers = {}
        ua = self.identity.get("user_agent")
        if ua:
            headers["User-Agent"] = ua
        origin = self.identity.get("origin")
        if origin:
            headers["Origin"] = origin
        referer = self.identity.get("referer")
        if referer:
            headers["Referer"] = referer
        lang = self.identity.get("accept_language")
        if lang:
            headers["Accept-Language"] = lang
        headers.update(self.identity.get("extra_headers") or {})
        headers.update(extra or {})
        return headers

    # ---- requests ---------------------------------------------------------

    def request(self, method, url, headers=None, body=None, expect_json=True):
        """
        One request, fully traced. Raises [HttpError] with the body attached — a provider that starts
        refusing us almost always says why in the body, and throwing that away is how "it just stopped
        working" reports happen.
        """
        sent = self.headers_for(headers)
        if body is not None and "Content-Type" not in sent:
            sent["Content-Type"] = "application/json"
        data = body.encode("utf-8") if isinstance(body, str) else body
        req = Request(url, data=data, headers=sent)
        req.get_method = lambda: method
        started = time.time()
        try:
            with self._open(req) as resp:                        # noqa: SIM117 (py3 only target)
                raw = resp.read()
                if resp.headers.get("Content-Encoding") == "gzip":
                    raw = gzip.GzipFile(fileobj=io.BytesIO(raw)).read()
                text = raw.decode("utf-8", "replace")
                elapsed = int((time.time() - started) * 1000)
                if self.trace:
                    diag.trace_request(method, url, sent, resp.status, elapsed, len(raw), text)
                if not (expect_json and text.strip()):
                    return text
                try:
                    return json.loads(text)
                except ValueError:
                    # A 200 whose body is not JSON, which is what a captive portal, an ISP error page or
                    # a hijacked DNS answer looks like from in here. Every caller in this addon handles
                    # HttpError and none of them handles ValueError, so this used to leave the refresh
                    # reporting "JSONDecodeError: Expecting value" — a message about our parser rather
                    # than about the page somebody else served us. The body travels along, because the
                    # first line of that page is usually the whole explanation.
                    raise NotJsonError(resp.status, url, text)
        except HTTPError as err:
            raw = err.read() or b""
            # An error body is gzipped just as often as a good one — the success path above decompresses
            # and this one used to not, so the single most useful thing in a failure (the service's own
            # explanation of WHY it said 403) reached the log as a screenful of binary.
            if (err.headers.get("Content-Encoding") or "").lower() == "gzip" and raw:
                try:
                    raw = gzip.GzipFile(fileobj=io.BytesIO(raw)).read()
                except (IOError, OSError, EOFError):
                    pass                                           # truncated body; the bytes still go in
            text = raw.decode("utf-8", "replace")
            elapsed = int((time.time() - started) * 1000)
            if self.trace:
                diag.trace_request(method, url, sent, err.code, elapsed, len(raw), text)
            raise HttpError(err.code, url, text, err)
        except (URLError, OSError) as err:
            elapsed = int((time.time() - started) * 1000)
            if self.trace:
                diag.trace_request(method, url, sent, None, elapsed, None, None, error=err)
            # No status at all: the request never reached the service. Distinguishing this from a 403 is
            # what separated "the phone's network blocks our host" from "the token is bad" in the field.
            raise HttpError(0, url, str(err), err)

    def get(self, url, headers=None, expect_json=True):
        return self.request("GET", url, headers=headers, expect_json=expect_json)

    def post(self, url, body=None, headers=None, expect_json=True):
        return self.request("POST", url, headers=headers, body=body, expect_json=expect_json)


def probe(session, url, method="GET"):
    """
    A single reachability check for the diagnostics screen: does this host answer us at all, and with
    what. Deliberately separate from [Session.request] because it must never raise — the whole job is to
    report, including reporting that nothing came back.
    """
    try:
        session.request(method, url, expect_json=False)
        return True, "OK"
    except HttpError as err:
        if err.status == 0:
            return False, "unreachable: %s" % err.body
        if err.looks_like_ua_block:
            return False, "HTTP 403 — this User-Agent is being refused"
        # AN API THAT REFUSES AN EMPTY PROBE IS STILL AN API THAT ANSWERED.
        #
        # From a customer's diagnostics on 2026-08-01: "Fail  Reachable — HTTP 406 {"success":false,
        # "message":"Something not provided or invalid format."}" — on an account whose channel list
        # was loading perfectly. The probe posts nothing to an endpoint that wants a JSON body, and the
        # server said so; that is the OPPOSITE of unreachable, and printing it in red sends somebody
        # hunting a network problem that does not exist.
        #
        # 4xx that means "your request was wrong" is reported as reachable-with-a-note. 401/403 stay
        # failures (credentials or a block), and 5xx stays a failure (the host is having a bad day).
        if err.status in (400, 405, 406, 415, 422):
            return True, "OK — %s answered (HTTP %s to an empty probe, which is correct)" % (
                url.split("//", 1)[-1].split("/", 1)[0], err.status)
        return False, "HTTP %s%s" % (err.status, (" — " + err.body[:120]) if err.body else "")
