# -*- coding: utf-8 -*-
"""
Interface language for everything the code prints, switchable from the addon's own settings.

## Why not string ids

`resources/settings.xml` has to use numeric ids into `strings.po` — that is Kodi's format and there is
no choice. Everything else, the ~160 dialogs and menu labels written in Python, deliberately does NOT:
here the SERBIAN TEXT IS THE KEY.

    xbmcgui.Dialog().ok(T("IPTV Balkan"), T("Nalog je zakljucan."))

Three reasons, each learned from the id approach next door:

  * A missing translation degrades to Serbian — readable — instead of to a blank line or a bare number.
    A settings screen with 34 empty labels is exactly how that failure looks, and it is invisible until
    it is on a television.
  * There is no second file to keep in step. An id renamed on one side and not the other is a silent
    hole; a string that is its own key cannot drift out of sync with itself.
  * The diff that introduces it is mechanical and reviewable — wrap the string, do not renumber it.

## Why not just follow Kodi's language

`getLocalizedString` reads whatever Kodi's interface is set to, which is the right default and is what
`Prati Kodi` does. But the box in the living room is often left in English while the person using it
wants Serbian, and changing Kodi's whole interface to get one addon translated is not a trade anyone
should have to make. So the setting can override it, and that means resolving the language here rather
than asking Kodi.
"""

from . import diag

try:
    import xbmc
    _IN_KODI = True
except ImportError:                                                # tooling / unit tests
    xbmc = None
    _IN_KODI = False

SERBIAN = "sr"
ENGLISH = "en"

#: Setting value -> language. "" (the default) means follow Kodi.
_CHOICES = {"0": "", "1": SERBIAN, "2": ENGLISH}

_current = None


def configure(settings):
    """Read the chosen language once. Called by whatever is about to print something."""
    global _current
    choice = str(settings.get("ui_language", "0") or "0")
    wanted = _CHOICES.get(choice, "")
    if not wanted:
        wanted = _kodi_language()
    _current = wanted
    return wanted


def _kodi_language():
    if not _IN_KODI:
        return SERBIAN
    try:
        # ISO 639-1 keeps this to two letters, so "Serbian" and "Serbian (Cyrillic)" both answer "sr".
        code = (xbmc.getLanguage(xbmc.ISO_639_1) or "").strip().lower()
    except Exception:                                              # noqa: BLE001
        return SERBIAN
    return ENGLISH if code and code != SERBIAN else SERBIAN


def language():
    return _current or SERBIAN


def T(text):
    """
    [text] in the chosen language. Serbian in, Serbian or English out.

    Deliberately forgiving: an unknown string is returned as it came. A user-facing string is not worth
    an exception, and a missing translation should look like an untranslated sentence rather than a
    crash in the middle of a dialog.
    """
    if language() != ENGLISH:
        # Serbian: the key IS the sentence, so this only puts the diacritics back. See _SR at the end.
        return _SR.get(text) or _SR.get(text.strip()) or text
    return _EN.get(text) or _EN.get(text.strip()) or text


def missing():
    """Serbian strings the English table does not cover — used by check-addon.py so a new dialog cannot
    quietly ship untranslated."""
    return sorted(_EN_MISSING)


#: Filled by check-addon.py when it scans the source; empty at runtime.
_EN_MISSING = set()


# ---------------------------------------------------------------------------
# Serbian -> English. Kept in one place, alphabetical by nothing in particular — grouped the way the
# screens are, because that is how they get read when something needs fixing.
# ---------------------------------------------------------------------------

_EN = {
    "Nema veze sa provajderom. Proveri internet.":
        "No connection to the provider. Check the internet.",
    "Nije uspelo automatsko prebacivanje. Otvaram Kodijeva podesavanja — jezik je pod "
    "Interface / Regional / Language.":
        "Switching automatically did not work. Opening Kodi's own settings — the language is "
        "under Interface / Regional / Language.",
    "Prebaci i Kodi na srpski": "Switch Kodi to Serbian too",
    "Ekran podesavanja crta Kodi i on prati KODIJEV jezik, a ne jezik dodatka. Prebaciti ceo Kodi na "
    "srpski? Ako srpski nije instaliran, Kodi ce ga prvo preuzeti.":
        "The settings screen is drawn by Kodi and follows KODI's language, not the addon's. Switch "
        "the whole of Kodi to Serbian? If Serbian is not installed, Kodi will download it first.",
    "Kodi je prebacen na srpski.": "Kodi has been switched to Serbian.",
    # ---- the addon's own menu, regrouped ------------------------------------------------------
    "Nalozi i uredjaji": "Accounts and devices",
    "Podesavanja": "Settings",
    "Pomoc, licenca i dijagnostika": "Help, licence and diagnostics",
    "Podesavanja dodatka (provajderi, nalozi)": "Add-on settings (providers, accounts)",
    "Unesi nalog ovde (otvara pregledac)": "Enter an account here (opens the browser)",
    "Unesi nalog sa drugog telefona (QR)": "Enter an account from another phone (QR)",
    # ---- the QR window's own controls ---------------------------------------------------------
    "Zatvori": "Close",
    "Otvori ovde": "Open here",
    "Ovde, na ovom uređaju (otvara pregledač)": "Here, on this device (opens the browser)",
    "Na drugom telefonu (QR kod)": "On another phone (QR code)",
    "Forma je otvorena u pregledacu ovog uredjaja. Popuni je i posalji, pa "
    "se vrati u Kodi.":
        "The form has been opened in this device's browser. Fill it in and submit it, then come "
        "back to Kodi.",
    "Preostalo: %d:%02d": "Time left: %d:%02d",
    # ---- main menu ----
    "Pretraga (kanali, EPG, Video klub)": "Search (channels, EPG, Video club)",
    "Licenca / broj uredjaja": "Licence / device number",
    "Nalozi na ovom uredjaju": "Accounts on this device",
    "Uredjaji na pretplati (slotovi)": "Devices on the subscription (slots)",
    "Posalji poruku podrsci (sa logom)": "Send a message to support (with the log)",
    "Unesi nalog telefonom (QR)": "Enter an account from your phone (QR)",
    "Povezi Yettel nalog (jednokratni kod)": "Link a Yettel account (one-time code)",
    "Dodaj Video klub na pocetni ekran": "Add the Video club to the home screen",
    # These five were the reverse of every other row here: ENGLISH text as the key, so they read as
    # English in a Serbian interface — the one language combination this addon's own audience uses.
    "Pokreni dijagnostiku": "Run diagnostics",
    "Osvezi kanale i vodic sada": "Refresh channels and guide now",
    "Kodi debug log: ukljuci/iskljuci": "Kodi debug log: on/off",
    "Pogledaj log": "View log",
    "Posalji log na telefon (QR)": "Send the log to your phone (QR)",
    "Obrisi log": "Clear log",
    "Log je obrisan": "The log was cleared",
    "Log je prazan.": "The log is empty.",
    "IPTV Balkan — log": "IPTV Balkan — log",
    "Nastavi gledanje": "Continue watching",

    # ---- home-screen shortcut ----
    "Dodato u Favorite. Da bi stajalo na pocetnom ekranu: Podesavanja -> Interfejs -> "
    "Skin -> Podesi skin -> Stavke glavnog menija.":
        "Added to Favourites. To have it on the home screen: Settings -> Interface -> "
        "Skin -> Configure skin -> Main menu items.",
    "Nije uspelo. Video klub mozes dodati i rucno: desni klik na njega -> Dodaj u favorite.":
        "It did not work. You can add the Video club by hand: right-click it -> Add to favourites.",

    # ---- search, and continue watching -------------------------------------
    # The bracketed markers are what tells a row apart at a glance on a list that mixes three kinds of
    # result. Kept SHORT on purpose: they sit in front of a title on a television, and a long word
    # pushes the name itself off the right edge on a 720p skin.
    "Pretraga": "Search",
    "Pretraga: kanal, emisija ili film": "Search: a channel, a show or a film",
    "IPTV Balkan — pretraga": "IPTV Balkan — search",
    "Video klub": "Video club",
    "Nema rezultata za \"%s\".": "Nothing found for \"%s\".",
    "TV": "TV",
    "ARHIVA": "ARCHIVE",
    "SADA": "NOW",
    "USKORO": "SOON",
    "VOD": "VOD",
    "Nema zapocetih naslova.": "Nothing started yet.",
    "jos %d min": "%d min left",
    "Zaboravi ovaj naslov": "Forget this title",
    "Sledeca strana": "Next page",
    "Sve": "All",
    "Nema opisa.": "No description.",
    # The Video klub's own category rows. Ours are preferred over the provider's for the reason
    # EonProvider.VOD_CATEGORY_NAMES explains, which means translating them is ours to do too.
    "Filmovi": "Films",
    "Serije": "Series",
    "Deca": "Children",
    "Muzika": "Music",
    "Sport": "Sport",
    "Dokumentarni": "Documentaries",
    "Zabava": "Entertainment",
    "Ostalo": "Other",

    # ---- licence ----
    # The status lines are whole keys and the date is appended outside them — see licence.describe.
    "Broj uredjaja:": "Device number:",
    "Id uredjaja:": "Device id:",
    "(pun: %s)": "(full: %s)",
    "do %s": "until %s",
    "Status: probni period": "Status: trial",
    "Status: [COLOR green]otkljucano[/COLOR]": "Status: [COLOR green]unlocked[/COLOR]",
    "Status: [COLOR red]zakljucano[/COLOR]": "Status: [COLOR red]locked[/COLOR]",
    "Status: jos nije provereno kod servera": "Status: not yet checked with the server",
    # ---- the crash handler: the last thing a customer should ever have to read ----------
    "IPTV Balkan — greska": "IPTV Balkan — error",
    "Nesto je puklo u dodatku i radnja nije zavrsena.\n\n%s":
        "Something broke inside the add-on and the action did not finish.\n\n%s",
    "Broj uredjaja: %s": "Device number: %s",
    "Poslati log podrsci?": "Send the log to support?",
    # ---- the privacy screen ------------------------------------------------------------
    'Privatnost — sta odlazi sa ovog uredjaja': 'Privacy — what leaves this device',
    'IPTV Balkan — privatnost': 'IPTV Balkan — privacy',
    'Ovaj dodatak ne salje nikakvu statistiku i nema reklame. Nijedan tok se ne prosledjuje preko naseg servera — uredjaj razgovara direktno sa tvojim operaterom.':
        'This add-on sends no analytics and carries no advertising. No stream is relayed through our server — the box talks to your operator directly.',
    '1. Provera licence — povremeno': '1. Licence check — from time to time',
    'Ide na nas server.': 'Goes to our server.',
    'Salje: broj ovog uredjaja (izveden iz MAC adrese, pa hesovan), verziju dodatka, otisak koda i otisak naloga — a to je hesovan spisak KOJI provajderi su podeseni, nikad korisnicko ime i nikad lozinka.':
        "Sends: this device's number (derived from the MAC address, then hashed), the add-on version, a fingerprint of the code and a fingerprint of the account — which is a hashed list of WHICH providers are configured, never a username and never a password.",
    'Vraca: stanje licence, poruke iz panela i kljuc kojim se otkljucavaju sacuvane lozinke na ovom uredjaju.':
        'Returns: the licence state, messages from the panel, and the key that unlocks the passwords stored on this box.',
    'Server vidi tvoju IP adresu, kao i svaki server kome se javis; u panelu se cuva samo njen hes, radi brojanja mreza.':
        'The server sees your IP address, as does every server you contact; the panel keeps only a hash of it, to count networks.',
    '2. Poruka podrsci — samo kad je ti posaljes': '2. A support message — only when you send one',
    'Uz poruku ide kraj loga sa ovog uredjaja i broj uredjaja, da bi se poruka spojila sa pravim uredjajem. Lozinke, tokeni i kljucevi za tok se BRISU iz loga pre nego sto se on uopste upise na disk.':
        "The end of this box's log travels with it, plus the device number so the message can be matched to the right device. Passwords, tokens and stream keys are REMOVED from the log before it is written to disk at all.",
    'Log se trenutno vodi na ovom uredjaju.': 'The log is currently being kept on this box.',
    'Log se trenutno ne vodi na ovom uredjaju.': 'The log is currently not being kept on this box.',
    '3. Slike i opisi za Video klub (TMDB)':
        '3. Artwork and descriptions for the Video club (TMDB)',
    'Naziv filma ili serije koju gledas u Video klubu ide na api.themoviedb.org da bi se nasla slika, opis i godina; same slike se preuzimaju sa image.tmdb.org. Ne ide ni ko si, ni koji nalog imas.':
        'The name of a film or series you look at in the Video club goes to api.themoviedb.org to find a poster, a description and a year, and the pictures themselves come from image.tmdb.org. Who you are and which account you have do not.',
    'Naziv filma ili serije koju gledas u Video klubu ide na nas server, koji ga prosledjuje TMDB-u svojim kljucem. Uz upit ide broj ovog uredjaja, jer server odgovara samo svojim korisnicima — znaci nas server moze da vidi sta se trazi sa ovog uredjaja. Slike se i dalje preuzimaju direktno sa image.tmdb.org.':
        "The name of a film or series you look at in the Video club goes to our server, which passes it on to TMDB using its own key. This box's device number goes with it, because the server only answers its own customers — so our server can see what is being looked up from this box. The pictures still come straight from image.tmdb.org.",
    'Kad TMDB nema opis na srpskom, tekst opisa ide na Google prevodilac (translate.googleapis.com). Iskljucuje se u podesavanjima.':
        'When TMDB has no Serbian description, the description text goes to Google Translate. It can be switched off in the settings.',
    'Iskljuceno na ovom uredjaju.': 'Switched off on this box.',
    '4. Tvoj TV provajder': '4. Your TV provider',
    'Ukljuceni: %s': 'Enabled: %s',
    'nijedan': 'none',
    'Prijava, lista kanala, vodic i sam tok idu direktno sa ovog uredjaja na provajderov server, tvojim nalogom. Mi to ne posredujemo i ne vidimo.':
        "The login, the channel list, the guide and the stream itself go straight from the box to the provider's server, using your account. We neither relay nor see any of it.",
    '5. Sta ostaje na uredjaju': '5. What stays on the box',
    'Nalozi, lista kanala, vodic, log i istorija gledanja su fajlovi u fascikli ovog dodatka. Lozinke se cuvaju sifrovane, kljucem koji stize uz licencu.':
        "Accounts, the channel list, the guide, the log and the watch history are files in this add-on's own folder. Passwords are stored encrypted, with the key that arrives with the licence.",
    'Sve to nestaje kad se dodatak obrise.': 'All of it goes when the add-on is removed.',
    "Preneto iz prethodne verzije: %s": "Brought over from the previous version: %s",
    "ova verzija nema licencu": "this version has no licence",
    "Kada probni period istekne, posalji gornji broj uredjaja u Telegram grupu ispod i dodatak se "
    "otkljucava sa moje strane. Ne treba nista da instaliras ponovo.":
        "When the trial runs out, send the device number above to the Telegram group below and the "
        "addon is unlocked from my side. Nothing has to be installed again.",
    "Posalji broj uredjaja u Telegram grupu ispod i otkljucacu ga. Kanali i vodic ostaju na "
    "uredjaju, samo cekaju otkljucavanje.":
        "Send the device number to the Telegram group below and I will unlock it. The channels and "
        "the guide stay on the device, they are only waiting to be unlocked.",
    "Id uredjaja iznad je isti onaj koji ce se koristiti kada licenca bude "
    "ukljucena, pa ga vredi sacuvati.":
        "The device id above is the same one that will be used once the licence is switched on, so "
        "it is worth keeping.",
    "Podrska i obavestenja — Telegram grupa:": "Support and announcements — Telegram group:",
    "IPTV Balkan — licenca": "IPTV Balkan — licence",
    "IPTV Balkan — podrska": "IPTV Balkan — support",
    "IPTV Balkan — Telegram grupa": "IPTV Balkan — Telegram group",
    "Prikazati QR kod za Telegram grupu?\n\nSkeniraj ga telefonom da se "
    "pridruzis grupi za podrsku i obavestenja.":
        "Show a QR code for the Telegram group?\n\nScan it with your phone to join the group for "
        "support and announcements.",
    "Skeniraj kod telefonom da se pridruzis grupi za podrsku.":
        "Scan the code with your phone to join the support group.",
    "Broj uredjaja: %s   ·   Back za izlaz": "Device number: %s   ·   Back to exit",
    "Prikazi QR": "Show QR",
    "Ne treba": "No thanks",

    # ---- devices ----
    "IPTV Balkan — uredjaji": "IPTV Balkan — devices",
    "IPTV Balkan — uredjaji na pretplati": "IPTV Balkan — devices on the subscription",
    "Nijedan uredjaj nije prijavljen.": "No devices are registered.",
    "Zelis li da oslobodis neki slot?": "Do you want to free a slot?",
    "Koji uredjaj da uklonim?": "Which device should be removed?",
    "Ukloni": "Remove",
    "Odustani": "Cancel",
    "Uredjaj je uklonjen": "The device was removed",
    "Ukloniti \"%s\" sa %s naloga?": "Remove \"%s\" from the %s account?",
    "\n\n[COLOR red]To je uredjaj na kom si sada.[/COLOR] Posle ovoga se ovaj Kodi "
    "vise nece prijaviti dok se ponovo ne registruje.":
        "\n\n[COLOR red]That is the device you are on right now.[/COLOR] After this, this Kodi will "
        "not log in again until it registers itself once more.",
    "Uklanjanje nije uspelo:\n\n%s": "The removal failed:\n\n%s",

    # ---- support ----
    "Opisi problem ili napisi poruku": "Describe the problem or write a message",
    "IPTV Balkan — poruka podrsci": "IPTV Balkan — message to support",
    "Posalji": "Send",
    "Poruka je poslata.": "The message was sent.",
    "Poruka je prazna.": "The message is empty.",
    "IPTV Balkan — poruka": "IPTV Balkan — message",
    "Poslati poruku zajedno sa logom sa ovog uredjaja?\n\n"
    "Broj uredjaja: %s\n\nLog sadrzi adrese i greske, ali NE i lozinke — one se ne "
    "upisuju.":
        "Send the message together with this device's log?\n\n"
        "Device number: %s\n\nThe log holds addresses and errors, but NOT passwords — those are "
        "never written to it.",
    "jos nije dodeljen": "not assigned yet",
    "%s\n\nOdgovor stize u ovaj isti dodatak — javice se sam kad dodje.":
        "%s\n\nThe reply arrives in this same addon — it will speak up by itself when it comes.",
    "%s\n\nAko se ponavlja, posalji log preko '%s'.":
        "%s\n\nIf it keeps happening, send the log with '%s'.",

    # ---- video club / TMDB ----
    "IPTV Balkan — Video klub": "IPTV Balkan — Video club",
    "Ispravi podatke (TMDB)": "Correct the details (TMDB)",
    "Tacan naziv za pretragu (TMDB)": "Correct title to search for (TMDB)",
    "Ispravka je uklonjena": "The correction was removed",
    "Ispravka nije mogla da se sacuva.": "The correction could not be saved.",
    "Pronadjeno: %s": "Found: %s",
    "Ni pod tim nazivom nema nista na TMDB-u.\n\nProbaj "
    "original (engleski) naziv, ili dodaj godinu.":
        "There is nothing under that title on TMDB either.\n\nTry the original (English) title, or "
        "add the year.",

    # ---- pairing / QR ----
    "IPTV Balkan — sparivanje telefonom": "IPTV Balkan — pair with a phone",
    "IPTV Balkan — sparivanje": "IPTV Balkan — pairing",
    "Sparivanje telefonom": "Pair with a phone",
    "Otvoriti ekran za unos naloga?": "Open the account-entry screen?",
    "Poceti povezivanje Yettel naloga?": "Start linking a Yettel account?",
    "IPTV Balkan — posalji log": "IPTV Balkan — send the log",
    "Port ne moze da se otvori: %s": "The port could not be opened: %s",
    "Kod ne moze da se napravi: %s": "The code could not be produced: %s",
    "Nalog je stigao sa telefona, ali ga je nesto na TV-u prebrisalo "
    "(%s).\n\nZatvori ekran podesavanja dodatka i pokusaj ponovo — dok je "
    "otvoren, on prepisuje sve sto se upise iza njega.":
        "The account arrived from the phone, but something on the TV overwrote it "
        "(%s).\n\nClose the addon's settings screen and try again — while it is open, it writes "
        "over anything saved behind it.",
    "Dodato: %s": "Added: %s",
    "Nalog je sacuvan. Osveziti listu kanala i vodic sada?":
        "The account was saved. Refresh the channel list and the guide now?",
    "IPTV Balkan — Yettel": "IPTV Balkan — Yettel",
    "Povezivanje nije moglo da počne: %s": "The linking could not start: %s",
    "Skeniraj kod telefonom, prijavi se na Yettel i unesi ovaj kod:  [B]%s[/B]":
        "Scan the code with your phone, sign in to Yettel and enter this code:  [B]%s[/B]",
    "Prijava je prošla, ali povezivanje nije dovršeno: %s":
        "The sign-in went through, but the linking was not completed: %s",
    "Yettel je povezan i uključen. Osveziti listu kanala sada?":
        "Yettel is linked and enabled. Refresh the channel list now?",

    # ---- accounts ----
    "IPTV Balkan — nalozi": "IPTV Balkan — accounts",
    "Nalozi na ovom uređaju": "Accounts on this device",
    "Nema nijednog uključenog naloga. Uključi provajdera u "
    "podešavanjima ili ga unesi telefonom.":
        "There is no enabled account. Enable a provider in the settings, or enter one from your "
        "phone.",
    "„%s“ je prvi nalog i živi u podešavanjima dodatka — tamo se menja i "
    "isključuje.\n\nDodatni nalozi se dodaju preko „Unesi nalog…“ u istom meniju, sa "
    "čekiranim „Dodaj kao NOV nalog“.":
        "\"%s\" is the first account and lives in the addon's settings — that is where it is "
        "changed and disabled.\n\nExtra accounts are added through \"Enter an account…\" in the "
        "same menu, with \"Add as a NEW account\" ticked.",
    "Obrisati nalog „%s“?\n\nKanali nestaju iz liste posle "
    "sledećeg osvežavanja.":
        "Delete the account \"%s\"?\n\nIts channels disappear from the list after the next refresh.",
    "iskljucen": "disabled",
    "podešavanja": "settings",
    "dodatni": "extra",
    "Isključi": "Disable",
    "Uključi": "Enable",
    "Obriši": "Delete",
    "Nazad": "Back",

    # ---- QR screens ----
    "Skeniraj telefonom. Log se otvara u pregledacu, sa dugmetom da se sacuva kao fajl.":
        "Scan with your phone. The log opens in a browser, with a button to save it as a file.",
    "Back kad zavrsis. Link vazi 5 minuta i gasi se sa ovim ekranom.":
        "Back when you are done. The link lasts 5 minutes and closes with this screen.",
    "Skeniraj kod telefonom koji je na istoj mrezi i unesi nalog tamo.":
        "Scan the code with a phone on the same network and enter the account there.",
    "Back za odustajanje. Link vazi 5 minuta.": "Back to cancel. The link lasts 5 minutes.",
    "IPTV Balkan — poveži Yettel nalog": "IPTV Balkan — link a Yettel account",
    "Ovo se radi jednom. Back za odustajanje.": "This is done once. Back to cancel.",
    "Yettel nalog je povezan": "The Yettel account is linked",
    "IPTV Balkan — Kodi debug log": "IPTV Balkan — Kodi debug log",
    "Kodijev debug log je prebacen (ukljucen ako je bio iskljucen).\n\n"
    "Sada: restartuj Kodi, sacekaj dva minuta na TV sekciji, pa posalji "
    "Kodijev log sa 'Posalji log na telefon' — tab Kodi.\n\n"
    "Kad zavrsimo, pritisni ovo jos jednom da ga ugasis: debug log je velik "
    "i usporava uredjaj.":
        "Kodi's debug log was toggled (on if it was off).\n\n"
        "Now: restart Kodi, wait two minutes on the TV section, then send Kodi's log with 'Send the "
        "log to your phone' — the Kodi tab.\n\n"
        "When we are done, press this once more to switch it off: the debug log is large and slows "
        "the box down.",
    "Nijedan uključen provajder nema video klub, ili prijava nije "
    "prošla. Pogledaj '%s'.":
        "No enabled provider has a video club, or the sign-in did not go through. See '%s'.",

    # ---- what the user is told when something goes wrong ----
    # Provider errors are translated AT THE POINT THEY ARE SHOWN rather than where they are raised:
    # most are built across several source lines, and a wrapper around a multi-line literal is exactly
    # the kind of edit that silently changes a sentence. The key here is the finished sentence.
    "IPTV Balkan — poruka nije poslata": "IPTV Balkan — the message was not sent",
    "Nijedan ukljucen provajder ne prijavljuje uredjaje.\n\n"
    "Iris i Yettel prijavljuju; EON ne nudi nista klijentu.":
        "No enabled provider reports devices.\n\n"
        "Iris and Yettel do; EON offers a client nothing.",
    "Zakljucano — posalji broj uredjaja %s": "Locked — send device number %s",
    "Osvezeno: %d kanala": "%d channels updated",
    "Osvezavanje liste — kanal je bio od ranije verzije": "Rebuilding the channel list — that row was from an older one",
    "Osvezavanje nije uspelo: %s": "Refresh failed: %s",

    # Parental PIN.
    "Roditeljski PIN za Video klub": "Parental PIN for the Video club",
    "Roditeljski PIN": "Parental PIN",
    "Trenutni PIN": "Current PIN",
    "Novi PIN (4 do 8 cifara)": "New PIN (4 to 8 digits)",
    "Ponovi PIN": "Repeat the PIN",
    "Promeni PIN": "Change the PIN",
    "Ukloni PIN": "Remove the PIN",
    "Zakljucaj odmah": "Lock now",
    "Zakljucano": "Locked",
    "PIN je uklonjen": "The PIN has been removed",
    "Pogresan PIN": "Wrong PIN",
    "PIN mora imati izmedju 4 i 8 cifara.": "The PIN must be between 4 and 8 digits.",
    "Dva unosa se ne poklapaju.": "The two entries do not match.",
    "Video klub sada trazi PIN. Jednom unet, vazi 15 minuta.":
        "The Video club now asks for the PIN. Once entered it lasts 15 minutes.",
    "Sta se zakljucava": "What is locked",
    "Ceo Video klub": "The whole Video club",
    "ceo Video klub": "the whole Video club",
    "Samo izabrane kategorije": "Only the chosen categories",
    "samo izabrane kategorije": "only the chosen categories",
    "Izmeni spisak kategorija": "Edit the category list",
    "Kategorije koje traze PIN (odvoji zarezom)":
        "Categories that ask for the PIN (comma separated)",
    "PIN se trazi na ulazu u Video klub. Nista se ne otvara bez njega.":
        "The PIN is asked at the door of the Video club. Nothing opens without it.",
    "Katalog je otvoren, PIN traze samo kategorije sa spiska (%s).\n\n"
    "Vazno: rezultat pretrage i 'Nastavi gledanje' vise nisu u kategoriji, pa se tamo "
    "moze proveriti samo naslov. Ako hoces cvrstu branu, izaberi ceo Video klub.":
        "The catalogue is open; only the categories on the list ask for the PIN (%s).\n\n"
        "Note: a search result and a 'Continue watching' row have left their category behind, so only "
        "the title can be checked there. For a hard barrier, choose the whole Video club.",
    "Spisak je vracen na podrazumevani: %s": "The list is back to the default: %s",
    "PIN sada traze kategorije cije ime sadrzi: %s":
        "The PIN is now asked by categories whose name contains: %s",
}


# ---------------------------------------------------------------------------
# SERBIAN, WITH ITS LETTERS.
#
# The keys in the table above are written without diacritics, because they are also IDENTIFIERS:
# they appear in every T("...") call in the source, and a key with a c-caron in it is a key
# somebody eventually mistypes - which fails silently, printing the key instead of the sentence.
#
# What a viewer sees is a different question, and until this table existed the screen mixed the
# two: "Ovde, na ovom uredjaju" (with its letters) one line under "Podesavanja" (without). A
# reader on the forum noticed that before anything else, on 2026-08-01.
#
# So the ASCII stays the identity and this is the DISPLAY. No call site changes, and a string with
# no entry here renders exactly as it was typed. Generated from a word map rather than retyped by
# hand - see scratchpad/diacritics.py - because a word checked once is not a word mistyped in the
# eleventh sentence that uses it.
# ---------------------------------------------------------------------------

_SR = {
    "Nije uspelo automatsko prebacivanje. Otvaram Kodijeva podesavanja — jezik je pod "
    "Interface / Regional / Language.":
        "Nije uspelo automatsko prebacivanje. Otvaram Kodijeva podešavanja — jezik je pod "
        "Interface / Regional / Language.",
    "Log se trenutno vodi na ovom uredjaju.": "Log se trenutno vodi na ovom uređaju.",
    "Log se trenutno ne vodi na ovom uredjaju.":
        "Log se trenutno ne vodi na ovom uređaju.",
    "Iskljuceno na ovom uredjaju.": "Isključeno na ovom uređaju.",
    "5. Sta ostaje na uredjaju": "5. Šta ostaje na uređaju",
    "Ekran podesavanja crta Kodi i on prati KODIJEV jezik, a ne jezik dodatka. Prebaciti ceo Kodi na "
    "srpski? Ako srpski nije instaliran, Kodi ce ga prvo preuzeti.":
        "Ekran podešavanja crta Kodi i on prati KODIJEV jezik, a ne jezik dodatka. Prebaciti ceo Kodi "
        "na srpski? Ako srpski nije instaliran, Kodi će ga prvo preuzeti.",
    "Ide na nas server.":
        "Ide na naš server.",
    "Ovaj dodatak ne salje nikakvu statistiku i nema reklame. Nijedan tok se ne prosledjuje preko naseg servera — uredjaj razgovara direktno sa tvojim operaterom.":
        "Ovaj dodatak ne šalje nikakvu statistiku i nema reklame. Nijedan tok se ne prosleđuje preko našeg servera — uređaj razgovara direktno sa tvojim operaterom.",
    "Server vidi tvoju IP adresu, kao i svaki server kome se javis; u panelu se cuva samo njen hes, radi brojanja mreza.":
        "Server vidi tvoju IP adresu, kao i svaki server kome se javiš; u panelu se čuva samo njen heš, radi brojanja mreža.",
    "Naziv filma ili serije koju gledas u Video klubu ide na api.themoviedb.org da bi se nasla slika, opis i godina; same slike se preuzimaju sa image.tmdb.org. Ne ide ni ko si, ni koji nalog imas.":
        "Naziv filma ili serije koju gledaš u Video klubu ide na api.themoviedb.org da bi se našla slika, opis i godina; same slike se preuzimaju sa image.tmdb.org. Ne ide ni ko si, ni koji nalog imaš.",
    "Naziv filma ili serije koju gledas u Video klubu ide na nas server, koji ga prosledjuje TMDB-u svojim kljucem. Uz upit ide broj ovog uredjaja, jer server odgovara samo svojim korisnicima — znaci nas server moze da vidi sta se trazi sa ovog uredjaja. Slike se i dalje preuzimaju direktno sa image.tmdb.org.":
        "Naziv filma ili serije koju gledaš u Video klubu ide na naš server, koji ga prosleđuje TMDB-u svojim ključem. Uz upit ide broj ovog uređaja, jer server odgovara samo svojim korisnicima — znači naš server može da vidi šta se traži sa ovog uređaja. Slike se i dalje preuzimaju direktno sa image.tmdb.org.",
    "Kad TMDB nema opis na srpskom, tekst opisa ide na Google prevodilac (translate.googleapis.com). Iskljucuje se u podesavanjima.":
        "Kad TMDB nema opis na srpskom, tekst opisa ide na Google prevodilac (translate.googleapis.com). Isključuje se u podešavanjima.",
    "Sve to nestaje kad se dodatak obrise.":
        "Sve to nestaje kad se dodatak obriše.",
    "Ukljuceni: %s":
        "Uključeni: %s",
    "Povezi Yettel nalog (jednokratni kod)":
        "Poveži Yettel nalog (jednokratni kod)",
    "Preneto iz prethodne verzije: %s":
        "Preneto iz prethodne verzije: %s",
    '\n\n[COLOR red]To je uredjaj na kom si sada.[/COLOR] Posle ovoga se ovaj Kodi vise nece prijaviti dok se ponovo ne registruje.':
        '\n\n[COLOR red]To je uređaj na kom si sada.[/COLOR] Posle ovoga se ovaj Kodi više neće prijaviti dok se ponovo ne registruje.',
    "%s\n\nAko se ponavlja, posalji log preko '%s'.":
        "%s\n\nAko se ponavlja, pošalji log preko '%s'.",
    '%s\n\nOdgovor stize u ovaj isti dodatak — javice se sam kad dodje.':
        '%s\n\nOdgovor stiže u ovaj isti dodatak — javiće se sam kad dođe.',
    '2. Poruka podrsci — samo kad je ti posaljes': '2. Poruka podršci — samo kad je ti pošalješ',
    # "opisi" is the NOUN (descriptions) and needs no diacritic; "opiši" is the imperative "describe",
    # which is what the screen said. The Serbian table is a mechanical restore of letters the ASCII
    # source drops, and this is the word where that goes wrong — pinned in test-i18n.py.
    '3. Slike i opisi za Video klub (TMDB)': '3. Slike i opisi za Video klub (TMDB)',
    '5. Sta ostaje na uredjaju': '5. Šta ostaje na uređaju',
    'Back kad zavrsis. Link vazi 5 minuta i gasi se sa ovim ekranom.':
        'Back kad završiš. Link važi 5 minuta i gasi se sa ovim ekranom.',
    'Back za odustajanje. Link vazi 5 minuta.': 'Back za odustajanje. Link važi 5 minuta.',
    'Broj uredjaja:': 'Broj uređaja:',
    'Broj uredjaja: %s': 'Broj uređaja: %s',
    'Broj uredjaja: %s   ·   Back za izlaz': 'Broj uređaja: %s   ·   Back za izlaz',
    'Dodaj Video klub na pocetni ekran': 'Dodaj Video klub na početni ekran',
    'Dodato u Favorite. Da bi stajalo na pocetnom ekranu: Podesavanja -> Interfejs -> Skin -> Podesi skin -> Stavke glavnog menija.':
        'Dodato u Favorite. Da bi stajalo na početnom ekranu: Podešavanja -> Interfejs -> Skin -> Podesi skin -> Stavke glavnog menija.',
    'Forma je otvorena u pregledacu ovog uredjaja. Popuni je i posalji, pa se vrati u Kodi.':
        'Forma je otvorena u pregledaču ovog uređaja. Popuni je i pošalji, pa se vrati u Kodi.',
    'IPTV Balkan — greska': 'IPTV Balkan — greška',
    'IPTV Balkan — podrska': 'IPTV Balkan — podrška',
    'IPTV Balkan — poruka podrsci': 'IPTV Balkan — poruka podršci',
    'IPTV Balkan — posalji log': 'IPTV Balkan — pošalji log',
    'IPTV Balkan — uredjaji': 'IPTV Balkan — uređaji',
    'IPTV Balkan — uredjaji na pretplati': 'IPTV Balkan — uređaji na pretplati',
    'Id uredjaja iznad je isti onaj koji ce se koristiti kada licenca bude ukljucena, pa ga vredi sacuvati.':
        'Id uređaja iznad je isti onaj koji će se koristiti kada licenca bude uključena, pa ga vredi sačuvati.',
    'Id uredjaja:': 'Id uređaja:',
    'Iskljuceno na ovom uredjaju.': 'Isključeno na ovom uređaju.',
    'Ispravka nije mogla da se sacuva.': 'Ispravka nije mogla da se sačuva.',
    'Kada probni period istekne, posalji gornji broj uredjaja u Telegram grupu ispod i dodatak se otkljucava sa moje strane. Ne treba nista da instaliras ponovo.':
        'Kada probni period istekne, pošalji gornji broj uređaja u Telegram grupu ispod i dodatak se otključava sa moje strane. Ne treba ništa da instaliraš ponovo.',
    "Katalog je otvoren, PIN traze samo kategorije sa spiska (%s).\n\nVazno: rezultat pretrage i 'Nastavi gledanje' vise nisu u kategoriji, pa se tamo moze proveriti samo naslov. Ako hoces cvrstu branu, izaberi ceo Video klub.":
        "Katalog je otvoren, PIN traže samo kategorije sa spiska (%s).\n\nVažno: rezultat pretrage i 'Nastavi gledanje' više nisu u kategoriji, pa se tamo može proveriti samo naslov. Ako hoćeš čvrstu branu, izaberi ceo Video klub.",
    'Kategorije koje traze PIN (odvoji zarezom)': 'Kategorije koje traže PIN (odvoji zarezom)',
    'Kod ne moze da se napravi: %s': 'Kod ne može da se napravi: %s',
    'Kodi debug log: ukljuci/iskljuci': 'Kodi debug log: uključi/isključi',
    "Kodijev debug log je prebacen (ukljucen ako je bio iskljucen).\n\nSada: restartuj Kodi, sacekaj dva minuta na TV sekciji, pa posalji Kodijev log sa 'Posalji log na telefon' — tab Kodi.\n\nKad zavrsimo, pritisni ovo jos jednom da ga ugasis: debug log je velik i usporava uredjaj.":
        "Kodijev debug log je prebacen (uključen ako je bio isključen).\n\nSada: restartuj Kodi, sačekaj dva minuta na TV sekciji, pa pošalji Kodijev log sa 'Pošalji log na telefon' — tab Kodi.\n\nKad završimo, pritisni ovo još jednom da ga ugasiš: debug log je velik i usporava uređaj.",
    'Koji uredjaj da uklonim?': 'Koji uređaj da uklonim?',
    'Licenca / broj uredjaja': 'Licenca / broj uređaja',
    'Nalog je sacuvan. Osveziti listu kanala i vodic sada?':
        'Nalog je sačuvan. Osvežiti listu kanala i vodič sada?',
    'Nalog je stigao sa telefona, ali ga je nesto na TV-u prebrisalo (%s).\n\nZatvori ekran podesavanja dodatka i pokusaj ponovo — dok je otvoren, on prepisuje sve sto se upise iza njega.':
        'Nalog je stigao sa telefona, ali ga je nešto na TV-u prebrisalo (%s).\n\nZatvori ekran podešavanja dodatka i pokušaj ponovo — dok je otvoren, on prepisuje sve što se upiše iza njega.',
    'Nalozi i uredjaji': 'Nalozi i uređaji',
    'Nalozi na ovom uredjaju': 'Nalozi na ovom uređaju',
    'Nalozi, lista kanala, vodic, log i istorija gledanja su fajlovi u fascikli ovog dodatka. Lozinke se cuvaju sifrovane, kljucem koji stize uz licencu.':
        'Nalozi, lista kanala, vodič, log i istorija gledanja su fajlovi u fascikli ovog dodatka. Lozinke se čuvaju šifrovane, ključem koji stiže uz licencu.',
    'Nema zapocetih naslova.': 'Nema započetih naslova.',
    'Nesto je puklo u dodatku i radnja nije zavrsena.\n\n%s':
        'Nešto je puklo u dodatku i radnja nije zavrsena.\n\n%s',
    'Ni pod tim nazivom nema nista na TMDB-u.\n\nProbaj original (engleski) naziv, ili dodaj godinu.':
        'Ni pod tim nazivom nema ništa na TMDB-u.\n\nProbaj original (engleski) naziv, ili dodaj godinu.',
    'Nije uspelo. Video klub mozes dodati i rucno: desni klik na njega -> Dodaj u favorite.':
        'Nije uspelo. Video klub možeš dodati i ručno: desni klik na njega -> Dodaj u favorite.',
    'Nijedan ukljucen provajder ne prijavljuje uredjaje.\n\nIris i Yettel prijavljuju; EON ne nudi nista klijentu.':
        'Nijedan uključen provajder ne prijavljuje uređaje.\n\nIris i Yettel prijavljuju; EON ne nudi ništa klijentu.',
    'Nijedan uredjaj nije prijavljen.': 'Nijedan uređaj nije prijavljen.',
    'Obrisi log': 'Obriši log',
    'Opisi problem ili napisi poruku': 'Opiši problem ili napiši poruku',
    'Osvezavanje nije uspelo: %s': 'Osvežavanje nije uspelo: %s',
    'Osvezeno: %d kanala': 'Osveženo: %d kanala',
    'Osvezavanje liste — kanal je bio od ranije verzije':
        'Osvežavanje liste — kanal je bio od ranije verzije',
    'Osvezi kanale i vodic sada': 'Osveži kanale i vodič sada',
    'PIN mora imati izmedju 4 i 8 cifara.': 'PIN mora imati između 4 i 8 cifara.',
    'PIN sada traze kategorije cije ime sadrzi: %s':
        'PIN sada traže kategorije čije ime sadrži: %s',
    'PIN se trazi na ulazu u Video klub. Nista se ne otvara bez njega.':
        'PIN se traži na ulazu u Video klub. Ništa se ne otvara bez njega.',
    'Poceti povezivanje Yettel naloga?': 'Početi povezivanje Yettel naloga?',
    'Podesavanja': 'Podešavanja',
    'Podesavanja dodatka (provajderi, nalozi)': 'Podešavanja dodatka (provajderi, nalozi)',
    'Podrska i obavestenja — Telegram grupa:': 'Podrška i obaveštenja — Telegram grupa:',
    'Pogresan PIN': 'Pogrešan PIN',
    'Pomoc, licenca i dijagnostika': 'Pomoć, licenca i dijagnostika',
    'Port ne moze da se otvori: %s': 'Port ne može da se otvori: %s',
    'Posalji': 'Pošalji',
    'Posalji broj uredjaja u Telegram grupu ispod i otkljucacu ga. Kanali i vodic ostaju na uredjaju, samo cekaju otkljucavanje.':
        'Pošalji broj uređaja u Telegram grupu ispod i otključaću ga. Kanali i vodič ostaju na uređaju, samo čekaju otključavanje.',
    'Posalji log na telefon (QR)': 'Pošalji log na telefon (QR)',
    'Posalji poruku podrsci (sa logom)': 'Pošalji poruku podršci (sa logom)',
    'Poslati log podrsci?': 'Poslati log podršci?',
    'Poslati poruku zajedno sa logom sa ovog uredjaja?\n\nBroj uredjaja: %s\n\nLog sadrzi adrese i greske, ali NE i lozinke — one se ne upisuju.':
        'Poslati poruku zajedno sa logom sa ovog uređaja?\n\nBroj uređaja: %s\n\nLog sadrži adrese i greške, ali NE i lozinke — one se ne upisuju.',
    'Prijava, lista kanala, vodic i sam tok idu direktno sa ovog uredjaja na provajderov server, tvojim nalogom. Mi to ne posredujemo i ne vidimo.':
        'Prijava, lista kanala, vodič i sam tok idu direktno sa ovog uređaja na provajderov server, tvojim nalogom. Mi to ne posredujemo i ne vidimo.',
    'Prikazati QR kod za Telegram grupu?\n\nSkeniraj ga telefonom da se pridruzis grupi za podrsku i obavestenja.':
        'Prikazati QR kod za Telegram grupu?\n\nSkeniraj ga telefonom da se pridružiš grupi za podršku i obaveštenja.',
    'Prikazi QR': 'Prikaži QR',
    'Privatnost — sta odlazi sa ovog uredjaja': 'Privatnost — šta odlazi sa ovog uređaja',
    'Pronadjeno: %s': 'Pronađeno: %s',
    'Salje: broj ovog uredjaja (izveden iz MAC adrese, pa hesovan), verziju dodatka, otisak koda i otisak naloga — a to je hesovan spisak KOJI provajderi su podeseni, nikad korisnicko ime i nikad lozinka.':
        'Šalje: broj ovog uređaja (izveden iz MAC adrese, pa hešovan), verziju dodatka, otisak koda i otisak naloga — a to je hešovan spisak KOJI provajderi su podešeni, nikad korisničko ime i nikad lozinka.',
    'Skeniraj kod telefonom da se pridruzis grupi za podrsku.':
        'Skeniraj kod telefonom da se pridružiš grupi za podršku.',
    'Skeniraj kod telefonom koji je na istoj mrezi i unesi nalog tamo.':
        'Skeniraj kod telefonom koji je na istoj mreži i unesi nalog tamo.',
    'Skeniraj telefonom. Log se otvara u pregledacu, sa dugmetom da se sacuva kao fajl.':
        'Skeniraj telefonom. Log se otvara u pregledaču, sa dugmetom da se sačuva kao fajl.',
    'Sledeca strana': 'Sledeća strana',
    'Spisak je vracen na podrazumevani: %s': 'Spisak je vraćen na podrazumevani: %s',
    'Sta se zakljucava': 'Šta se zaključava',
    'Status: [COLOR green]otkljucano[/COLOR]': 'Status: [COLOR green]otključano[/COLOR]',
    'Status: [COLOR red]zakljucano[/COLOR]': 'Status: [COLOR red]zaključano[/COLOR]',
    'Status: jos nije provereno kod servera': 'Status: još nije provereno kod servera',
    'Tacan naziv za pretragu (TMDB)': 'Tačan naziv za pretragu (TMDB)',
    'Unesi nalog ovde (otvara pregledac)': 'Unesi nalog ovde (otvara pregledač)',
    'Uredjaj je uklonjen': 'Uređaj je uklonjen',
    'Uredjaji na pretplati (slotovi)': 'Uređaji na pretplati (slotovi)',
    'Uz poruku ide kraj loga sa ovog uredjaja i broj uredjaja, da bi se poruka spojila sa pravim uredjajem. Lozinke, tokeni i kljucevi za tok se BRISU iz loga pre nego sto se on uopste upise na disk.':
        'Uz poruku ide kraj loga sa ovog uređaja i broj uređaja, da bi se poruka spojila sa pravim uređajem. Lozinke, tokeni i ključevi za tok se BRIŠU iz loga pre nego što se on uopšte upiše na disk.',
    'Video klub sada trazi PIN. Jednom unet, vazi 15 minuta.':
        'Video klub sada traži PIN. Jednom unet, važi 15 minuta.',
    'Vraca: stanje licence, poruke iz panela i kljuc kojim se otkljucavaju sacuvane lozinke na ovom uredjaju.':
        'Vraća: stanje licence, poruke iz panela i ključ kojim se otključavaju sačuvane lozinke na ovom uređaju.',
    'Yettel je povezan i uključen. Osveziti listu kanala sada?':
        'Yettel je povezan i uključen. Osvežiti listu kanala sada?',
    'Zakljucaj odmah': 'Zaključaj odmah',
    'Zakljucano': 'Zaključano',
    'Zakljucano — posalji broj uredjaja %s': 'Zaključano — pošalji broj uređaja %s',
    'Zelis li da oslobodis neki slot?': 'Želiš li da oslobodiš neki slot?',
    'iskljucen': 'isključen',
    'jos %d min': 'još %d min',
    'jos nije dodeljen': 'još nije dodeljen',
}
