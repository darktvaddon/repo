# -*- coding: utf-8 -*-
"""
Iris (MTS, Huawei VSP) — ported from the IptvBox Android client, where this flow runs against a live
account daily. Nothing here was inferred from endpoint names; every field and every ordering below is
what the working Kotlin sends.

Iris is a fourth backend shape, unrelated to EON's United Cloud. Three things about it drive the whole
design of this file, and each one silently breaks everything if missed:

  1. **Cookies are the session.** The login chain is four calls, and the backend sits behind a load
     balancer that pins a session with CSESSIONID/XSESSIONID/JSESSIONID. Without a cookie jar the last
     call lands on a node that never saw the third and answers "125023001: user session not found or
     timeout" — reliably, not intermittently, and the message points at tokens rather than cookies.
  2. **Playback is DASH + Widevine**, not a signed URL. The play call returns a manifest, a licence
     server and a `customData` JWT that must ride along as the `acquirelicense.customdata` header on
     every licence request. No JWT, no picture.
  3. **A stream that stops reporting gets dropped.** The official web player sends a heartbeat every
     60 seconds; sitting on one channel without it dies mid-programme. See service.py, which owns the
     cadence — the addon's plugin process is gone the moment playback starts, so the resident service
     is the only thing that can keep beating.

Catch-up is per PROGRAMME, not per timestamp: CUTV wants a `playbillID`. IPTV Simple hands us a UTC
start time, so a replay tune costs one extra guide lookup to turn that time back into a programme id.
"""

import hashlib
import io
import json
import os
import threading
import time
import uuid

from .. import diag, net
from ..provider import Provider, ProviderError, register

BASE = "https://iris.mts.rs"
DEVICE_MODEL = "Chrome_Irdeto_Widevine"
SOFTWARE_VERSION = "0.0.71"

#: Seconds to wait before the second and third login attempt. Read off a failure on the box rather
#: than picked: the login that refused twice inside three seconds went through unchanged eight seconds
#: later, so the ladder has to reach past that and there is no point making the FIRST retry slow.
LOGIN_BACKOFF = (1.5, 4.0)

#: The server hard-rejects any `count` above this ("the value [200] of count doesn't match range
#: (-1, 100]") and fails the WHOLE request rather than clamping, so the guide has to be paged.
EPG_PAGE_SIZE = 100
#: Safety stop for the paging loop, well above what a real channel has over the window below.
EPG_MAX_PROGRAMMES = 500
#: Channels per guide request. Measured against the live API: 30 is accepted, 40 is refused with
#: "channelIds size is over limit!".
EPG_CHANNEL_BATCH = 30

#: How far back the guide and catch-up reach. Measured on the Android side, not chosen: the guide is one
#: paged request per channel, so a 9-day window over ~460 channels becomes ~1400 rapid calls, Iris starts
#: shedding load with 503s, and the result came back with FEWER programmes than a 3-day window because
#: whole channels dropped out.
CATCHUP_DAYS = 3

#: The Video klub's tree starts here — the standalone client's own root subject id.
VOD_ROOT_SUBJECT = "7000"
VOD_PAGE_SIZE = 60
#: A stop for the paging walk, not a target: a subject with more titles than this is a catalogue nobody
#: scrolls to the end of anyway.
VOD_MAX_TITLES = 600

PLAY_CACHE = "iris_play.json"
#: The logged-in session, kept between processes. See _load_session for why this is the single biggest
#: thing standing in front of an Iris channel change.
SESSION_CACHE = "iris_session.json"
COOKIE_CACHE = "iris_cookies.txt"
#: How long a stored session is offered to the next tune before the chain is run again. Iris does not
#: say how long its own sessions last, so this is deliberately short of any plausible answer — and a
#: stale one costs a single failed call, not a failed tune, because the retry below re-logs in.
SESSION_MAX_AGE = 6 * 3600
#: What service.py reads to know whether to keep a stream alive. Written at tune time, removed when
#: playback stops.
NOW_PLAYING = "iris_playing.json"


#: Iris' own codes for "whatever session you are holding is no good". 125023001 is the one this
#: backend actually serves — see the login docstring, where the same code appears as passing weather on
#: a FRESH login. On a restored session it means the opposite, which is why the two are told apart by
#: where the session came from rather than by the code alone.
SESSION_ERROR_CODES = ("125023001", "125023002", "-1")


def _is_session_error(answer):
    try:
        code = str(((answer or {}).get("result") or {}).get("retCode") or "")
    except AttributeError:
        return False
    return code in SESSION_ERROR_CODES


@register
class IrisProvider(Provider):

    key = "iris"
    label = "Iris"
    supports_vod = True
    #: Lists slots, cannot free one — see [devices].
    supports_devices = True
    default_identity = {
        "user_agent": ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                       "(KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36"),
        "origin": BASE,
        "referer": BASE + "/EPG/jsp/webtv/index.html",
        "extra_headers": {"Accept": "application/json, text/plain, */*"},
    }

    def __init__(self, settings):
        Provider.__init__(self, settings)
        # cookies=True is not optional here — see the module docstring. The jar is kept on disk as well,
        # because the affinity it carries is half of what makes a session reusable at all.
        self.session = self._new_session()
        self.terminal_id = None
        self.user_token = ""
        self.logged_in = False
        #: True when this session came off the disk rather than from a fresh chain. A call that fails on
        #: a restored session is worth one retry; the same failure on a fresh one is real.
        self.session_restored = False
        #: True while the login chain is running, so the retry above cannot fire from inside it.
        self._logging_in = False
        #: Held while a dead session is being replaced. RE-ENTRANT on purpose: the login chain
        #: issues its own _post calls, and a plain Lock would deadlock the thread that took it.
        self._relogin_lock = threading.RLock()

    def _new_session(self, fresh=False):
        """
        The one place a session is built, because the jar FILE is the part that gets forgotten.

        It was: the constructor passed `cookie_file`, and the login retry built a replacement without it.
        A Session with no file keeps a plain CookieJar, `save_cookies()` then returns False without
        complaining (see net.Session), and `_store_session` calls it and does not look. So after any
        retried login the token was written to disk and the cookies were not — and the next tune restored
        a session whose load-balancer affinity was missing or stale, was refused with "user session not
        found", and paid for a full four-step login. Every channel change, for as long as that lasted.

        Nothing in the logs points at cookies; the message names a session timeout, which sends the
        reader to tokens. The fix is not "pass the argument in both places" — it is that there is only
        one place.

        [fresh] is the retry's meaning of a new session: start the affinity dance over. The file is
        REMOVED rather than skipped, so the new jar begins empty and can still be saved — skipping it
        is what broke this the first time.
        """
        path = self.cache_path(COOKIE_CACHE)
        if fresh:
            try:
                os.remove(path)
            except OSError:
                pass
        return net.Session(self.identity(), trace=self.settings.verbose(), cookies=True,
                           cookie_file=path)

    # ---- transport --------------------------------------------------------

    def _post(self, path, body=None, _retried=False):
        """
        One VSP call, with the retry Iris' own load shedding requires.

        503/429 are the only codes retried: a catalogue refresh fires hundreds of guide calls in a burst
        and Iris sheds rather than queues, so one transient 503 used to cost a whole channel's guide.
        Every other status is a real answer, and repeating it just burns the burst budget.
        """
        payload = json.dumps(body if body is not None else {})
        last = None
        for attempt in range(3):
            if attempt:
                time.sleep(attempt * 0.7)
            try:
                answer = self.session.post(BASE + path, body=payload.encode("utf-8"))
            except net.HttpError as err:
                if err.status not in (503, 429):
                    raise
                last = err
                continue
            # A SESSION THAT DIED WHILE IT WAS ON DISK, handled here and nowhere else.
            #
            # The stored session is offered to the next process without being proved (proving it costs
            # the round trip the store exists to save), so something has to notice when it turns out to
            # be dead. That was first written into `resolve()` alone — and `test-devices.py` found the
            # hole the same day, against the live account: the device screen asked for a list, the
            # restored session had expired, and it failed outright where it used to log in fresh.
            #
            # Every VSP call goes through here, so here is the only place that cannot be forgotten by
            # the next screen somebody adds. Once, and only for a session that came off the disk: the
            # same code on a session minted seconds ago is a real answer.
            # ONE THREAD LOGS IN, THE OTHERS WAIT AND USE WHAT IT GOT. The guide is fetched by up to
            # `epg_workers` threads sharing this instance, and "test the flag, then set it" is not
            # atomic — so two workers that hit the same dead session both went through the full
            # chain. On Iris that is not merely wasted work: every login REGISTERS the device, and
            # the account has a fixed number of slots. A refresh could quietly spend two.
            #
            # Inside the lock the question is asked again, because by then it is usually already
            # answered: a successful login clears session_restored, so the waiting thread simply
            # retries its call on the session the first one established.
            if (not _retried and self.session_restored and not self._logging_in
                    and _is_session_error(answer)):
                with self._relogin_lock:
                    if self.session_restored and not self._logging_in:
                        diag.log("Iris: the stored session was refused (%s) — logging in again"
                                 % path)
                        self.forget_session()
                        self.login()
                return self._post(path, body, _retried=True)
            return answer
        raise last

    @staticmethod
    def _check(response, action):
        """
        VSP errors live in `result.retCode` ("000000000" is success), NOT in the HTTP status — a refused
        call is a perfectly healthy 200. Reading only the status is how a device-limit rejection reads as
        success and then fails much later with an empty channel list.

        `retryable` is what `login()` reads to decide whether starting the chain over could help. A VSP
        refusal usually can be: the one that made the retry necessary in the first place is
        SwitchProfile's "125023001: user session not found or timeout", which clears by itself. A full
        subscription is the exception, and it is marked as such — repeating it cannot free a slot and
        every attempt is another chance to be counted against one.
        """
        result = (response or {}).get("result")
        if not isinstance(result, dict):
            return response
        code = str(result.get("retCode") or "000000000")
        if code and code != "000000000":
            message = str(result.get("retMsg") or "unknown error")
            if _looks_like_device_limit(message):
                raise ProviderError(
                    "Iris: nov uredjaj je odbijen (%s). Pretplata je verovatno popunila sva mesta "
                    "(obicno 3). Prekopiraj Device ID sa uredjaja na kome ovaj nalog vec radi, "
                    "umesto da registrujes novi."
                    % code)
            raise ProviderError("Iris %s: greska %s — %s" % (action, code, message), retryable=True)
        return response

    # ---- auth -------------------------------------------------------------

    def _device_id(self):
        """
        Iris counts devices per subscription like everyone else, and its rejection surfaces late — at
        TSSSOAuth, with real credentials, not at the guest Authenticate that happily accepts any fresh
        id. So a configured id is reused verbatim and only a genuinely empty setting mints one.
        """
        configured = self.setting("device_id").strip()
        if configured:
            return configured
        fresh = str(uuid.uuid4())
        self.remember("device_id", fresh)
        diag.log("Iris: minted a device id for this install (%s…) — paste it into another install to "
                 "share the same slot" % fresh[:8])
        return fresh

    def login(self):
        """
        The four-step chain, restarted whole while the failure is one that repeating can clear.

        SwitchProfile answers "125023001: user session not found or timeout" on the FIRST attempt when
        logging in again with the same device id shortly after a previous login — this account's own
        session cleanup lagging behind, not anything a client controls. A short delay and one repeat
        clears it every time.

        The third attempt, and the wait in front of it, are from a run on the box: TSSSOAuth answered
        twice within three seconds with a short body carrying no session at all, the tune failed in
        front of the viewer, and eight seconds later the identical request went through untouched. Two
        attempts 1.5 seconds apart cannot cross a gap that size, and the whole ladder still costs about
        ten seconds — spent only on a login that is already failing.

        What is NOT repeated is a verdict: a full subscription, or credentials TSSSOAuth answered with
        a retcode of its own. Those come back identically however long one waits, the viewer waits
        five and a half seconds to be told what was already known, and on the credential path every
        extra attempt is another failed sign-in against somebody's real account.
        """
        username = self.setting("username")
        password = self.setting("password")
        if not username or not password:
            raise ProviderError("Iris: unesi korisnicko ime i lozinku u podesavanjima.")
        self.terminal_id = self._device_id()

        self._logging_in = True
        try:
            return self._login_ladder(username, password)
        finally:
            self._logging_in = False

    def _login_ladder(self, username, password):
        last = None
        for attempt in range(3):
            if attempt:
                time.sleep(LOGIN_BACKOFF[attempt - 1])
                # A fresh jar as well: the point of the retry is to start the whole affinity dance over.
                self.session = self._new_session(fresh=True)
            try:
                self._attempt_login(username, password)
                return
            except ProviderError as err:
                # Whether repeating can help is the raiser's judgement, carried on the error itself.
                # It used to be decided here by looking for the word "mesta" in a Serbian sentence,
                # which is a rule that a rewording, a translation or a second refusal phrased
                # differently all break silently — and what breaks is a full subscription being asked
                # again, and again counted.
                if not err.retryable:
                    raise
                last = err
            except net.HttpError as err:
                last = ProviderError("Iris: server nije odgovorio (%s)" % err, retryable=True)
        raise last or ProviderError("Iris: prijava nije uspela.")

    def _attempt_login(self, username, password):
        terminal = self.terminal_id

        # 1. VSP Login — device model only.
        self._check(self._post("/VSP/V3/Login", {"deviceModel": DEVICE_MODEL}), "Login")

        # 2. Authenticate as GUEST (userType 3). This binds the physical device id to a slot, and it
        #    accepts any id — the real check comes one step later.
        auth = {
            "authenticateBasic": {
                "userType": 3,
                "authType": 0,
                "timeZone": "Europe/Belgrade",
                "isSupportWebpImgFormat": 1,
                "lang": "en",
                "needPosterTypes": ["1", "2", "3", "4", "5", "6", "7", "9", "10", "12"],
                "pageTrackerUIType": "HW_PC",
            },
            "authenticateDevice": {
                "physicalDeviceID": terminal,
                "terminalID": terminal,
                "authTerminalID": terminal,
                "deviceModel": DEVICE_MODEL,
                "OSVersion": "123",
                "terminalVendor": "Chrome",
                "CADeviceInfos": [{"CADeviceID": terminal, "CADeviceType": 7}],
            },
            "ignoreReLogin": True,
        }
        data = self._check(self._post("/VSP/V3/Authenticate", auth), "Authenticate") or {}
        self.user_token = data.get("userToken") or self.user_token

        # 3. TSSSOAuth — the real credentials. Its error is a TOP-LEVEL "retcode" (string "0" = OK),
        #    unlike every VSP call's nested result.retCode, so it needs its own check.
        oauth_body = {
            "terminalid": terminal,
            "mac": terminal,
            "terminaltype": DEVICE_MODEL,
            "terminalvendor": "OTT",
            "osversion": "Chrome - 150 (Windows - 10)",
            "timezone": "Europe/Belgrade",
            "templatename": "default",
            "cnonce": os.urandom(4).hex(),
            "userName": username,
            "subscriberId": username,
            "password": password,
            "softwareVersion": SOFTWARE_VERSION,
        }
        oauth = self._post("/EPG/JSON/TSSSOAuth", oauth_body) or {}
        retcode = str(oauth.get("retcode") or "")
        if retcode and retcode != "0":
            message = str(oauth.get("retmsg") or "unknown error")
            self._log_refusal(oauth)
            if _looks_like_device_limit(message):
                raise ProviderError(
                    "Iris: nov uredjaj je odbijen (%s). Pretplata je verovatno popunila sva mesta "
                    "(obicno 3). Prekopiraj Device ID sa uredjaja na kome ovaj nalog vec radi."
                    % retcode)
            if retcode in DEVICE_REFUSAL_CODES:
                # Named as being about the DEVICE, and retryable, because the alternative wording
                # ("prijava odbijena") reads as "your account was rejected" and is what sent the owner
                # to re-check a correct password after a login that succeeded seconds later.
                raise ProviderError(
                    "Iris: pristupna tacka je odbila OVAJ UREDJAJ (%s), nalog i lozinka nisu u pitanju. "
                    "Pokusavam ponovo; ako se ponovi, prekopiraj Device ID sa uredjaja na kome "
                    "ovaj nalog vec radi."
                    % retcode, retryable=True)
            raise ProviderError("Iris: prijava odbijena (%s) — %s" % (retcode, message))
        # THIS step's own session, with no falling back to the one the guest Authenticate handed over.
        # The old `or self.user_token` made a sessionless answer indistinguishable from a good one
        # whenever the guest step had produced a token: the chain walked on to SwitchProfile carrying a
        # token that had never seen the credentials — and could not work anyway, because the same short
        # answer also omits `profiles`, i.e. the profile password SwitchProfile is authenticated with.
        # A missing session here is a failed attempt and belongs on the retry ladder, not further down.
        token = oauth.get("userToken")
        if not token:
            self._log_refusal(oauth)
            # Seen on the box, twice in a row, three seconds apart, on an account that was working:
            # a short answer with neither a retcode to explain it nor a session to use, and the same
            # request succeeding untouched moments later. Naming it as passing weather matters,
            # because the old wording ("prijava je prosla ali server nije vratio token") reads like a
            # broken account and sends somebody to retype a password that was never wrong.
            raise ProviderError("Iris: server je odgovorio bez sesije — obicno prolazno, pokusaj "
                                "ponovo za nekoliko sekundi.", retryable=True)
        self.user_token = token

        # 4. SwitchProfile, with the PROFILE password from the login response — not the account
        #    password. They are different values and sending the account one fails.
        profile_password = ""
        for profile in oauth.get("profiles") or []:
            if not isinstance(profile, dict):
                continue
            if profile.get("id") == username or not profile_password:
                profile_password = profile.get("password") or profile_password
        switched = self._check(
            self._post("/VSP/V3/SwitchProfile", {"profileID": username, "password": profile_password}),
            "SwitchProfile") or {}
        self.user_token = switched.get("userToken") or self.user_token
        self.logged_in = True
        self.session_restored = False
        diag.log("Iris: logged in (device %s)" % terminal)
        self._store_session()

    @staticmethod
    def _log_refusal(oauth):
        """
        Why a login stopped, in one line that survives the trace's truncation.

        The ordinary HTTP trace keeps only the first MAX_BODY_SNIPPET characters of a body, which is
        right for the 19 KB success and wrong for the one answer anybody ever needs to read: a refused
        TSSSOAuth is around a kilobyte and opens with the same boilerplate as a good one, so the log
        showed two identical-looking lines and nothing about which field was missing. Field NAMES only
        — the values here include a session and a profile password.
        """
        diag.log("Iris: TSSSOAuth nije dalo sesiju — retcode=%r retmsg=%r, polja u odgovoru: %s"
                 % (oauth.get("retcode"), oauth.get("retmsg"), ", ".join(sorted(oauth)[:24]) or "(nema)"))

    def _ensure(self):
        if self.logged_in:
            return
        if self._load_session():
            return
        self.login()

    # ---- the session, kept between processes -------------------------------
    #
    # THE SINGLE BIGGEST COST IN FRONT OF AN IRIS CHANNEL CHANGE, and it was invisible because it is not
    # in this file's control flow at all: the plugin process lives for ONE tune, `logged_in` is instance
    # state, so every press of a channel ran the whole four-step chain — Login, Authenticate, TSSSOAuth,
    # SwitchProfile — four sequential round trips to the operator before PlayChannel was even sent.
    # EON has cached its session on disk since 0.5; Iris never did, and the reason is that its session
    # is only half token: the other half is the load balancer affinity held in COOKIES, and a cookie jar
    # that lives in memory dies with the process too. Both halves are stored now.
    #
    # It also spends fewer device slots. Iris allows three, every full login registers against one, and
    # a viewer zapping through twenty channels used to run twenty logins.

    def _session_path(self):
        return self.cache_path(SESSION_CACHE)

    def _load_session(self):
        """Restore a stored session, or answer False. Makes NO network call: proving the session works
        is what the tune itself does, and a probe would give back the round trip this exists to save."""
        try:
            with io.open(self._session_path(), "r", encoding="utf-8") as handle:
                data = json.loads(handle.read())
        except (OSError, IOError, ValueError):
            return False
        if not isinstance(data, dict) or time.time() >= (data.get("expires_at") or 0):
            return False
        # Bound to the account it was minted for, exactly as EON's is: changing the username in settings
        # must not keep playing the previous subscription.
        if data.get("account") != self._account_fingerprint():
            return False
        if not data.get("user_token") or not data.get("terminal_id"):
            return False
        self.terminal_id = data["terminal_id"]
        self.user_token = data["user_token"]
        self.logged_in = True
        self.session_restored = True
        diag.log("Iris: reusing the stored session (device %s)" % self.terminal_id)
        return True

    def _store_session(self):
        payload = {
            "account": self._account_fingerprint(),
            "expires_at": time.time() + SESSION_MAX_AGE,
            "terminal_id": self.terminal_id,
            "user_token": self.user_token,
        }
        try:
            with io.open(self._session_path(), "w", encoding="utf-8") as handle:
                handle.write(json.dumps(payload, ensure_ascii=False))
        except (OSError, IOError, ValueError) as err:
            diag.log("Iris: the session could not be stored (%s) — the next tune logs in again" % err)
            return
        self.session.save_cookies()

    def forget_session(self):
        for path in (self._session_path(), self.cache_path(COOKIE_CACHE)):
            try:
                os.remove(path)
            except OSError:
                pass
        self.logged_in = False
        self.session_restored = False
        self.user_token = ""

    def _account_fingerprint(self):
        """Username only — the password is not needed to tell one subscription from another, and this
        value is written to disk."""
        return hashlib.sha256((self.setting("username") or "").encode("utf-8")).hexdigest()[:16]

    # ---- catalogue --------------------------------------------------------

    def _subject_names(self):
        """
        subjectID -> category name for live TV, e.g. "1604" -> "Filmski".

        Iris does categorise its channels; each one carries `subjectIDs` mixing real genre subjects with
        `PRICATE…` *package* subjects. Only the former are categories. The names come from the same
        subject tree VOD uses, queried with contentTypes ["CHANNEL"].

        Deliberately only two levels deep (roots, then their children): that is ~11 requests and covers
        every genre actually in use, where a full recursive walk costs hundreds of calls per refresh for
        nothing. Only CHILD subjects are kept — the roots are shelf labels like "Live", never a category
        anyone wants to see.
        """
        def subjects(subject_id):
            try:
                data = self._post("/VSP/V3/QueryVODSubjectList", {
                    "subjectID": subject_id, "count": 200, "offset": 0, "contentTypes": ["CHANNEL"],
                }) or {}
            except (net.HttpError, ProviderError):
                return []
            out = []
            for entry in data.get("subjects") or []:
                if not isinstance(entry, dict):
                    continue
                sid, name = entry.get("ID") or "", entry.get("name") or ""
                if sid and name:
                    out.append((sid, name))
            return out

        names = {}
        try:
            for root_id, _root_name in subjects(""):
                for child_id, child_name in subjects(root_id):
                    names[child_id] = child_name
        except Exception as err:                                   # noqa: BLE001
            # Grouping is a nicety; the channel list is not. Never let this fail a refresh.
            diag.log("Iris: category names unavailable (%s); channels will be ungrouped" % err, "ERROR")
        return names

    def channels(self):
        self._ensure()
        subject_names = self._subject_names()
        data = self._check(self._post("/VSP/V3/QueryAllChannel", {}), "QueryAllChannel") or {}
        details = data.get("channelDetails") or []

        out = []
        play_cache = {}
        for index, obj in enumerate(details):
            if not isinstance(obj, dict):
                continue
            cid = str(obj.get("ID") or obj.get("id") or "")
            if not cid:
                continue
            name = (obj.get("name") or "").strip() or ("Channel %s" % cid)

            logo = ""
            icons = ((obj.get("picture") or {}).get("icons")) or []
            if icons:
                logo = icons[0] or ""

            # Media id for DASH live: fileFormat "4" first, else "2", else whatever is first.
            media_id = cid
            physical = obj.get("physicalChannels") or []
            picked = ""
            for wanted in ("4", "2"):
                for entry in physical:
                    if isinstance(entry, dict) and str(entry.get("fileFormat")) == wanted:
                        picked = str(entry.get("ID") or entry.get("id") or "")
                        break
                if picked:
                    break
            if not picked and physical and isinstance(physical[0], dict):
                picked = str(physical[0].get("ID") or physical[0].get("id") or "")
            if picked:
                media_id = picked

            # EVERY genre subject the channel belongs to, not just the first — IPTV Simple takes a
            # semicolon-separated list. The Android client keeps only one because its model has a
            # single group field.
            groups = []
            for sid in obj.get("subjectIDs") or []:
                sid = str(sid or "")
                if not sid or sid.startswith("PRICATE"):
                    continue
                label = subject_names.get(sid)
                if label and label not in groups:
                    groups.append(label)

            url = ("plugin://plugin.video.iptvbalkan/?action=play&provider=iris&id=%s%s"
                   % (cid, self._account_param()))
            entry = {
                "id": self.scoped("iris_%s" % cid),
                "provider": self.key,
                "provider_label": self.label,
                "provider_ref": cid,
                "name": name,
                "tvg_id": "iris_%s" % cid,
                "number": index + 1,
                "logo": logo,
                "group": ";".join(groups),
                # Every channel is offered with catch-up. There is NO per-channel CUTV flag in
                # QueryAllChannel to gate on — the payload carries no CUTVStatus at all, and a guess at
                # one is what silently disabled replay on every channel in the Android client. Real
                # eligibility is per programme and only the CUTV call knows it, so an unavailable
                # programme fails with a clear message instead of never being offered.
                "catchup_days": CATCHUP_DAYS,
                # VOD, not the default timeshift mode — see the comment in playlist.py. A CUTV resolve
                # returns a static manifest for the WHOLE programme, so the player seeks inside it and
                # the addon is entered exactly once per replay instead of once per seek.
                "catchup_mode": "vod",
                # …and the matching half of that decision: the programme is played as a VIDEO, with the
                # bar Kodi draws taken from the manifest we hand it rather than from its live model.
                # Without this the media is correct and the timeline over it is not — see the long note
                # in playlist.py for why the two settings have to agree and how the per-channel opt-out
                # works. EON leaves this alone and keeps the PVR overlay.
                "catchup_play_as_live": False,
                "catchup_source": url + "&utc={utc}",
                "url": url,
                # Deliberately NO manifest_type/license_* here. The playlist entry points at a
                # `plugin://` URL, and a #KODIPROP on it would tell Kodi to hand that plugin address
                # itself to inputstream.adaptive as if it were a DASH manifest. Everything the player
                # needs — manifest type, Widevine licence URL, the per-tune customData header — is set
                # by default.py at resolve time, which is the only moment those values exist.
            }
            out.append(entry)
            # CUTV needs the WHOLE raw channel object echoed back, so it is cached rather than refetched:
            # QueryAllChannel is one large response and re-fetching it per replay tune would put a
            # visible delay in front of every rewind.
            play_cache[cid] = {"media_id": media_id, "raw": obj}

        _write_json(self._cache_path(PLAY_CACHE), play_cache)
        diag.log("Iris: %d channels" % len(out))
        return out

    def epg(self, channels, hours_back=None, hours_forward=None):
        """
        The guide, asked for THIRTY channels at a time rather than one.

        `QueryPlaybillListStcProps` takes a LIST of channel ids and answers with one block per channel —
        the plural in `channelPlaybills` was always the hint. Asking per channel made this account's 467
        channels cost up to 2,300 requests, which on a box runs past the guide budget and stops with the
        guide half-built. The batch limit was measured against the live API, not assumed: 30 is accepted,
        40 comes back "channelIds size is over limit!", and `count` above 100 is refused outright.

        The window is clamped to what Iris will actually serve — see CATCHUP_DAYS.
        """
        self._ensure()
        back = min(hours_back if hours_back else CATCHUP_DAYS * 24, CATCHUP_DAYS * 24)
        forward = min(hours_forward if hours_forward else 24, 48)
        now = int(time.time() * 1000)
        start, end = now - back * 3600000, now + forward * 3600000
        budget_until = time.time() + self.settings.get_int("iris_epg_budget_sec", 300)

        out, done, failed = [], 0, 0
        batches = [channels[first:first + EPG_CHANNEL_BATCH]
                   for first in range(0, len(channels), EPG_CHANNEL_BATCH)]

        # A WINDOW OF BATCHES AT A TIME. Batching already made this thirty channels per request instead
        # of one; the batches are independent, so the only thing left is to stop waiting for each in
        # turn. The budget and Kodi's shutdown are still checked BETWEEN windows, which is what keeps
        # "stop now" meaning at most `workers` requests still in the air rather than the whole guide.
        #
        # Results are collected by POSITION and merged in order: a guide assembled in arrival order is
        # a guide that differs between two identical refreshes, and a diff nobody can read is how a real
        # change hides.
        workers = max(1, min(8, self.settings.get_int("epg_workers", 4)))
        results = {}
        pending = list(enumerate(batches))

        def fetch(position, batch):
            try:
                results[position] = (self._epg_for_batch(batch, start, end), None)
            except (net.HttpError, ProviderError) as err:
                results[position] = ([], err)

        while pending:
            if time.time() > budget_until:
                diag.log("Iris: guide budget spent after %d/%d channels — the rest follows next refresh"
                         % (done, len(channels)))
                break
            # See Provider.stopping: a refresh that keeps working through Kodi's shutdown is what an
            # unresponsive box looks like from the sofa.
            if self.stopping():
                diag.log("Iris: Kodi is closing — the guide stops after %d/%d channels"
                         % (done, len(channels)))
                break
            window, pending = pending[:workers], pending[workers:]
            threads = [threading.Thread(target=fetch, args=(position, batch))
                       for position, batch in window]
            for thread in threads:
                thread.daemon = True
                thread.start()
            for thread in threads:
                thread.join()
            done += sum(len(batch) for _position, batch in window)

        for position in sorted(results):
            programmes, err = results[position]
            if err is not None:
                failed += len(batches[position])
                done -= len(batches[position])
                continue
            out.extend(programmes)
        if failed:
            diag.log("Iris: guide failed on %d channels" % failed, "ERROR")
        diag.log("Iris: %d programmes over %d channels" % (len(out), done))
        return out

    def _epg_for_batch(self, batch, start, end):
        """One batch of channels, paged until every one of them is exhausted."""
        # Programmes are matched to their channel by the `channelID` each one carries, NOT by the order
        # of the blocks: a block itself holds only `playbillCount`, so position is the only other thing
        # to go on and trusting it would silently hang one channel's guide on another's row.
        by_ref = {}
        for ch in batch:
            by_ref[str(ch["provider_ref"])] = ch
        out, offset = [], 0
        while offset < EPG_MAX_PROGRAMMES:
            body = {
                "needChannel": 0,
                "queryChannel": {"channelIDs": [str(c["provider_ref"]) for c in batch]},
                "queryPlaybill": {"type": 0, "startTime": start, "endTime": end,
                                  "count": EPG_PAGE_SIZE, "offset": offset, "isFillProgram": 2},
            }
            data = self._check(self._post("/VSP/V3/QueryPlaybillListStcProps", body),
                               "QueryPlaybillListStcProps") or {}
            biggest = 0
            for block in data.get("channelPlaybills") or []:
                items = (block or {}).get("playbillLites") or []
                biggest = max(biggest, len(items))
                for item in items:
                    if not isinstance(item, dict):
                        continue
                    ch = by_ref.get(str(item.get("channelID") or ""))
                    if ch is None:
                        continue
                    begin = _as_int(item.get("startTime"))
                    stop = _as_int(item.get("endTime"))
                    title = item.get("name") or ""
                    if begin <= 0 or stop <= 0 or not title:
                        continue
                    out.append({
                        "channel_id": ch["tvg_id"],
                        "start": _xmltv_time(begin),
                        "stop": _xmltv_time(stop),
                        "title": title,
                        "desc": item.get("introduce") or "",
                        "category": "",
                    })
            # Done when the FULLEST channel in the batch came back short — a channel that ran out earlier
            # simply returns nothing on the later pages.
            if biggest < EPG_PAGE_SIZE:
                break
            offset += EPG_PAGE_SIZE
        return out

    # ---- playback ---------------------------------------------------------

    def _cache_path(self, name):
        return self.cache_path(name)

    def _play_entry(self, channel_ref):
        entry = _read_json(self._cache_path(PLAY_CACHE)).get(str(channel_ref))
        if entry:
            return entry
        # Miss: a channel added since the last refresh, or a play before any refresh ran.
        data = self._check(self._post("/VSP/V3/QueryAllChannel", {}), "QueryAllChannel") or {}
        for obj in data.get("channelDetails") or []:
            if isinstance(obj, dict) and str(obj.get("ID") or obj.get("id") or "") == str(channel_ref):
                return {"media_id": str(obj.get("ID") or channel_ref), "raw": obj}
        raise ProviderError("Iris: kanal %s nije u listi ovog naloga." % channel_ref)

    #: How far BEFORE a programme's start the request for it may arrive.
    #:
    #: IPTV Simple does not ask for the start time. It asks for the start MINUS
    #: `catchupWatchEpgBeginBufferMins`, a hidden setting whose default is 5 minutes, so that a programme
    #: which ran late is still caught from the beginning. For EON that costs nothing — its URL carries an
    #: instant, so the stream merely starts a few minutes early. For Iris it changed WHICH PROGRAMME was
    #: played: replay is addressed by `playbillID`, that id is looked up FROM the instant, and five
    #: minutes before a programme starts is inside the PREVIOUS one. Confirmed on the box: picking a
    #: programme from the guide played the one before it.
    #:
    #: Ten minutes rather than five, so a box whose buffer has been raised is still right, and short
    #: enough that it can only ever reach the programme immediately after the instant.
    CATCHUP_LEAD_IN_MS = 10 * 60 * 1000

    def _playbill_at(self, channel_ref, at_utc):
        """
        Turn a wall-clock time back into the programme id CUTV wants.

        IPTV Simple templates catch-up URLs with `{utc}` while Iris addresses replay by `playbillID`.
        One narrow guide lookup bridges the two, and the rule for choosing is not "which programme
        contains this instant" — see CATCHUP_LEAD_IN_MS for why that answered with the wrong show.

        A programme STARTING at or just after the instant wins over one that merely contains it. Both
        callers are served by that: IPTV Simple asks a few minutes early for the programme that follows,
        and the addon's own search screen asks with a programme's exact start, where the two rules agree.
        Containment remains the fallback for an instant genuinely inside a programme with nothing due.
        """
        at_ms = int(at_utc) * 1000
        body = {
            "needChannel": 0,
            "queryChannel": {"channelIDs": [str(channel_ref)]},
            "queryPlaybill": {"type": 0, "startTime": at_ms - 4 * 3600000,
                              "endTime": at_ms + 4 * 3600000,
                              "count": EPG_PAGE_SIZE, "offset": 0, "isFillProgram": 2},
        }
        data = self._check(self._post("/VSP/V3/QueryPlaybillListStcProps", body),
                           "QueryPlaybillListStcProps") or {}
        starting, containing = None, ""
        best, best_distance = "", None
        for block in data.get("channelPlaybills") or []:
            for item in (block or {}).get("playbillLites") or []:
                if not isinstance(item, dict):
                    continue
                begin, stop = _as_int(item.get("startTime")), _as_int(item.get("endTime"))
                pid = str(item.get("ID") or "")
                if not pid or begin <= 0:
                    continue
                # The one being asked for: it starts at the instant, or within the lead-in after it.
                if at_ms <= begin <= at_ms + self.CATCHUP_LEAD_IN_MS:
                    if starting is None or begin < starting[0]:
                        starting = (begin, pid)
                elif begin <= at_ms < stop and not containing:
                    containing = pid
                distance = abs(begin - at_ms)
                if best_distance is None or distance < best_distance:
                    best, best_distance = pid, distance
        chosen = (starting[1] if starting else "") or containing or best
        if not chosen:
            raise ProviderError("Iris: za taj termin nema emisije u vodicu, pa nema sta da se pusti.")
        return chosen

    # ---- on demand --------------------------------------------------------

    def vod(self, node=None):
        """
        The Video klub. Iris organises it as a tree of "subjects", so this walks that tree.

        One thing about that tree is not obvious and cost the standalone client a round: a node can hold
        sub-categories OR titles OR both, and asking a titles-only node for its children answers
        `ERR-144020010: is a leaf subject`. That is not a failure — it means "no sub-categories here" —
        so both calls are made and whatever comes back is shown.
        """
        self._ensure()
        node = node or VOD_ROOT_SUBJECT
        if node.startswith("series:"):
            return self._vod_episodes(node.split(":", 1)[1])

        out = []
        for subject in self._vod_subjects(node):
            out.append({"kind": "dir", "name": subject["name"], "node": subject["id"]})
        out.extend(self._vod_titles(node))
        return out

    def _vod_subjects(self, subject_id):
        try:
            data = self._check(self._post("/VSP/V3/QueryVODSubjectList", {
                "subjectID": subject_id, "count": 100, "offset": 0, "contentTypes": ["VOD"]}),
                "QueryVODSubjectList") or {}
        except (ProviderError, net.HttpError):
            # A leaf subject answers with an error rather than an empty list; see the docstring above.
            return []
        out = []
        for subject in data.get("subjects") or []:
            # `child_id`, not `subject_id`: reusing the parameter name here overwrote the subject this
            # function was CALLED for. Harmless today only because nothing reads it after the loop —
            # which is precisely how the same shape went unnoticed in the Video klub until every series
            # stopped opening. The check in check-addon.py now refuses this pattern outright.
            child_id = str((subject or {}).get("ID") or "")
            if child_id:
                out.append({"id": child_id, "name": subject.get("name") or "?"})
        return out

    def _vod_titles(self, subject_id):
        out, offset = [], 0
        while offset < VOD_MAX_TITLES:
            try:
                data = self._check(self._post("/VSP/V3/QueryVODListStcPropsBySubject", {
                    "subjectID": subject_id, "count": VOD_PAGE_SIZE, "showAdult": False,
                    "offset": offset, "VODFilter": {"ratingID": "18"},
                    "VODExcluder": {"supersetType": "1"}}), "QueryVODListStcPropsBySubject") or {}
            except (ProviderError, net.HttpError):
                break
            items = data.get("VODs") or []
            if not items:
                break
            for item in items:
                entry = _vod_entry(item)
                if entry:
                    out.append(entry)
            if len(items) < VOD_PAGE_SIZE:
                break
            offset += len(items)
        return out

    def _vod_episodes(self, vod_id):
        """
        A series' children.

        Each row nests the child under `"VOD"` with its position in `sitcomNO` alongside — it is NOT a
        flat object, and reading `ID` at the top level comes back empty, which reads as "this series has
        no episodes" rather than "you read the wrong level".
        """
        data = self._check(self._post("/VSP/V3/QueryEpisodeList",
                                      {"VODID": vod_id, "offset": 0, "count": 100}),
                           "QueryEpisodeList") or {}
        out = []
        for row in data.get("episodes") or []:
            child = (row or {}).get("VOD") or {}
            entry = _vod_entry(child)
            if not entry:
                continue
            try:
                number = int((row or {}).get("sitcomNO") or len(out) + 1)
            except (TypeError, ValueError):
                number = len(out) + 1
            entry["name"] = "%02d  %s" % (number, entry["name"])
            entry["_sort"] = number
            out.append(entry)
        return sorted(out, key=lambda e: e.pop("_sort"))

    def _resolve_vod(self, vod_id):
        """
        One on-demand title: its detail, then PlayVOD against the right media file.

        The media file is chosen by FORMAT, not by position. Every title carries two — `fileFormat` 4
        (DASH) and 2 (HLS) — in an order that varies per title, and the HLS one is FairPlay-only, which
        nothing outside Apple can decrypt. Taking whichever came first is exactly why playback used to
        look random: neighbouring titles, one playing and one failing with an opaque source error.
        """
        detail_raw = self._check(self._post("/VSP/V3/QueryVOD", {"VODID": str(vod_id)}), "QueryVOD") or {}
        detail = detail_raw.get("VODDetail") or detail_raw

        media_id = ""
        files = detail.get("mediaFiles") or []
        for wanted in ("4", "2", None):
            for media in files:
                if wanted is not None and str((media or {}).get("fileFormat") or "") != wanted:
                    continue
                media_id = str((media or {}).get("ID") or (media or {}).get("id") or "")
                if media_id:
                    break
            if media_id:
                break
        if not media_id:
            # Deliberately NOT falling back to the title's own id. A series or season legitimately has no
            # media of its own, and sending its id as a mediaID asks the server for a file that was never
            # meant to exist — which it reports as "VodMediaFile do not exist", a baffling way to say
            # "you handed me a folder".
            raise ProviderError("Iris: „%s“ nema medija za reprodukciju — otvori naslov i izaberi "
                                "epizodu." % (detail.get("name") or vod_id))

        data = self._check(self._post("/VSP/V3/PlayVOD", {
            "VODID": str(vod_id), "mediaID": media_id,
            "checkLock": {"checkType": 0}}), "PlayVOD") or {}
        url = data.get("playURL") or data.get("attachedPlayURL") or ""
        if not url:
            raise ProviderError("Iris: server nije vratio adresu strima za taj naslov.")

        result = {"url": url, "manifest_type": "mpd",
                  "headers": {k: v for k, v in self.session.headers_for().items()
                              if k in ("User-Agent", "Referer", "Origin")}}
        triggers = ((data.get("authorizeResult") or {}).get("triggers")) or []
        if triggers and isinstance(triggers[0], dict):
            licence_url = triggers[0].get("licenseURL") or ""
            custom_data = triggers[0].get("customData") or ""
            if licence_url and custom_data:
                result["license_type"] = "com.widevine.alpha"
                result["license_key"] = "%s|%s|R{SSM}|" % (
                    licence_url,
                    "&".join(["acquirelicense.customdata=" + custom_data,
                              "Content-Type=application/octet-stream"]))
        return result

    def resolve(self, channel_ref, at_utc=None, vod=False):
        """
        A tune.

        The session on disk is offered without being proved first — proving it would cost the round trip
        the store exists to save — and the recovery when it turns out to be dead lives in `_post`, which
        every call goes through. It was written here first, and `test-devices.py` found the hole within
        the hour: the device screen does not tune, so it was not covered.
        """
        return self._resolve_once(channel_ref, at_utc, vod)

    def _resolve_once(self, channel_ref, at_utc=None, vod=False):
        if vod:
            self._ensure()
            return self._resolve_vod(channel_ref)
        self._ensure()
        entry = self._play_entry(channel_ref)
        media_id = entry.get("media_id") or str(channel_ref)

        if at_utc:
            body = {
                "channelID": str(channel_ref),
                "mediaID": media_id,
                "businessType": "CUTV",
                "playbillID": self._playbill_at(channel_ref, at_utc),
            }
            # The web client echoes the whole channel object back on CUTV and the call fails without it.
            if entry.get("raw"):
                body["channel"] = entry["raw"]
        else:
            body = {"channelID": str(channel_ref), "mediaID": media_id, "businessType": "BTV"}

        data = self._check(self._post("/VSP/V3/PlayChannel", body), "PlayChannel") or {}
        # The stream URL is the TOP-LEVEL playURL. `authorizeResult.playURL` exists and is always empty —
        # reading that one gives a blank URL on a perfectly successful call.
        url = data.get("playURL") or data.get("attachedPlayURL") or ""
        if not url:
            raise ProviderError("Iris: server nije vratio adresu strima za taj kanal.")

        licence_url, custom_data = "", ""
        triggers = ((data.get("authorizeResult") or {}).get("triggers")) or []
        if triggers and isinstance(triggers[0], dict):
            licence_url = triggers[0].get("licenseURL") or ""
            custom_data = triggers[0].get("customData") or ""

        # Remembered so the resident service can keep the stream alive; Iris drops one that stops
        # reporting, and this plugin process ends the moment playback starts.
        # The URL is stored alongside the ids so the service can tell whether what Kodi is playing RIGHT
        # NOW is still this stream. Without it, "is something playing" was the only test available, and
        # zapping from an Iris channel to anything else — an EON channel, a film in another addon — left
        # this file in place and the heartbeat running: MTS went on counting a stream nobody was
        # watching, and on an account with one or two concurrent streams the second TV in the house was
        # refused. Stopping playback cleaned it up; changing channel did not.
        _write_json(self._cache_path(NOW_PLAYING),
                    {"channel_id": str(channel_ref), "media_id": media_id, "url": url,
                     "since": int(time.time())})

        result = {
            "url": url,
            "manifest_type": "mpd",
            "headers": {k: v for k, v in self.session.headers_for().items()
                        if k in ("User-Agent", "Referer", "Origin")},
        }
        if licence_url and custom_data:
            result["license_type"] = "com.widevine.alpha"
            # inputstream.adaptive's licence key is `url|request headers|request body|response`. The JWT
            # travels as a REQUEST HEADER (`acquirelicense.customdata`), which is what the Android client
            # sends and what the licence server expects; `R{SSM}` posts the raw challenge back.
            result["license_key"] = "%s|%s|R{SSM}|" % (
                licence_url,
                "&".join(["acquirelicense.customdata=" + custom_data,
                          "Content-Type=application/octet-stream"]))
        elif licence_url:
            diag.log("Iris: channel %s returned a licence URL but no customData — playing without DRM"
                     % channel_ref)
        return result

    def playing_url(self):
        """The stream this provider last handed to the player, or "" if it handed out none."""
        return (_read_json(self._cache_path(NOW_PLAYING)) or {}).get("url") or ""

    def heartbeat(self):
        """
        Keeps the current stream alive. Called by service.py roughly once a minute while something is
        playing; returns False when there is nothing to keep alive so the caller can stop.
        """
        state = _read_json(self._cache_path(NOW_PLAYING))
        channel_id, media_id = state.get("channel_id"), state.get("media_id")
        if not channel_id or not media_id:
            return False
        self._ensure()
        try:
            self._post("/VSP/V3/PlayChannelHeartbeat", {"mediaID": media_id, "channelID": channel_id})
        except (net.HttpError, ProviderError) as err:
            diag.log("Iris: heartbeat failed (%s)" % err)
        return True

    def stop_heartbeat(self):
        try:
            os.remove(self._cache_path(NOW_PLAYING))
        except OSError:
            pass

    # ---- device slots -----------------------------------------------------

    def devices(self):
        """
        The subscription's registered devices.

        Read-only on purpose, and that is Iris' limit rather than a shortcut: `QueryDeviceList` answers,
        but the Android client — which has been against this account for months — found no call that
        removes one, and inventing an endpoint name to try would be guessing with someone's
        subscription. So the screen lists them and says where the removal has to happen.
        """
        self._ensure()
        data = self._check(self._post("/VSP/V3/QueryDeviceList",
                                      {"deviceType": "2", "subscriberID": self.setting("username")}),
                           "QueryDeviceList") or {}
        mine = (self.terminal_id or self.setting("device_id") or "").strip()
        out = []
        for entry in data.get("devices") or []:
            if not isinstance(entry, dict):
                continue
            physical = str(entry.get("physicalDeviceID") or "")
            identifier = str(entry.get("ID") or physical)
            if not identifier:
                continue
            bits = ["na mrezi" if str(entry.get("onlineState") or "0") == "1" else "nije na mrezi"]
            if entry.get("deviceModel"):
                bits.append(str(entry["deviceModel"]))
            out.append({
                "id": identifier,
                "name": (entry.get("name") or "").strip() or identifier,
                "detail": ", ".join(bits),
                # Matched on the PHYSICAL id, which is what this addon registers itself as — the `ID`
                # is Iris' own row key and never equals our terminal id.
                "current": bool(mine) and physical == mine,
            })
        return out

    # ---- diagnostics ------------------------------------------------------

    def diagnose(self):
        rows = []
        ok, detail = net.probe(self.session, BASE + "/EPG/jsp/webtv/index.html")
        rows.append(("Iris reachable", ok, detail))
        if not ok:
            return rows
        try:
            self.login()
            rows.append(("Account login", True, "device %s" % self.setting("device_id")))
        except Exception as err:                                   # noqa: BLE001
            rows.append(("Account login", False, str(err)))
            return rows
        try:
            channels = self.channels()
            rows.append(("Channel list", bool(channels), "%d channels" % len(channels)))
        except Exception as err:                                   # noqa: BLE001
            rows.append(("Channel list", False, "%s: %s" % (type(err).__name__, err)))
        return rows


# ---- helpers ---------------------------------------------------------------

def _vod_entry(item):
    """
    One Video klub row.

    `VODType` is what tells a playable title from a folder: "0" owns media files, "2" is a series and
    "3" a season. Handing a container to PlayVOD is what produced "VodMediaFile do not exist" on every
    single series — it has no media of its own, only children.
    """
    vod_id = str((item or {}).get("ID") or "")
    name = (item or {}).get("name") or ""
    if not vod_id or not name:
        return None
    container = str(item.get("VODType") or "") in ("2", "3")
    picture = item.get("picture") or {}
    poster = ""
    for key in ("icons", "stills"):
        values = picture.get(key) or []
        if values:
            poster = str(values[0] or "")
            if poster:
                break
    entry = {"kind": "dir" if container else "item", "name": name,
             "logo": poster, "plot": item.get("summary") or ""}
    if container:
        entry["node"] = "series:%s" % vod_id
    else:
        entry["id"] = vod_id
    return entry


#: TSSSOAuth retcodes that are about the DEVICE, not about the credentials, and that a repeat of the
#: whole chain has been seen to clear.
#:
#: The words are the normal way to tell those apart, and for these codes there are none: `67174404`
#: arrives as `ERR- 1: Unknown`, which is not a message so much as a placeholder. That was reported from
#: the box as `prijava odbijena (67174404)` immediately followed by a successful login and normal
#: playback — so the addon announced a refused ACCOUNT, sending its owner to check a password that was
#: never wrong, about a login that then worked on its own.
#:
#: Be clear about what is and is not known here. That these codes concern the device is established;
#: that a retry clears them is measured, twice, in the field. What each one MEANS inside the VSP is not
#: — there is no published table, and the numbers are opaque — so nothing here claims a cause. They are
#: retried and, only if all three attempts fail, reported as naming the DEVICE.
#:
#: This is deliberately NOT the same thing as a full subscription. That refusal is wordy, is caught by
#: [_looks_like_device_limit], and is never repeated: repeating it cannot free a slot and every attempt
#: is one more login counted against the account.
DEVICE_REFUSAL_CODES = ("67174404", "33619984")


def _looks_like_device_limit(message):
    """
    Is this rejection about a FULL subscription, or merely about a device?

    Any single one of these words used to be enough, so "terminal not registered" — a different problem
    with a different fix — told the user their three slots were full and to go copy a device id out of
    the Android app. Advice that confident and that wrong costs more than no advice. A limit message
    has to name both a subject and the exhaustion.
    """
    low = (message or "").lower()
    subject = any(word in low for word in ("device", "terminal", "uredjaj", "uređaj"))
    exhausted = any(word in low for word in ("limit", "exceed", "maximum", "max ", "too many",
                                             "reached", "full", "mesta", "popunj"))
    return subject and exhausted


def _as_int(value):
    try:
        return int(str(value))
    except (TypeError, ValueError):
        return 0


def _xmltv_time(millis):
    return time.strftime("%Y%m%d%H%M%S +0000", time.gmtime(millis / 1000.0))


def _read_json(path):
    try:
        with open(path, "r", encoding="utf-8") as handle:
            data = json.loads(handle.read())
        return data if isinstance(data, dict) else {}
    except (OSError, IOError, ValueError):
        return {}


def _write_json(path, data):
    try:
        with open(path, "w", encoding="utf-8") as handle:
            handle.write(json.dumps(data, ensure_ascii=False))
    except (OSError, IOError, ValueError) as err:
        diag.log("Iris: could not write %s (%s)" % (os.path.basename(path), err), "ERROR")
