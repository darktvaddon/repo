# -*- coding: utf-8 -*-
"""
Move TV (MTS-SI) — ported from `MoveApi.kt`, which is verified against a live account (301 channels,
playback working).

This file was rewritten rather than patched. The first version was built from guesswork rather than
from the working client, and every layer of it was wrong: a different host (`api.mts-si.tv` instead of
`api2.mts-si.tv/api/v2`), GET instead of POST, a Bearer header instead of `X-Auth-Token`, and field
names — `id`, `name`, `channelNumber`, `logoUrl`, `categoryName` — that this API does not serve. It
could never have worked, and it was carried for weeks as "written but unproven", which is the polite
form of "not written".

Three things about this provider that are not guessable and are the reason to port rather than invent:

**A channel has TWO ids.** `contentId` keys the guide; `liveId` mints the stream. They are different
numbers for the same channel and swapping them fails in different ways at different times.

**The stream token is a HEADER.** `/content/live/source/get` returns a plain DASH manifest plus
`protection.headerValue`, and that value has to ride as `X-Play-Auth` on the manifest AND on every
media segment — which is what the resolved stream's headers are for.

**A 200 is not success.** Every response carries `{"success": bool}`, and a 200 with `success:false` is
a real failure with a real message in it. Reading only the status code loses the reason.

**Catch-up works as of 2026-08-03.** It was withheld for a long time and the reason is worth keeping:
the provider reports a real archive window per channel (168h is typical) but the per-programme source
call had never been captured, so advertising an archive that could not be minted would have put a
Replay button on every programme that then silently played live. The call was finally caught from a
live session at play.move.tv — `/content/epg/source/get`, taking `epgId` + `contentId` — and the
window that was being read and discarded all along now becomes `catchup_days`.

A replay resolves to `index-<start>-<duration>.mpd`: ONE STATIC manifest holding exactly that
programme. Hence `catchup_mode: "vod"` and `catchup_play_as_live: False` — the addon is entered once
per replay and the player seeks inside the media, so Kodi must draw the bar from the manifest rather
than from its live model. That costs the PVR overlay, the same trade Iris makes; EON escapes it only
because its archive is HLS with a sliding window that ffmpegdirect can run as a timeshift. It is not
about DRM — Move's catch-up has none.
"""

import calendar
import hashlib
import json
import os
import re
import time
import uuid

from .. import diag, net, store
from ..provider import Provider, ProviderError, register

BASE = "https://api2.mts-si.tv/api/v2"
WEB_ORIGIN = "https://play.move.tv"
#: Relative image paths (`/images/logo/rts-1_2_dark.png`) hang off this host.
IMAGE_BASE = "https://edge-mts-si-2.mts-si.tv"

#: Fixed client identity, exactly as the real web client sends it.
PARTNER_ID = 2
DEVICE_MODEL_ID = 10
DEVICE_NAME = "Chrome 150"
APP_VERSION = "3.4.8"
#: 1 = Serbian. Move TV is a Serbian service; no other locale is worth exposing.
LANG = 1
#: `dtype` in the live-source request. 1 = DASH, which is what the web client asks for.
DTYPE_DASH = 1

#: contentTypeId / contentSubTypeId — the same two values under two names (from vod/filters).
TYPE_FILM = 2
TYPE_SERIES = 5
#: Pages pulled per catalogue. Move pages the Video klub and there are 36 catalogues; walking all
#: of them to the end would take longer than the whole rest of a refresh.
VOD_MAX_PAGES = 3

#: The API wants the literal string "null" for an unauthenticated request — an ABSENT header is a
#: different thing to this server, and the login call is the one that depends on it.
UNAUTHENTICATED = "null"

#: Where a channel with no genre is filed. Deliberately NOT run through T(): this is a channel GROUP
#: name, and it goes into the playlist, IPTV Simple's database and Kodi's own PVR tables. A group whose
#: name followed the interface language would become a SECOND group the moment someone switched
#: language, splitting one row of channels into two. The Video klub's own "Ostalo" is a screen label and
#: is translated — same word, different job.
GROUP_OTHER = "Ostalo"

#: What a Move client id looks like — a uuid, optionally with the server-appended ".<partnerId>".
_UID_SHAPE = re.compile(r"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}(\.\d+)?$")

PLAY_AUTH_HEADER = "X-Play-Auth"
#: The token carries its own expiry: `hash-…-expires-1784821848-cusid-…`.
_PLAY_AUTH_EXPIRY = re.compile(r"expires-(\d+)")

#: Channel-list rows are the only place liveId is served, and the play route needs it at tune time.
#: Cached beside the playlist rather than refetched, the same way EON caches its play descriptors.
PLAY_CACHE = "move_play.json"
#: The logged-in session, kept between PROCESSES. The plugin runs for exactly one action — one tune,
#: one Video klub screen — so a token held only in memory is a token thrown away at the moment it
#: becomes useful, and every screen paid for another sign-in. See _load_session.
SESSION_CACHE = "move_session.json"
#: Move's own answer carries the lifetime it means: `"t": 32400`, nine hours. Six is used instead —
#: comfortably inside it, and it means a session that goes stale early costs one re-login rather than
#: a screen of refusals. Same number Iris uses, for the same reason.
SESSION_MAX_AGE = 6 * 3600


@register
class MoveProvider(Provider):

    key = "move"
    label = "Move TV"
    #: THE VIDEO KLUB WAS BUILT AND THEN COULD NOT BE PLAYED, because this line was missing.
    #:
    #: default.py gates the on-demand call on it — `if vod and provider.supports_vod` — so without it
    #: every press on a film or an episode fell through to the LIVE branch: resolve() looked the title
    #: up as a channel, missed, re-fetched all 302 channels to be sure, missed again, and the viewer got
    #: "taj kanal nije u listi" on a film. The catalogue screens all worked, which is what made it look
    #: like a playback problem rather than a missing flag. Seen on the owner's box on 2026-08-04 at
    #: 07:48:57 and 07:49:08 — twice, ten seconds apart, and both times the log shows /content/live/all
    #: for something that was never a channel. test-tune.py now refuses a provider that offers a Video
    #: klub without declaring it.
    supports_vod = True
    default_identity = {
        "user_agent": ("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
                       "(KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36"),
        "origin": WEB_ORIGIN,
        "referer": WEB_ORIGIN + "/",
        "extra_headers": {"Accept": "*/*"},
    }

    def __init__(self, settings):
        Provider.__init__(self, settings)
        self.session = net.Session(self.identity(), trace=settings.verbose())
        self.token = ""
        self.customer = 0
        self.profile = 0
        #: True when this session came off the disk rather than from a fresh sign-in. A refusal on a
        #: restored session is worth one silent re-login; the same refusal on a fresh one is real.
        self.session_restored = False
        #: True while the login chain runs, so the retry in _post cannot fire from inside it.
        self._logging_in = False

    # ---- transport --------------------------------------------------------

    def _post(self, path, body, authenticated=True, _retried=False):
        """
        Every call to Move goes through here, and so does the one recovery it needs.

        A session is now read off disk (see _load_session), which is what makes this necessary: before
        that, every process signed in first and a token could not be stale. A restored one can be — the
        account was used elsewhere, the server dropped it, six hours passed on their clock and not on
        ours — and the refusal arrives at whatever the viewer just pressed.
        `
        So: one silent re-login and one repeat, HERE rather than in the callers. Iris shipped this retry
        inside resolve() alone and the guide kept failing; Yettel shipped _ensure in some entry points
        and not others. One funnel, one place to be wrong.

        Guarded three ways so it cannot become a login loop: only for a session that was RESTORED (a
        refusal on a freshly-minted token is real and must be shown), only once per call, and never
        while the login chain itself is running.
        """
        def _refused(err):
            if not authenticated or _retried or self._logging_in or not self.session_restored:
                return False
            return _is_auth_failure(err)

        try:
            data = self.session.post(
                BASE + path, body=json.dumps(body),
                headers={"Content-Type": "application/json",
                         "X-Auth-Token": self.token if (authenticated and self.token) else UNAUTHENTICATED})
        except net.HttpError as err:
            if not _refused(err):
                raise
            diag.log("Move TV: the stored session was refused (%s) — signing in again" % err)
            self.forget_session()
            self.login()
            return self._post(path, body, authenticated, _retried=True)

        try:
            return self._ok(data, path)
        except ProviderError as err:
            # This API also refuses inside a 200 body — see _ok and _is_auth_failure.
            if not _refused(err):
                raise
            diag.log("Move TV: the stored session was refused (%s) — signing in again" % err.message)
            self.forget_session()
            self.login()
            return self._post(path, body, authenticated, _retried=True)

    @staticmethod
    def _ok(data, what):
        """`success:false` inside a 200 is this API's normal way of refusing, and it says why."""
        if not isinstance(data, dict):
            raise ProviderError("Move TV %s: odgovor nije JSON." % what)
        if not data.get("success"):
            raise ProviderError("Move TV %s: %s" % (what, data.get("message") or "success=false"))
        return data

    # ---- auth -------------------------------------------------------------

    def _uid(self):
        """
        A stable per-install client id.

        Minted once and written back, because the account treats a new uid as a NEW DEVICE — a fresh one
        per launch quietly fills the account's device list, which is the same trap EON's device number
        and Yettel's udid exist to avoid.
        """
        uid = self.setting("device_id").strip()
        if not uid:
            uid = str(uuid.uuid4())
            self.remember("device_id", uid)
            diag.log("Move TV: minted a device id for this install (%s…)" % uid[:8])
            return uid
        # A Move uid is a UUID, optionally with a ".<partnerId>" suffix the server appends on
        # registration (e.g. "65ed1b51-…-50cc208fd1b3.2"). It is NOT the numeric device id shown
        # beside it — and that is the mistake this catches, because it does not fail: the server
        # happily accepts any string and registers it as a BRAND NEW DEVICE, silently taking a slot.
        # Seen exactly once, with "6612929" typed in where the uuid belonged.
        if not _UID_SHAPE.match(uid):
            diag.log("Move TV: device id %r does not look like a uuid — if you meant to reuse an "
                     "existing device, this is the wrong value and the account will register a NEW "
                     "one instead of sharing that slot" % uid, "ERROR")
        return uid

    def login(self):
        username = self.setting("username")
        password = self.setting("password")
        if not username or not password:
            raise ProviderError("Move TV: korisničko ime i lozinka nisu uneti.")
        self._logging_in = True
        try:
            self._login_chain(username, password)
        finally:
            self._logging_in = False

    def _login_chain(self, username, password):
        data = self._post("/login", {
            "username": username, "password": password,
            "partnerId": PARTNER_ID, "deviceName": DEVICE_NAME,
            "deviceModelId": DEVICE_MODEL_ID, "uid": self._uid(), "appVersion": APP_VERSION,
        }, authenticated=False)

        self.token = str(data.get("auth_token") or "")
        self.customer = int(data.get("customer_id") or 0)
        # NOT the same number as customer_id, and every catalogue, guide and stream call needs it.
        self.profile = int(((data.get("profile") or {}).get("id")) or 0)
        if not self.token or not self.profile:
            raise ProviderError("Move TV: prijava je prošla ali nije vratila sesiju.")
        # A token this process minted itself. The retry in _post is only for a RESTORED one:
        # if the server refuses a token it handed over seconds ago, that is an answer, not a
        # stale session, and repeating the sign-in would only ask the account twice.
        self.session_restored = False
        diag.log("Move TV: logged in (customer %s, profile %s)" % (self.customer, self.profile))
        self._store_session()

    # ---- the session, kept between processes -------------------------------
    #
    # WHY THIS EXISTS, measured rather than assumed. The owner's log from 2026-08-04 shows four sign-ins
    # inside three minutes — 06:49:14, 06:51:03, 06:52:40, 06:52:45 — one for every screen he opened,
    # because `self.token` lived only in this process and the plugin process dies with the action. Iris
    # and Yettel have kept their sessions on disk for exactly this reason and say "reusing the stored
    # session" in that same log; Move was the one provider still paying the round trip every time. One
    # of those four cost 1418 ms, and that is time in front of a viewer waiting for a picture.
    #
    # It also stops filling the account's device list, which is the trap `_uid` was written to avoid:
    # every sign-in registers a device, and the numeric device id in the answer is the slot it took.

    def _session_path(self):
        # _cache_path, not cache_path: move.py routes every cache file through that one seam (see
        # its definition below), which is also what the tests point somewhere private.
        return self._cache_path(SESSION_CACHE)

    def _account_fingerprint(self):
        """Username only — the password is not needed to tell one subscription from another, and this
        value is written to disk."""
        return hashlib.sha256((self.setting("username") or "").encode("utf-8")).hexdigest()[:16]

    def _load_session(self):
        """Restore a stored session, or answer False. Makes NO network call: whether the session still
        works is what the very next call proves, and probing it would spend the round trip this is here
        to save."""
        data = _read_json(self._session_path())
        if not isinstance(data, dict) or time.time() >= (data.get("expires_at") or 0):
            return False
        # Bound to the account it was minted for: changing the username in settings must not keep
        # playing the previous subscription.
        if data.get("account") != self._account_fingerprint():
            return False
        if not data.get("token") or not data.get("profile") or not data.get("customer"):
            return False
        self.token = str(data["token"])
        self.customer = int(data["customer"])
        self.profile = int(data["profile"])
        self.session_restored = True
        diag.log("Move TV: reusing the stored session (customer %s, profile %s)"
                 % (self.customer, self.profile))
        return True

    def _store_session(self):
        _write_json(self._session_path(), {
            "account": self._account_fingerprint(),
            "expires_at": time.time() + SESSION_MAX_AGE,
            "customer": self.customer,
            "profile": self.profile,
            "token": self.token,
        })

    def forget_session(self):
        """Throw the stored session away. Called when the server refuses one — a stored token that is no
        longer accepted is worse than none, because it is tried first on every process that follows."""
        self.token, self.customer, self.profile = "", 0, 0
        self.session_restored = False
        try:
            os.remove(self._session_path())
        except OSError:
            pass

    def _ensure(self):
        if self.token:
            return
        if self._load_session():
            return
        self.login()

    # ---- catalogue --------------------------------------------------------

    def channels(self):
        self._ensure()
        data = self._post("/content/live/all", {
            "customerId": self.customer, "customerProfileId": self.profile,
            "lang": LANG, "appVersion": APP_VERSION,
        })
        rows = data.get("content") or []
        out, skipped, play_cache = [], 0, {}
        for item in rows:
            if not (item or {}).get("subscribed"):
                # Listing channels the account cannot play only produces rows that refuse to open. The
                # count is logged so "channels are missing" has an answer without a support round-trip.
                skipped += 1
                continue
            entry = self._channel_from(item, len(out) + 1, play_cache)
            if entry:
                out.append(entry)
        if not out:
            raise ProviderError("Move TV: nijedan kanal nije u pretplati (od %d ponuđenih)." % len(rows))
        _write_json(self._cache_path(PLAY_CACHE), play_cache)
        diag.log("Move TV: %d channels (%d not subscribed, skipped)" % (len(out), skipped))
        return out

    def _channel_from(self, item, fallback_number, play_cache):
        content_id = str(item.get("contentId") or "")
        live_id = str(item.get("liveId") or "")
        name = item.get("contentName") or ""
        if not content_id or not live_id or not name:
            return None

        catchup_hours = int((item.get("catchup") or {}).get("duration")
                            or item.get("contentLiveCatchupDuration") or 0)
        categories = item.get("categories") or []
        genre = str((categories[0] or {}).get("name") or "") if categories else ""
        radio = bool(item.get("audioOnly"))
        play_cache[content_id] = {"live_id": live_id, "catchup_hours": catchup_hours}
        return {
            "id": self.scoped("move_%s" % content_id),
            "tvg_id": self.scoped("move_%s" % content_id),
            # The GUIDE's key, not the stream's — see the module docstring on the two ids.
            "provider_ref": content_id,
            "name": name,
            "number": int(item.get("contentPosition") or fallback_number),
            "group": "Radio" if radio else (genre or GROUP_OTHER),
            "radio": radio,
            "logo": _image_url((item.get("picture") or {}).get("icon")),
            "url": ("plugin://plugin.video.iptvbalkan/?action=play&provider=move&id=%s%s"
                    % (content_id, self._account_param())),
            # The provider's OWN window, per channel — 168h is typical, but a channel that reports none
            # gets no Replay button rather than one that fails when pressed.
            #
            # This was hardcoded 0 until 2026-08-03. The window was never the blocker; the per-programme
            # source call was, and it had never appeared in any capture. It was finally caught live at
            # play.move.tv (`/content/epg/source/get`) and `resolve()` mints from it now.
            "catchup_days": max(1, catchup_hours // 24) if catchup_hours else 0,
            # VOD mode, and NOT played as live — the same pair Iris uses, for the same reason. A Move
            # replay resolves to `index-<start>-<duration>.mpd`, a STATIC manifest holding exactly one
            # programme, so the addon is entered once per replay and the player seeks inside the media.
            # Kodi must therefore draw the bar from the manifest, not from its live model.
            #
            # NOTE, because the opposite was briefly believed: this has nothing to do with DRM. EON keeps
            # the PVR overlay because its archive is HLS with a sliding window, which ffmpegdirect can
            # run as a timeshift; Move's static DASH goes to inputstream.adaptive exactly like Iris and
            # inherits the same either/or. See section 10 of IRIS-EON-INTEGRATION.md.
            "catchup_mode": "vod",
            "catchup_play_as_live": False,
            "catchup_source": ("plugin://plugin.video.iptvbalkan/?action=play&provider=move&id=%s%s&utc={utc}"
                               % (content_id, self._account_param())),
            "provider_label": self.label,
        }

    def epg(self, channels, hours_back=24, hours_forward=48):
        """One request per channel — Move TV has no batched guide endpoint, so this is budgeted like
        EON's rather than run to completion."""
        self._ensure()
        budget_until = time.time() + self.settings.get_int("move_epg_budget_sec", 180)
        out, done, failed, first_error = [], 0, 0, ""
        # A refusal that will refuse the next channel too, stopped after three rather than three hundred.
        #
        # The customer's log is the argument: 300 channels, every one answering 401, and the addon asked
        # all 300 anyway — a minute of requests against a real subscription to produce an empty guide,
        # and 65 identical ERROR lines for whoever reads the log afterwards. The EON guide learned this
        # the same way a day earlier. A per-channel failure (one bad id, one odd programme) still just
        # counts and carries on; it is the CONSECUTIVE run that means "asking again cannot help".
        consecutive, renewed = 0, False
        for ch in channels:
            if time.time() > budget_until:
                diag.log("Move TV: guide budget spent after %d/%d channels — the rest follows next "
                         "refresh" % (done, len(channels)))
                break
            # See Provider.stopping.
            if self.stopping():
                diag.log("Move TV: Kodi is closing — the guide stops after %d/%d channels"
                         % (done, len(channels)))
                break
            try:
                out.extend(self._epg_for(ch["provider_ref"], hours_back, hours_forward))
                done += 1
                consecutive = 0
            except (ProviderError, net.HttpError) as err:
                # Counted, not swallowed: a guide that came back empty because every channel failed must
                # not look the same as a provider that simply has no programmes.
                failed += 1
                consecutive += 1
                first_error = first_error or str(err)
                # A cached session outlives its token (Move's own answer says `t: 32400`, nine hours),
                # and the guide is the first thing a scheduled refresh asks for — so the first refusal
                # buys ONE fresh login and one more try. Once only: a login per failed channel would be
                # three hundred sign-ins on an account that counts them.
                if not renewed and _is_auth_failure(err):
                    renewed = True
                    consecutive = 0
                    diag.log("Move TV: the guide was refused (%s) — logging in again and retrying once"
                             % str(err)[:90])
                    try:
                        self.token = ""
                        self.login()
                    except ProviderError as login_error:
                        diag.log("Move TV: the retry login failed too — %s" % login_error, "ERROR")
                        break
                    # THE SAME CHANNEL, not the next one. `continue` here went straight on to the
                    # following channel, so the one whose refusal paid for the fresh login was the
                    # single channel that never got to use it — it stayed without a guide until the
                    # next refresh, while the comment above promised "one more try". Asked again
                    # here, and the failure counted a moment ago is taken back, because it did not
                    # turn out to be one.
                    try:
                        programmes = self._epg_for(ch["provider_ref"], hours_back, hours_forward)
                    except (ProviderError, net.HttpError) as retry_error:
                        diag.log("Move TV: the channel failed again after the fresh login (%s)"
                                 % str(retry_error)[:90])
                        continue
                    failed -= 1
                    out.extend(programmes)
                    done += 1
                    continue
                if consecutive >= 3:
                    diag.log("Move TV: three channels in a row were refused — the guide stops here "
                             "rather than asking %d more times. Last answer: %s"
                             % (max(0, len(channels) - done - failed), str(err)[:120]), "ERROR")
                    break
        if failed:
            diag.log("Move TV: %d of %d channels had no guide (first: %s)"
                     % (failed, len(channels), first_error), "ERROR")
        diag.log("Move TV: %d programmes over %d channels" % (len(out), done))
        return out

    def _epg_for(self, content_id, hours_back, hours_forward):
        now_ms = int(time.time() * 1000)
        data = self._post("/content/epg/all", {
            "customerId": self.customer,
            # THE FIELD WHOSE ABSENCE ANSWERED 401, AND THE REASON THIS PROVIDER SHIPPED WITH NO GUIDE.
            #
            # Read off a customer's log on 2026-08-01 (serial 4012, a real Move subscription): the same
            # token, the same headers, seconds apart — `/content/live/all` answered 200 with 300
            # channels and `/content/epg/all` answered `401 Unauthorized` three hundred times. The only
            # difference between the two requests was this line.
            #
            # It was not guesswork that was missing, it was reading our own note: login() says, in the
            # comment above `self.profile`, that "every catalogue, guide and stream call needs it" — and
            # the Android client this was ported from says the same thing in its own docstring while its
            # `getEpg` quietly omits it. The port copied the code and not the sentence. Neither side had
            # ever run against a Move account, so nothing contradicted it until a customer did.
            "customerProfileId": self.profile,
            "partnerId": PARTNER_ID,
            "contentId": int(content_id), "time": now_ms,
            # The window is expressed in HOURS either side of an anchor, not as absolute bounds.
            "backwards": max(0, min(24 * 14, int(hours_back))),
            "forwards": max(0, min(24 * 14, int(hours_forward))),
            "appVersion": APP_VERSION,
        })
        out = []
        for row in data.get("content") or []:
            # MILLISECONDS here. Kaltura's are seconds — an easy mix-up between providers, and one that
            # puts the whole guide in 1970.
            start = int((row or {}).get("start") or 0)
            end = int((row or {}).get("end") or 0)
            title = (row or {}).get("title") or ""
            if start <= 0 or end <= 0 or not title:
                continue
            out.append({
                "channel_id": self.scoped("move_%s" % content_id),
                "start": _xmltv(start),
                "stop": _xmltv(end),
                "title": title,
                "desc": row.get("epgDesc") or "",
            })
        return out

    # ---- playback ---------------------------------------------------------

    def _cache_path(self, name):
        return self.cache_path(name)

    def _live_id(self, content_id):
        entry = _read_json(self._cache_path(PLAY_CACHE)).get(str(content_id)) or {}
        live_id = str(entry.get("live_id") or "")
        if live_id:
            return live_id
        # A channel added since the last refresh: fetch the list once rather than refusing to play.
        self.channels()
        entry = _read_json(self._cache_path(PLAY_CACHE)).get(str(content_id)) or {}
        return str(entry.get("live_id") or "")

    def _epg_id_at(self, content_id, at_utc):
        """The provider's `epgId` for whatever aired on [content_id] at [at_utc] (seconds).

        Asked fresh rather than cached with the guide. The guide on disk can be days old and the id has
        to be right for the ONE programme being replayed; one extra POST at the start of a replay is
        cheaper than a wrong id, and far cheaper than a stale cache that fails only for old programmes.
        """
        at_ms = int(at_utc) * 1000
        now_ms = int(time.time() * 1000)
        # Anchor the window on NOW (the API takes hours either side of an anchor, not absolute bounds)
        # and reach back far enough to cover the requested instant, with an hour of slack each way.
        back_h = max(1, int((now_ms - at_ms) / 3600000.0) + 1)
        data = self._post("/content/epg/all", {
            "customerId": self.customer, "customerProfileId": self.profile,
            "partnerId": PARTNER_ID, "contentId": int(content_id), "time": now_ms,
            "backwards": min(24 * 14, back_h), "forwards": 1, "appVersion": APP_VERSION,
        })
        # COMPARED IN SECONDS, deliberately. IPTV Simple substitutes {utc} with whole seconds while
        # this guide is in milliseconds, so a programme whose start carries a millisecond remainder
        # (…7350) sits just ABOVE the truncated instant and `start <= at_ms` misses it by a fraction of
        # a second — refusing a replay of exactly the programme the user picked from the guide. Rounding
        # both sides down to seconds makes the boundary behave the way both ends already assume.
        at_s = int(at_utc)
        for row in data.get("content") or []:
            start = int((row or {}).get("start") or 0)
            end = int((row or {}).get("end") or 0)
            epg_id = (row or {}).get("epgId")
            # A boundary instant belongs to the programme STARTING there — what IPTV Simple sends when
            # the user picks a programme rather than scrubbing to an arbitrary point.
            if epg_id and (start // 1000) <= at_s < (end // 1000):
                return str(epg_id)
        return None

    def resolve(self, channel_ref, at_utc=None, vod=False):
        self._ensure()
        if vod:
            return self._resolve_vod(channel_ref)
        live_id = self._live_id(channel_ref)
        if not live_id:
            raise ProviderError("Move TV: taj kanal nije u listi — osveži listu kanala pa probaj ponovo.")

        if at_utc:
            # REPLAY. Note the id: the per-programme call wants the channel's `contentId` (which is what
            # `channel_ref` is), NOT the `liveId` the live call above wants. This API uses two different
            # ids for the same channel depending on the call — the trap it sets most reliably.
            epg_id = self._epg_id_at(channel_ref, at_utc)
            if not epg_id:
                raise ProviderError("Move TV: za taj termin nema emisije u programu — arhiva ga ne pokriva.")
            data = self._post("/content/epg/source/get", {
                "customerId": self.customer, "customerProfileId": self.profile,
                "epgId": int(epg_id), "contentId": int(channel_ref),
                "dtype": DTYPE_DASH, "appVersion": APP_VERSION,
            })
            diag.log("Move TV: replay %s at %s -> epgId %s"
                     % (channel_ref, time.strftime("%Y-%m-%d %H:%M", time.localtime(int(at_utc))), epg_id))
        else:
            data = self._post("/content/live/source/get", {
                "customerId": self.customer, "customerProfileId": self.profile,
                "liveId": int(live_id), "dtype": DTYPE_DASH, "appVersion": APP_VERSION,
            })
        manifest = str(data.get("content_url") or "")
        play_auth = str((data.get("protection") or {}).get("headerValue") or "")
        if not manifest:
            raise ProviderError("Move TV: server nije vratio adresu strima za taj kanal.")
        if not play_auth:
            raise ProviderError("Move TV: server nije vratio %s token za taj kanal." % PLAY_AUTH_HEADER)
        if ((data.get("drm") or {}).get("enabled")):
            # Widevine is advertised account-wide but was never enabled on any channel sampled so far.
            # THE STREAM IS STILL HANDED OVER, deliberately: this flag has never been seen true, so
            # refusing on it would be refusing on a guess, and if the X-Play-Auth scheme happens to
            # carry the channel anyway the viewer gets a picture instead of a message. What the line
            # below buys is a NAME for the failure when it does come — without it, an encrypted
            # manifest with no licence is indistinguishable from any other playback error in the log.
            # (The comment here used to claim this branch refused. It never did.)
            diag.log("Move TV: channel %s reports drm.enabled — this build only handles the %s scheme, "
                     "playback will probably fail" % (channel_ref, PLAY_AUTH_HEADER), "ERROR")

        expires = _PLAY_AUTH_EXPIRY.search(play_auth)
        if expires:
            # Date included on purpose: these tokens last about 24 hours, so a time-only stamp
            # showed the SAME clock time it was minted at and looked expired on arrival.
            diag.log("Move TV: play token for %s valid until %s"
                     % (channel_ref,
                        time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(int(expires.group(1))))))

        headers = dict(self.session.headers_for())
        # On the manifest AND on every segment — that is the whole point of returning it here rather
        # than folding it into the URL.
        headers[PLAY_AUTH_HEADER] = play_auth
        return {
            "url": manifest, "manifest_type": "mpd", "headers": headers,
            # NOT a sliding window. A Move replay is a static manifest of the whole programme, so it
            # goes to inputstream.adaptive and is seeked inside; ffmpegdirect's timeshift mode cannot
            # open it at all. See the note in default.py.
            "timeshift": False,
        }

    # ---- Video klub -------------------------------------------------------

    def vod(self, node=None):
        """
        The Video klub, as a three-level tree: catalogues -> titles -> (for a series) episodes.

        Node scheme, chosen so nothing has to be looked up again on the way back down:

            None              the 36 catalogues from /content/vod/filters
            cat:<catalogId>   one catalogue, paged
            ser:<contentId>   one series' episodes

        Item ids follow the same idea. A film is its own `contentId` and needs the detail call to
        learn its `vodId`; an EPISODE is `vid:<vodId>` because it already knows one — see the note in
        _resolve_vod on why episodes cannot be keyed by contentId.
        """
        self._ensure()
        if not node:
            return self._vod_catalogs()
        if node.startswith("cat:"):
            return self._vod_titles(node[4:])
        if node.startswith("ser:"):
            return self._vod_episodes(node[4:])
        return []

    def _vod_catalogs(self):
        data = self._post("/content/vod/filters", {
            "customerProfileId": self.profile, "lang": LANG, "appVersion": APP_VERSION,
        })
        content = data.get("content") or {}
        out = []
        for cat in content.get("catalogs") or []:
            cid = (cat or {}).get("catalogId")
            name = (cat or {}).get("name")
            if cid and name:
                out.append({"kind": "dir", "name": name, "node": "cat:%s" % cid})
        diag.log("Move TV: Video klub — %d catalogues" % len(out))
        return out

    def _vod_titles(self, catalog_id):
        out, page, pages = [], 1, 0
        while page and pages < VOD_MAX_PAGES:
            data = self._post("/content/vod/get/all", {
                "customerProfileId": self.profile, "lang": LANG, "page": page,
                "sort": "newest", "catalogId": int(catalog_id), "appVersion": APP_VERSION,
            })
            for item in data.get("content") or []:
                entry = self._vod_entry(item)
                if entry:
                    out.append(entry)
            page = data.get("nextPage") or 0
            pages += 1
        return out

    def _vod_entry(self, item):
        item = item or {}
        if not item.get("subscribed", True):
            return None
        content_id = str(item.get("contentId") or "")
        title = item.get("title") or ""
        if not content_id or not title:
            return None
        picture = item.get("picture") or {}
        # A series is a DIRECTORY: it is opened, never played. contentSubTypeId 5 = Serija.
        if int(item.get("contentSubTypeId") or TYPE_FILM) == TYPE_SERIES:
            return {"kind": "dir", "name": title, "node": "ser:%s" % content_id,
                    "logo": _image_url(picture.get("poster"))}
        return {"kind": "item", "name": title, "id": content_id,
                "logo": _image_url(picture.get("poster")),
                "year": int(item.get("vodYear") or 0) or None}

    def _vod_episodes(self, content_id):
        """
        Episodes of a series — from the SAME /content/vod/get the detail call makes.

        There is no per-series endpoint and no component walk; a captured series page issued neither
        /content/page/get nor /content/component/get. The response carries the series' own fields at
        the top level and EVERY EPISODE in `content`.
        """
        data = self._post("/content/vod/get", {
            "customerProfileId": self.profile, "lang": LANG,
            "contentId": int(content_id), "appVersion": APP_VERSION,
        })
        out = []
        for ep in data.get("content") or []:
            ep = ep or {}
            vod_id = str(ep.get("vodId") or "")
            if not vod_id:
                continue
            season = int(ep.get("season") or 0)
            episode = int(ep.get("episode") or 0)
            # Every episode repeats the SERIES title, so a bare title is unusable as a row label —
            # the S/E prefix is what makes the list readable at all.
            label = ep.get("title") or content_id
            if season or episode:
                label = "S%02dE%02d  %s" % (season, episode, label)
            out.append({
                "kind": "item", "name": label,
                # vid: because contentId is the SERIES for every one of these — see _resolve_vod.
                "id": "vid:%s" % vod_id,
                "logo": _image_url((ep.get("picture") or {}).get("poster")),
                "plot": ep.get("description") or "",
                "duration": int(ep.get("duration") or 0) or None,
                "year": int(ep.get("year") or 0) or None,
            })
        diag.log("Move TV: series %s -> %d episode(s)" % (content_id, len(out)))
        return out

    def _resolve_vod(self, ref):
        """
        Plays one Video klub title.

        TWO IDS AGAIN, and this time the trap is worse than for channels: every episode of a series
        carries the SERIES' contentId, so contentId identifies a series and never an episode. `vodId`
        is the only thing that tells two episodes apart, which is why episode refs arrive here already
        carrying one ("vid:<vodId>") and skip the detail call.

        WHAT PROTECTS THE STREAM — both at once, and each fails looking like the other:
          * Widevine via EZDRM (`drm.server_url`, keyed on `drm.user_id`) — without it, encrypted
            media and no licence.
          * The X-Play-Auth token on manifest AND segments — without it the CDN 403s the media first,
            so it fails BEFORE DRM matters and reads as a dead link.
        Live and catch-up have neither; this is the only Move surface that carries both.
        """
        if ref.startswith("vid:"):
            vod_id, type_id = ref[4:], TYPE_SERIES
        else:
            detail = self._post("/content/vod/get", {
                "customerProfileId": self.profile, "lang": LANG,
                "contentId": int(ref), "appVersion": APP_VERSION,
            })
            # For a film `content` holds exactly one entry — itself.
            items = detail.get("content") or []
            first = (items[0] if items else {}) or {}
            vod_id = str(first.get("vodId") or "")
            type_id = int(detail.get("contentSubTypeId") or first.get("contentTypeId") or TYPE_FILM)
            if not vod_id:
                raise ProviderError("Move TV: taj naslov nema stream (vodId nije vracen).")

        data = self._post("/content/vod/source/get", {
            "customerId": self.customer, "customerProfileId": self.profile,
            "vodId": int(vod_id), "contentTypeId": type_id,
            "dtype": DTYPE_DASH, "appVersion": APP_VERSION,
        })
        manifest = str(data.get("content_url") or "")
        play_auth = str((data.get("protection") or {}).get("headerValue") or "")
        if not manifest:
            raise ProviderError("Move TV: server nije vratio adresu strima za taj naslov.")
        if not play_auth:
            raise ProviderError("Move TV: server nije vratio %s token za taj naslov." % PLAY_AUTH_HEADER)

        headers = dict(self.session.headers_for())
        headers[PLAY_AUTH_HEADER] = play_auth
        resolved = {"url": manifest, "manifest_type": "mpd", "headers": headers}

        drm = data.get("drm") or {}
        if drm.get("enabled"):
            licence = str(drm.get("server_url") or "")
            user_id = str(drm.get("user_id") or "")
            if licence:
                resolved["license_type"] = "com.widevine.alpha"
                # inputstream.adaptive's key is `url|request headers|request body|response`. EZDRM keys
                # the licence on user_id, so it rides in the request headers half.
                resolved["license_key"] = "%s|%s|R{SSM}|" % (
                    licence,
                    "&".join(["Content-Type=application/octet-stream"] +
                             (["x-ezdrm-userid=%s" % user_id] if user_id else [])),
                )
                diag.log("Move TV: VOD %s is Widevine (EZDRM)%s"
                         % (vod_id, "" if user_id else " — WITHOUT a user_id, the licence may be refused"))
        return resolved

    # ---- diagnostics ------------------------------------------------------

    def diagnose(self):
        rows = []
        ok, detail = net.probe(self.session, BASE + "/login", method="POST")
        rows.append(("Reachable", ok, detail))
        rows.append(("Credentials", bool(self.setting("username") and self.setting("password")),
                     self.setting("username") or "not set"))
        try:
            self.login()
            rows.append(("Login", True, "customer %s, profile %s" % (self.customer, self.profile)))
        except ProviderError as err:
            rows.append(("Login", False, err.message))
            return rows
        try:
            channels = self.channels()
            rows.append(("Channel list", bool(channels), "%d channels" % len(channels)))
        except Exception as err:                                   # noqa: BLE001
            rows.append(("Channel list", False, "%s: %s" % (type(err).__name__, err)))
            return rows

        # AND THEN ACTUALLY RESOLVE ONE, because "Move does not work" has been reported twice
        # against a screen that only ever proved the login. Every other row above can be green
        # while playback is impossible: the channel list comes from one call and the stream from
        # another, and the second is the one that carries the play token and the DRM flag.
        #
        # The first channel, not a random one: it makes two runs comparable, and one resolve is
        # the smallest thing that exercises the whole path a viewer presses play on.
        if channels:
            first = channels[0]
            try:
                stream = self.resolve(first.get("id") or first.get("ref") or "")
                url = (stream or {}).get("url", "") if isinstance(stream, dict) else str(stream)
                rows.append(("Playback", bool(url),
                             "%s -> %s" % (first.get("name") or "?", (url or "no url")[:60])))
            except ProviderError as err:
                # The message is written for the user, so it is worth showing as it is.
                rows.append(("Playback", False, err.message))
            except Exception as err:                               # noqa: BLE001
                rows.append(("Playback", False, "%s: %s" % (type(err).__name__, err)))
        return rows


def _is_auth_failure(err):
    """
    Was this refusal about the SESSION rather than about the request?

    Two shapes mean the same thing here and only one of them is an HTTP status. `net.HttpError` carries
    401/403 plainly; but this API also refuses inside a 200 body (`success:false` with an `appCode`),
    which `_ok` turns into a ProviderError with the message in it — and the message a customer's log
    showed for an expired session was exactly "Unauthorized!". Both are worth one fresh login; neither
    is worth three hundred.
    """
    if isinstance(err, net.HttpError):
        return err.is_auth
    text = str(getattr(err, "message", "") or err).lower()
    return "unauthorized" in text or "401" in text or "token" in text


def _image_url(path):
    path = str(path or "")
    if not path:
        return ""
    return path if path.startswith("http") else (IMAGE_BASE + path)


def _xmltv(value):
    """
    Accepts epoch seconds, epoch millis, or an ISO string — providers are inconsistent about this and a
    guide that silently drops half its programmes is worse than one that guesses sensibly.

    The ISO branch used to slice the string at 19 characters and stamp the result `+0000`, which threw
    the offset away and declared a local time to be UTC: every programme sat an hour or two from where
    it belonged, and a guide wrong by a whole hour looks like a broken provider rather than a formatting
    bug. The offset is now read and applied.
    """
    try:
        number = float(value)
        if number > 1e11:
            number /= 1000.0
        return time.strftime("%Y%m%d%H%M%S +0000", time.gmtime(number))
    except (TypeError, ValueError):
        pass

    text = str(value).strip()
    match = re.match(r"^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2}):(\d{2})"
                     r"(?:\.\d+)?\s*(Z|[+-]\d{2}:?\d{2})?$", text)
    if not match:
        # Unparseable is not a reason to lose the whole guide — the caller drops one programme.
        diag.log("Move TV: unrecognised timestamp %r in the guide" % text[:40])
        return ""
    year, month, day, hour, minute, second = (int(g) for g in match.groups()[:6])
    offset = match.group(7)
    stamp = calendar.timegm((year, month, day, hour, minute, second, 0, 0, 0))
    if offset and offset not in ("Z", "z"):
        sign = 1 if offset[0] == "+" else -1
        offset = offset[1:].replace(":", "")
        stamp -= sign * (int(offset[:2]) * 3600 + int(offset[2:]) * 60)
    return time.strftime("%Y%m%d%H%M%S +0000", time.gmtime(stamp))


def _read_json(path):
    try:
        with open(path, "r", encoding="utf-8") as handle:
            data = json.loads(handle.read())
        return data if isinstance(data, dict) else {}
    except (OSError, IOError, ValueError):
        return {}


def _write_json(path, data):
    """Through store.write_json like every other small file — the rule is newer than this function was."""
    store.write_json(path, data)
